/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.preferences;

import org.eclipse.jdt.ui.PreferenceConstants;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferenceConverter;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.ui.texteditor.AbstractTextEditor;

/**
 * Preference Constants used for the IRL Editor
 * @author lmirguet
 * @version $Revision: 1.1 $
 */
public class JETTemplateEditorPreferenceConstants {

  public static final String JET_EXPRESSION_BACKGROUND_COLOR = "jet_expression_background";
  public static final String JET_DIRECTIVE_BACKGROUND_COLOR = "jet_directive_background";
  public static final String JET_SCRIPTLET_BACKGROUND_COLOR = "jet_scriptlet_background";
  public static final String JET_STRING_OR_COMMENT_BACKGROUND_COLOR = "string_or_comment_background";

  public static final String JAVA_KEYWORD_BOLD = "java_keyword_bold";
  public static final String JET_STRING_BOLD = "jet_string_bold";
  public static final String JET_BRACKET_BOLD = "jet_bracket_bold";
  public static final String DEFAULT_FG_BOLD = "AbstractTextEditor.Color.Foreground_bold";

  public static final String JAVA_KEYWORD_COLOR = "java_keyword";
  public static final String JET_STRING_COLOR = "jet_string";
  public static final String JET_BRACKET_COLOR = "jet_bracket";
  public static final String DEFAULT_FG_COLOR = "AbstractTextEditor.Color.Foreground";

  public static final String LINE_NUMBER = "line_number";
  public static final String AUTO_COMPLETE_ENABLED = "autoCompleteEnable";
  public static final String AUTO_COMPLETE_DELAY = "autoCompleteDelay";
  
  /**
   * Should not be instanciated.
   *
   */
  private JETTemplateEditorPreferenceConstants() {
  }

  /**
   * Initialize with the default values.
   * @param store IPreferenceStore
   */
  public static void initializeDefaultValues(IPreferenceStore store) {

    PreferenceConstants.initializeDefaultValues(store);

    PreferenceConverter.setDefault(store, JET_EXPRESSION_BACKGROUND_COLOR, new RGB(225, 240, 240));
    PreferenceConverter.setDefault(store, JET_DIRECTIVE_BACKGROUND_COLOR, new RGB(230, 230, 230));
    PreferenceConverter.setDefault(store, JET_SCRIPTLET_BACKGROUND_COLOR, new RGB(230, 230, 230));
    PreferenceConverter.setDefault(store, JET_STRING_OR_COMMENT_BACKGROUND_COLOR, PreferenceConverter.getDefaultColor(
        store, AbstractTextEditor.PREFERENCE_COLOR_BACKGROUND));

    PreferenceConverter.setDefault(store, JAVA_KEYWORD_COLOR, PreferenceConverter.getDefaultColor(store,
        PreferenceConstants.EDITOR_JAVA_KEYWORD_COLOR));
    PreferenceConverter.setDefault(store, JET_STRING_COLOR, PreferenceConverter.getDefaultColor(store,
        PreferenceConstants.EDITOR_STRING_COLOR));
    PreferenceConverter.setDefault(store, JET_BRACKET_COLOR, PreferenceConverter.getDefaultColor(store,
        PreferenceConstants.EDITOR_JAVA_KEYWORD_COLOR));
    PreferenceConverter.setDefault(store, DEFAULT_FG_COLOR, PreferenceConverter.getDefaultColor(store,
        AbstractTextEditor.PREFERENCE_COLOR_FOREGROUND));

    
    store.setDefault(JAVA_KEYWORD_BOLD, store.getDefaultBoolean(PreferenceConstants.EDITOR_JAVA_KEYWORD_BOLD));
    store.setDefault(JET_STRING_BOLD, store.getDefaultBoolean(PreferenceConstants.EDITOR_STRING_BOLD));
    store.setDefault(JET_BRACKET_BOLD, store.getDefaultBoolean(PreferenceConstants.EDITOR_JAVA_KEYWORD_BOLD));
    store.setDefault(DEFAULT_FG_BOLD, store.getDefaultBoolean(PreferenceConstants.EDITOR_JAVA_DEFAULT_BOLD));

    store.setDefault(AUTO_COMPLETE_ENABLED, store.getDefaultBoolean(PreferenceConstants.CODEASSIST_AUTOACTIVATION));
    store.setDefault(AUTO_COMPLETE_DELAY, store.getDefaultInt(PreferenceConstants.CODEASSIST_AUTOACTIVATION_DELAY));
  }

}
