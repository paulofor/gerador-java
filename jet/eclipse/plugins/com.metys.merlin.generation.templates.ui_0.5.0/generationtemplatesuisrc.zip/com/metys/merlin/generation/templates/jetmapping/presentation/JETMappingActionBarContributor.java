/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.jetmapping.presentation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.SubProgressMonitor;
import org.eclipse.emf.common.ui.viewer.IViewerProvider;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.edit.domain.EditingDomain;
import org.eclipse.emf.edit.domain.IEditingDomainProvider;
import org.eclipse.emf.edit.ui.action.CreateChildAction;
import org.eclipse.emf.edit.ui.action.CreateSiblingAction;
import org.eclipse.emf.edit.ui.action.EditingDomainActionBarContributor;
import org.eclipse.emf.edit.ui.action.LoadResourceAction;
import org.eclipse.emf.edit.ui.action.ValidateAction;
import org.eclipse.emf.mapping.Mapping;
import org.eclipse.jdt.internal.ui.JavaPlugin;
import org.eclipse.jdt.internal.ui.javaeditor.JavaSourceViewer;
import org.eclipse.jdt.ui.PreferenceConstants;
import org.eclipse.jdt.ui.text.JavaSourceViewerConfiguration;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.ActionContributionItem;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.action.IContributionItem;
import org.eclipse.jface.action.IContributionManager;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.action.SubContributionItem;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.text.Document;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.source.SourceViewer;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IEditorDescriptor;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.actions.WorkspaceModifyOperation;
import org.eclipse.ui.editors.text.EditorsUI;
import org.eclipse.ui.editors.text.TextSourceViewerConfiguration;
import org.eclipse.ui.part.FileEditorInput;

import com.metys.merlin.generation.templates.JETTemplate;
import com.metys.merlin.generation.templates.JavaJETTemplate;
import com.metys.merlin.generation.templates.TextJETTemplate;
import com.metys.merlin.generation.templates.jetmapping.JETMappingFactory;
import com.metys.merlin.generation.templates.jetmapping.JETMappingGenerator;
import com.metys.merlin.generation.templates.jetmapping.JETTemplateMappingRoot;
import com.metys.merlin.generation.templates.provider.JETTemplatesUIPlugin;

/**
 * This is the action bar contributor for the JETMapping model editor.
 * <!-- begin-user-doc --> <!-- end-user-doc -->
 * @generated
 */
public class JETMappingActionBarContributor extends EditingDomainActionBarContributor implements
    ISelectionChangedListener {
	/**
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
  public static final String copyright = "(c) 2005 Jo�l Cheuoua & Contributors";

	/**
	 * This keeps track of the active editor.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
  protected IEditorPart activeEditorPart;

	/**
	 * This keeps track of the current selection provider.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
  protected ISelectionProvider selectionProvider;

	/**
	 * This action opens the Properties view.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
  protected IAction showPropertiesViewAction =
		new Action(JETTemplatesUIPlugin.INSTANCE.getString("_UI_ShowPropertiesView_menu_item")) {
			public void run() {
				try {
					getPage().showView("org.eclipse.ui.views.PropertySheet");
				}
				catch (PartInitException exception) {
					JETTemplatesUIPlugin.INSTANCE.log(exception);
				}
			}
		};

	/**
	 * This action refreshes the viewer of the current editor if the editor
	 * implements {@link org.eclipse.emf.common.ui.viewer.IViewerProvider}.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
  protected IAction refreshViewerAction =
		new Action(JETTemplatesUIPlugin.INSTANCE.getString("_UI_RefreshViewer_menu_item")) {
			public boolean isEnabled() {
				return activeEditorPart instanceof IViewerProvider;
			}

			public void run() {
				if (activeEditorPart instanceof IViewerProvider) {
					Viewer viewer = ((IViewerProvider)activeEditorPart).getViewer();
					if (viewer != null) {
						viewer.refresh();
					}
				}
			}
		};

	/**
	 * This will contain one {@link org.eclipse.emf.edit.ui.action.CreateChildAction} corresponding to each descriptor
	 * generated for the current selection by the item provider.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
  protected Collection createChildActions;

  /**
   * This is the menu manager into which menu contribution items should be added for CreateChild actions. <!--
   * begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  protected IMenuManager createChildMenuManager;

	/**
	 * This will contain one {@link org.eclipse.emf.edit.ui.action.CreateSiblingAction} corresponding to each descriptor
	 * generated for the current selection by the item provider.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
  protected Collection createSiblingActions;

  /**
   * This is the menu manager into which menu contribution items should be added for CreateSibling actions. <!--
   * begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  protected IMenuManager createSiblingMenuManager;

  protected GenerateAction generateAction;

  protected OpenTemplateFileAction openTemplateFileAction;
  
  protected Collection openPreviewViewerActions;
  protected IMenuManager openPreviewViewerMenuManager;
  
  /**
   * This creates an instance of the contributor. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated NOT
   */
  public JETMappingActionBarContributor() {
    loadResourceAction = new LoadResourceAction();
    validateAction = new ValidateAction();
    generateAction = new GenerateAction();
    openTemplateFileAction = new OpenTemplateFileAction();
  }

	/**
	 * This adds Separators for editor additions to the tool bar.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
  public void contributeToToolBar(IToolBarManager toolBarManager) {
		toolBarManager.add(new Separator("jetmapping-settings"));
		toolBarManager.add(new Separator("jetmapping-additions"));
	}

  /**
   * This adds to the menu bar a menu and some separators for editor additions, as well as the sub-menus for object
   * creation items. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated NOT
   */
  public void contributeToMenu(IMenuManager menuManager) {
    super.contributeToMenu(menuManager);

    IMenuManager submenuManager = new MenuManager(JETTemplatesUIPlugin.INSTANCE.getString("_UI_JETMappingEditor_menu"),
        "com.metys.merlin.generation.templates.jetmappingMenuID");
    menuManager.insertAfter("additions", submenuManager);
    submenuManager.add(new Separator("settings"));
    submenuManager.add(new Separator("actions"));
    submenuManager.add(new Separator("additions"));
    submenuManager.add(new Separator("additions-end"));

    // Prepare for CreateChild item addition or removal.
    //
    createChildMenuManager = new MenuManager(JETTemplatesUIPlugin.INSTANCE.getString("_UI_CreateChild_menu_item"));
    submenuManager.insertBefore("additions", createChildMenuManager);

    // Prepare for CreateSibling item addition or removal.
    //
    createSiblingMenuManager = new MenuManager(JETTemplatesUIPlugin.INSTANCE.getString("_UI_CreateSibling_menu_item"));
    submenuManager.insertBefore("additions", createSiblingMenuManager);

    openPreviewViewerMenuManager = new MenuManager("Preview");
    submenuManager.insertBefore("actions", openPreviewViewerMenuManager);
    
    // Force an update because Eclipse hides empty menus now.
    //
    submenuManager.addMenuListener(new IMenuListener() {
      public void menuAboutToShow(IMenuManager menuManager) {
        menuManager.updateAll(true);
      }
    });

    addGlobalActions(submenuManager);
  }

  /**
   * When the active editor changes, this remembers the change and registers with it as a selection provider. <!--
   * begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   * @param part
   *          IEditorPart
   * @see org.eclipse.ui.IEditorActionBarContributor#setActiveEditor(IEditorPart)
   */
  public void setActiveEditor(IEditorPart part) {
		super.setActiveEditor(part);
		activeEditorPart = part;

		// Switch to the new selection provider.
		//
		if (selectionProvider != null) {
			selectionProvider.removeSelectionChangedListener(this);
		}
		if (part == null) {
			selectionProvider = null;
		}
		else {
			selectionProvider = part.getSite().getSelectionProvider();
			selectionProvider.addSelectionChangedListener(this);

			// Fake a selection changed event to update the menus.
			//
			if (selectionProvider.getSelection() != null) {
				selectionChanged(new SelectionChangedEvent(selectionProvider, selectionProvider.getSelection()));
			}
		}
	}

  /**
   * This implements {@link org.eclipse.jface.viewers.ISelectionChangedListener}, handling
   * {@link org.eclipse.jface.viewers.SelectionChangedEvent}s by querying for the children and siblings that can be
   * added to the selected object and updating the menus accordingly. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated NOT
   */
  public void selectionChanged(SelectionChangedEvent event) {
    // Remove any menu items for old selection.
    //
    if (createChildMenuManager != null) {
      depopulateManager(createChildMenuManager, createChildActions);
    }
    if (createSiblingMenuManager != null) {
      depopulateManager(createSiblingMenuManager, createSiblingActions);
    }
    if (openPreviewViewerMenuManager != null) {
      depopulateManager(openPreviewViewerMenuManager, openPreviewViewerActions);      
    }

    // Query the new selection for appropriate new child/sibling descriptors
    //
    Collection newChildDescriptors = null;
    Collection newSiblingDescriptors = null;

    ISelection selection = event.getSelection();
    if (selection instanceof IStructuredSelection && ((IStructuredSelection) selection).size() == 1) {
      Object object = ((IStructuredSelection) selection).getFirstElement();

      EditingDomain domain = ((IEditingDomainProvider) activeEditorPart).getEditingDomain();

      newChildDescriptors = domain.getNewChildDescriptors(object, null);
      newSiblingDescriptors = domain.getNewChildDescriptors(null, object);
    }

    // Generate actions for selection; populate and redraw the menus.
    //
    createChildActions = generateCreateChildActions(newChildDescriptors, selection);
    createSiblingActions = generateCreateSiblingActions(newSiblingDescriptors, selection);
    openPreviewViewerActions = generatePreviewViewerActions(selection);
    
    if (createChildMenuManager != null) {
      populateManager(createChildMenuManager, createChildActions, null);
      createChildMenuManager.update(true);
    }
    if (createSiblingMenuManager != null) {
      populateManager(createSiblingMenuManager, createSiblingActions, null);
      createSiblingMenuManager.update(true);
    }
    if (openPreviewViewerMenuManager != null) {
      populateManager(openPreviewViewerMenuManager, openPreviewViewerActions, null);
      openPreviewViewerMenuManager.update(true);
    }
  }

  /**
   * This generates a {@link org.eclipse.emf.edit.ui.action.CreateChildAction} for each object in
   * <code>descriptors</code>, and returns the collection of these actions. <!-- begin-user-doc --> <!-- end-user-doc
   * -->
   * 
   * @generated
   */
  protected Collection generateCreateChildActions(Collection descriptors, ISelection selection) {
		Collection actions = new ArrayList();
		if (descriptors != null) {
			for (Iterator i = descriptors.iterator(); i.hasNext(); ) {
				actions.add(new CreateChildAction(activeEditorPart, selection, i.next()));
			}
		}
		return actions;
	}

  /**
   * This generates a {@link org.eclipse.emf.edit.ui.action.CreateSiblingAction} for each object in
   * <code>descriptors</code>, and returns the collection of these actions. <!-- begin-user-doc --> <!-- end-user-doc
   * -->
   * 
   * @generated
   */
  protected Collection generateCreateSiblingActions(Collection descriptors, ISelection selection) {
		Collection actions = new ArrayList();
		if (descriptors != null) {
			for (Iterator i = descriptors.iterator(); i.hasNext(); ) {
				actions.add(new CreateSiblingAction(activeEditorPart, selection, i.next()));
			}
		}
		return actions;
	}

  protected Collection generatePreviewViewerActions(ISelection selection) {
    if (!(selection instanceof IStructuredSelection) ||
        ((IStructuredSelection)selection).size() != 1)
      return Collections.EMPTY_LIST;
    IStructuredSelection ss = (IStructuredSelection) selection;
    
    JETMappingEditor editor = (JETMappingEditor) activeEditorPart;
    JETTemplateMappingRoot mappingRoot = (JETTemplateMappingRoot) editor.getMappingDomain().getMappingRoot();
    
    Collection selectionMappings = null;

    if (ss.getFirstElement() instanceof Mapping) {
      selectionMappings = new ArrayList();
      selectionMappings.add(ss.getFirstElement());
    }
    else {
      selectionMappings = mappingRoot.getMappings(ss.getFirstElement());
    }
    
    Collection results = new ArrayList();
    for (Iterator iter = selectionMappings.iterator(); iter.hasNext();) {
      Mapping mapping = (Mapping) iter.next();
      for (Iterator inputs = mapping.getInputs().iterator(); inputs.hasNext();) {
        Object input = (Object) inputs.next();
        for (Iterator outputs = mapping.getOutputs().iterator(); outputs.hasNext();) {
          Object output = (Object) outputs.next();
          if (input instanceof EObject &&
              (output instanceof JavaJETTemplate || output instanceof TextJETTemplate)) {
            EObject generatedObject = (EObject) input;
            JETTemplate jetTemplate = (JETTemplate) output;
            IPath templateFilePath = Path.fromPortableString(jetTemplate.getTemplateFilePath());
            IPath containerPath = jetTemplate.getTemplateContainer() == null ? null : jetTemplate.getTemplateContainer().getContainerPath();
            if (templateFilePath.getDevice() != null)
              containerPath = null;
            IPath resourcePath = containerPath == null ? templateFilePath : containerPath.append(templateFilePath);
            String location = null;
            IResource jetResource = null;
            if (resourcePath.getDevice() != null) {
              location = resourcePath.toString();
            } else {
              jetResource = ResourcesPlugin.getWorkspace().getRoot().findMember(resourcePath);
              if (jetResource == null || !jetResource.exists())
                jetResource = ResourcesPlugin.getWorkspace().getRoot().findMember(templateFilePath);
              if (jetResource != null && jetResource.exists())
                location = jetResource.getLocation().toString();
            }
            if (location != null) {
              OpenPreviewViewerAction action = new OpenPreviewViewerAction(location, generatedObject, jetTemplate, jetResource);
              results.add(action);
            }
          }
        }
      }      
    }    
    return results;
  }
	/**
	 * This populates the specified <code>manager</code> with {@link org.eclipse.jface.action.ActionContributionItem}s
	 * based on the {@link org.eclipse.jface.action.IAction}s contained in the <code>actions</code> collection,
	 * by inserting them before the specified contribution item <code>contributionID</code>.
	 * If <code>ID</code> is <code>null</code>, they are simply added.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
  protected void populateManager(IContributionManager manager, Collection actions, String contributionID) {
		if (actions != null) {
			for (Iterator i = actions.iterator(); i.hasNext(); ) {
				IAction action = (IAction)i.next();
				if (contributionID != null) {
					manager.insertBefore(contributionID, action);
				}
				else {
					manager.add(action);
				}
			}
		}
	}
		
  /**
   * This removes from the specified <code>manager</code> all {@link org.eclipse.jface.action.ActionContributionItem}s
   * based on the {@link org.eclipse.jface.action.IAction}s contained in the <code>actions</code> collection. <!--
   * begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  protected void depopulateManager(IContributionManager manager, Collection actions) {
		if (actions != null) {
			IContributionItem[] items = manager.getItems();
			for (int i = 0; i < items.length; i++) {
				// Look into SubContributionItems
				//
				IContributionItem contributionItem = items[i];
				while (contributionItem instanceof SubContributionItem) {
					contributionItem = ((SubContributionItem)contributionItem).getInnerItem();
				}

				// Delete the ActionContributionItems with matching action.
				//
				if (contributionItem instanceof ActionContributionItem) {
					IAction action = ((ActionContributionItem)contributionItem).getAction();
					if (actions.contains(action)) {
						manager.remove(contributionItem);
					}
				}
			}
		}
	}

  /**
   * This populates the pop-up menu before it appears. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated NOT
   * @param menuManager
   *          IMenuManager
   * @see org.eclipse.jface.action.IMenuListener#menuAboutToShow(IMenuManager)
   */
  public void menuAboutToShow(IMenuManager menuManager) {
    menuManager.add(new Separator("actions"));
    super.menuAboutToShow(menuManager);
    MenuManager submenuManager = null;

    submenuManager = new MenuManager(JETTemplatesUIPlugin.INSTANCE.getString("_UI_CreateChild_menu_item"));
    populateManager(submenuManager, createChildActions, null);
    menuManager.insertBefore("additions", submenuManager);

    submenuManager = new MenuManager(JETTemplatesUIPlugin.INSTANCE.getString("_UI_CreateSibling_menu_item"));
    populateManager(submenuManager, createSiblingActions, null);
    menuManager.insertBefore("additions", submenuManager);

    submenuManager = new MenuManager("Preview");
    populateManager(submenuManager, openPreviewViewerActions, null);
    menuManager.insertBefore("actions", submenuManager);
    
    ISelection s = ((JETMappingEditor) activeEditorPart).getSelection();
    if ((s instanceof IStructuredSelection)) {
      IStructuredSelection ss = (IStructuredSelection) s;
      if (ss.size() > 0) {
        boolean canAllGenerate = true;
        for (Iterator iter = ss.iterator(); iter.hasNext();) {
          Object selected = iter.next();
          if (!(selected instanceof EObject) || 
              selected instanceof JETTemplate ||
              selected instanceof Mapping) {
            canAllGenerate = false;
            break;
          }
        }
        if (canAllGenerate) {
          menuManager.insertBefore("actions", generateAction);
          generateAction.setEnabled(generateAction.isEnabled());
        }
        if (ss.size() == 1 && ss.getFirstElement() instanceof JETTemplate) {
          menuManager.insertBefore("actions", openTemplateFileAction);
          openTemplateFileAction.setEnabled(openTemplateFileAction.isEnabled());
        }        
      }
    }    
  }

	/**
	 * This inserts global actions before the "additions-end" separator.
	 * <!-- begin-user-doc --> <!-- end-user-doc -->
	 * @generated
	 */
  protected void addGlobalActions(IMenuManager menuManager) {
		menuManager.insertAfter("additions-end", new Separator("ui-actions"));
		menuManager.insertAfter("ui-actions", showPropertiesViewAction);

		refreshViewerAction.setEnabled(refreshViewerAction.isEnabled());		
		menuManager.insertAfter("ui-actions", refreshViewerAction);

		super.addGlobalActions(menuManager);
	}

  public String getEObjectName(EObject eObject) {
    JETMappingEditor editor = (JETMappingEditor) activeEditorPart;
    return editor.getMappingDomain().getName(eObject); 
  }
  
  public class OpenPreviewViewerAction extends Action {

    private JETMappingGenerator generator;
    String location;
    EObject generatedObject;
    JETTemplate jetTemplate;
    IResource jetResource;
    
    public OpenPreviewViewerAction(String location, EObject object, JETTemplate template, IResource resource) {
      this.location = location;
      generatedObject = object;
      jetTemplate = template;
      jetResource = resource;
      setText(JETTemplatesUIPlugin.INSTANCE.getString("_UI_OpenPreviewViewerAction_label", new Object[]{getEObjectName(object), getEObjectName(template)}));
    }
    
    /**
     * Method isEnabled.
     * 
     * @return boolean
     * @see org.eclipse.jface.action.IAction#isEnabled()
     */
    public boolean isEnabled() {
      if (location != null &&
          (jetTemplate instanceof JavaJETTemplate || jetTemplate instanceof TextJETTemplate) &&
          (generatedObject != null))
        return true;
      return false;
    }

    /**
     * Method run.
     * 
     * @see org.eclipse.jface.action.IAction#run()
     */
    public void run() {
      JETMappingEditor editor = (JETMappingEditor) activeEditorPart;

      JETTemplateMappingRoot mappingRoot = (JETTemplateMappingRoot) editor.getMappingDomain().getMappingRoot();
      generator = JETMappingFactory.eINSTANCE.createJETMappingGenerator();
      generator.setMappingRoot(mappingRoot);
      
      class MyDialog extends Dialog {
        public MyDialog(Shell shell) {
          super(shell);
          setShellStyle(getShellStyle() | SWT.RESIZE);
        }
        
        /*
         * @see org.eclipse.jface.window.Window#configureShell(org.eclipse.swt.widgets.Shell)
         */
        protected void configureShell(Shell newShell) {
          super.configureShell(newShell);
          newShell.setText("JET Template Mapping Preview");
        }
        
        protected void createButtonsForButtonBar(Composite parent) {
            // create OK button only by default
            createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL,true);            
        }

        /*
         * @see org.eclipse.jface.dialogs.Dialog#createDialogArea(org.eclipse.swt.widgets.Composite)
         */
        protected Control createDialogArea(Composite parent) {
          Composite composite = new Composite(parent, SWT.NULL);
          GridLayout layout = new GridLayout();
          layout.numColumns = 2;
          layout.marginWidth = layout.marginHeight = 9;
          composite.setLayout(layout);
          GridData gd = new GridData(GridData.FILL_BOTH);
          composite.setLayoutData(gd);
          
          generator.resetClassLoader(generatedObject, jetResource, jetTemplate.getTemplateContainer());
          if (jetTemplate instanceof JavaJETTemplate) {
            String string = generator.generateJava(generatedObject, location, null, null, new NullProgressMonitor());            
            IPreferenceStore store= JavaPlugin.getDefault().getCombinedPreferenceStore();
            JavaSourceViewer sourceViewer= new JavaSourceViewer(composite, null, null, false, SWT.H_SCROLL + SWT.V_SCROLL, store);    
            sourceViewer.configure(new JavaSourceViewerConfiguration(JavaPlugin.getDefault().getJavaTextTools().getColorManager(), store, null, null));    
            sourceViewer.getTextWidget().setFont(JFaceResources.getFont(PreferenceConstants.EDITOR_TEXT_FONT));
            sourceViewer.setEditable(false);
            
            if (string != null) {
              IDocument document = new Document(string);
              JavaPlugin.getDefault().getJavaTextTools().setupJavaDocumentPartitioner(document);
              sourceViewer.setInput(document);
            } else {
              IDocument document = new Document("/** Cannot generate preview with the given input ... Consult the logfile for details.*/");
              JavaPlugin.getDefault().getJavaTextTools().setupJavaDocumentPartitioner(document);
              sourceViewer.setInput(document);            
            }
            gd = new GridData(GridData.FILL_BOTH); 
            gd.widthHint = 450;
            gd.heightHint = 400;
            sourceViewer.getControl().setLayoutData(gd);
            
          } else if (jetTemplate instanceof TextJETTemplate){
            String string = generator.generateText(generatedObject, location, null, null, new NullProgressMonitor());            
            IPreferenceStore store= EditorsUI.getPreferenceStore();
            SourceViewer sourceViewer= new SourceViewer(composite,  null, SWT.H_SCROLL + SWT.V_SCROLL);    
            sourceViewer.configure(new TextSourceViewerConfiguration(store));    
            sourceViewer.getTextWidget().setFont(JFaceResources.getFont(PreferenceConstants.EDITOR_TEXT_FONT));
            sourceViewer.setEditable(false);
            
            if (string != null) {
              IDocument document = new Document(string);
              sourceViewer.setInput(document);
            } else {
              IDocument document = new Document("/** Cannot generate preview with the given input ... Consult the logfile for details.*/");
              sourceViewer.setInput(document);            
            }
            gd = new GridData(GridData.FILL_BOTH); 
            gd.widthHint = 450;
            gd.heightHint = 400;
            sourceViewer.getControl().setLayoutData(gd);
          }          
          return composite;
        }
      }
      Dialog dialog = new MyDialog(editor.getSite().getShell());
      dialog.open();
    }
  }

  /**
   */
  public class GenerateAction extends Action {
    private JETMappingGenerator generator;

    public GenerateAction() {
      super(JETTemplatesUIPlugin.INSTANCE.getString("_UI_GenerateAction_label"));
    }

    /**
     * Method isEnabled.
     * 
     * @return boolean
     * @see org.eclipse.jface.action.IAction#isEnabled()
     */
    public boolean isEnabled() {
      JETMappingEditor editor = (JETMappingEditor) activeEditorPart;

      ISelection s = editor.getSelection();
      if (!(s instanceof IStructuredSelection)) {
        return false;
      }

      IStructuredSelection ss = (IStructuredSelection) s;
      if (ss.size() == 0) {
        return false;
      }

      JETTemplateMappingRoot mappingRoot = (JETTemplateMappingRoot) editor.getMappingDomain().getMappingRoot();

      generator = JETMappingFactory.eINSTANCE.createJETMappingGenerator();
      generator.setMappingRoot(mappingRoot);

      for (Iterator iter = ss.iterator(); iter.hasNext();) {
        Object selected = iter.next();
        if (!(selected instanceof EObject) || !generator.canGenerate((EObject) selected)) {
          return false;
        }
      }
      return true;
    }

    /**
     * Method run.
     * 
     * @see org.eclipse.jface.action.IAction#run()
     */
    public void run() {
      // Do the work within an operation because this is a long running activity
      // that modifies the workbench.
      WorkspaceModifyOperation operation = new WorkspaceModifyOperation() {
        // This is the method that gets invoked when the operation runs.
        //
        protected void execute(IProgressMonitor progressMonitor) throws CoreException {
          JETMappingEditor editor = (JETMappingEditor) activeEditorPart;
          Collection selection = ((IStructuredSelection) editor.getSelection()).toList();
          progressMonitor.beginTask("", selection.size());
          try {
            for (Iterator iter = selection.iterator(); iter.hasNext();) {
              EObject generatedObject = (EObject) iter.next();
              generator.generate(generatedObject, new SubProgressMonitor(progressMonitor, 1));
            }
          } catch (Exception exception) {
            JETTemplatesUIPlugin.INSTANCE.log(exception);
          }
          progressMonitor.done();
        }
      };

      // This runs the options, and shows progress.
      // (It appears to be a bad thing to fork this onto another thread.)
      //
      try {
        new ProgressMonitorDialog(activeEditorPart.getSite().getShell()).run(true, false, operation);
      } catch (Exception exception) {
        // Something went wrong that shouldn't.
        //
        JETTemplatesUIPlugin.INSTANCE.log(exception);
      }
    }
  }

  /**
   */
  public class OpenTemplateFileAction extends Action {
    public OpenTemplateFileAction() {
      super(JETTemplatesUIPlugin.INSTANCE.getString("_UI_OpenTemplateFileAction_label"));
    }

    /**
     * Method isEnabled.
     * 
     * @return boolean
     * @see org.eclipse.jface.action.IAction#isEnabled()
     */
    public boolean isEnabled() {
      JETMappingEditor editor = (JETMappingEditor) activeEditorPart;

      ISelection s = editor.getSelection();
      if (!(s instanceof IStructuredSelection)) {
        return false;
      }

      IStructuredSelection ss = (IStructuredSelection) s;
      if (ss.size() != 1) {
        return false;
      }

      Object selected = ss.getFirstElement();
      if (!(selected instanceof JETTemplate))
        return false;
      IResource resource = ResourcesPlugin.getWorkspace().getRoot().findMember(
          ((JETTemplate) selected).getTemplateFilePath());

      if (resource != null && resource.getType() == IResource.FILE) {
        IWorkbenchPage page = editor.getSite().getPage();
        IWorkbenchWindow workbenchWindow = page.getWorkbenchWindow();
        IWorkbench workbench = workbenchWindow.getWorkbench();
        IEditorDescriptor descriptor = workbench.getEditorRegistry()
            .getDefaultEditor(resource.getFullPath().toString());
        return descriptor != null;
      }
      return false;
    }

    /**
     * Method run.
     * 
     * @see org.eclipse.jface.action.IAction#run()
     */
    public void run() {
      JETMappingEditor editor = (JETMappingEditor) activeEditorPart;

      IStructuredSelection ss = (IStructuredSelection) editor.getSelection();
      JETTemplate selected = (JETTemplate) ss.getFirstElement();
      IResource resource = ResourcesPlugin.getWorkspace().getRoot().findMember(selected.getTemplateFilePath());
      IWorkbenchPage page = editor.getSite().getPage();
      IWorkbenchWindow workbenchWindow = page.getWorkbenchWindow();
      IWorkbench workbench = workbenchWindow.getWorkbench();
      // Open an editor on the new file.
      //
      try {
        IEditorDescriptor descriptor = workbench.getEditorRegistry()
            .getDefaultEditor(resource.getFullPath().toString());
        page.openEditor(new FileEditorInput((IFile) resource), descriptor.getId());
      } catch (PartInitException exception) {
        MessageDialog.openError(workbenchWindow.getShell(), JETTemplatesUIPlugin.INSTANCE
            .getString("_UI_OpenEditorError_label"), exception.getMessage());
      }
    }
  }
}