/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.jetmapping.presentation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.mapping.MappingRoot;
import org.eclipse.emf.mapping.action.AddRootBottomAction;
import org.eclipse.emf.mapping.domain.AdapterFactoryMappingDomain;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.dialogs.ResourceSelectionDialog;

import com.metys.merlin.generation.mappingmodel.MappingModelUIPlugin;
import com.metys.merlin.generation.mappingmodel.mapping.Transformer;
import com.metys.merlin.generation.mappingmodel.mapping.MappingFactory;
import com.metys.merlin.generation.mappingmodel.mapping.MappingPackage;
import com.metys.merlin.generation.mappingmodel.mapping.TypeMappingRoot;
import com.metys.merlin.generation.mappingmodel.util.MappingModelUtil;
import com.metys.merlin.generation.templates.presentation.JETTemplateModelWizard;
import com.metys.merlin.generation.templates.provider.JETTemplatesUIPlugin;

/**
 *  
 * @author Jo�l
 * @version $Revision: 1.5 $
 */
public class AddOutputRootAction extends AddRootBottomAction {
  private IFile createdFile;

  private Object[] selectedModels;

  /**
   *  
   */
  public AddOutputRootAction() {
    super();
  }

  /**
   */
  public class OutputModelWizard extends JETTemplateModelWizard {

    /**
     * This is the details page.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     */
    protected GetOrCreateOutputPage getOrCreateOutputPage;

    /**
     * This is the file creation page.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     */
    protected ModelWizardFileSelectionPage fileSelectionPage;

    /**
     * This is the file creation page.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     */
    protected MappingFileSelectionPage mappingFilePage;
    /**
     * Remember the selection during initialization for populating the default container.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     */
    protected IStructuredSelection selection;

    /**
     * Remember the workbench during initialization.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    protected IWorkbench workbench;

    protected static final int EXISTING_JET_TEMPLATES_MODEL = 0;

    protected static final int NEW_JET_TEMPLATES_MODEL_FROM_MAPPINGS = 1;
    
    protected static final int NEW_JET_TEMPLATES_MODEL = 2;

    protected int whichOutput = 0;

    /**
     * Method getNextPage.
     * @param page IWizardPage
     * @return IWizardPage
     * @see org.eclipse.jface.wizard.IWizard#getNextPage(IWizardPage)
     */
    public IWizardPage getNextPage(IWizardPage page) {
      if (page == getOrCreateOutputPage) {
        switch (whichOutput) {
          case NEW_JET_TEMPLATES_MODEL: {
            return newFileCreationPage;
          }
          case NEW_JET_TEMPLATES_MODEL_FROM_MAPPINGS: {
            return mappingFilePage;
          }
          case EXISTING_JET_TEMPLATES_MODEL: {
            return fileSelectionPage;
          }
        }
      } else if (page == fileSelectionPage || page == mappingFilePage) {
        return null;
      }
      return super.getNextPage(page);
    }

    /**
     * The framework calls this to create the contents of the wizard.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated NOT
     * @see org.eclipse.jface.wizard.IWizard#addPages()
     */
    public void addPages() {

      getOrCreateOutputPage = new GetOrCreateOutputPage("GetOrCreateOutputPage");
      getOrCreateOutputPage.setTitle(JETTemplatesUIPlugin.INSTANCE.getString("_UI_OutputDetails_title"));
      getOrCreateOutputPage.setDescription(JETTemplatesUIPlugin.INSTANCE.getString("_UI_OutputDetails_description"));
      addPage(getOrCreateOutputPage);
      
      fileSelectionPage = new ModelWizardFileSelectionPage("ModelWizardFileSelectionPage");
      fileSelectionPage.setTitle(JETTemplatesUIPlugin.INSTANCE.getString("_UI_SelectModelFileWizard_label"));
      fileSelectionPage
          .setDescription(JETTemplatesUIPlugin.INSTANCE.getString("_UI_SelectModelFileWizard_description"));
      addPage(fileSelectionPage);
      
      mappingFilePage = new MappingFileSelectionPage("MappingFileSelectionPage");
      mappingFilePage.setTitle(JETTemplatesUIPlugin.INSTANCE.getString("_UI_SelectMappingFileWizard_label"));
      mappingFilePage
          .setDescription(JETTemplatesUIPlugin.INSTANCE.getString("_UI_SelectMappingFileWizard_description"));
      addPage(mappingFilePage);
      super.addPages();      
    }

    /**
     * Do the work after everything is specified.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     * @return boolean
     * @see org.eclipse.jface.wizard.IWizard#performFinish()
     */
    public boolean performFinish() {
      try {
        createdFile = null;
        selectedModels = null;
        if (whichOutput == NEW_JET_TEMPLATES_MODEL_FROM_MAPPINGS) {
          AdapterFactoryMappingDomain domain = ((JETMappingEditor)workbenchPart).getMappingDomain();
          ResourceSet resourceSet = domain.getResourceSet();
          
          URI mappingResourceURI = URI.createPlatformResourceURI(mappingFilePage.getMappingFile().getFullPath().toString());
          Resource emfMappingFileResource = resourceSet.getResource(mappingResourceURI, true);

          Transformer transformer = MappingFactory.eINSTANCE.createTransformer();

          TypeMappingRoot metaModelMappingRoot = (TypeMappingRoot) emfMappingFileResource.getContents().get(0);    
          
          MappingRoot instanceMappingRoot = domain.getMappingRoot();
          instanceMappingRoot.setTypeMapping(metaModelMappingRoot);
          ArrayList initialModel = new ArrayList();    
          
          transformer.setTypeMappingRoot(metaModelMappingRoot);
          transformer.setMappingRoot(instanceMappingRoot);
          transformer.transform(((JETMappingEditor)workbenchPart).getInputResources(), null, null);
          Collection results = MappingModelUtil.allOutputs(instanceMappingRoot);
          
          for (Iterator it = results.iterator(); it.hasNext();) {
            EObject obj = (EObject) it.next();
            if (obj.eContainer() == null)
              initialModel.add(obj);
          }    
          
          instanceMappingRoot.getOutputs().addAll(initialModel);
          IContainer container = mappingFilePage.getMappingFile().getParent();
          //  create the jettemplates resource
          IFileEditorInput editorInput = (IFileEditorInput) ((IEditorPart)workbenchPart).getEditorInput();
          String jettemplateFileName = editorInput.getFile().getName().replaceAll(".jetmapping",".jettemplate");
          IFile jetTemplateModelFile = container.getFile(new Path(jettemplateFileName));
          URI jetTemplateModelURI = URI.createPlatformResourceURI(jetTemplateModelFile.getFullPath().toString());
          Resource jetTemplateModelResource = resourceSet.createResource(jetTemplateModelURI);
          for (Iterator it = initialModel.iterator(); it.hasNext();) {
            Object rootObject = it.next();
            jetTemplateModelResource.getContents().add(rootObject);
          }
          
          // Save the contents of the resources to the file system.
          //
          Map options = new HashMap();
          options.put(XMLResource.OPTION_ENCODING, "UTF-8");
          try {
            jetTemplateModelResource.save(options);
          } catch (IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
          }
        }
        else if (whichOutput == NEW_JET_TEMPLATES_MODEL) {
          createdFile = getModelFile();
          return super.performFinish(false);          
        }
        selectedModels = getSelectedModels();
        return true;
      } catch (Exception exception) {
        JETTemplatesUIPlugin.INSTANCE.log(exception);
        return false;
      }
    }

    /**
     * A page that allows choosing an existing model in a resource selection
     * @author Jo�l
     * @version $Revision: 1.5 $
     */
    public class ModelWizardFileSelectionPage extends WizardPage {
      protected Text modelFilesLocationText;

      protected boolean isDirty = true;

      protected Object[] selectedModels;

      /**
       * Constructor for ModelWizardFileSelectionPage.
       * @param pageId String
       */
      public ModelWizardFileSelectionPage(String pageId) {
        super(pageId);
        setPageComplete(false);
      }

      /**
       * Method createControl.
       * @param parent Composite
       * @see org.eclipse.jface.dialogs.IDialogPage#createControl(Composite)
       */
      public void createControl(Composite parent) {
        Composite composite = new Composite(parent, SWT.NONE);
        {
          GridLayout layout = new GridLayout();
          layout.numColumns = 2;
          layout.verticalSpacing = 12;
          composite.setLayout(layout);

          GridData data = new GridData();
          data.verticalAlignment = GridData.FILL;
          data.grabExcessVerticalSpace = true;
          data.horizontalAlignment = GridData.FILL;
          composite.setLayoutData(data);
        }

        Label modelFilesLocationLabel = new Label(composite, SWT.LEFT);
        {
          String label = JETTemplatesUIPlugin.INSTANCE.getString("_UI_JETTemplateModelFiles_label");
          modelFilesLocationLabel.setText(label);

          GridData data = new GridData();
          data.horizontalAlignment = GridData.FILL;
          modelFilesLocationLabel.setLayoutData(data);
        }

        Composite buttonComposite = new Composite(composite, SWT.NONE);
        {
          GridData data = new GridData();
          data.horizontalAlignment = GridData.END;
          buttonComposite.setLayoutData(data);

          RowLayout layout = new RowLayout();
          layout.justify = true;
          layout.pack = true;
          layout.spacing = 15;
          buttonComposite.setLayout(layout);
        }
        Button modelFilesBrowseWorkspaceButton = new Button(buttonComposite, SWT.PUSH);
        modelFilesBrowseWorkspaceButton.setText(JETTemplatesUIPlugin.INSTANCE.getString("_UI_BrowseWorkspace_label"));

        modelFilesLocationText = new Text(composite, SWT.SINGLE | SWT.BORDER);
        {
          GridData data = new GridData();
          data.horizontalAlignment = GridData.FILL;
          data.grabExcessHorizontalSpace = true;
          data.horizontalSpan = 3;
          modelFilesLocationText.setLayoutData(data);
        }

        modelFilesLocationText.setEditable(false);

        modelFilesBrowseWorkspaceButton.addSelectionListener(new SelectionAdapter() {
          public void widgetSelected(SelectionEvent event) {
            String dialogLabel = JETTemplatesUIPlugin.INSTANCE.getString("_UI_SelectJETTemplateModelFile_label");
            ResourceSelectionDialog containerSelectionDialog = new ResourceSelectionDialog(
                ModelWizardFileSelectionPage.this.getShell(), ResourcesPlugin.getWorkspace().getRoot(), dialogLabel);

            containerSelectionDialog.open();
            Object[] result = containerSelectionDialog.getResult();
            if (result != null) {
              StringBuffer text = new StringBuffer();
              for (int i = 0; i < result.length; ++i) {
                if (result[i] instanceof IResource) {
                  IResource resource = (IResource) result[i];
                  if (text.length() > 0)
                    text.append(",");
                  text.append(resource.getFullPath().toString());
                }
              }
              selectedModels = result;
              modelFilesLocationText.setText(text.toString());
              setPageComplete(true);
            }
          }
        });
        setControl(composite);
      }

      /**
       * Method getSelectedModels.
       * @return Object[]
       */
      public Object[] getSelectedModels() {
        return selectedModels;
      }
    }

    /**
     * A page that allows choosing and output from existing or newly created model files
     * @author Jo�l
     * @version $Revision: 1.5 $
     */
    public class GetOrCreateOutputPage extends WizardPage {
      protected Button loadFromExistingJETTemplateModel;
      protected Button loadFromNewJETTemplateModelFromMappings;
      protected Button loadFromNewJETTemplateModel;

      /**
       * Constructor for GetOrCreateOutputPage.
       * @param pageId String
       */
      public GetOrCreateOutputPage(String pageId) {
        super(pageId);
      }

      public void chooseExistingJETTemplate() {
        whichOutput = EXISTING_JET_TEMPLATES_MODEL;
        newFileCreationPage.setPageComplete(true);
        detailsPage.setPageComplete(true);
        jetPluginChooserPage.setPageComplete(true);
        jetProjectChooserPage.setPageComplete(true);
        fileSelectionPage.setPageComplete(fileSelectionPage.isPageComplete());
        mappingFilePage.setPageComplete(true);
        setPageComplete(true);
      }

      public void chooseNewJETTemplateFromMapping() {
        whichOutput = NEW_JET_TEMPLATES_MODEL_FROM_MAPPINGS;
        newFileCreationPage.setPageComplete(true);
        detailsPage.setPageComplete(true);
        jetPluginChooserPage.setPageComplete(true);
        jetProjectChooserPage.setPageComplete(true);
        fileSelectionPage.setPageComplete(true);
        mappingFilePage.setPageComplete(mappingFilePage.isPageComplete());
        setPageComplete(true);
      }
      
      public void chooseNewJETTemplate() {
        whichOutput = NEW_JET_TEMPLATES_MODEL;
        newFileCreationPage.setPageComplete(newFileCreationPage.isPageComplete());
        detailsPage.setPageComplete(detailsPage.isPageComplete());
        jetPluginChooserPage.setPageComplete(jetPluginChooserPage.isPageComplete());
        jetProjectChooserPage.setPageComplete(jetProjectChooserPage.isPageComplete());
        fileSelectionPage.setPageComplete(true);
        mappingFilePage.setPageComplete(true);
        setPageComplete(true);
      }

      /**
       * Method createControl.
       * @param parent Composite
       * @see org.eclipse.jface.dialogs.IDialogPage#createControl(Composite)
       */
      public void createControl(Composite parent) {
        Composite composite = new Composite(parent, SWT.NONE);
        {
          GridLayout layout = new GridLayout();
          layout.numColumns = 1;
          layout.verticalSpacing = 12;
          composite.setLayout(layout);

          GridData data = new GridData();
          data.verticalAlignment = GridData.FILL;
          data.grabExcessVerticalSpace = true;
          data.horizontalAlignment = GridData.FILL;
          composite.setLayoutData(data);
        }

        loadFromExistingJETTemplateModel = new Button(composite, SWT.RADIO);
        if (whichOutput == EXISTING_JET_TEMPLATES_MODEL) {
          loadFromExistingJETTemplateModel.setSelection(true);
        }
        loadFromExistingJETTemplateModel.setText(JETTemplatesUIPlugin.INSTANCE
            .getString("_UI_LoadFromExistingJETTemplateModels_label"));
        {
          GridData data = new GridData();
          loadFromExistingJETTemplateModel.setLayoutData(data);
        }
        loadFromExistingJETTemplateModel.addSelectionListener(new SelectionAdapter() {
          public void widgetSelected(SelectionEvent event) {
            if (loadFromExistingJETTemplateModel.getSelection()) {
              chooseExistingJETTemplate();
            }
          }
        });

        loadFromNewJETTemplateModelFromMappings = new Button(composite, SWT.RADIO);
        if (whichOutput == NEW_JET_TEMPLATES_MODEL_FROM_MAPPINGS) {
          loadFromNewJETTemplateModelFromMappings.setSelection(true);
        }
        loadFromNewJETTemplateModelFromMappings.setText(JETTemplatesUIPlugin.INSTANCE
            .getString("_UI_LoadFromMappingBasedNewJETTemplateModels_label"));
        {
          GridData data = new GridData();
          loadFromNewJETTemplateModelFromMappings.setLayoutData(data);
        }
        loadFromNewJETTemplateModelFromMappings.addSelectionListener(new SelectionAdapter() {
          public void widgetSelected(SelectionEvent event) {
            if (loadFromNewJETTemplateModelFromMappings.getSelection()) {
              chooseNewJETTemplateFromMapping();
            }
          }
        });

        loadFromNewJETTemplateModel = new Button(composite, SWT.RADIO);
        if (whichOutput == NEW_JET_TEMPLATES_MODEL) {
          loadFromNewJETTemplateModel.setSelection(true);
        }
        loadFromNewJETTemplateModel.setText(JETTemplatesUIPlugin.INSTANCE
            .getString("_UI_LoadFromNewJETTemplateModels_label"));
        {
          GridData data = new GridData();
          loadFromNewJETTemplateModel.setLayoutData(data);
        }
        loadFromNewJETTemplateModel.addSelectionListener(new SelectionAdapter() {
          public void widgetSelected(SelectionEvent event) {
            if (loadFromNewJETTemplateModel.getSelection()) {
              chooseNewJETTemplate();
            }
          }
        });
        loadFromNewJETTemplateModelFromMappings.setEnabled(!((JETMappingEditor)editorPart).getInputResources().isEmpty());
        chooseExistingJETTemplate();
        setControl(composite);
      }
    }
    
    /**
     * A page that allows choosing an existing mapping model file in a resource selection
     * @author Jo�l
     * @version $Revision: 1.5 $
     */
    public class MappingFileSelectionPage extends WizardPage {
      protected Text mappingFileLocationText;

      protected IResource mappingFileResource;
      
      /**
       * Constructor for MappingFileSelectionPage.
       * @param pageId String
       */
      public MappingFileSelectionPage(String pageId) {
        super(pageId);
        setPageComplete(false);
      }

      /**
       * Method createControl.
       * @param parent Composite
       * @see org.eclipse.jface.dialogs.IDialogPage#createControl(Composite)
       */
      public void createControl(Composite parent) {
        Composite composite = new Composite(parent, SWT.NONE);
        {
          GridLayout layout = new GridLayout();
          layout.numColumns = 2;
          layout.verticalSpacing = 12;
          composite.setLayout(layout);

          GridData data = new GridData();
          data.verticalAlignment = GridData.FILL;
          data.grabExcessVerticalSpace = true;
          data.horizontalAlignment = GridData.FILL;
          composite.setLayoutData(data);
        }
        
        // Mapping 
        Label fileLocationLabel = new Label(composite, SWT.LEFT);
        {
          String label = MappingModelUIPlugin.INSTANCE.getString("_UI_MappingFile_label");
          fileLocationLabel.setText(label);

          GridData data = new GridData();
          data.horizontalAlignment = GridData.FILL;
          fileLocationLabel.setLayoutData(data);
        }

        Composite buttonComposite = new Composite(composite, SWT.NONE);
        {
          GridData data = new GridData();
          data.horizontalAlignment = GridData.END;
          buttonComposite.setLayoutData(data);

          RowLayout layout = new RowLayout();
          layout.justify = true;
          layout.pack = true;
          layout.spacing = 15;
          buttonComposite.setLayout(layout);
        }
        Button browseWorkspaceButton = new Button(buttonComposite, SWT.PUSH);
        browseWorkspaceButton.setText(MappingModelUIPlugin.INSTANCE.getString("_UI_BrowseWorkspace_label"));
        
        mappingFileLocationText = new Text(composite, SWT.SINGLE | SWT.BORDER);
        {
          GridData data = new GridData();
          data.horizontalAlignment = GridData.FILL;
          data.grabExcessHorizontalSpace = true;
          data.horizontalSpan = 3;
          mappingFileLocationText.setLayoutData(data);
        }

        mappingFileLocationText.setEditable(false);

        browseWorkspaceButton.addSelectionListener(new SelectionAdapter() {
          public void widgetSelected(SelectionEvent event) {
            String dialogLabel = MappingModelUIPlugin.INSTANCE.getString("_UI_SelectMappingFile_label");
            ResourceSelectionDialog containerSelectionDialog = new ResourceSelectionDialog(
                MappingFileSelectionPage.this.getShell(), ResourcesPlugin.getWorkspace().getRoot(), dialogLabel);

            containerSelectionDialog.open();
            Object[] result = containerSelectionDialog.getResult();
            if (result != null && result.length > 0) {
              StringBuffer text = new StringBuffer();
              if (result[0] instanceof IResource) {
                mappingFileResource = (IResource) result[0];
                boolean ok = selectionsValid();
                if (ok)
                  mappingFileLocationText.setText(mappingFileResource.getFullPath().toString());
                setPageComplete(ok);              
              }            
            }
          }
        });
        
        setControl(composite);
      }

      /**
       * Method getMappingFile.
       * @return IResource
       */
      public IResource getMappingFile() {
        return mappingFileResource;
      }

      /**
       * @return boolean
       */
      private boolean selectionsValid() {
        boolean ok = false;
        if (mappingFileResource != null) {
          MappingPackage.eINSTANCE.getNsURI(); // ensure mapping model is loaded
          
          ResourceSet resourceSet = new ResourceSetImpl();          
          URI uri = URI.createPlatformResourceURI(mappingFileResource.getFullPath().toString());
          Resource mappingFileResource = resourceSet.getResource(uri, true);
          
          if (mappingFileResource != null && !mappingFileResource.getContents().isEmpty()) {
            EObject mappingTopContent = (EObject) mappingFileResource.getContents().get(0);
            if (mappingTopContent instanceof TypeMappingRoot) {
              TypeMappingRoot typeMappingRoot = (TypeMappingRoot) mappingTopContent;
              if (typeMappingRoot.getOutputs().contains(jetTemplatePackage)) {
                ok = true;
              }
            }
          }
        }
        return ok;
      }
    }
    /**
     * Get the file from the page.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     * @return Object[]
     */
    public Object[] getSelectedModels() {
      return fileSelectionPage.getSelectedModels();
    }
  }
  
  /*
   * (non-Javadoc)
   * 
   * @see org.eclipse.emf.mapping.action.AddRootTopAction#getTopsToAdd()
   */
  /**
   * Method getBottomsToAdd.
   * @return Collection
   */
  protected Collection getBottomsToAdd() {
    Collection topsToAdd = new ArrayList();

    OutputModelWizard jetTemplateModelWizard = new OutputModelWizard();
    if ((IFileEditorInput) editorPart.getEditorInput() != null) {
      IFile currentFile = ((IFileEditorInput) editorPart.getEditorInput()).getFile();
      IStructuredSelection selection = new StructuredSelection(currentFile);
      jetTemplateModelWizard.init(editorPart.getEditorSite().getWorkbenchWindow().getWorkbench(), selection);
    }
    WizardDialog wizardDialog = new WizardDialog(editorPart.getEditorSite().getShell(), jetTemplateModelWizard);
    wizardDialog.create();
    wizardDialog.getShell().setSize(540, 580);
    int result = wizardDialog.open();

    if (createdFile != null) {
      topsToAdd.addAll(((JETMappingEditor) editorPart).getEditingDomain().getResourceSet().getResource(
          URI.createPlatformResourceURI(createdFile.getFullPath().toString()), true).getContents());
    } else if (selectedModels != null) {
      for (int i = 0; i < selectedModels.length; i++) {
        IResource resource = (IResource) selectedModels[i];
        if (resource.getType() == IResource.FILE && "jettemplate".equals(resource.getFullPath().getFileExtension())) //$NON-NLS-1$
        {
          topsToAdd.addAll(((JETMappingEditor) editorPart).getEditingDomain().getResourceSet().getResource(
              URI.createPlatformResourceURI(resource.getFullPath().toString()), true).getContents());
        }
      }
    }
    return topsToAdd;
  }
}