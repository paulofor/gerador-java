/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.jetmapping.presentation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.codegen.ecore.genmodel.provider.GenModelItemProviderAdapterFactory;
import org.eclipse.emf.common.command.BasicCommandStack;
import org.eclipse.emf.common.command.Command;
import org.eclipse.emf.common.command.CommandStack;
import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.provider.EcoreItemProviderAdapterFactory;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.edit.command.InitializeCopyCommand;
import org.eclipse.emf.edit.provider.ComposedAdapterFactory;
import org.eclipse.emf.edit.provider.ReflectiveItemProviderAdapterFactory;
import org.eclipse.emf.edit.provider.resource.ResourceItemProviderAdapterFactory;
import org.eclipse.emf.mapping.Mapping;
import org.eclipse.emf.mapping.MappingRoot;
import org.eclipse.emf.mapping.command.InitializeCopyOverrideCommand;
import org.eclipse.emf.mapping.domain.AdapterFactoryMappingDomain;
import org.eclipse.emf.mapping.domain.MappingDomain;
import org.eclipse.emf.mapping.domain.PluginAdapterFactoryMappingDomain;
import org.eclipse.emf.mapping.presentation.MappingEditor;
import org.eclipse.emf.mapping.provider.MappingItemProviderAdapterFactory;
import org.eclipse.ui.part.FileEditorInput;

import com.metys.merlin.generation.templates.jetmapping.JETMappingFactory;
import com.metys.merlin.generation.templates.jetmapping.JETTemplateMappingRoot;
import com.metys.merlin.generation.templates.jetmapping.provider.JETMappingItemProviderAdapterFactory;
import com.metys.merlin.generation.templates.provider.JETTemplateItemProviderAdapterFactory;
import com.metys.merlin.generation.templates.provider.JETTemplatesUIPlugin;

/**
 * This is an example of a JETMapping model editor. <!-- begin-user-doc --> <!--
 * end-user-doc -->
 * 
 * @generated NOT
 * @author Jo�l
 * @version $Revision: 1.2 $
 */
public class JETMappingEditor extends MappingEditor {
  
  /**
   */
  public static class MyInitializeCopyOverrideCommand extends InitializeCopyOverrideCommand {
    /**
     * Constructor for MyInitializeCopyOverrideCommand.
     * 
     * @param domain
     * @param initializeCommand
     */
    public MyInitializeCopyOverrideCommand(MappingDomain domain, InitializeCopyCommand initializeCommand) {
      super(domain, initializeCommand);
    }

    /**
     * @see org.eclipse.emf.common.command.Command#execute()
     */
    public void execute() {
      super.execute();
    }
  }

  /**
   */
  public static class EditorMappingDomain extends PluginAdapterFactoryMappingDomain {
    /**
     * Constructor for EditorMappingDomain.
     * 
     * @param mappingDomainAdapterFactory
     * @param topDomainAdapterFactory
     * @param bottomDomainAdapterFactory
     * @param commandStack
     * @param mappingDomainKey
     */
    public EditorMappingDomain(AdapterFactory mappingDomainAdapterFactory, AdapterFactory topDomainAdapterFactory,
        AdapterFactory bottomDomainAdapterFactory, CommandStack commandStack, String mappingDomainKey) {
      super(mappingDomainAdapterFactory, topDomainAdapterFactory, bottomDomainAdapterFactory, commandStack,
          mappingDomainKey);
      setMappingEnablementFlags(MappingDomain.ENABLE_ALL);
    }

    /**
     * Method createComposedAdapterFactory.
     * @param mappingDomainAdapterFactory AdapterFactory
     * @param topDomainAdapterFactory AdapterFactory
     * @param bottomDomainAdapterFactory AdapterFactory
     * @return ComposedAdapterFactory
     */
    protected ComposedAdapterFactory createComposedAdapterFactory(AdapterFactory mappingDomainAdapterFactory,
        AdapterFactory topDomainAdapterFactory, AdapterFactory bottomDomainAdapterFactory) {
      AdapterFactory[] adapterFactories;

      if (topDomainAdapterFactory == bottomDomainAdapterFactory) {
        adapterFactories = new AdapterFactory[] { mappingDomainAdapterFactory,
            new LabelUpdatePropagatingComposedAdapterFactory(topDomainAdapterFactory) };
      } else {
        adapterFactories = new AdapterFactory[] { mappingDomainAdapterFactory,
          new LabelUpdatePropagatingComposedAdapterFactory(bottomDomainAdapterFactory),
          new LabelUpdatePropagatingComposedAdapterFactory(topDomainAdapterFactory) };        
      }

      return createComposedAdapterFactory(adapterFactories);
    }

    /**
     * Method createInitializeCopyOverrideCommand.
     * @param initializeCopyCommand InitializeCopyCommand
     * @return Command
     */
    protected Command createInitializeCopyOverrideCommand(InitializeCopyCommand initializeCopyCommand) {
      EObject copy = initializeCopyCommand.getCopy();
      EObject owner = initializeCopyCommand.getOwner();

      // If the owner and the copy are of the same type, we can proceed with the
      // command, i.e. no override.
      // If not, we will skip this command by returning a do-nothing override.
      //
      if (!isSameEditingDomainAdapterFactory) {
        return new MyInitializeCopyOverrideCommand(this, initializeCopyCommand);
      }

      return null;
    }
  }

  public JETMappingEditor() {
    topLabel = JETTemplatesUIPlugin.getPlugin().getString("_UI_Model_label");
    bottomLabel = JETTemplatesUIPlugin.getPlugin().getString("_UI_JETTemplateModel_label");
  }
  /**
   * Method getInputResources.
   * @return Collection
   */
  public Collection getInputResources() {
    return getInputResources(mappingRoot);
  }
  /**
   * Method getInputResources.
   * @param mapping Mapping
   * @return Collection
   */
  private Collection getInputResources(Mapping mapping) {
    HashSet results = new HashSet();
    for (Iterator it = mapping.getInputs().iterator(); it.hasNext();) {
      Object input = it.next();
      if (input instanceof EObject && ((EObject)input).eResource() != null) {
        results.add(((EObject)input).eResource());
      }
    }
    for (Iterator it = mapping.getNested().iterator(); it.hasNext();) {
      Mapping sub = (Mapping) it.next();
      results.addAll(getInputResources(sub));
    }
    return results;
  }
  /**
   * Method setMappingRoot.
   * @param mappingRoot MappingRoot
   */
  protected void setMappingRoot(MappingRoot mappingRoot) {
    if (mappingRoot.getTypeMappingRoot() != null) {
      mappingRoot.getTypeMappingRoot().setDomain(mappingDomain);
    }
    super.setMappingRoot(mappingRoot);
  }
  /**
   * Method createMappingDomain.
   * @return AdapterFactoryMappingDomain
   */
  protected AdapterFactoryMappingDomain createMappingDomain() {
    AdapterFactory mappingAdapterFactory = new ComposedAdapterFactory(new AdapterFactory[] {
        new ResourceItemProviderAdapterFactory(), new MappingItemProviderAdapterFactory(),
        new JETMappingItemProviderAdapterFactory() });

    // This is a test case for the persistent command stack implementation.
    //
    CommandStack commandStack = new BasicCommandStack();
    List adapterFactories = new ArrayList();
    Collection customInputAdapterFactories = JETTemplatesUIPlugin.getPlugin().getCustomInputAdapterFactories();
    if (customInputAdapterFactories != null)
      adapterFactories.addAll(customInputAdapterFactories);    
    adapterFactories.add(new GenModelItemProviderAdapterFactory());
    adapterFactories.add(new EcoreItemProviderAdapterFactory());
    adapterFactories.add(new ReflectiveItemProviderAdapterFactory());
    
    AdapterFactory topDomainAdapterFactory = new ComposedAdapterFactory(adapterFactories);

    AdapterFactory bottomDomainAdapterFactory = new JETTemplateItemProviderAdapterFactory();

    // This is a test case for cross domain code.
    // It creates two instances of the factory.
    //
    AdapterFactoryMappingDomain mappingDomain = new EditorMappingDomain(mappingAdapterFactory, topDomainAdapterFactory,
        bottomDomainAdapterFactory, commandStack, null);
    return mappingDomain;
  }

  /**
   * @see org.eclipse.emf.mapping.presentation.MappingEditor#handleMissingModelFile()
   */
  protected void handleMissingModelFile() {
    try {
      IFile mappingModelFile = modelFile.getFile().getParent().getFile(
          new Path(new Path(modelFile.getName()).removeFileExtension().toOSString() + ".mapper"));

      MappingRoot originalRootObject = (MappingRoot) ((Resource) mappingDomain.getResourceSet().getResources()
          .iterator().next()).getContents().get(0);

      // Switch over.
      //
      modelFile = new FileEditorInput(mappingModelFile);

      Resource mappingModelResource = null;
      if (mappingModelFile.exists()) {
        Resource resource = mappingDomain.loadResource(getURIFromFile(modelFile.getFile()));
        mappingRoot = (MappingRoot) resource.getContents().get(0);
      } else {
        // Get the resource factory for this type of file name.
        //
        mappingModelResource = mappingDomain.getResourceSet().createResource(
            URI.createFileURI(modelFile.getFile().getFullPath().toString()));

        // Add the initial model object to the extent.
        //
        mappingRoot = JETMappingFactory.eINSTANCE.createJETTemplateMappingRoot();

        mappingModelResource.getContents().add(mappingRoot);

        mappingDomain.getResourceSet().getResources().add(mappingModelResource);

        mappingRoot.getInputs().add(originalRootObject);

        IFile outputModelFile = modelFile.getFile().getParent().getFile(
            new Path(new Path(modelFile.getName()).removeFileExtension().toOSString() + "_mapper_result.classside"));

        Resource outputResource = null;

        if (outputModelFile.exists()) {
          outputResource = mappingDomain.loadResource(getURIFromFile(outputModelFile));
        } else {
          // Get the resource factory for this type of file name.
          //
          outputResource = mappingDomain.getResourceSet()
              .createResource(URI.createURI(getURIFromFile(outputModelFile)));

          JETTemplateMappingRoot templateMappingRoot = JETMappingFactory.eINSTANCE.createJETTemplateMappingRoot();

          outputResource.getContents().add(templateMappingRoot);

          mappingRoot.getOutputs().addAll(outputResource.getContents());
        }

        doSave(null);
      }
      mappingRoot.setDomain(mappingDomain);
      mappingRoot.setTopToBottom(true);
    } catch (Exception exception) {
      exception.printStackTrace();
    }
  }
}