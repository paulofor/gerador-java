/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.presentation;

import java.util.Iterator;
import java.util.ResourceBundle;

import org.eclipse.jdt.internal.ui.IJavaHelpContextIds;
import org.eclipse.jdt.internal.ui.JavaPlugin;
import org.eclipse.jdt.ui.text.IColorManager;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.text.source.ISharedTextColors;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.jface.text.source.IVerticalRuler;
import org.eclipse.jface.text.source.OverviewRuler;
import org.eclipse.jface.text.source.SourceViewer;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.editors.text.TextEditor;
import org.eclipse.ui.internal.editors.text.EditorsPlugin;
import org.eclipse.ui.texteditor.AnnotationPreference;
import org.eclipse.ui.texteditor.ContentAssistAction;
import org.eclipse.ui.texteditor.IDocumentProvider;
import org.eclipse.ui.texteditor.ITextEditorActionDefinitionIds;
import org.eclipse.ui.texteditor.MarkerAnnotationPreferences;
import org.eclipse.ui.texteditor.SourceViewerDecorationSupport;

import com.metys.merlin.generation.templates.preferences.JETTemplateEditorPreferenceConstants;
import com.metys.merlin.generation.templates.util.JETTemplateDocumentProvider;
import com.metys.merlin.generation.templates.util.JETTemplateSourceViewerConfiguration;
/**
 * @see TextEditor
 * @author Jo�l
 * @version $Revision: 1.5 $
 */
public class JETTextEditor extends TextEditor {
  private MarkerAnnotationPreferences fAnnotationPreferences = new MarkerAnnotationPreferences();
  
  /**
   * Text operation code for requesting correction assist to show correction proposals for the
   * current position.
   */
  public static final int CORRECTIONASSIST_PROPOSALS = 50;
  
  /**
   * Text operation code for requesting common prefix completion.
   */
  public static final int CONTENTASSIST_COMPLETE_PREFIX = 60;
  private IDocumentProvider provider;

  public JETTextEditor() {
    IPreferenceStore preferenceStore = JavaPlugin.getDefault().getPreferenceStore();
    JETTemplateEditorPreferenceConstants.initializeDefaultValues(preferenceStore);
    setPreferenceStore(preferenceStore);
    setDocumentProvider(provider = new JETTemplateDocumentProvider());
    IColorManager colorManager = JavaPlugin.getDefault().getJavaTextTools().getColorManager();
    setSourceViewerConfiguration(new JETTemplateSourceViewerConfiguration(colorManager,
        preferenceStore, this, null));
  }
  /**
   * Method getProvider.
   * @return IDocumentProvider
   */
  public IDocumentProvider getProvider() {
    return provider;
  }
  /**
   * Method setProvider.
   * @param provider IDocumentProvider
   */
  public void setProvider(IDocumentProvider provider) {
    this.provider = provider;
  }
  
  /*
   * @see AbstractTextEditor#createActions()
   */
  protected void createActions() {
    super.createActions();
    ResourceBundle resourceBundle = ResourceBundle.getBundle("com.metys.merlin.generation.templates.presentation.TextEditorMessages");
    Action action = new ContentAssistAction(resourceBundle,"ContentAssistProposal.", this); //$NON-NLS-1$
    action.setActionDefinitionId(ITextEditorActionDefinitionIds.CONTENT_ASSIST_PROPOSALS);
    setAction("ContentAssistProposal", action); //$NON-NLS-1$
    markAsStateDependentAction("ContentAssistProposal", true); //$NON-NLS-1$
    PlatformUI.getWorkbench().getHelpSystem().setHelp(action,
        IJavaHelpContextIds.CONTENT_ASSIST_ACTION);       
  }
  
  /*
   * (non-Javadoc)
   * 
   * @see org.eclipse.ui.texteditor.AbstractTextEditor#createSourceViewer(org.eclipse.swt.widgets.Composite,
   *      org.eclipse.jface.text.source.IVerticalRuler, int)
   */
  protected ISourceViewer createSourceViewer(Composite parent, IVerticalRuler ruler, int styles) {
    fAnnotationAccess = createAnnotationAccess();
    ISharedTextColors sharedColors = EditorsPlugin.getDefault().getSharedTextColors();
    fOverviewRuler = new OverviewRuler(fAnnotationAccess, VERTICAL_RULER_WIDTH, sharedColors);
    Iterator e = fAnnotationPreferences.getAnnotationPreferences().iterator();
    while (e.hasNext()) {
      AnnotationPreference preference = (AnnotationPreference) e.next();
      if (preference.contributesToHeader())
        fOverviewRuler.addHeaderAnnotationType(preference.getAnnotationType());
    }
    ISourceViewer sourceViewer = new SourceViewer(parent, ruler, fOverviewRuler,
        isOverviewRulerVisible(), styles);
    fSourceViewerDecorationSupport = new SourceViewerDecorationSupport(sourceViewer,
        fOverviewRuler, fAnnotationAccess, sharedColors);
    configureSourceViewerDecorationSupport(fSourceViewerDecorationSupport);
    return sourceViewer;
  }
}
