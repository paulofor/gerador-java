/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.dyncheck;

import java.util.Iterator;

import org.eclipse.jdt.internal.ui.text.JavaWordFinder;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextHover;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.Position;
import org.eclipse.jface.text.source.Annotation;
import org.eclipse.jface.text.source.IAnnotationModel;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.texteditor.IDocumentProvider;

import com.metys.merlin.generation.templates.presentation.JETTextEditor;

/**
 * @author Jo�l
 * @version $Revision: 1.2 $
 */
public class JETTextHover implements ITextHover {

  private IEditorPart editor;
  
  /**
   * Constructor for JETTextHover.
   * @param editor IEditorPart
   */
  public JETTextHover(IEditorPart editor) {
    this.editor = editor;
  }

  /* (non-Javadoc)
   * @see org.eclipse.jface.text.ITextHover#getHoverInfo(org.eclipse.jface.text.ITextViewer, org.eclipse.jface.text.IRegion)
   */
  public String getHoverInfo(ITextViewer textViewer, IRegion hoverRegion) {
    if (editor == null)
      return null;

    IDocumentProvider provider = ((JETTextEditor)editor).getDocumentProvider();
    IAnnotationModel model = provider.getAnnotationModel(getEditor().getEditorInput());

    if (model != null) {
      Iterator e = model.getAnnotationIterator();
      while (e.hasNext()) {
        Annotation a = (Annotation)e.next();
        Position p = model.getPosition(a);
        if (p.overlapsWith(hoverRegion.getOffset(), hoverRegion.getLength())) {
          if (a instanceof JETProblemAnnotation) {
            String msg = ((JETProblemAnnotation)a).getText();
            if (msg != null && msg.trim().length() > 0)
              return msg;
          }
        }
      }
    }
    return null;
  }

  /* (non-Javadoc)
   * @see org.eclipse.jface.text.ITextHover#getHoverRegion(org.eclipse.jface.text.ITextViewer, int)
   */
  public IRegion getHoverRegion(ITextViewer textViewer, int offset) {
    return JavaWordFinder.findWord(textViewer.getDocument(), offset);
  }

  /**
   * @return IEditorPart
   */
  public IEditorPart getEditor() {
    return editor;
  }

}
