/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.util.hovers;

import java.io.StringReader;

import org.eclipse.jdt.internal.ui.text.HTMLPrinter;
import org.eclipse.jdt.internal.ui.text.JavaWordFinder;
import org.eclipse.jdt.internal.ui.text.javadoc.JavaDoc2HTMLTextReader;
import org.eclipse.jdt.ui.text.java.hover.IJavaEditorTextHover;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.contentassist.ICompletionProposal;
import org.eclipse.ui.IEditorPart;

import com.metys.merlin.generation.templates.codeassist.JETTemplateCompletionProcessor;
import com.metys.merlin.generation.templates.presentation.JETTextEditor;

/**
 * @author jcheuoua
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 * @version $Revision: 1.2 $
 */
public class JETTemplateScriptletHover implements IJavaEditorTextHover {

	private IEditorPart jetEditor;

	/**
	 * Constructor for JETTemplateScriptletHover.
	 * @param editor JETTextEditor
	 */
	public JETTemplateScriptletHover(JETTextEditor editor) {
		jetEditor = editor;
	}

	/**
	 * Method setEditor.
	 * @param editor IEditorPart
	 * @see org.eclipse.jdt.ui.text.java.hover.IJavaEditorTextHover#setEditor(IEditorPart)
	 */
	public void setEditor(IEditorPart editor) {
		jetEditor = editor;
	}

	/**
	 * Method getHoverInfo.
	 * @param textViewer ITextViewer
	 * @param hoverRegion IRegion
	 * @return String
	 * @see org.eclipse.jface.text.ITextHover#getHoverInfo(ITextViewer, IRegion)
	 */
	public String getHoverInfo(ITextViewer textViewer, IRegion hoverRegion) {
		ProposalThread pt = new ProposalThread(textViewer, hoverRegion);
		textViewer.getTextWidget().getDisplay().syncExec(pt);
		if (pt.proposals != null && pt.proposals.length == 1) {
			ICompletionProposal p = pt.proposals[0];
			return createHoverInfo(p);
		} else {
			return null;
		}
	}

	/**
	 * Method createHoverInfo.
	 * @param p ICompletionProposal
	 * @return String
	 */
	private String createHoverInfo(ICompletionProposal p) {
		StringBuffer buffer = new StringBuffer();
		HTMLPrinter.addSmallHeader(buffer, p.getDisplayString());
		if (p.getAdditionalProposalInfo() != null) {
			StringReader reader = new StringReader(p.getAdditionalProposalInfo());
			HTMLPrinter.addParagraph(buffer, new JavaDoc2HTMLTextReader(reader));
		}
		return buffer.toString();
	}

	/**
	 * Method getHoverRegion.
	 * @param textViewer ITextViewer
	 * @param offset int
	 * @return IRegion
	 * @see org.eclipse.jface.text.ITextHover#getHoverRegion(ITextViewer, int)
	 */
	public IRegion getHoverRegion(ITextViewer textViewer, int offset) {
		return JavaWordFinder.findWord(textViewer.getDocument(), offset);
	}

	/**
	 */
	private class ProposalThread implements Runnable {
		/**
		 * Method run.
		 * @see java.lang.Runnable#run()
		 */
		public void run() {
			JETTemplateCompletionProcessor processor =
				new JETTemplateCompletionProcessor(
					(JETTextEditor) JETTemplateScriptletHover.this.jetEditor);
			proposals = processor.computeCompletionProposals(textViewer, hoverRegion.getOffset());
		}
		protected ICompletionProposal proposals[];
		private ITextViewer textViewer;
		private IRegion hoverRegion;

		/**
		 * Constructor for ProposalThread.
		 * @param textViewer ITextViewer
		 * @param hoverRegion IRegion
		 */
		public ProposalThread(ITextViewer textViewer, IRegion hoverRegion) {
			proposals = null;
			this.textViewer = null;
			this.textViewer = textViewer;
			this.hoverRegion = hoverRegion;
		}
	}
}
