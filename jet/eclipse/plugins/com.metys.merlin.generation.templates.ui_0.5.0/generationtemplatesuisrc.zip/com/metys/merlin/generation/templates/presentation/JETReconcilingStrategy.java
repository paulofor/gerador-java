/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.presentation;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.net.MalformedURLException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.StringTokenizer;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.codegen.jet.JETNature;
import org.eclipse.emf.codegen.jet.JETSkeleton;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.IProblemRequestor;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.WorkingCopyOwner;
import org.eclipse.jdt.core.compiler.IProblem;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.Position;
import org.eclipse.jface.text.reconciler.DirtyRegion;
import org.eclipse.jface.text.reconciler.IReconcilingStrategy;
import org.eclipse.jface.text.source.Annotation;
import org.eclipse.jface.text.source.IAnnotationModel;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IFileEditorInput;

import com.metys.merlin.generation.templates.dyncheck.JETAnnotationModel;
import com.metys.merlin.generation.templates.dyncheck.JETProblemAnnotation;
import com.metys.merlin.generation.templates.provider.JETTemplatesUIPlugin;
import com.metys.merlin.generation.templates.util.JETCompilerExt;

/**
 */
public class JETReconcilingStrategy implements IReconcilingStrategy, IProblemRequestor {
  private JETTextEditor jetEditor;
  private ISourceViewer sourceViewer;
  private IDocument currentDocument;
  private IFile jetFile;
  private JETCompilerExt jetCompiler;
  private ICompilationUnit compilationUnit;
  private String generatedSource;
  private HashSet problems;
  
  /**
   * Constructor for JETReconcilingStrategy.
   * @param sourceViewer ISourceViewer
   * @param jetEditor JETTextEditor
   */
  public JETReconcilingStrategy(ISourceViewer sourceViewer, JETTextEditor jetEditor) {
    this.jetEditor = jetEditor;
    this.sourceViewer = sourceViewer;
  }
  /**
   * Method setDocument.
   * @param document IDocument
   * @see org.eclipse.jface.text.reconciler.IReconcilingStrategy#setDocument(IDocument)
   */
  public void setDocument(IDocument document) {
    this.currentDocument = document;
  }
  /**
   * Method reconcile.
   * @param dirtyRegion DirtyRegion
   * @param subRegion IRegion
   * @see org.eclipse.jface.text.reconciler.IReconcilingStrategy#reconcile(DirtyRegion, IRegion)
   */
  public void reconcile(DirtyRegion dirtyRegion, IRegion subRegion) {
    reconcile();
  }
  /**
   * Method reconcile.
   * @param partition IRegion
   * @see org.eclipse.jface.text.reconciler.IReconcilingStrategy#reconcile(IRegion)
   */
  public void reconcile(IRegion partition) {
    reconcile();
  }
  /**
   * Method getPackageContainer.
   * @param root IContainer
   * @param packagename String
   * @return IContainer
   */
  private IContainer getPackageContainer(IContainer root, String packagename) {
    for (StringTokenizer stringTokenizer = new StringTokenizer(packagename, "."); stringTokenizer.hasMoreTokens();) {
      IFolder newContainer = root.getFolder(new Path(stringTokenizer.nextToken()));
      root = newContainer;
    }
    return root;
  }
  private void reconcile() {
    IEditorInput editorInput = jetEditor.getEditorInput();
    if (editorInput != null) {
      jetFile = ((IFileEditorInput) editorInput).getFile();
      IProject project = jetFile.getProject();
      try {
        IJavaProject javaProject = JavaCore.create(project);
        JETNature jetNature = JETNature.getRuntime(project);
        if (javaProject == null || jetNature == null)
          return;
        IContainer parent = jetFile.getParent();
        while (parent != null) {
          if (jetNature.getTemplateContainers().contains(parent))
            break;
          parent = parent.getParent();
        }
        if (parent == null) {
          jetNature.getTemplateContainers().add(jetFile.getParent());
          jetNature.setTemplateContainers(jetNature.getTemplateContainers());
        }
        IContainer javaSourceContainer = jetNature.getJavaSourceContainer();
        if (javaSourceContainer == null) {
          IPackageFragmentRoot[] fragmentRoots = javaProject.getPackageFragmentRoots();
          for (int i = 0; i < fragmentRoots.length; i++) {
            IPackageFragmentRoot fragmentRoot = fragmentRoots[i];
            if (fragmentRoot.getKind() == IPackageFragmentRoot.K_SOURCE) {
              jetNature.setJavaSourceContainer((IContainer) fragmentRoot.getCorrespondingResource());
              break;
            }
          }
        }

        // Ensure the template java class is generated
        //jetEditor.getSite().getPage().saveEditor(jetEditor, false);
        String uri = jetFile.getLocation().toFile().getAbsoluteFile().toURL().toString();
        String jetSource = currentDocument.get();
        ByteArrayInputStream is = new ByteArrayInputStream(jetSource.getBytes());
        jetCompiler = new JETCompilerExt(uri, is);
        jetCompiler.parse();
        ByteArrayOutputStream arrayOutputStream = new ByteArrayOutputStream();
        jetCompiler.generate(arrayOutputStream);
        generatedSource = new String(arrayOutputStream.toByteArray());
        JETSkeleton skeleton = jetCompiler.getSkeleton();
        IContainer container = getPackageContainer(jetNature.getJavaSourceContainer(), skeleton.getPackageName());
        IPackageFragmentRoot[] roots = javaProject.getPackageFragmentRoots();
        for (int i = 0; i < roots.length; i++) {
          IPackageFragmentRoot root = roots[i];
          IPackageFragment packageFragment = root.getPackageFragment(skeleton.getPackageName());
          if (packageFragment != null && packageFragment.exists()) {
            compilationUnit = packageFragment.createCompilationUnit(skeleton.getClassName() + ".java", arrayOutputStream
                .toString(), true, new NullProgressMonitor());
            break;
          }
        }
        if (compilationUnit == null)
          return;
        WorkingCopyOwner owner = new WorkingCopyOwner() {/*non shared working copy*/};
        
        ICompilationUnit copy = compilationUnit.getWorkingCopy(owner, this, null);

        JETAnnotationModel annotationModel = (JETAnnotationModel) sourceViewer.getAnnotationModel();
        annotationModel.setFireChanges(false);

        // clean the annotation model
        Iterator it = annotationModel.getAnnotationIterator();
        while (it.hasNext()) {
          Annotation annotation = (Annotation) it.next();
          if (annotation instanceof JETProblemAnnotation) {
            annotationModel.removeAnnotation(annotation);
          }
        }
        
        copy.reconcile(ICompilationUnit.NO_AST, true, owner, null);
        
        annotationModel.setFireChanges(true);
        annotationModel.fireAnnotationModelChanged();
//        IMarker[] markers = copy.getUnderlyingResource().findMarkers(IJavaModelMarker.JAVA_MODEL_PROBLEM_MARKER, false, IResource.DEPTH_INFINITE);
      } catch (CoreException e) {
        JETTemplatesUIPlugin.INSTANCE.log(e);
      } catch (MalformedURLException e) {
        JETTemplatesUIPlugin.INSTANCE.log(e);
      }
    }
  }
  /**
   * Method acceptProblem.
   * @param problem IProblem
   * @see org.eclipse.jdt.core.IProblemRequestor#acceptProblem(IProblem)
   */
  public void acceptProblem(IProblem problem) {    
    problems.add(problem);        
  }
  /**
   * Method beginReporting.
   * @see org.eclipse.jdt.core.IProblemRequestor#beginReporting()
   */
  public void beginReporting() {
    if (problems == null)
      problems = new HashSet();
    problems.clear();
  }
  
  /**
   * Method endReporting.
   * @see org.eclipse.jdt.core.IProblemRequestor#endReporting()
   */
  public void endReporting() {
    for (Iterator iter = problems.iterator(); iter.hasNext();) {
      IProblem problem = (IProblem) iter.next();
      IAnnotationModel annotationModel = sourceViewer.getAnnotationModel();
      try {
        
        String jetContent = currentDocument.get();
        String javaSource = generatedSource;
        
        int offset = problem.getSourceStart();
        int length = problem.getSourceEnd() - problem.getSourceStart() + 1;
        JETCompilerExt.Range javaRange = jetCompiler.getJavaRange(offset);
        JETCompilerExt.Range jetRange = javaRange == null ? null : jetCompiler.getJetRange(javaRange);
        
        int jetOffset = (jetRange == null) ? 0 : jetRange.start + (offset - javaRange.start);
        
        JETProblemAnnotation annotation = new JETProblemAnnotation(problem, compilationUnit);
        Position position = new Position(jetOffset, length);
        annotationModel.addAnnotation(annotation, position);
      } catch (Exception e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }
    }
  }
  
  /**
   * Method isActive.
   * @return boolean
   * @see org.eclipse.jdt.core.IProblemRequestor#isActive()
   */
  public boolean isActive() {
    return true;
  }
}
