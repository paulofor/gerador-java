/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.scanners;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jdt.internal.ui.text.JavaWordDetector;
import org.eclipse.jdt.ui.text.IColorManager;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.text.TextAttribute;
import org.eclipse.jface.text.rules.IRule;
import org.eclipse.jface.text.rules.IToken;
import org.eclipse.jface.text.rules.SingleLineRule;
import org.eclipse.jface.text.rules.Token;
import org.eclipse.jface.text.rules.WordRule;
import org.eclipse.swt.graphics.Color;

import com.metys.merlin.generation.templates.preferences.JETTemplateEditorPreferenceConstants;
import com.metys.merlin.generation.templates.util.keywords.JETTemplateDirectiveKeywords;
import com.metys.merlin.generation.templates.util.rules.JETTemplateBracketRule;
import com.metys.merlin.generation.templates.util.rules.JETTemplateWordRule;

/**
 */
public class JETTemplateDirectiveScanner extends AbstractJETTemplateScanner {

  /**
   * Constructor for JETTemplateDirectiveScanner.
   * @param colorManager IColorManager
   * @param preferenceStore IPreferenceStore
   */
  public JETTemplateDirectiveScanner(IColorManager colorManager, IPreferenceStore preferenceStore) {
    super(colorManager, preferenceStore);
    initialize();
  }
  
  /**
   * Method getTokenProperties.
   * @return String[]
   */
  public String[] getTokenProperties() {
    return colorProperties;
  }

  private static String colorProperties[] = { 
    JETTemplateEditorPreferenceConstants.JET_DIRECTIVE_BACKGROUND_COLOR,
    JETTemplateEditorPreferenceConstants.JAVA_KEYWORD_COLOR,
    JETTemplateEditorPreferenceConstants.JET_STRING_COLOR,
    JETTemplateEditorPreferenceConstants.JET_BRACKET_COLOR,
    JETTemplateEditorPreferenceConstants.DEFAULT_FG_COLOR };

  private static String javaConstants[] = { "false", "null", "true" };
  
  /*
   * @see AbstractJavaScanner#createRules()
   */
  protected List createRules() {
    List brRules = new ArrayList();

    if (preferenceStore != null) {
      Color bg = getColor(JETTemplateEditorPreferenceConstants.JET_DIRECTIVE_BACKGROUND_COLOR);
      boolean isBold = false;

      isBold = preferenceStore.getBoolean(JETTemplateEditorPreferenceConstants.DEFAULT_FG_BOLD);
      IToken code = new Token(new TextAttribute(
          getColor(JETTemplateEditorPreferenceConstants.DEFAULT_FG_COLOR), bg, isBold ? 1 : 0));

      isBold = preferenceStore.getBoolean(JETTemplateEditorPreferenceConstants.JET_BRACKET_BOLD);
      IToken bracket = new Token(new TextAttribute(
          getColor(JETTemplateEditorPreferenceConstants.JET_BRACKET_COLOR), bg, isBold ? 1 : 0));
      
      isBold = preferenceStore.getBoolean(JETTemplateEditorPreferenceConstants.JAVA_KEYWORD_BOLD);
      IToken javaKeyword = new Token(new TextAttribute(
          getColor(JETTemplateEditorPreferenceConstants.JAVA_KEYWORD_COLOR), bg, isBold ? 1 : 0));

      isBold = preferenceStore.getBoolean(JETTemplateEditorPreferenceConstants.JET_STRING_BOLD);
      IToken string = new Token(new TextAttribute(
          getColor(JETTemplateEditorPreferenceConstants.JET_STRING_COLOR), bg, isBold ? 1 : 0));

      isBold = preferenceStore.getBoolean(JETTemplateEditorPreferenceConstants.JAVA_KEYWORD_BOLD);
      IToken jetKeywords = new Token(new TextAttribute(
          getColor(JETTemplateEditorPreferenceConstants.JAVA_KEYWORD_COLOR), bg, isBold ? 1 : 0));

      WordRule javaReservedWordsRule = new JETTemplateWordRule(new JavaWordDetector(), code);
      for (int i = 0; i < javaConstants.length; i++)
        javaReservedWordsRule.addWord(javaConstants[i], javaKeyword);

      String jspwrds[] = JETTemplateDirectiveKeywords.getAllKeywords();
      for (int i = 0; i < jspwrds.length; i++)
        javaReservedWordsRule.addWord(jspwrds[i], javaKeyword);

      jspwrds = JETTemplateDirectiveKeywords.getAllInnerKeywords();
      for (int i = 0; i < jspwrds.length; i++)
        javaReservedWordsRule.addWord(jspwrds[i], javaKeyword);

      brRules.add(javaReservedWordsRule);
      brRules.add(new JETTemplateBracketRule(bracket));
      brRules.add(new SingleLineRule("\"", "\"", string, '\\'));
      brRules.add(new SingleLineRule("'", "'", string, '\\'));
      setRules((IRule[]) brRules.toArray(new IRule[brRules.size()]));
      setDefaultReturnToken(code);
    }

    return brRules;
  }

}