/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.util;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.text.DefaultLineTracker;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IDocumentPartitioner;
import org.eclipse.jface.text.ILineTracker;
import org.eclipse.jface.text.rules.FastPartitioner;
import org.eclipse.jface.text.rules.IPartitionTokenScanner;
import org.eclipse.jface.text.source.IAnnotationModel;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.editors.text.FileDocumentProvider;
import org.eclipse.ui.part.FileEditorInput;

import com.metys.merlin.generation.templates.dyncheck.JETAnnotationModel;
import com.metys.merlin.generation.templates.scanners.JETTemplatePartitionScanner;

/**
 * @author jcheuoua
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 * @version $Revision: 1.2 $
 */
public class JETTemplateDocumentProvider extends FileDocumentProvider {
	
	private IPartitionTokenScanner scanner;
	
	/**
	 * Method createDocument.
	 * @param element Object
	 * @return IDocument
	 * @throws CoreException
	 */
	public IDocument createDocument(Object element) throws CoreException {
		IDocument document = super.createDocument(element);
		if (document != null) {
			if (scanner == null)
				scanner = new JETTemplatePartitionScanner();
			IDocumentPartitioner partitioner = new FastPartitioner(scanner, JETTemplatePartitionScanner.getLegalContentTypes());
			if (partitioner != null) {
				partitioner.connect(document);
				document.setDocumentPartitioner(partitioner);
			}
		}
		return document;
	}

	/**
	 * Method createElementInfo.
	 * @param element Object
	 * @return ElementInfo
	 * @throws CoreException
	 */
	protected ElementInfo createElementInfo(Object element)
		throws CoreException {
		if (element instanceof FileEditorInput) {
			FileEditorInput input = (FileEditorInput) element;
			org.eclipse.core.resources.IFile ifile;
			if (input != null)
				ifile = input.getFile();
		}
		return super.createElementInfo(element);
	}
  
  /**
   * Gets or creates the partition scanner that will be attached to the
   * documents created by this documentProvider.
   * @return IPartitionTokenScanner
   */
  public IPartitionTokenScanner getPartitionScanner() {
    if (scanner == null)
      scanner = new JETTemplatePartitionScanner();
    return scanner;
  }
  /**
   * Sets the partition scanner that will be attached to the
   * documents created by this documentProvider.
   * @param scanner IPartitionTokenScanner
   */
  public void setPartitionScanner(IPartitionTokenScanner scanner) {
    this.scanner = scanner;
  }

  /* (non-Javadoc)
   * @see org.eclipse.ui.texteditor.AbstractDocumentProvider#createAnnotationModel(java.lang.Object)
   */
  protected IAnnotationModel createAnnotationModel(Object element)
    throws CoreException {
    if (element instanceof IFileEditorInput) {
      IFileEditorInput input = (IFileEditorInput) element;
      return new JETAnnotationModel(input.getFile());
    }  
    return super.createAnnotationModel(element);
  }
  
  /**
   * Creates a line tracker working with the same line delimiters as the document
   * of the given element. Assumes the element to be managed by this document provider.
   * 
   * @param element the element serving as blue print
   * @return a line tracker based on the same line delimiters as the element's document
   */
  public ILineTracker createLineTracker(Object element) {
    return new DefaultLineTracker();
  }


}
