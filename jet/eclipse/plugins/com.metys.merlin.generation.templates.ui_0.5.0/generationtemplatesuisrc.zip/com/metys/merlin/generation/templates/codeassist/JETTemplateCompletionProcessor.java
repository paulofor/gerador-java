/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.codeassist;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.net.MalformedURLException;
import java.util.Arrays;
import java.util.StringTokenizer;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.codegen.jet.JETNature;
import org.eclipse.emf.codegen.jet.JETSkeleton;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.internal.corext.template.java.JavaContextType;
import org.eclipse.jdt.internal.ui.JavaPlugin;
import org.eclipse.jdt.internal.ui.text.java.JavaCompletionProposal;
import org.eclipse.jdt.internal.ui.text.java.LazyJavaCompletionProposal;
import org.eclipse.jdt.internal.ui.text.template.contentassist.TemplateEngine;
import org.eclipse.jdt.internal.ui.text.template.contentassist.TemplateProposal;
import org.eclipse.jdt.ui.text.java.CompletionProposalCollector;
import org.eclipse.jdt.ui.text.java.CompletionProposalComparator;
import org.eclipse.jdt.ui.text.java.IJavaCompletionProposal;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.contentassist.ICompletionProposal;
import org.eclipse.jface.text.contentassist.IContentAssistProcessor;
import org.eclipse.jface.text.contentassist.IContextInformation;
import org.eclipse.jface.text.contentassist.IContextInformationValidator;
import org.eclipse.jface.text.templates.TemplateContextType;
import org.eclipse.swt.graphics.Point;
import org.eclipse.ui.IFileEditorInput;

import com.metys.merlin.generation.templates.presentation.JETTextEditor;
import com.metys.merlin.generation.templates.provider.JETTemplatesUIPlugin;
import com.metys.merlin.generation.templates.util.JETCompilerExt;

/**
 * @author jcheuoua
 * 
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 * @version $Revision: 1.4 $
 */
public class JETTemplateCompletionProcessor implements IContentAssistProcessor {
  protected IFile jetFile;
  protected JETTextEditor jetEditor;
  protected IJavaProject javaProject;
  protected JETNature jetNature;
  private TemplateEngine fTemplateEngine;
  private CompletionProposalComparator fComparator;
  private char[] fProposalAutoActivationSet;
  
  /**
   * Constructor for JETTemplateCompletionProcessor.
   * @param editor JETTextEditor
   */
  public JETTemplateCompletionProcessor(JETTextEditor editor) {
    this.jetEditor = editor;
    setCompletionProposalAutoActivationCharacters(".".toCharArray());
    jetFile = ((IFileEditorInput) editor.getEditorInput()).getFile();
    javaProject = JavaCore.create(getProject());
    jetNature = JETNature.getRuntime(getProject());
    TemplateContextType contextType = JavaPlugin.getDefault().getTemplateContextRegistry().getContextType("java"); //$NON-NLS-1$
    if (contextType == null) {
      contextType = new JavaContextType();
      JavaPlugin.getDefault().getTemplateContextRegistry().addContextType(contextType);
    }
    if (contextType != null)
      fTemplateEngine = new TemplateEngine(contextType);
    fComparator= new CompletionProposalComparator();
  }

  /**
   * Sets this processor's set of characters triggering the activation of the
   * completion proposal computation.
   * 
   * @param activationSet the activation set
   */
  public void setCompletionProposalAutoActivationCharacters(char[] activationSet) {
    fProposalAutoActivationSet= activationSet;
  }
  
  /**
   * Method getProject.
   * @return IProject
   */
  private IProject getProject() {
    if (jetFile == null)
      return null;
    return jetFile.getProject();
  }

  /**
   * Method getJavaProject.
   * @return IJavaProject
   */
  protected IJavaProject getJavaProject() {
    if (javaProject == null)
      javaProject = JavaCore.create(getProject());
    return javaProject;
  }

  /**
   * Method getJETNature.
   * @return JETNature
   */
  protected JETNature getJETNature() {
    if (jetNature == null)
      jetNature = JETNature.getRuntime(getProject());
    return jetNature;
  }

  /**
   * Method getPackageContainer.
   * @param root IContainer
   * @param packagename String
   * @return IContainer
   */
  private IContainer getPackageContainer(IContainer root, String packagename) {
    for (StringTokenizer stringTokenizer = new StringTokenizer(packagename, "."); stringTokenizer.hasMoreTokens();) {
      IFolder newContainer = root.getFolder(new Path(stringTokenizer.nextToken()));
      root = newContainer;
    }
    return root;
  }

  /**
   * @param compiler
   * @param javaSource String
   * @param viewer ITextViewer
   * @param offset
   * @return int
   */
  protected int findJavaMatchingOffset(JETCompilerExt compiler, String javaSource, ITextViewer viewer, int offset) {
    IDocument document = viewer.getDocument();
    String jetContent = document.get();

    JETCompilerExt.Range jetRange = compiler.getJETRange(offset, jetFile.getFullPath().toString());
    JETCompilerExt.Range javaRange = compiler.getJavaRange(jetRange);

    int javaOffset = (javaRange == null) ? -1 : javaRange.start + (offset - jetRange.start);
    if (javaRange == null)
      return -1;
    /*String firtsStr = new StringBuffer().
       append(javaSource.charAt(javaOffset)).
       append(javaSource.charAt(javaOffset + 1)).
       append(javaSource.charAt(javaOffset + 2)).
       append(javaSource.charAt(javaOffset + 3)).
       append(javaSource.charAt(javaOffset + 4)).
       append(javaSource.charAt(javaOffset + 5)).
       append(javaSource.charAt(javaOffset + 6)).
       append(javaSource.charAt(javaOffset + 7)).
       append(javaSource.charAt(javaOffset + 8)).toString();

    String firtsjetStr = new StringBuffer().
      append(jetContent.charAt(offset-3)).
      append(jetContent.charAt(offset-2)).
      append(jetContent.charAt(offset-1)).
      append(jetContent.charAt(offset)).
      append(jetContent.charAt(offset + 1)).
      append(jetContent.charAt(offset + 2)).
      append(jetContent.charAt(offset + 3)).
      append(jetContent.charAt(offset + 4)).
      append(jetContent.charAt(offset + 5)).
      append(jetContent.charAt(offset + 6)).
      append(jetContent.charAt(offset + 7)).
      append(jetContent.charAt(offset + 8)).toString();*/

    return javaOffset;
  }

  /**
   * @see IContentAssistProcessor#computeCompletionProposals(ITextViewer, int)
   */
  public ICompletionProposal[] computeCompletionProposals(ITextViewer viewer, int offset) {
    ICompletionProposal[] results;
    IProject project = getProject();
    try {
      if (getJavaProject() == null || getJETNature() == null)
        return results = new ICompletionProposal[0];
      IContainer parent = jetFile.getParent();
      while (parent != null) {
        if (jetNature.getTemplateContainers().contains(parent))
          break;
        parent = parent.getParent();
      }
      if (parent == null) {
        jetNature.getTemplateContainers().add(jetFile.getParent());
        jetNature.setTemplateContainers(jetNature.getTemplateContainers());
      }
      IContainer javaSourceContainer = jetNature.getJavaSourceContainer();
      if (javaSourceContainer == null) {
        IPackageFragmentRoot[] fragmentRoots = javaProject.getPackageFragmentRoots();
        for (int i = 0; i < fragmentRoots.length; i++) {
          IPackageFragmentRoot fragmentRoot = fragmentRoots[i];
          if (fragmentRoot.getKind() == IPackageFragmentRoot.K_SOURCE) {
            jetNature.setJavaSourceContainer((IContainer) fragmentRoot.getCorrespondingResource());
            break;
          }
        }
      }

      // Ensure the template java class is generated
      //jetEditor.getSite().getPage().saveEditor(jetEditor, false);
      String uri = jetFile.getLocation().toFile().getAbsoluteFile().toURL().toString();
      String jetSource = viewer.getDocument().get();
      ByteArrayInputStream is = new ByteArrayInputStream(jetSource.getBytes());
      JETCompilerExt jetCompiler = new JETCompilerExt(uri, is);
      jetCompiler.parse();
      ByteArrayOutputStream arrayOutputStream = new ByteArrayOutputStream();
      jetCompiler.generate(arrayOutputStream);

      JETSkeleton skeleton = jetCompiler.getSkeleton();
      IContainer container = getPackageContainer(jetNature.getJavaSourceContainer(), skeleton.getPackageName());
      IPackageFragmentRoot[] roots = getJavaProject().getPackageFragmentRoots();
      ICompilationUnit compilationUnit = null;

      for (int i = 0; i < roots.length; i++) {
        IPackageFragmentRoot fragmentRoot = roots[i];
        if (fragmentRoot.getKind() == IPackageFragmentRoot.K_SOURCE) {
          IPackageFragment packageFragment = fragmentRoot.getPackageFragment(skeleton.getPackageName());
          if (packageFragment != null && packageFragment.exists()) {
            compilationUnit = packageFragment.createCompilationUnit(skeleton.getClassName() + ".java", arrayOutputStream
                .toString(), true, new NullProgressMonitor());
            break;
          }
        }
      }

      int javaOffset = findJavaMatchingOffset(jetCompiler, arrayOutputStream.toString(), viewer, offset);
      if (javaOffset == -1)
        return null;

      CompletionProposalCollector collector = new CompletionProposalCollector(compilationUnit);
      
      Point selection = viewer.getSelectedRange();
      if (selection.y > 0)
        collector.setReplacementLength(selection.y);

      compilationUnit.codeComplete(javaOffset, collector);
      results= collector.getJavaCompletionProposals();

      if (fTemplateEngine != null) {
        fTemplateEngine.reset();
        fTemplateEngine.complete(viewer, offset, compilationUnit);

        TemplateProposal[] templateResults = fTemplateEngine.getResults();

        // update relevance of template proposals that match with a keyword
        IJavaCompletionProposal[] keyWordResults = collector.getKeywordCompletionProposals();
        for (int i = 0; i < keyWordResults.length; i++) {
          String keyword = keyWordResults[i].getDisplayString();
          for (int k = 0; k < templateResults.length; k++) {
            TemplateProposal curr = templateResults[k];
            if (keyword.equals(curr.getTemplate().getName())) {
              curr.setRelevance(keyWordResults[i].getRelevance());
            }
          }
        }

        // concatenate arrays
        ICompletionProposal[] total = new ICompletionProposal[results.length + templateResults.length];
        System.arraycopy(templateResults, 0, total, 0, templateResults.length);
        System.arraycopy(results, 0, total, templateResults.length, results.length);
        results = total;
      }

      viewer.setSelectedRange(offset, 0);
      viewer.revealRange(offset, 10);
      for (int i = 0; i < results.length; i++) {
        if (results[i] instanceof JavaCompletionProposal) {
          JavaCompletionProposal proposal = (JavaCompletionProposal) results[i];
          proposal.setReplacementOffset(offset);
        }
        if (results[i] instanceof LazyJavaCompletionProposal) {
          LazyJavaCompletionProposal proposal = (LazyJavaCompletionProposal) results[i];
          proposal.setReplacementOffset(offset);
        }        
      }      
      return order(results);
    } catch (CoreException e) {
      JETTemplatesUIPlugin.INSTANCE.log(e);
    } catch (MalformedURLException e) {
      JETTemplatesUIPlugin.INSTANCE.log(e);
    }
    return null;
  }

  /**
   * Order the given proposals.
   * @param proposals ICompletionProposal[]
   * @return ICompletionProposal[]
   */
  private ICompletionProposal[] order(ICompletionProposal[] proposals) {
    Arrays.sort(proposals, fComparator);
    return proposals;
  }

  public char[] getCompletionProposalAutoActivationCharacters() {
    return fProposalAutoActivationSet;
  }

  public IContextInformation[] computeContextInformation(ITextViewer viewer, int offset) {
    // TODO Auto-generated method stub
    return null;
  }

  public char[] getContextInformationAutoActivationCharacters() {
    // TODO Auto-generated method stub
    return null;
  }

  public String getErrorMessage() {
    // TODO Auto-generated method stub
    return null;
  }

  public IContextInformationValidator getContextInformationValidator() {
    // TODO Auto-generated method stub
    return null;
  }
}