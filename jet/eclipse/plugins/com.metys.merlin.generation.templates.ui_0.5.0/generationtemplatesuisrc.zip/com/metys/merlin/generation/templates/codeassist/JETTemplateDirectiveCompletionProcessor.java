/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.codeassist;

import java.util.ArrayList;
import java.util.Stack;

import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.contentassist.CompletionProposal;
import org.eclipse.jface.text.contentassist.ICompletionProposal;
import org.eclipse.jface.text.contentassist.IContentAssistProcessor;
import org.eclipse.jface.text.contentassist.IContextInformation;
import org.eclipse.jface.text.contentassist.IContextInformationValidator;

import com.metys.merlin.generation.templates.util.JETDocumentReader;
import com.metys.merlin.generation.templates.util.keywords.JETTemplateDirectiveKeywords;

/**
 * @author jcheuoua
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 * @version $Revision: 1.2 $
 */
public class JETTemplateDirectiveCompletionProcessor implements IContentAssistProcessor {

	public JETTemplateDirectiveCompletionProcessor() {
	}

	/**
	 * Method getAllWords.
	 * @param c char
	 * @param reader JETDocumentReader
	 * @return String[]
	 */
	private String[] getAllWords(char c, JETDocumentReader reader) {
		ArrayList all = new ArrayList(20);
		char currChar = c;
		currChar = trimBlanksBackward(reader, currChar);
		for (boolean done = false; !done;) {
			Stack stack = new Stack();
			for (; currChar != '\uFFFF' && !Character.isWhitespace(currChar); currChar = reader.readBackward())
				stack.push(new Character(currChar));

			String s;
			for (s = new String(); !stack.empty(); s = s + ((Character) stack.pop()).toString());
			int jspPt = s.indexOf("<%@");
			if (jspPt >= 0) {
				s = s.substring(jspPt + 3);
				done = true;
			}
			all.add(s);
			currChar = trimBlanksBackward(reader, currChar);
			if (currChar == '\uFFFF' || currChar == '@')
				done = true;
		}

		return (String[]) all.toArray(new String[all.size()]);
	}

	/**
	 * Method trimBlanksBackward.
	 * @param reader JETDocumentReader
	 * @param currChar char
	 * @return char
	 */
	private char trimBlanksBackward(JETDocumentReader reader, char currChar) {
		for (; currChar != '\uFFFF' && Character.isWhitespace(currChar); currChar = reader.readBackward());
		return currChar;
	}

	/**
	 * Method computeCompletionProposals.
	 * @param viewer ITextViewer
	 * @param documentOffset int
	 * @return ICompletionProposal[]
	 * @see org.eclipse.jface.text.contentassist.IContentAssistProcessor#computeCompletionProposals(ITextViewer, int)
	 */
	public ICompletionProposal[] computeCompletionProposals(ITextViewer viewer, int documentOffset) {
		org.eclipse.jface.text.IDocument doc = viewer.getDocument();
		JETDocumentReader reader = new JETDocumentReader(doc, documentOffset);
		char c = reader.readBackward();
		ICompletionProposal result[] = (ICompletionProposal[]) null;
		String allWords[] = getAllWords(c, reader);
		if (Character.isSpaceChar(c)) {
			String nonTagWords[] =
				JETTemplateDirectiveKeywords.getInnerKeywordsFor(allWords[allWords.length - 1]);
			result = new ICompletionProposal[nonTagWords.length];
			for (int i = 0; i < nonTagWords.length; i++)
				result[i] = new CompletionProposal(nonTagWords[i], documentOffset, 0, nonTagWords[i].length());

		} else if (c == '@') {
			String words[] = JETTemplateDirectiveKeywords.getTags();
			result = new ICompletionProposal[words.length];
			for (int i = 0; i < words.length; i++)
				result[i] =
					new CompletionProposal(
						words[i].substring(allWords[0].length()),
						documentOffset,
						0,
						words[i].length() - allWords[0].length(),
						null,
						words[i],
						null,
						null);

		} else if (Character.isLetter(c)) {
			String words[];
			if (allWords.length > 1)
				words =
					JETTemplateDirectiveKeywords.getNonTagsKeywordsWithPrefix(
						allWords[allWords.length - 1],
						allWords[0]);
			else
				words = JETTemplateDirectiveKeywords.getTagsWithPrefix(allWords[0]);
			result = new ICompletionProposal[words.length];
			for (int i = 0; i < words.length; i++)
				result[i] =
					new CompletionProposal(
						words[i].substring(allWords[0].length()),
						documentOffset,
						0,
						words[i].length() - allWords[0].length(),
						null,
						words[i],
						null,
						null);

		}
		return result;
	}

	/**
	 * Method computeContextInformation.
	 * @param viewer ITextViewer
	 * @param documentOffset int
	 * @return IContextInformation[]
	 * @see org.eclipse.jface.text.contentassist.IContentAssistProcessor#computeContextInformation(ITextViewer, int)
	 */
	public IContextInformation[] computeContextInformation(ITextViewer viewer, int documentOffset) {
		return null;
	}

	/**
	 * Method getCompletionProposalAutoActivationCharacters.
	 * @return char[]
	 * @see org.eclipse.jface.text.contentassist.IContentAssistProcessor#getCompletionProposalAutoActivationCharacters()
	 */
	public char[] getCompletionProposalAutoActivationCharacters() {
		return null;
	}

	/**
	 * Method getContextInformationAutoActivationCharacters.
	 * @return char[]
	 * @see org.eclipse.jface.text.contentassist.IContentAssistProcessor#getContextInformationAutoActivationCharacters()
	 */
	public char[] getContextInformationAutoActivationCharacters() {
		return null;
	}

	/**
	 * Method getContextInformationValidator.
	 * @return IContextInformationValidator
	 * @see org.eclipse.jface.text.contentassist.IContentAssistProcessor#getContextInformationValidator()
	 */
	public IContextInformationValidator getContextInformationValidator() {
		return null;
	}

	/**
	 * Method getErrorMessage.
	 * @return String
	 * @see org.eclipse.jface.text.contentassist.IContentAssistProcessor#getErrorMessage()
	 */
	public String getErrorMessage() {
		return null;
	}
}
