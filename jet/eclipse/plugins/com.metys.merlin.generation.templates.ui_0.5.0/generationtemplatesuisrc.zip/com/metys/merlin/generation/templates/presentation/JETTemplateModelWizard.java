/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.presentation;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.emf.codegen.jet.JETNature;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.edit.ui.provider.ExtendedImageRegistry;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.pde.core.plugin.IPluginModelBase;
import org.eclipse.pde.internal.core.PDECore;
import org.eclipse.pde.internal.core.PluginModelManager;
import org.eclipse.pde.internal.ui.wizards.PluginSelectionDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.actions.WorkspaceModifyOperation;
import org.eclipse.ui.dialogs.ContainerSelectionDialog;
import org.eclipse.ui.dialogs.WizardNewFileCreationPage;
import org.eclipse.ui.part.FileEditorInput;
import org.eclipse.ui.part.ISetSelectionTarget;
import org.osgi.framework.Bundle;

import com.metys.merlin.generation.templates.GIFTemplate;
import com.metys.merlin.generation.templates.JETTemplate;
import com.metys.merlin.generation.templates.JETTemplateContainer;
import com.metys.merlin.generation.templates.JETTemplateFactory;
import com.metys.merlin.generation.templates.JETTemplatePackage;
import com.metys.merlin.generation.templates.TextJETTemplate;
import com.metys.merlin.generation.templates.provider.JETTemplatesUIPlugin;

/**
 * This is a simple wizard for creating a new model file. <!-- begin-user-doc --> <!-- end-user-doc -->
 * 
 * @generated NOT
 * @author Jo�l
 * @version $Revision: 1.2 $
 */
public class JETTemplateModelWizard extends Wizard implements INewWizard {
  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  public static final String copyright = "(c) METYS SOFTWARE 2004";

  /**
   * This caches an instance of the model package. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  protected JETTemplatePackage jetTemplatePackage = JETTemplatePackage.eINSTANCE;

  /**
   * This caches an instance of the model factory. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  protected JETTemplateFactory jetTemplateFactory = jetTemplatePackage.getJETTemplateFactory();

  /**
   * This is the file creation page. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  protected JETTemplateModelWizardNewFileCreationPage newFileCreationPage;

  protected DetailsPage detailsPage;

  protected JETPluginChooserPage jetPluginChooserPage;

  protected JETProjectChooserPage jetProjectChooserPage;

  /**
   * Remember the selection during initialization for populating the default container. <!-- begin-user-doc --> <!--
   * end-user-doc -->
   * 
   * @generated
   */
  protected IStructuredSelection selection;

  /**
   * Remember the workbench during initialization. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  protected IWorkbench workbench;

  protected static final int JAVAJETPLUGIN = 0;

  protected static final int JAVAJETPROJECT = 1;

  protected static final int NOTHING = 2;

  protected int whichModel = 0;

  /**
   * This just records the information. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   * @param workbench IWorkbench
   * @param selection IStructuredSelection
   * @see org.eclipse.ui.IWorkbenchWizard#init(IWorkbench, IStructuredSelection)
   */
  public void init(IWorkbench workbench, IStructuredSelection selection) {
    this.workbench = workbench;
    this.selection = selection;
    setWindowTitle(JETTemplatesUIPlugin.INSTANCE.getString("_UI_Wizard_label"));
    setDefaultPageImageDescriptor(ExtendedImageRegistry.INSTANCE.getImageDescriptor(JETTemplatesUIPlugin.INSTANCE
        .getImage("full/wizban/NewJETTemplate")));
  }

  /**
   * Method containsJETFiles.
   * @param directory File
   * @return boolean
   */
  public boolean containsJETFiles(File directory) {
    File[] subFiles = directory.listFiles();
    for (int i = 0; i < subFiles.length; i++) {
      File subFile = subFiles[i];
      if (subFile.getName().equals("emf-merge.xml") || subFile.getName().equals(".jetinc")
          || subFile.getName().endsWith(".javajet") || subFile.getName().endsWith(".propertiesjet")
          || subFile.getName().endsWith(".xmljet"))
        return true;
    }
    for (int i = 0; i < subFiles.length; i++) {
      File subFile = subFiles[i];
      if (subFile.isDirectory() && containsJETFiles(subFile)) {
        return true;
      }
    }
    return false;
  }

//  public List getTemplateContainers(File directory) {
//    List containers = new ArrayList();
//    if (containsJETFiles(directory))
//      containers.add(directory);
//    else {
//      File[] subFiles = directory.listFiles();
//      for (int i = 0; i < subFiles.length; i++) {
//        File subFile = subFiles[i];
//        if (subFile.isDirectory())
//          containers.addAll(getTemplateContainers(subFile));
//      }
//    }
//    return containers;
//  }
//
//  public List getTemplateContainers(IPluginModelBase pluginModelBase) {
//    File root = new File(pluginModelBase.getInstallLocation());
//    if (root.isDirectory())
//      return getTemplateContainers(root);
//    return Collections.EMPTY_LIST;
//  }

  /**
   * Create a new model. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated NOT
   * @return List
   */
  protected List createInitialModels() {
    List initialModels = new ArrayList();
    if (whichModel == JAVAJETPLUGIN) {
      Iterator pluginExtensions = jetPluginChooserPage.getPluginExtensions().iterator();
      while (pluginExtensions.hasNext()) {
        IPluginModelBase pluginModelBase = (IPluginModelBase) pluginExtensions.next();
        JETTemplateContainer templateContainer = JETTemplateFactory.eINSTANCE.createJETTemplateContainer();
        initialModels.add(templateContainer);
        templateContainer.setJavaJETSource(pluginModelBase.getPluginBase().getId());
        // 
        File container = new File(pluginModelBase.getInstallLocation());
        fetchTemplateFilesRecursively(templateContainer, new FileWrapper(container));        
      }
    } else if (whichModel == JAVAJETPROJECT) {
      Iterator javaProjects = jetProjectChooserPage.getJavaJETProjects().iterator();
      while (javaProjects.hasNext()) {
        IProject javaProject = (IProject) javaProjects.next();
        JETTemplateContainer templateContainer = JETTemplateFactory.eINSTANCE.createJETTemplateContainer();
        initialModels.add(templateContainer);
        templateContainer.setJavaJETSource(javaProject.getName());
        JETNature jetNature = JETNature.getRuntime(javaProject);
        Iterator templateContainers = jetNature.getTemplateContainers().iterator();
        while (templateContainers.hasNext()) {
          Object templateContainerDir = templateContainers.next();
          IContainer container = null;
          if (templateContainerDir instanceof IContainer) {
            container = (IContainer) templateContainerDir;
          } else if (templateContainerDir instanceof URI) {
            container = (IContainer) javaProject.findMember(new Path(((URI) templateContainerDir).toString()));
          }
          fetchTemplateFilesRecursively(templateContainer, new FileWrapper(container));
        }
      }
    }
    return initialModels;
  }

  /**
   * @param templateContainer
   * @param container
   */
  private void fetchTemplateFilesRecursively(JETTemplateContainer templateContainer, FileWrapper container) {
    FileWrapper[] members = container.members();
    if (members == null)
      return;
    for (int i = 0; i < members.length; i++) {
      FileWrapper fileWrapper = members[i];
      if (fileWrapper.isFile()) {
        JETTemplate jetTemplate = null;
        if (fileWrapper.hasExtension("javajet")) {
          jetTemplate = JETTemplateFactory.eINSTANCE.createJavaJETTemplate();
          IProject modelFileProject = getModelFile().getProject();
          if (modelFileProject != null) {
            IJavaProject javaProject = JavaCore.create(modelFileProject);
            if (javaProject.exists()) {
              boolean found = false;
              try {
                IPackageFragmentRoot[] fragmentRoots = javaProject.getPackageFragmentRoots();
                for (int j = 0; j < fragmentRoots.length; j++) {
                  IPackageFragmentRoot fragmentRoot = fragmentRoots[j];
                  if (fragmentRoot.getKind() == IPackageFragmentRoot.K_SOURCE) {
                    found = true;
                    jetTemplate.setOutputDirectoryPath(fragmentRoot.getCorrespondingResource().getFullPath().toPortableString());
                    break;
                  }
                }
              } catch (JavaModelException jme) {
                found = false;
              }
              if (!found) {
                jetTemplate.setOutputDirectoryPath(modelFileProject.getFullPath().toPortableString());
              }
            } else {
              jetTemplate.setOutputDirectoryPath(modelFileProject.getFullPath().toPortableString());
            }
          }
        }
        else if (fileWrapper.getName().endsWith("jet")) {
          jetTemplate = JETTemplateFactory.eINSTANCE.createTextJETTemplate();
          String name = fileWrapper.getName();
          int dotIndex = name.lastIndexOf(".");
          String baseName = name.substring(0, dotIndex);
          String extension = name.substring(dotIndex+1);            
          name = baseName + "." + extension.substring(0, extension.indexOf("jet"));
          ((TextJETTemplate) jetTemplate).setOutputFileName(name);
          IProject modelFileProject = getModelFile().getProject();
          if (modelFileProject != null) {
            jetTemplate.setOutputDirectoryPath(modelFileProject.getFullPath().toPortableString());
          }
        }
        else if (fileWrapper.hasExtension("gif")) {
          jetTemplate = JETTemplateFactory.eINSTANCE.createGIFTemplate();
          String name = fileWrapper.getName();
          name = name.replaceFirst(".gif", "");
          ((GIFTemplate) jetTemplate).setFileSuffix(name);
          IProject modelFileProject = getModelFile().getProject();
          if (modelFileProject != null) {
            jetTemplate.setOutputDirectoryPath(modelFileProject.getFullPath().toPortableString());
          }
        }
        if (jetTemplate != null) {
          templateContainer.getJetTemplates().add(jetTemplate);
          jetTemplate.setTemplateFilePath(fileWrapper.getFullPath().toPortableString());
        }
      } else if (fileWrapper.isContainer()) {
        fetchTemplateFilesRecursively(templateContainer, fileWrapper);
      }
    }
  }

  /**
   */
  class FileWrapper {
    File file;

    IResource resource;

    /**
     * Constructor for FileWrapper.
     * @param file File
     */
    FileWrapper(File file) {
      this.file = file;
    }

    /**
     * Constructor for FileWrapper.
     * @param resource IResource
     */
    FileWrapper(IResource resource) {
      this.resource = resource;
    }

    /**
     * Method isContainer.
     * @return boolean
     */
    boolean isContainer() {
      if (file != null)
        return file.isDirectory();
      return resource instanceof IContainer;
    }

    /**
     * Method isFile.
     * @return boolean
     */
    boolean isFile() {
      if (file != null)
        return file.isFile();
      return resource.getType() == IResource.FILE;
    }

    /**
     * Method getName.
     * @return String
     */
    String getName() {
      if (file != null)
        return file.getName();
      return resource.getName();
    }

    /**
     * Method hasExtension.
     * @param extension String
     * @return boolean
     */
    boolean hasExtension(String extension) {
      if (file != null)
        return file.getName().endsWith("." + extension);
      return resource.getFileExtension().equals(extension);
    }

    /**
     * Method getFullPath.
     * @return IPath
     */
    IPath getFullPath() {
      if (file != null)
        return new Path(file.getAbsolutePath());
      return resource.getFullPath();
    }

    /**
     * Method getParent.
     * @return FileWrapper
     */
    FileWrapper getParent() {
      if (file != null)
        return new FileWrapper(file.getParentFile());
      return new FileWrapper(resource.getParent());
    }

    /**
     * Method members.
     * @return FileWrapper[]
     */
    FileWrapper[] members() {
      if (!isContainer())
        return new FileWrapper[0];
      if (file != null) {
        File[] files = file.listFiles();
        int length = files == null ? 0 : files.length;
        FileWrapper[] members = new FileWrapper[length];
        for (int i = 0; i < length; i++) {
          members[i] = new FileWrapper(files[i]);
        }
        return members;
      }
      IResource[] resources = null;
      try {
        resources = ((IContainer) resource).members();
      } catch (CoreException e) {
        JETTemplatesUIPlugin.INSTANCE.log(e);
      }
      int length = resources == null ? 0 : resources.length;
      FileWrapper[] members = new FileWrapper[length];
      for (int i = 0; i < length; i++) {
        members[i] = new FileWrapper(resources[i]);
      }
      return members;
    }
  }

  /**
   * Do the work after everything is specified. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated NOT
   * @return boolean
   * @see org.eclipse.jface.wizard.IWizard#performFinish()
   */
  public boolean performFinish() {
    return performFinish(true);
  }

  /**
   * Do the work after everything is specified. Open the editor only if asked <!-- begin-user-doc --> <!-- end-user-doc
   * -->
   * @param openEditor boolean
   * @return boolean
   */
  protected boolean performFinish(boolean openEditor) {
    try {
      // Remember the file.
      //
      final IFile modelFile = getModelFile();
      // Do the work within an operation.
      //
      WorkspaceModifyOperation operation = new WorkspaceModifyOperation() {
        protected void execute(IProgressMonitor progressMonitor) {
          try {
            // Create a resource set
            //
            ResourceSet resourceSet = new ResourceSetImpl();
            // Get the URI of the model file.
            //
            URI fileURI = URI.createPlatformResourceURI(modelFile.getFullPath().toString());
            // Create a resource for this file.
            //
            Resource resource = resourceSet.createResource(fileURI);
            // Add the initial model object to the contents.
            //
            Iterator rootObjects = createInitialModels().iterator();
            while (rootObjects.hasNext()) {
              resource.getContents().add(rootObjects.next());
            }
            // Save the contents of the resource to the file system.
            //
            Map options = new HashMap();
            options.put(XMLResource.OPTION_ENCODING, "UTF-8");
            resource.save(options);
          } catch (Exception exception) {
            JETTemplatesUIPlugin.INSTANCE.log(exception);
          } finally {
            progressMonitor.done();
          }
        }
      };
      getContainer().run(false, false, operation);
      // Select the new file resource in the current view.
      //
      IWorkbenchWindow workbenchWindow = workbench.getActiveWorkbenchWindow();
      IWorkbenchPage page = workbenchWindow.getActivePage();
      final IWorkbenchPart activePart = page.getActivePart();
      if (activePart instanceof ISetSelectionTarget) {
        final ISelection targetSelection = new StructuredSelection(modelFile);
        getShell().getDisplay().asyncExec(new Runnable() {
          public void run() {
            ((ISetSelectionTarget) activePart).selectReveal(targetSelection);
          }
        });
      }
      // Open an editor on the new file on demand.
      //
      if (openEditor) {
        try {
          page.openEditor(new FileEditorInput(modelFile), workbench.getEditorRegistry().getDefaultEditor(
              modelFile.getFullPath().toString()).getId());
        } catch (PartInitException exception) {
          MessageDialog.openError(workbenchWindow.getShell(), JETTemplatesUIPlugin.INSTANCE
              .getString("_UI_OpenEditorError_label"), exception.getMessage());
          return false;
        }
      }
      return true;
    } catch (Exception exception) {
      JETTemplatesUIPlugin.INSTANCE.log(exception);
      return false;
    }
  }

  /**
   * This is the one page of the wizard. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   * @author Jo�l
   * @version $Revision: 1.2 $
   */
  public class JETTemplateModelWizardNewFileCreationPage extends WizardNewFileCreationPage {
    /**
     * Remember the model file. <!-- begin-user-doc --> <!-- end-user-doc -->
     * 
     * @generated
     */
    protected IFile modelFile;

    /**
     * Pass in the selection. <!-- begin-user-doc --> <!-- end-user-doc -->
     * 
     * @generated
     * @param pageId String
     * @param selection IStructuredSelection
     */
    public JETTemplateModelWizardNewFileCreationPage(String pageId, IStructuredSelection selection) {
      super(pageId, selection);
    }

    /**
     * The framework calls this to see if the file is correct. <!-- begin-user-doc --> <!-- end-user-doc -->
     * 
     * @generated NOT
     * @return boolean
     */
    protected boolean validatePage() {
      if (super.validatePage()) {
        // Make sure the file ends in ".jettemplate", ".jettemplate",
        // ".xmljet" or ".propertiesjet".
        //
        String enteredExt = new Path(getFileName()).getFileExtension();
        if (enteredExt == null || (!enteredExt.equals("jettemplate"))) {
          setErrorMessage(JETTemplatesUIPlugin.INSTANCE.getString("_WARN_FilenameExtension",
              new Object[] { "jettemplate" }));
          return false;
        } else {
          return true;
        }
      } else {
        return false;
      }
    }

    /**
     * Store the dialog field settings upon completion. <!-- begin-user-doc --> <!-- end-user-doc -->
     * 
     * @generated
     * @return boolean
     */
    public boolean performFinish() {
      modelFile = getModelFile();
      return true;
    }

    /**
     * <!-- begin-user-doc --> <!-- end-user-doc -->
     * 
     * @generated
     * @return IFile
     */
    public IFile getModelFile() {
      return modelFile == null ? ResourcesPlugin.getWorkspace().getRoot().getFile(
          getContainerFullPath().append(getFileName())) : modelFile;
    }
  }

  /**
   * A page that allows JET Template Model to be created from a JETProject
   * @author Jo�l
   * @version $Revision: 1.2 $
   */
  public class DetailsPage extends WizardPage {
    protected Button loadFromJETProject;

    protected Button loadFromJETPlugin;

    protected Button loadNothing;

    /**
     * Constructor for DetailsPage.
     * @param pageId String
     */
    public DetailsPage(String pageId) {
      super(pageId);
    }

    public void chooseJavaJETProject() {
      whichModel = JAVAJETPROJECT;
      jetPluginChooserPage.setPageComplete(true);
      jetProjectChooserPage.setPageComplete(jetProjectChooserPage.isPageComplete());
      setPageComplete(true);
    }

    public void chooseJavaJETPlugin() {
      whichModel = JAVAJETPLUGIN;
      jetPluginChooserPage.setPageComplete(jetPluginChooserPage.isPageComplete());
      jetProjectChooserPage.setPageComplete(true);
      setPageComplete(true);
    }

    public void chooseNothing() {
      whichModel = NOTHING;
      jetPluginChooserPage.setPageComplete(true);
      jetProjectChooserPage.setPageComplete(true);
      setPageComplete(true);
    }

    /**
     * Method createControl.
     * @param parent Composite
     * @see org.eclipse.jface.dialogs.IDialogPage#createControl(Composite)
     */
    public void createControl(Composite parent) {
      Composite composite = new Composite(parent, SWT.NONE);
      {
        GridLayout layout = new GridLayout();
        layout.numColumns = 1;
        layout.verticalSpacing = 12;
        composite.setLayout(layout);

        GridData data = new GridData();
        data.verticalAlignment = GridData.FILL;
        data.grabExcessVerticalSpace = true;
        data.horizontalAlignment = GridData.FILL;
        composite.setLayoutData(data);
      }

      loadFromJETPlugin = new Button(composite, SWT.RADIO);
      if (whichModel == JAVAJETPLUGIN) {
        loadFromJETPlugin.setSelection(true);
      }
      loadFromJETPlugin.setText(JETTemplatesUIPlugin.INSTANCE.getString("_UI_LoadFromJETPlugins_label"));
      {
        GridData data = new GridData();
        loadFromJETPlugin.setLayoutData(data);
      }

      loadFromJETPlugin.addSelectionListener(new SelectionAdapter() {
        public void widgetSelected(SelectionEvent event) {
          if (loadFromJETPlugin.getSelection()) {
            chooseJavaJETPlugin();
          }
        }
      });

      loadFromJETProject = new Button(composite, SWT.RADIO);
      if (whichModel == JAVAJETPROJECT) {
        loadFromJETProject.setSelection(true);
      }
      loadFromJETProject.setText(JETTemplatesUIPlugin.INSTANCE.getString("_UI_LoadFromJETProjects_label"));
      {
        GridData data = new GridData();
        loadFromJETProject.setLayoutData(data);
      }

      loadFromJETProject.addSelectionListener(new SelectionAdapter() {
        public void widgetSelected(SelectionEvent event) {
          if (loadFromJETProject.getSelection()) {
            chooseJavaJETProject();
          }
        }
      });

      loadNothing = new Button(composite, SWT.RADIO);
      loadNothing.setText(JETTemplatesUIPlugin.INSTANCE.getString("_UI_CreateEmptyJETTemplatesModel_label"));
      {
        GridData data = new GridData();
        loadNothing.setLayoutData(data);
      }

      loadNothing.addSelectionListener(new SelectionAdapter() {
        public void widgetSelected(SelectionEvent event) {
          if (loadNothing.getSelection()) {
            chooseNothing();
          }
        }
      });

      chooseJavaJETPlugin();
      setControl(composite);
    }
  }

  /**
   * A page that allows JET Template Model to be created from a JETProject
   * @author Jo�l
   * @version $Revision: 1.2 $
   */
  public class JETProjectChooserPage extends WizardPage {
    protected Text javaJETProjectsLocationText;

    protected boolean isDirty = true;

    protected List javaJETProjects = new ArrayList();

    /**
     * Constructor for JETProjectChooserPage.
     * @param pageId String
     */
    public JETProjectChooserPage(String pageId) {
      super(pageId);
      setPageComplete(false);
    }

    /**
     * Method createControl.
     * @param parent Composite
     * @see org.eclipse.jface.dialogs.IDialogPage#createControl(Composite)
     */
    public void createControl(Composite parent) {
      Composite composite = new Composite(parent, SWT.NONE);
      {
        GridLayout layout = new GridLayout();
        layout.numColumns = 2;
        layout.verticalSpacing = 12;
        composite.setLayout(layout);

        GridData data = new GridData();
        data.verticalAlignment = GridData.FILL;
        data.grabExcessVerticalSpace = true;
        data.horizontalAlignment = GridData.FILL;
        composite.setLayoutData(data);
      }

      Label javaJETProjectLocationLabel = new Label(composite, SWT.LEFT);
      {
        javaJETProjectLocationLabel.setText(JETTemplatesUIPlugin.INSTANCE.getString("_UI_JavaJETProjects_label"));

        GridData data = new GridData();
        data.horizontalAlignment = GridData.FILL;
        javaJETProjectLocationLabel.setLayoutData(data);
      }

      Composite buttonComposite = new Composite(composite, SWT.NONE);
      {
        GridData data = new GridData();
        data.horizontalAlignment = GridData.END;
        buttonComposite.setLayoutData(data);

        RowLayout layout = new RowLayout();
        layout.justify = true;
        layout.pack = true;
        layout.spacing = 15;
        buttonComposite.setLayout(layout);
      }
      Button jetProjectsBrowseWorkspaceButton = new Button(buttonComposite, SWT.PUSH);
      jetProjectsBrowseWorkspaceButton.setText(JETTemplatesUIPlugin.INSTANCE.getString("_UI_BrowseWorkspace_label"));

      javaJETProjectsLocationText = new Text(composite, SWT.SINGLE | SWT.BORDER);
      {
        GridData data = new GridData();
        data.horizontalAlignment = GridData.FILL;
        data.grabExcessHorizontalSpace = true;
        data.horizontalSpan = 3;
        javaJETProjectsLocationText.setLayoutData(data);
      }

      javaJETProjectsLocationText.setEditable(false);

      jetProjectsBrowseWorkspaceButton.addSelectionListener(new SelectionAdapter() {
        public void widgetSelected(SelectionEvent event) {
          Collection ecoreModelResources = new ArrayList();
          ContainerSelectionDialog containerSelectionDialog = new ContainerSelectionDialog(JETProjectChooserPage.this
              .getShell(), ResourcesPlugin.getWorkspace().getRoot(), false, JETTemplatesUIPlugin.INSTANCE
              .getString("_UI_SelectJETProjects_label"));

          containerSelectionDialog.open();
          javaJETProjects.clear();
          Object[] result = containerSelectionDialog.getResult();
          if (result != null) {
            StringBuffer text = new StringBuffer();
            for (int i = 0; i < result.length; ++i) {
              IResource resource = (IResource) ResourcesPlugin.getWorkspace().getRoot().findMember((IPath) result[i]);
              IProject project = null;
              if (resource.getType() == IResource.PROJECT)
                project = (IProject) resource;
              if (project != null) {
                IJavaProject javaProject = JavaCore.create(project);
                JETNature jetNature = JETNature.getRuntime(project);
                if (javaProject != null && jetNature != null) {
                  if (text.length() > 0)
                    text.append(",");
                  text.append(resource.getFullPath().toString());
                  javaJETProjects.add(project);
                }
              }
            }
            javaJETProjectsLocationText.setText(text.toString());
            setPageComplete(true);
          }
        }
      });
      setControl(composite);
    }

    /**
     * Method getJavaJETProjects.
     * @return Collection
     */
    public Collection getJavaJETProjects() {
      return javaJETProjects;
    }
  }

  /**
   * A page that allows JET Template Model to be created from a JETProject
   * @author Jo�l
   * @version $Revision: 1.2 $
   */
  public class JETPluginChooserPage extends WizardPage {
    protected Text javaJETPluginLocationText;

    protected boolean isDirty = true;

    protected List pluginExtensions = new ArrayList();

    /**
     * Constructor for JETPluginChooserPage.
     * @param pageId String
     */
    public JETPluginChooserPage(String pageId) {
      super(pageId);
      setPageComplete(false);
    }

    /**
     * Method createControl.
     * @param parent Composite
     * @see org.eclipse.jface.dialogs.IDialogPage#createControl(Composite)
     */
    public void createControl(Composite parent) {
      Composite composite = new Composite(parent, SWT.NONE);
      {
        GridLayout layout = new GridLayout();
        layout.numColumns = 2;
        layout.verticalSpacing = 12;
        composite.setLayout(layout);

        GridData data = new GridData();
        data.verticalAlignment = GridData.FILL;
        data.grabExcessVerticalSpace = true;
        data.horizontalAlignment = GridData.FILL;
        composite.setLayoutData(data);
      }

      Label javaJETProjectLocationLabel = new Label(composite, SWT.LEFT);
      {
        javaJETProjectLocationLabel.setText(JETTemplatesUIPlugin.INSTANCE.getString("_UI_JavaJETPlugins_label"));

        GridData data = new GridData();
        data.horizontalAlignment = GridData.FILL;
        javaJETProjectLocationLabel.setLayoutData(data);
      }

      Composite buttonComposite = new Composite(composite, SWT.NONE);
      {
        GridData data = new GridData();
        data.horizontalAlignment = GridData.END;
        buttonComposite.setLayoutData(data);

        RowLayout layout = new RowLayout();
        layout.justify = true;
        layout.pack = true;
        layout.spacing = 15;
        buttonComposite.setLayout(layout);
      }
      Button jetPluginsBrowseWorkspaceButton = new Button(buttonComposite, SWT.PUSH);
      jetPluginsBrowseWorkspaceButton.setText(JETTemplatesUIPlugin.INSTANCE.getString("_UI_BrowseWorkspace_label"));

      javaJETPluginLocationText = new Text(composite, SWT.SINGLE | SWT.BORDER);
      {
        GridData data = new GridData();
        data.horizontalAlignment = GridData.FILL;
        data.grabExcessHorizontalSpace = true;
        data.horizontalSpan = 3;
        javaJETPluginLocationText.setLayoutData(data);
      }

      javaJETPluginLocationText.setEditable(false);

      jetPluginsBrowseWorkspaceButton.addSelectionListener(new SelectionAdapter() {
        public void widgetSelected(SelectionEvent event) {
          PluginModelManager manager = PDECore.getDefault().getModelManager();
          IPluginModelBase[] allPlugins = manager.getPluginsOnly();
          List filteredList = new ArrayList();
          for (int i = 0; i < allPlugins.length; i++) {
            IPluginModelBase candidate = allPlugins[i];
            Bundle bundle = Platform.getBundle(candidate.getPluginBase().getId());
            if (bundle == null)
              continue;
            File container = new File(candidate.getInstallLocation());
            if (!containsJETFiles(container))
              continue;
            filteredList.add(candidate);
          }
          IPluginModelBase[] filtered = (IPluginModelBase[]) filteredList.toArray(new IPluginModelBase[filteredList
              .size()]);
          PluginSelectionDialog pluginSelectionDialog = new PluginSelectionDialog(JETPluginChooserPage.this.getShell(),
              filtered, false);
          pluginSelectionDialog.open();
          pluginExtensions.clear();
          Object[] result = pluginSelectionDialog.getResult();
          if (result != null) {
            StringBuffer text = new StringBuffer();
            for (int i = 0; i < result.length; i++) {
              IPluginModelBase candidate = (IPluginModelBase) result[i];
              if (text.length() > 0)
                text.append(",");
              text.append(candidate.getPluginBase().getId());
              pluginExtensions.add(candidate);
            }
            javaJETPluginLocationText.setText(text.toString());
            setPageComplete(true);
          }
        }
      });
      setControl(composite);
    }

    /**
     * Method getPluginExtensions.
     * @return Collection
     */
    public Collection getPluginExtensions() {
      return pluginExtensions;
    }
  }

  /**
   * Method getNextPage.
   * @param page IWizardPage
   * @return IWizardPage
   * @see org.eclipse.jface.wizard.IWizard#getNextPage(IWizardPage)
   */
  public IWizardPage getNextPage(IWizardPage page) {
    if (page == detailsPage) {
      switch (whichModel) {
      case JAVAJETPLUGIN: {
        return jetPluginChooserPage;
      }
      case JAVAJETPROJECT: {
        return jetProjectChooserPage;
      }
      case NOTHING: {
        return null;
      }
      }
    } else if (page == jetPluginChooserPage || page == jetProjectChooserPage) {
      return null;
    }

    return super.getNextPage(page);
  }

  /**
   * The framework calls this to create the contents of the wizard. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated NOT
   * @see org.eclipse.jface.wizard.IWizard#addPages()
   */
  public void addPages() {
    // Create a page, set the title, and the initial model file name.
    //
    newFileCreationPage = new JETTemplateModelWizardNewFileCreationPage("Whatever", selection);
    newFileCreationPage.setTitle(JETTemplatesUIPlugin.INSTANCE.getString("_UI_JETTemplateModelWizard_label"));
    newFileCreationPage.setDescription(JETTemplatesUIPlugin.INSTANCE
        .getString("_UI_JETTemplateModelWizard_description"));
    newFileCreationPage.setFileName(JETTemplatesUIPlugin.INSTANCE.getString("_UI_JETTemplateEditorFilenameDefaultBase")
        + ".jettemplate");
    addPage(newFileCreationPage);

    detailsPage = new DetailsPage("Whatever2");
    detailsPage.setTitle(JETTemplatesUIPlugin.INSTANCE.getString("_UI_InitialContents_title"));
    detailsPage.setDescription(JETTemplatesUIPlugin.INSTANCE.getString("_UI_InitialContents_description"));
    addPage(detailsPage);

    jetPluginChooserPage = new JETPluginChooserPage("Whatever5");
    jetPluginChooserPage.setTitle(JETTemplatesUIPlugin.INSTANCE.getString("_UI_LoadFromJETPlugins_title"));
    jetPluginChooserPage.setDescription(JETTemplatesUIPlugin.INSTANCE.getString("_UI_LoadFromJETPlugins_description"));
    addPage(jetPluginChooserPage);

    jetProjectChooserPage = new JETProjectChooserPage("Whatever4");
    jetProjectChooserPage.setTitle(JETTemplatesUIPlugin.INSTANCE.getString("_UI_LoadFromJETProjects_title"));
    jetProjectChooserPage
        .setDescription(JETTemplatesUIPlugin.INSTANCE.getString("_UI_LoadFromJETProjects_description"));
    addPage(jetProjectChooserPage);

    // Try and get the resource selection to determine a current directory
    // for the file dialog.
    //
    if (selection != null && !selection.isEmpty()) {
      // Get the resource...
      //
      Object selectedElement = selection.iterator().next();
      if (selectedElement instanceof IResource) {
        // Get the resource parent, if its a file.
        //
        IResource selectedResource = (IResource) selectedElement;
        if (selectedResource.getType() == IResource.FILE) {
          selectedResource = selectedResource.getParent();
        }
        // This gives us a directory...
        //
        if (selectedResource instanceof IFolder || selectedResource instanceof IProject) {
          // Set this for the container.
          //
          String currentDirectory = selectedResource.getLocation().toOSString();
          newFileCreationPage.setContainerFullPath(selectedResource.getFullPath());
          // Make up a unique new name here.
          //
          String defaultModelBaseFilename = JETTemplatesUIPlugin.INSTANCE
              .getString("_UI_JETTemplateEditorFilenameDefaultBase");
          String defaultModelFilenameExtension = "jettemplate";
          String modelFilename = defaultModelBaseFilename + "." + defaultModelFilenameExtension;
          for (int i = 1; ((IContainer) selectedResource).findMember(modelFilename) != null; ++i) {
            modelFilename = defaultModelBaseFilename + i + "." + defaultModelFilenameExtension;
          }
          newFileCreationPage.setFileName(modelFilename);
        }
      }
    }
  }

  /**
   * Get the file from the page. <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   * @return IFile
   */
  public IFile getModelFile() {
    return newFileCreationPage.getModelFile();
  }

}