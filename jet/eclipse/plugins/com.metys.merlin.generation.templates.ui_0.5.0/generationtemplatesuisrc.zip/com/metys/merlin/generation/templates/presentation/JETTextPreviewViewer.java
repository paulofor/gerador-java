/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * Initial Implementation : Jo�l, 4 mai 2005
 */

package com.metys.merlin.generation.templates.presentation;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.emf.codegen.ecore.genmodel.provider.GenModelItemProviderAdapterFactory;
import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.edit.provider.ComposedAdapterFactory;
import org.eclipse.emf.edit.provider.ReflectiveItemProviderAdapterFactory;
import org.eclipse.emf.edit.provider.resource.ResourceItemProviderAdapterFactory;
import org.eclipse.emf.edit.ui.provider.AdapterFactoryContentProvider;
import org.eclipse.emf.edit.ui.provider.AdapterFactoryLabelProvider;
import org.eclipse.emf.mapping.provider.MappingItemProviderAdapterFactory;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.ui.PreferenceConstants;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.text.Document;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.source.SourceViewer;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.dialogs.ContainerSelectionDialog;
import org.eclipse.ui.dialogs.ResourceSelectionDialog;
import org.eclipse.ui.editors.text.EditorsUI;
import org.eclipse.ui.editors.text.TextSourceViewerConfiguration;
import org.eclipse.ui.forms.ManagedForm;
import org.eclipse.ui.forms.SectionPart;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;
import org.eclipse.ui.forms.widgets.Section;

import bsh.BshClassManager;
import bsh.EvalError;
import bsh.Interpreter;
import bsh.NameSpace;

import com.metys.merlin.generation.templates.JETURLClassLoader;
import com.metys.merlin.generation.templates.JavaClassLoaderFactory;
import com.metys.merlin.generation.templates.jetmapping.JETMappingFactory;
import com.metys.merlin.generation.templates.jetmapping.JETMappingGenerator;
import com.metys.merlin.generation.templates.jetmapping.provider.JETMappingItemProviderAdapterFactory;
import com.metys.merlin.generation.templates.provider.JETTemplateItemProviderAdapterFactory;
import com.metys.merlin.generation.templates.provider.JETTemplatesUIPlugin;

/**
 * @author Jo�l
 */
public class JETTextPreviewViewer extends Viewer {

  private SourceViewer sourceViewer;
  private Object fInput;
  private ScrolledForm sForm;
  
  private Text inputResource = null;
  private Button browseWorkspace = null;
 
  private Tree tree = null;
  private TreeViewer treeViewer = null;
  private ISelection selection;
  private Button fromEObjectRadioButton;
  private Button fromJavaExpressionRadioButton;
  private Text javaExpressionText;
  private Interpreter interpreter;
  
  public JETTextPreviewViewer(Composite parent) {
    Display display = parent.getDisplay();
    FormToolkit formToolkit = new FormToolkit(display);
    sForm = formToolkit.createScrolledForm(parent);
    ManagedForm overviewForm = new ManagedForm(formToolkit, sForm);
    Composite body = sForm.getBody();

    GridLayout layout = new GridLayout();
    layout.numColumns = 1;
    layout.marginWidth = 10;
    layout.horizontalSpacing = 10;
    layout.verticalSpacing = 10;
    body.setLayout(layout);

    createInputArgumentsSection(overviewForm, body, formToolkit);
    createTextViewerSection(overviewForm, body, formToolkit);
    
    overviewForm.initialize();
    overviewForm.refresh();    
    
  }
  
  /**
   * @param mForm
   * @param body
   * @param formToolkit
   */
  private void createInputArgumentsSection(ManagedForm mForm, Composite body, FormToolkit formToolkit) {
    final Section section = formToolkit.createSection(body, Section.TITLE_BAR);
    section.setText("Input Argument"); //$NON-NLS-1$    
    Composite client = formToolkit.createComposite(section);
    GridLayout layout = new GridLayout();
    layout.marginWidth = formToolkit.getBorderStyle() != SWT.NULL ? 0 : 2;
    layout.numColumns = 2;
    client.setLayout(layout);
    
    fromJavaExpressionRadioButton = formToolkit.createButton(client, "Java Expression Input", SWT.RADIO);
    GridData gd = new GridData();
    gd.horizontalSpan = 2;
    fromJavaExpressionRadioButton.setLayoutData(gd);
    
    javaExpressionText = formToolkit.createText(client, "", SWT.BORDER);
    gd = new GridData();
    gd.horizontalSpan = 2;
    gd.grabExcessHorizontalSpace = true;
    gd.horizontalAlignment = GridData.FILL;
    javaExpressionText.setLayoutData(gd);    
    
    fromEObjectRadioButton = formToolkit.createButton(client, "EObject from resource Input", SWT.RADIO);
    gd = new GridData();
    gd.horizontalSpan = 2;
    fromEObjectRadioButton.setLayoutData(gd);
    
    inputResource = formToolkit.createText(client, "<Empty>");
    inputResource.setEditable(false);
    gd = new GridData();
    gd.horizontalSpan = 1;
    gd.grabExcessHorizontalSpace = true;
    gd.horizontalAlignment = GridData.FILL;
    gd.grabExcessVerticalSpace = false;
    inputResource.setLayoutData(gd);
    
    browseWorkspace = formToolkit.createButton(client, "Browse ...", SWT.NONE);
    browseWorkspace.addSelectionListener(new SelectionAdapter() {
      public void widgetSelected(SelectionEvent e) {
        ResourceSelectionDialog resSelectionDialog = 
          new ResourceSelectionDialog(section.getShell(), ResourcesPlugin.getWorkspace().getRoot(), "Select a workspace resource");
        if (resSelectionDialog.open() == ContainerSelectionDialog.OK) {
          Object[] result = resSelectionDialog.getResult();
          if (result.length == 1) {
            String inputFile = ((IResource) result[0]).getFullPath().toString();
            inputResource.setText(inputFile);
            ResourceSet resourceSet = new ResourceSetImpl();
            URI uri = URI.createPlatformResourceURI(inputFile);
            Resource resource = resourceSet.getResource(uri, true);
            if (resource != null)
              treeViewer.setInput(resourceSet);
          }
        }
      }
    });
    
    tree = formToolkit.createTree(client, SWT.BORDER | SWT.SINGLE);
    gd = new GridData();
    gd.horizontalSpan = 2;
    gd.horizontalAlignment = GridData.FILL;
    gd.verticalAlignment = GridData.FILL;
    gd.grabExcessVerticalSpace = true;
    tree.setLayoutData(gd);
    treeViewer = new TreeViewer(tree);
    
    List factories = new ArrayList();
    factories.add(new ResourceItemProviderAdapterFactory());
    factories.add(new JETTemplateItemProviderAdapterFactory());
    factories.add(new JETMappingItemProviderAdapterFactory());
    factories.add(new GenModelItemProviderAdapterFactory());
    factories.add(new MappingItemProviderAdapterFactory());
    factories.add(new ReflectiveItemProviderAdapterFactory());

    AdapterFactory adapterFactory = new ComposedAdapterFactory(factories);
    treeViewer.setContentProvider(new AdapterFactoryContentProvider(adapterFactory));
    treeViewer.setLabelProvider(new AdapterFactoryLabelProvider(adapterFactory));
    
    Button button = formToolkit.createButton(client,"Apply", SWT.PUSH | SWT.FLAT);    
    button.addSelectionListener(new SelectionAdapter() {
      public void widgetSelected(SelectionEvent e) {
        IFileEditorInput fileInput = (IFileEditorInput) fInput;
        IJavaProject javaProject = JavaCore.create(fileInput.getFile().getProject());
        JETMappingGenerator jetMappingGenerator = JETMappingFactory.eINSTANCE.createJETMappingGenerator();
        Object generatedObject = null;
        sourceViewer.setInput(null);
        
        if (fromJavaExpressionRadioButton.getSelection()) {
          // Create the bean shell interpreter
          Interpreter interp = getInterpreter();
          //  Create the bean shell class loader
          ClassLoader classLoader = JavaClassLoaderFactory.getClassLoader(javaProject, getClass().getClassLoader());
          interp.setClassLoader(classLoader);
          interp.getNameSpace().classLoaderChanged();
          try {
            // Run the script and get the result back
            interp.eval("generatedObject = (" + javaExpressionText.getText() + ")");
            generatedObject = interp.get("generatedObject");
          } catch (EvalError error) {
            JETTemplatesUIPlugin.getPlugin().logInError(error, null);
            IDocument document = new Document("/** Cannot generate preview ... an unexpected java expression was provided. Consult the logfile for details.*/");
            sourceViewer.setInput(document);
            return;
          }
        } else {
          TreeItem[] selection = tree.getSelection();
          if (selection.length == 1) {
            generatedObject = selection[0].getData();
          }
        }
        
        if (generatedObject != null) {
          ClassLoader objectClassLoader = generatedObject.getClass().getClassLoader();
          ClassLoader classLoader = JavaClassLoaderFactory.getClassLoader(javaProject, objectClassLoader);
          ClassLoader currentClassLoader = jetMappingGenerator.getClass().getClassLoader();
          ((JETURLClassLoader)classLoader).addClassLoaderDelegate(currentClassLoader);          
          jetMappingGenerator.setClassLoader(classLoader);
          
          String string = jetMappingGenerator.generateText(generatedObject, fileInput.getFile().getLocation().toString(), null, null, new NullProgressMonitor());
          if (string != null) {
            IDocument document = new Document(string);
            sourceViewer.setInput(document);
          } else {
            IDocument document = new Document("/** Cannot generate preview with the given input ... Consult the logfile for details.*/");
            sourceViewer.setInput(document);            
          }
        } else {
          IDocument document = new Document("/** Cannot generate preview ... no input was provided.*/");
          sourceViewer.setInput(document);
        }
      }
    });
    
    SelectionAdapter selectionAdapter = new SelectionAdapter() {
      public void widgetSelected(SelectionEvent e) {
        if (fromJavaExpressionRadioButton.getSelection()) {
          javaExpressionText.setEnabled(true);
          browseWorkspace.setEnabled(false);
          tree.setEnabled(false);
        } else {
          javaExpressionText.setEnabled(false);
          browseWorkspace.setEnabled(true);
          tree.setEnabled(true);
        }
      }
    };
    fromJavaExpressionRadioButton.addSelectionListener(selectionAdapter);
    fromEObjectRadioButton.addSelectionListener(selectionAdapter);
    
    fromJavaExpressionRadioButton.setSelection(true);
    javaExpressionText.setEnabled(true);
    browseWorkspace.setEnabled(false);
    tree.setEnabled(false);
    
    section.setClient(client);
    
    gd = new GridData();
    gd.grabExcessHorizontalSpace = true;
    gd.horizontalAlignment = GridData.FILL;
    gd.verticalAlignment = GridData.BEGINNING;
    section.setLayoutData(gd);
    SectionPart sectionPart = new SectionPart(section);
    mForm.addPart(sectionPart);
  }
  
  /**
   * @param mForm
   * @param body
   * @param formToolkit
   */
  private void createTextViewerSection(ManagedForm mForm, Composite body, FormToolkit formToolkit) {
    Section section = formToolkit.createSection(body, Section.TITLE_BAR);
    section.setText("Preview"); //$NON-NLS-1$
    
    IPreferenceStore store= EditorsUI.getPreferenceStore();
    sourceViewer= new SourceViewer(section, null, SWT.H_SCROLL + SWT.V_SCROLL);    
    sourceViewer.configure(new TextSourceViewerConfiguration(store));    
    sourceViewer.getTextWidget().setFont(JFaceResources.getFont(PreferenceConstants.EDITOR_TEXT_FONT));
    sourceViewer.setEditable(false);
    
    section.setClient(sourceViewer.getControl());
    
    GridData gd = new GridData();
    gd.horizontalAlignment = GridData.FILL;
    gd.verticalAlignment = GridData.FILL;
    gd.grabExcessHorizontalSpace = true;
    gd.grabExcessVerticalSpace = true;
    
    section.setLayoutData(gd);
    SectionPart sectionPart = new SectionPart(section);
    mForm.addPart(sectionPart);
  }
  
  /**
   * @return
   */
  public Interpreter getInterpreter() {
    if (interpreter == null) {
      BshClassManager classManager = new BshClassManager();
      NameSpace namespace = new NameSpace(classManager, "Namespace");
      //  Create the bean shell interpreter
      interpreter = new Interpreter();
      interpreter.setNameSpace(namespace);
    }
    return interpreter;
  }
  
  public Control getControl() {
    return sForm;
  }
  
  public void setInput(Object input) {
    fInput= input;
  }
  
  public Object getInput() {
    return fInput;
  }
  
  public ISelection getSelection() {
    return selection;
  }
  
  public void setSelection(ISelection s, boolean reveal) {
    this.selection = s;
  }
  
  public void refresh() {
  }

}
