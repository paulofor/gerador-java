/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.util.keywords;

import java.util.ArrayList;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * @author jcheuoua
 * 
 * To change the template for this generated type comment go to Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code
 * and Comments
 * @version $Revision: 1.1 $
 */
public class JETTemplateDirectiveKeywords {
  private static String rootTags[] = { "jet", "include" };

  private static String tags[][] = {
      { "jet", "skeleton", "package", "imports", "class", "nlString", "startTag", "endTag", "extends", "implements",
          "methodname", "methodName", "throws", "parameters", "writer" }, { "include", "file" } };

  private static TreeSet keywordSet;

  private static TreeSet innerKeywordSet;

  private static TreeMap innerMap;

  static {
    keywordSet = new TreeSet();
    innerKeywordSet = new TreeSet();
    innerMap = new TreeMap();
    for (int i = 0; i < tags.length; i++)
      keywordSet.add(tags[i][0]);

    for (int i = 0; i < tags.length; i++) {
      TreeSet innerSet = new TreeSet();
      for (int j = 1; j < tags[i].length; j++) {
        innerSet.add(tags[i][j]);
        innerKeywordSet.add(tags[i][j]);
      }

      innerMap.put(tags[i][0], innerSet);
    }

  }

  public JETTemplateDirectiveKeywords() {
  }

  /**
   * Method getAllKeywords.
   * @return String[]
   */
  public static String[] getAllKeywords() {
    return (String[]) keywordSet.toArray(new String[keywordSet.size()]);
  }

  /**
   * Method getAllInnerKeywords.
   * @return String[]
   */
  public static String[] getAllInnerKeywords() {
    return (String[]) innerKeywordSet.toArray(new String[innerKeywordSet.size()]);
  }

  /**
   * Method getTags.
   * @return String[]
   */
  public static String[] getTags() {
    return rootTags;
  }

  /**
   * Method getInnerKeywordsFor.
   * @param key String
   * @return String[]
   */
  public static String[] getInnerKeywordsFor(String key) {
    TreeSet set = (TreeSet) innerMap.get(key);
    if (set == null && key.length() == 0)
      return getTags();
    else
      return (String[]) set.toArray(new String[set.size()]);
  }

  /**
   * Method prefixMatches.
   * @param prefix String
   * @param word String
   * @return boolean
   */
  private static boolean prefixMatches(String prefix, String word) {
    prefix = prefix.toLowerCase();
    return word.startsWith(prefix);
  }

  /**
   * Method getAllWordsWithPrefix.
   * @param prefix String
   * @return String[]
   */
  public static String[] getAllWordsWithPrefix(String prefix) {
    String all[] = getAllKeywords();
    return getMatched(prefix, all);
  }

  /**
   * Method getMatched.
   * @param prefix String
   * @param all String[]
   * @return String[]
   */
  private static String[] getMatched(String prefix, String all[]) {
    ArrayList matched = new ArrayList(10);
    for (int i = 0; i < all.length; i++)
      if (prefixMatches(prefix, all[i]))
        matched.add(all[i]);

    return (String[]) matched.toArray(new String[matched.size()]);
  }

  /**
   * Method getTagsWithPrefix.
   * @param prefix String
   * @return String[]
   */
  public static String[] getTagsWithPrefix(String prefix) {
    return getMatched(prefix, getTags());
  }

  /**
   * Method getNonTagsKeywordsWithPrefix.
   * @param key String
   * @param prefix String
   * @return String[]
   */
  public static String[] getNonTagsKeywordsWithPrefix(String key, String prefix) {
    return getMatched(prefix, getInnerKeywordsFor(key));
  }
}
