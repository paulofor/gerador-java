/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package com.metys.merlin.generation.gef.genmodel;


import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Gen Figure</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenFigure#getFigureClass <em>Figure Class</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenFigure#getLayoutClass <em>Layout Class</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenFigure#isAdditionalEditableLabel <em>Additional Editable Label</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenFigure()
 * @model
 * @generated
 */
public interface GenFigure extends EObject{
  /**
   * Returns the value of the '<em><b>Figure Class</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Figure Class</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Figure Class</em>' attribute.
   * @see #setFigureClass(String)
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenFigure_FigureClass()
   * @model
   * @generated
   */
  String getFigureClass();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.genmodel.GenFigure#getFigureClass <em>Figure Class</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Figure Class</em>' attribute.
   * @see #getFigureClass()
   * @generated
   */
  void setFigureClass(String value);

  /**
   * Returns the value of the '<em><b>Layout Class</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Layout Class</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Layout Class</em>' attribute.
   * @see #setLayoutClass(String)
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenFigure_LayoutClass()
   * @model
   * @generated
   */
  String getLayoutClass();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.genmodel.GenFigure#getLayoutClass <em>Layout Class</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Layout Class</em>' attribute.
   * @see #getLayoutClass()
   * @generated
   */
  void setLayoutClass(String value);

  /**
   * Returns the value of the '<em><b>Additional Editable Label</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Additional Editable Label</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Additional Editable Label</em>' attribute.
   * @see #setAdditionalEditableLabel(boolean)
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenFigure_AdditionalEditableLabel()
   * @model
   * @generated
   */
  boolean isAdditionalEditableLabel();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.genmodel.GenFigure#isAdditionalEditableLabel <em>Additional Editable Label</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Additional Editable Label</em>' attribute.
   * @see #isAdditionalEditableLabel()
   * @generated
   */
  void setAdditionalEditableLabel(boolean value);

} // GenFigure
