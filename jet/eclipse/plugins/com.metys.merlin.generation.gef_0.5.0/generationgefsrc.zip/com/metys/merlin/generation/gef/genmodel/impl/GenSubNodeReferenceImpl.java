/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package com.metys.merlin.generation.gef.genmodel.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import com.metys.merlin.generation.gef.genmodel.GenModelPackage;
import com.metys.merlin.generation.gef.genmodel.GenSubNodeReference;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Gen Sub Node Reference</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenSubNodeReferenceImpl#getReference <em>Reference</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenSubNodeReferenceImpl#getParentLayoutClass <em>Parent Layout Class</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class GenSubNodeReferenceImpl extends EObjectImpl implements GenSubNodeReference {
  /**
   * The cached value of the '{@link #getReference() <em>Reference</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getReference()
   * @generated
   * @ordered
   */
  protected EReference reference = null;

  /**
   * The default value of the '{@link #getParentLayoutClass() <em>Parent Layout Class</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getParentLayoutClass()
   * @generated
   * @ordered
   */
  protected static final String PARENT_LAYOUT_CLASS_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getParentLayoutClass() <em>Parent Layout Class</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getParentLayoutClass()
   * @generated
   * @ordered
   */
  protected String parentLayoutClass = PARENT_LAYOUT_CLASS_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected GenSubNodeReferenceImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return GenModelPackage.eINSTANCE.getGenSubNodeReference();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getReference() {
    if (reference != null && reference.eIsProxy()) {
      EReference oldReference = reference;
      reference = (EReference)eResolveProxy((InternalEObject)reference);
      if (reference != oldReference) {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, GenModelPackage.GEN_SUB_NODE_REFERENCE__REFERENCE, oldReference, reference));
      }
    }
    return reference;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference basicGetReference() {
    return reference;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setReference(EReference newReference) {
    EReference oldReference = reference;
    reference = newReference;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_SUB_NODE_REFERENCE__REFERENCE, oldReference, reference));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getParentLayoutClass() {
    return parentLayoutClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setParentLayoutClass(String newParentLayoutClass) {
    String oldParentLayoutClass = parentLayoutClass;
    parentLayoutClass = newParentLayoutClass;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_SUB_NODE_REFERENCE__PARENT_LAYOUT_CLASS, oldParentLayoutClass, parentLayoutClass));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_SUB_NODE_REFERENCE__REFERENCE:
        if (resolve) return getReference();
        return basicGetReference();
      case GenModelPackage.GEN_SUB_NODE_REFERENCE__PARENT_LAYOUT_CLASS:
        return getParentLayoutClass();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_SUB_NODE_REFERENCE__REFERENCE:
        setReference((EReference)newValue);
        return;
      case GenModelPackage.GEN_SUB_NODE_REFERENCE__PARENT_LAYOUT_CLASS:
        setParentLayoutClass((String)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_SUB_NODE_REFERENCE__REFERENCE:
        setReference((EReference)null);
        return;
      case GenModelPackage.GEN_SUB_NODE_REFERENCE__PARENT_LAYOUT_CLASS:
        setParentLayoutClass(PARENT_LAYOUT_CLASS_EDEFAULT);
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_SUB_NODE_REFERENCE__REFERENCE:
        return reference != null;
      case GenModelPackage.GEN_SUB_NODE_REFERENCE__PARENT_LAYOUT_CLASS:
        return PARENT_LAYOUT_CLASS_EDEFAULT == null ? parentLayoutClass != null : !PARENT_LAYOUT_CLASS_EDEFAULT.equals(parentLayoutClass);
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString() {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (parentLayoutClass: ");
    result.append(parentLayoutClass);
    result.append(')');
    return result.toString();
  }

} //GenSubNodeReferenceImpl
