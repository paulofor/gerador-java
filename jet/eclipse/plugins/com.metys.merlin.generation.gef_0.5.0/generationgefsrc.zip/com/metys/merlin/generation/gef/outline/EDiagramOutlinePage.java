/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.outline;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.draw2d.LightweightSystem;
import org.eclipse.draw2d.MarginBorder;
import org.eclipse.draw2d.Viewport;
import org.eclipse.draw2d.parts.ScrollableThumbnail;
import org.eclipse.draw2d.parts.Thumbnail;
import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.gef.LayerConstants;
import org.eclipse.gef.RootEditPart;
import org.eclipse.gef.editparts.ScalableFreeformRootEditPart;
import org.eclipse.gef.editparts.ScalableRootEditPart;
import org.eclipse.gef.editparts.ZoomManager;
import org.eclipse.gef.ui.actions.ActionRegistry;
import org.eclipse.gef.ui.parts.ContentOutlinePage;
import org.eclipse.gef.ui.parts.TreeViewer;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.actions.ActionFactory;
import org.eclipse.ui.part.IPageSite;
import org.eclipse.ui.part.PageBook;

import com.metys.merlin.generation.gef.GefPlugin;
import com.metys.merlin.generation.gef.editor.GEFEditor;

/**
 * @author jcheuoua
 * @version $Revision: 1.1 $
 */
public class EDiagramOutlinePage extends ContentOutlinePage
  implements IAdaptable {
  
  static final int ID_OUTLINE  = 0;
  static final int ID_OVERVIEW = 1;
  
  private AdapterFactory adapterFactory;
  private GEFEditor editor;
  
  private TreeViewer viewer;  
  private Control outline;
  private Canvas overview;
  private Thumbnail thumbnail;
  private DisposeListener disposeListener;
  private PageBook pageBook;
  
  private IAction showOutlineAction;
  private IAction showOverviewAction;
  
  /**
   * Constructor for EDiagramOutlinePage.
   * @param editor GEFEditor
   * @param adapterFactory AdapterFactory
   */
  public EDiagramOutlinePage(GEFEditor editor, AdapterFactory adapterFactory) {
    super(new TreeViewer());
    this.viewer = (TreeViewer) getViewer();
    this.editor = editor;
    this.adapterFactory = adapterFactory;
  }
  
  /**
   * Method init.
   * @param pageSite IPageSite
   * @see org.eclipse.ui.part.IPageBookViewPage#init(IPageSite)
   */
  public void init(IPageSite pageSite) {
    super.init(pageSite);
    ActionRegistry registry = editor.getActionRegistry();
    IActionBars bars = pageSite.getActionBars();
    String id = ActionFactory.UNDO.getId();
    bars.setGlobalActionHandler(id, registry.getAction(id));
    id = ActionFactory.REDO.getId();
    bars.setGlobalActionHandler(id, registry.getAction(id));
    bars.updateActionBars();
    IToolBarManager manager = bars.getToolBarManager();
    IAction action = new Action() {
      public void run() {
        expand(((Tree) viewer.getControl()).getItems());
      }
      private void expand(TreeItem[] items) {
        for (int i = 0; i < items.length; i++) {
          expand(items[i].getItems());
          items[i].setExpanded(false);
        }
      }
    };
    action.setImageDescriptor(ImageDescriptor.createFromURL(
        GefPlugin.getPlugin().getBundle().getEntry("icons/collapseall.gif"))); //$NON-NLS-1$
    action.setToolTipText("Collapse All");
    manager.add(action);
    action = new Action() {
      public void run() {
        expand(((Tree) viewer.getControl()).getItems());
      }
      private void expand(TreeItem[] items) {
        for (int i = 0; i < items.length; i++) {
          expand(items[i].getItems());
          items[i].setExpanded(true);
        }
      }
    };
    action.setImageDescriptor(ImageDescriptor.createFromURL(
        GefPlugin.getPlugin().getBundle().getEntry("icons/expandall.gif"))); //$NON-NLS-1$
    action.setToolTipText("Expand All");
    manager.add(action);
  }
  /**
   * Method createControl.
   * @param parent Composite
   * @see org.eclipse.ui.part.IPage#createControl(Composite)
   */
  public void createControl(Composite parent) {
    pageBook = new PageBook(parent, SWT.NONE);
    outline = getViewer().createControl(pageBook);
    overview = new Canvas(pageBook, SWT.NONE);
    pageBook.showPage(outline);
    configureOutlineViewer();
    hookOutlineViewer();
    initializeOutlineViewer();                    
  }
  /**
   * Method getControl.
   * @return Control
   * @see org.eclipse.ui.part.IPage#getControl()
   */
  public Control getControl() {
    return pageBook;
  }
  
  private void configureOutlineViewer() {
    viewer.setEditDomain(editor.getEditDomain());
    viewer.setEditPartFactory(new EDiagramTreePartFactory(editor.getModelResource(), adapterFactory));    
    viewer.addDragSourceListener(new OutlineDragSourceListener(viewer, editor.getTransferInstance()));
    viewer.setKeyHandler(editor.getCommonKeyHandler());
    IToolBarManager tbm = getSite().getActionBars().getToolBarManager();
    showOutlineAction = new Action() {
      public void run() {
        showPage(ID_OUTLINE);
      }
    };
    showOutlineAction.setImageDescriptor(ImageDescriptor.createFromURL(
                GefPlugin.getPlugin().getBundle().getEntry("icons/outline.gif"))); //$NON-NLS-1$
    tbm.add(showOutlineAction);
    showOutlineAction.setToolTipText("Show Outline Tree");
    showOverviewAction = new Action() {
      public void run() {
        showPage(ID_OVERVIEW);
      }
    };
    showOverviewAction.setImageDescriptor(ImageDescriptor.createFromURL(
        GefPlugin.getPlugin().getBundle().getEntry("icons/overview.gif"))); //$NON-NLS-1$
    tbm.add(showOverviewAction);
    showOverviewAction.setToolTipText("Show Overview");
    showPage(ID_OUTLINE);
  }
  
  private void initializeOutlineViewer() {
    viewer.setContents(editor.getDiagram());
  }
  
  protected void hookOutlineViewer(){
    editor.getSelectionSynchronizer().addViewer(getViewer());
  }
  
  protected void unhookOutlineViewer(){
    editor.getSelectionSynchronizer().removeViewer(getViewer());
    if (disposeListener != null && editor.getGraphicalViewer().getControl() != null && !editor.getGraphicalViewer().getControl().isDisposed())
      editor.getGraphicalViewer().getControl().removeDisposeListener(disposeListener);
  }

  protected void initializeOverview() {
    LightweightSystem lws = new LightweightSystem(overview);
    RootEditPart rootEditPart = editor.getGraphicalViewer().getRootEditPart();
    if (rootEditPart instanceof ScalableFreeformRootEditPart) {
      ScalableFreeformRootEditPart root = (ScalableFreeformRootEditPart) editor.getGraphicalViewer().getRootEditPart();
      thumbnail = new ScrollableThumbnail((Viewport)root.getFigure());
      thumbnail.setBorder(new MarginBorder(3));
      thumbnail.setSource(root.getLayer(LayerConstants.PRINTABLE_LAYERS));
      lws.setContents(thumbnail);
      disposeListener = new DisposeListener() {
        public void widgetDisposed(DisposeEvent e) {
          if (thumbnail != null) {
            thumbnail.deactivate();
            thumbnail = null;
          }
        }
      };
      editor.getGraphicalViewer().getControl().addDisposeListener(disposeListener);
    }
    if (rootEditPart instanceof ScalableRootEditPart) {
      ScalableRootEditPart root = (ScalableRootEditPart) editor.getGraphicalViewer().getRootEditPart();
      thumbnail = new ScrollableThumbnail((Viewport)root.getFigure());
      thumbnail.setBorder(new MarginBorder(3));
      thumbnail.setSource(root.getLayer(LayerConstants.PRINTABLE_LAYERS));
      lws.setContents(thumbnail);
      disposeListener = new DisposeListener() {
        public void widgetDisposed(DisposeEvent e) {
          if (thumbnail != null) {
            thumbnail.deactivate();
            thumbnail = null;
          }
        }
      };
      editor.getGraphicalViewer().getControl().addDisposeListener(disposeListener);
    }
  }
  
  /**
   * Method showPage.
   * @param id int
   */
  protected void showPage(int id) {
    if (id == ID_OUTLINE) {
      showOutlineAction.setChecked(true);
      showOverviewAction.setChecked(false);
      pageBook.showPage(outline);
      if (thumbnail != null)
        thumbnail.setVisible(false);
    } else if (id == ID_OVERVIEW) {
      if (thumbnail == null)
        initializeOverview();
      showOutlineAction.setChecked(false);
      showOverviewAction.setChecked(true);
      pageBook.showPage(overview);
      if (thumbnail != null)
        thumbnail.setVisible(true);
    }
  }
  /**
   * Method getAdapter.
   * @param type Class
   * @return Object
   * @see org.eclipse.core.runtime.IAdaptable#getAdapter(Class)
   */
  public Object getAdapter(Class type) {
    if (type == ZoomManager.class)
      return editor.getGraphicalViewer().getProperty(ZoomManager.class.toString());
    return null;
  }
  
  /**
   * Method dispose.
   * @see org.eclipse.ui.part.IPage#dispose()
   */
  public void dispose(){
    unhookOutlineViewer();
    if (thumbnail != null) {
      thumbnail.deactivate();
      thumbnail = null;
    }
    super.dispose();
    editor.setOutlinePage(null);
  }

}