/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.genmodel.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.codegen.ecore.genmodel.GenClass;
import org.eclipse.emf.codegen.ecore.genmodel.GenFeature;
import org.eclipse.emf.codegen.ecore.genmodel.GenModel;
import org.eclipse.emf.codegen.ecore.genmodel.GenPackage;
import org.eclipse.emf.codegen.ecore.genmodel.impl.GenModelImpl;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.ENamedElement;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EStructuralFeature;

import com.metys.merlin.generation.gef.genmodel.GenEditPart;
import com.metys.merlin.generation.gef.genmodel.GenLinkEditPart;
import com.metys.merlin.generation.gef.genmodel.GenNodeEditPart;

public class GenModelHelper {
  
  public static IPath getPath(ENamedElement namedElement) {
    return new Path(getQualifiedName(namedElement, '/'));
  }
  
  public static Collection getGenLinkEditParts(Collection genEditParts) {
    if (genEditParts == null || genEditParts.isEmpty())
      return Collections.EMPTY_LIST;
    Collection result = new ArrayList();
    for (Iterator iter = genEditParts.iterator(); iter.hasNext();) {
      GenEditPart editPart = (GenEditPart) iter.next();
      if (editPart instanceof GenLinkEditPart)
        result.add(editPart);
    }
    return result;
  }
  
  public static Collection getGenNodeEditParts(Collection genEditParts) {
    if (genEditParts == null || genEditParts.isEmpty())
      return Collections.EMPTY_LIST;
    Collection result = new ArrayList();
    for (Iterator iter = genEditParts.iterator(); iter.hasNext();) {
      GenEditPart editPart = (GenEditPart) iter.next();
      if (editPart instanceof GenNodeEditPart)
        result.add(editPart);
    }
    return result;
  }
  
  public static GenPackage getGenPackage(GenModel genModel, EPackage ePackage) {
    return ((GenModelImpl)genModel).findGenPackage(ePackage);    
  }
    
  public static GenClass getGenClass(GenModel genModel, EClass eClass) {
    GenPackage genPackage = getGenPackage(genModel, eClass.getEPackage());
    for (Iterator iter = genPackage.getGenClasses().iterator(); iter.hasNext();) {
      GenClass genClass = (GenClass) iter.next();      
      if (genClass.getEcoreClass() == eClass)
        return genClass;
    }
    return null;
  }
  
  public static GenFeature getGenFeature(GenModel genModel, EStructuralFeature eFeature) {
    GenClass genClass = getGenClass(genModel, eFeature.getEContainingClass());
    for (Iterator iter = genClass.getGenFeatures().iterator(); iter.hasNext();) {
      GenFeature genFeature = (GenFeature) iter.next();      
      if (genFeature.getEcoreFeature() == eFeature)
        return genFeature;
    }
    return null;
  }

  public static String getQualifiedName(ENamedElement namedElement) {
    return getQualifiedName(namedElement, '.');
  }
  
  public static String shortName(String qualifiedName) {
    return shortName(qualifiedName, '.');
  }

  public static String containerQName(String qualifiedName) {
    return containerQName(qualifiedName, '.');
  }
  
  public static String getQualifiedName(ENamedElement namedElement, char separator) {
    String qualifiedName = namedElement.getName();
    if (namedElement.eContainer() instanceof ENamedElement) {
      ENamedElement parentElt = (ENamedElement) namedElement.eContainer();
      while (parentElt != null) {
        if (qualifiedName != null)
          qualifiedName = parentElt.getName() + separator + qualifiedName;
        else
          qualifiedName = parentElt.getName();
        if (parentElt.eContainer() instanceof ENamedElement)
          parentElt = (ENamedElement) parentElt.eContainer();
        else
          parentElt = null;
      }
    }
    return qualifiedName;
  }
  
  public static String shortName(String qualifiedName, char separator) {
    int lastDot = qualifiedName.lastIndexOf(separator);
    String shortName = qualifiedName.substring(lastDot + 1);
    return shortName;
  }

  public static String containerQName(String qualifiedName, char separator) {
    int lastDot = qualifiedName.lastIndexOf(separator);
    String packageName = lastDot == -1 ? null : qualifiedName.substring(0, lastDot);
    return packageName;
  }
  
  public static String getImportedQualifiedEditPartClass(GenModel genModel, GenEditPart genEditPart) {
    String packageName = genEditPart.getPackageName();
    String className = genEditPart.getEcoreClass().getName() + "EditPart";
    return genModel.getImportedName(packageName + "." + className);
  }
  public static String getImportedQualifiedLinkEditPartClass(GenModel genModel, GenEditPart genEditPart) {
    String packageName = genEditPart.getPackageName();
    String className = genEditPart.getEcoreClass().getName() + "LinkEditPart";
    return genModel.getImportedName(packageName + "." + className);
  }
  
  public static String getComponentEditPolicyExtendsLitteral(GenModel genModel, GenNodeEditPart genEditPart) {
    return getExtendsLitteral(genModel, genEditPart, ".policies", "ComponentEditPolicy", "com.metys.merlin.generation.gef.policies.ENodeComponentEditPolicy");
  }
  
  public static String getDirectEditPolicyExtendsLitteral(GenModel genModel, GenNodeEditPart genEditPart) {
    return getExtendsLitteral(genModel, genEditPart, ".policies", "DirectEditPolicy", "com.metys.merlin.generation.gef.policies.ENodeDirectEditPolicy");
  }
  
  public static String getGraphicalNodeEditPolicyExtendsLitteral(GenModel genModel, GenNodeEditPart genEditPart) {
    return getExtendsLitteral(genModel, genEditPart, ".policies", "GraphicalNodeEditPolicy", "com.metys.merlin.generation.gef.policies.ENodeGraphicalNodeEditPolicy");
  }
  
  public static String getGraphicalEditPolicyExtendsLitteral(GenModel genModel, GenNodeEditPart genEditPart) {
    return getExtendsLitteral(genModel, genEditPart, ".policies", "GraphicalEditPolicy", "com.metys.merlin.generation.gef.policies.ENodeGraphicalEditPolicy");
  }
  
  public static String getLayoutEditPolicyExtendsLitteral(GenModel genModel, GenNodeEditPart genEditPart) {
    return getExtendsLitteral(genModel, genEditPart, ".policies", "LayoutEditPolicy", "com.metys.merlin.generation.gef.policies.ENodeLayoutEditPolicy");
  }
  
  public static String getNodeEditPartExtendsLitteral(GenModel genModel, GenNodeEditPart genEditPart) {
    return getExtendsLitteral(genModel, genEditPart, "", "EditPart", "com.metys.merlin.generation.gef.parts.ENodeEditPart");
  }
  
  
  public static String getExtendsLitteral(GenModel genModel, GenEditPart genEditPart, String packagePrefix, String classPrefix, String defaultExtendedClassQName) {
    String extendsLitteral = "";
    GenClass genClass = getGenClass(genModel, genEditPart.getEcoreClass());
    GenClass extendedGenClass = genClass.getClassExtendsGenClass();
    if (extendedGenClass != null) {
      GenEditPart extendedGenEditPart = null;
      for (Iterator iter = genEditPart.getGenGEFModel().getGenEditParts().iterator(); iter.hasNext();) {
        GenEditPart editPart = (GenEditPart) iter.next();
        if (extendedGenClass.getEcoreClass().equals(editPart.getEcoreClass())) {
          extendedGenEditPart = editPart;
          break;
        }
      }
      if (extendedGenEditPart != null) {
        String packageQualifiedName = extendedGenEditPart.getPackageName() + packagePrefix;
        String className = extendedGenClass.getEcoreClass().getName() + classPrefix;
        String superClassQualifiedName = packageQualifiedName + "." + className;
        extendsLitteral = " extends " + genModel.getImportedName(superClassQualifiedName);
      }
    }
    if ("".equals(extendsLitteral))
      extendsLitteral = " extends " + genModel.getImportedName(defaultExtendedClassQName);
    return extendsLitteral;
  }
}
