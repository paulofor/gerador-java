package com.metys.merlin.generation.gef.compiledtemplates.policies;

import com.metys.merlin.generation.gef.genmodel.*;
import com.metys.merlin.generation.gef.genmodel.util.*;
import org.eclipse.emf.ecore.*;
import org.eclipse.emf.codegen.ecore.genmodel.*;

public class NodeGraphicalEditPolicy
{
  protected static String nl;
  public static synchronized NodeGraphicalEditPolicy create(String lineSeparator)
  {
    nl = lineSeparator;
    NodeGraphicalEditPolicy result = new NodeGraphicalEditPolicy();
    nl = null;
    return result;
  }

  protected final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = "/**" + NL + " * <copyright>" + NL + " * </copyright>" + NL + " *" + NL + " * ";
  protected final String TEXT_3 = "Id";
  protected final String TEXT_4 = NL + " */" + NL + "" + NL + "package ";
  protected final String TEXT_5 = ".policies;" + NL;
  protected final String TEXT_6 = NL + NL + "/**" + NL + " * <!-- begin-user-doc -->" + NL + " * <!-- end-user-doc -->" + NL + " * @generated" + NL + " */" + NL + "public ";
  protected final String TEXT_7 = "abstract ";
  protected final String TEXT_8 = "class ";
  protected final String TEXT_9 = "GraphicalEditPolicy";
  protected final String TEXT_10 = " {" + NL + "  " + NL + "  /**" + NL + "\t * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  private ";
  protected final String TEXT_11 = " revertColor;" + NL + "\t" + NL + "\t/**" + NL + "\t * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "\tprivate static Color highLightColor = new Color(null, 200, 200, 240);" + NL + "" + NL + "\t/**" + NL + "\t * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "\tpublic void eraseTargetFeedback(";
  protected final String TEXT_12 = " request) {" + NL + "\t\tif (revertColor != null) {" + NL + "\t\t\tgetHostFigure().setBackgroundColor(revertColor);" + NL + "\t\t\trevertColor = null;" + NL + "\t\t}" + NL + "\t}" + NL + "" + NL + "  /**" + NL + "\t * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "\tpublic ";
  protected final String TEXT_13 = " getTargetEditPart(Request request) {" + NL + "\t\treturn request.getType().equals(";
  protected final String TEXT_14 = ".REQ_SELECTION_HOVER) ? getHost() : null;" + NL + "\t}" + NL + "" + NL + "  /**" + NL + "\t * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "\tpublic void showTargetFeedback(Request request) {" + NL + "\t\tif (request.getType().equals(RequestConstants.REQ_CREATE)" + NL + "\t\t\t|| request.getType().equals(RequestConstants.REQ_ADD))" + NL + "\t\t\tshowHighlight();" + NL + "\t}" + NL + "\t" + NL + "\t/**" + NL + "\t * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "\tprotected void showHighlight() {" + NL + "\t\tif (revertColor == null) {" + NL + "\t\t\trevertColor = getHostFigure().getBackgroundColor();" + NL + "\t\t\tgetHostFigure().setBackgroundColor(highLightColor);" + NL + "\t\t}" + NL + "\t}" + NL + "}";

  public String generate(Object argument)
  {
    StringBuffer stringBuffer = new StringBuffer();
    
/**
 * Copyright (c) 2005 Joel Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

    GenNodeEditPart genEditPart = (GenNodeEditPart) argument; EClass ecoreClass = genEditPart.getEcoreClass(); EPackage ecorePackage = (EPackage) ecoreClass.getEPackage(); GenModel genModel = genEditPart.getGenGEFModel().getGenModel(); GenClass genClass = GenModelHelper.getGenClass(genModel, ecoreClass);
    stringBuffer.append(TEXT_1);
    stringBuffer.append(TEXT_2);
    stringBuffer.append("$");
    stringBuffer.append(TEXT_3);
    stringBuffer.append("$");
    stringBuffer.append(TEXT_4);
    stringBuffer.append(genEditPart.getPackageName());
    stringBuffer.append(TEXT_5);
    genModel.markImportLocation(stringBuffer);
    stringBuffer.append(TEXT_6);
    if (ecoreClass.isAbstract()) {
    stringBuffer.append(TEXT_7);
    }
    stringBuffer.append(TEXT_8);
    stringBuffer.append(ecoreClass.getName());
    stringBuffer.append(TEXT_9);
    stringBuffer.append(GenModelHelper.getGraphicalEditPolicyExtendsLitteral(genModel, genEditPart));
    stringBuffer.append(TEXT_10);
    stringBuffer.append(genModel.getImportedName("org.eclipse.swt.graphics.Color"));
    stringBuffer.append(TEXT_11);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.Request"));
    stringBuffer.append(TEXT_12);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.EditPart"));
    stringBuffer.append(TEXT_13);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.RequestConstants"));
    stringBuffer.append(TEXT_14);
    genModel.emitSortedImports();
    return stringBuffer.toString();
  }
}
