/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package com.metys.merlin.generation.gef.genmodel.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;

import com.metys.merlin.generation.gef.genmodel.GenEditPartFactory;
import com.metys.merlin.generation.gef.genmodel.GenGEFModel;
import com.metys.merlin.generation.gef.genmodel.GenModelPackage;
import com.metys.merlin.generation.gef.genmodel.GenViewer;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Gen Viewer</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenViewerImpl#getGenEditPartFactory <em>Gen Edit Part Factory</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenViewerImpl#getGenGEFModel <em>Gen GEF Model</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class GenViewerImpl extends GenGEFBaseImpl implements GenViewer {
  /**
   * The cached value of the '{@link #getGenEditPartFactory() <em>Gen Edit Part Factory</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getGenEditPartFactory()
   * @generated
   * @ordered
   */
  protected GenEditPartFactory genEditPartFactory = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected GenViewerImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return GenModelPackage.eINSTANCE.getGenViewer();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenEditPartFactory getGenEditPartFactory() {
    if (genEditPartFactory != null && genEditPartFactory.eIsProxy()) {
      GenEditPartFactory oldGenEditPartFactory = genEditPartFactory;
      genEditPartFactory = (GenEditPartFactory)eResolveProxy((InternalEObject)genEditPartFactory);
      if (genEditPartFactory != oldGenEditPartFactory) {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, GenModelPackage.GEN_VIEWER__GEN_EDIT_PART_FACTORY, oldGenEditPartFactory, genEditPartFactory));
      }
    }
    return genEditPartFactory;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenEditPartFactory basicGetGenEditPartFactory() {
    return genEditPartFactory;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setGenEditPartFactory(GenEditPartFactory newGenEditPartFactory) {
    GenEditPartFactory oldGenEditPartFactory = genEditPartFactory;
    genEditPartFactory = newGenEditPartFactory;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_VIEWER__GEN_EDIT_PART_FACTORY, oldGenEditPartFactory, genEditPartFactory));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenGEFModel getGenGEFModel() {
    if (eContainerFeatureID != GenModelPackage.GEN_VIEWER__GEN_GEF_MODEL) return null;
    return (GenGEFModel)eContainer;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setGenGEFModel(GenGEFModel newGenGEFModel) {
    if (newGenGEFModel != eContainer || (eContainerFeatureID != GenModelPackage.GEN_VIEWER__GEN_GEF_MODEL && newGenGEFModel != null)) {
      if (EcoreUtil.isAncestor(this, newGenGEFModel))
        throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
      NotificationChain msgs = null;
      if (eContainer != null)
        msgs = eBasicRemoveFromContainer(msgs);
      if (newGenGEFModel != null)
        msgs = ((InternalEObject)newGenGEFModel).eInverseAdd(this, GenModelPackage.GEN_GEF_MODEL__GEN_VIEWERS, GenGEFModel.class, msgs);
      msgs = eBasicSetContainer((InternalEObject)newGenGEFModel, GenModelPackage.GEN_VIEWER__GEN_GEF_MODEL, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_VIEWER__GEN_GEF_MODEL, newGenGEFModel, newGenGEFModel));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case GenModelPackage.GEN_VIEWER__GEN_GEF_MODEL:
          if (eContainer != null)
            msgs = eBasicRemoveFromContainer(msgs);
          return eBasicSetContainer(otherEnd, GenModelPackage.GEN_VIEWER__GEN_GEF_MODEL, msgs);
        default:
          return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case GenModelPackage.GEN_VIEWER__GEN_GEF_MODEL:
          return eBasicSetContainer(null, GenModelPackage.GEN_VIEWER__GEN_GEF_MODEL, msgs);
        default:
          return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
    if (eContainerFeatureID >= 0) {
      switch (eContainerFeatureID) {
        case GenModelPackage.GEN_VIEWER__GEN_GEF_MODEL:
          return eContainer.eInverseRemove(this, GenModelPackage.GEN_GEF_MODEL__GEN_VIEWERS, GenGEFModel.class, msgs);
        default:
          return eDynamicBasicRemoveFromContainer(msgs);
      }
    }
    return eContainer.eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_VIEWER__NAME:
        return getName();
      case GenModelPackage.GEN_VIEWER__PACKAGE_NAME:
        return getPackageName();
      case GenModelPackage.GEN_VIEWER__GEN_EDIT_PART_FACTORY:
        if (resolve) return getGenEditPartFactory();
        return basicGetGenEditPartFactory();
      case GenModelPackage.GEN_VIEWER__GEN_GEF_MODEL:
        return getGenGEFModel();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_VIEWER__NAME:
        setName((String)newValue);
        return;
      case GenModelPackage.GEN_VIEWER__PACKAGE_NAME:
        setPackageName((String)newValue);
        return;
      case GenModelPackage.GEN_VIEWER__GEN_EDIT_PART_FACTORY:
        setGenEditPartFactory((GenEditPartFactory)newValue);
        return;
      case GenModelPackage.GEN_VIEWER__GEN_GEF_MODEL:
        setGenGEFModel((GenGEFModel)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_VIEWER__NAME:
        setName(NAME_EDEFAULT);
        return;
      case GenModelPackage.GEN_VIEWER__PACKAGE_NAME:
        setPackageName(PACKAGE_NAME_EDEFAULT);
        return;
      case GenModelPackage.GEN_VIEWER__GEN_EDIT_PART_FACTORY:
        setGenEditPartFactory((GenEditPartFactory)null);
        return;
      case GenModelPackage.GEN_VIEWER__GEN_GEF_MODEL:
        setGenGEFModel((GenGEFModel)null);
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_VIEWER__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case GenModelPackage.GEN_VIEWER__PACKAGE_NAME:
        return PACKAGE_NAME_EDEFAULT == null ? packageName != null : !PACKAGE_NAME_EDEFAULT.equals(packageName);
      case GenModelPackage.GEN_VIEWER__GEN_EDIT_PART_FACTORY:
        return genEditPartFactory != null;
      case GenModelPackage.GEN_VIEWER__GEN_GEF_MODEL:
        return getGenGEFModel() != null;
    }
    return eDynamicIsSet(eFeature);
  }

} //GenViewerImpl
