/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.model;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>ELink</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.gef.model.ELink#getSource <em>Source</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.ELink#getTarget <em>Target</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.ELink#getBendpoints <em>Bendpoints</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.ELink#getInvalidMessage <em>Invalid Message</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.metys.merlin.generation.gef.model.ModelPackage#getELink()
 * @model abstract="true"
 * @generated
 */
public interface ELink extends EObject{
  /**
   * Returns the value of the '<em><b>Source</b></em>' container reference.
   * It is bidirectional and its opposite is '{@link com.metys.merlin.generation.gef.model.ENode#getOutgoingLinks <em>Outgoing Links</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Source</em>' container reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Source</em>' container reference.
   * @see #setSource(ENode)
   * @see com.metys.merlin.generation.gef.model.ModelPackage#getELink_Source()
   * @see com.metys.merlin.generation.gef.model.ENode#getOutgoingLinks
   * @model opposite="outgoingLinks"
   * @generated
   */
  ENode getSource();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.model.ELink#getSource <em>Source</em>}' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Source</em>' container reference.
   * @see #getSource()
   * @generated
   */
  void setSource(ENode value);

  /**
   * Returns the value of the '<em><b>Target</b></em>' reference.
   * It is bidirectional and its opposite is '{@link com.metys.merlin.generation.gef.model.ENode#getIncomingLinks <em>Incoming Links</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Target</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Target</em>' reference.
   * @see #setTarget(ENode)
   * @see com.metys.merlin.generation.gef.model.ModelPackage#getELink_Target()
   * @see com.metys.merlin.generation.gef.model.ENode#getIncomingLinks
   * @model opposite="incomingLinks"
   * @generated
   */
  ENode getTarget();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.model.ELink#getTarget <em>Target</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Target</em>' reference.
   * @see #getTarget()
   * @generated
   */
  void setTarget(ENode value);

  /**
   * Returns the value of the '<em><b>Bendpoints</b></em>' attribute list.
   * The list contents are of type {@link org.eclipse.draw2d.Bendpoint}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Bendpoints</em>' attribute list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Bendpoints</em>' attribute list.
   * @see com.metys.merlin.generation.gef.model.ModelPackage#getELink_Bendpoints()
   * @model type="org.eclipse.draw2d.Bendpoint" dataType="com.metys.merlin.generation.gef.Bendpoint"
   * @generated
   */
  EList getBendpoints();

  /**
   * Returns the value of the '<em><b>Invalid Message</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Invalid Message</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Invalid Message</em>' attribute.
   * @see #setInvalidMessage(String)
   * @see com.metys.merlin.generation.gef.model.ModelPackage#getELink_InvalidMessage()
   * @model
   * @generated
   */
  String getInvalidMessage();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.model.ELink#getInvalidMessage <em>Invalid Message</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Invalid Message</em>' attribute.
   * @see #getInvalidMessage()
   * @generated
   */
  void setInvalidMessage(String value);

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model
   * @generated
   */
  void doLink();

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model
   * @generated
   */
  void doUnlink();

} // ELink
