package com.metys.merlin.generation.gef.compiledtemplates.parts;

import com.metys.merlin.generation.gef.genmodel.*;
import com.metys.merlin.generation.gef.genmodel.util.*;
import org.eclipse.emf.ecore.*;
import org.eclipse.emf.codegen.ecore.genmodel.*;

public class NodeEditPart
{
  protected static String nl;
  public static synchronized NodeEditPart create(String lineSeparator)
  {
    nl = lineSeparator;
    NodeEditPart result = new NodeEditPart();
    nl = null;
    return result;
  }

  protected final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = "/**" + NL + " * <copyright>" + NL + " * </copyright>" + NL + " *" + NL + " * ";
  protected final String TEXT_3 = "Id";
  protected final String TEXT_4 = NL + " */" + NL + "" + NL + "package ";
  protected final String TEXT_5 = ";" + NL;
  protected final String TEXT_6 = NL + NL + "/**" + NL + " * <!-- begin-user-doc -->" + NL + " * <!-- end-user-doc -->" + NL + " * @generated" + NL + " */" + NL + "public ";
  protected final String TEXT_7 = "abstract ";
  protected final String TEXT_8 = "class ";
  protected final String TEXT_9 = "EditPart";
  protected final String TEXT_10 = "{" + NL + "\t" + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "\tpublic ";
  protected final String TEXT_11 = "EditPart(";
  protected final String TEXT_12 = " model, ";
  protected final String TEXT_13 = " adapterFactory) {" + NL + "\t\tsuper(model, adapterFactory);" + NL + "\t}" + NL + "\t" + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "\tpublic ";
  protected final String TEXT_14 = " get";
  protected final String TEXT_15 = "() {" + NL + "\t\treturn (";
  protected final String TEXT_16 = ")getENode().getEObject();" + NL + "\t}" + NL + "\t" + NL + "  /**" + NL + "   * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#createFigure()" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated   " + NL + "   */" + NL + "  protected ";
  protected final String TEXT_17 = " createFigure() {";
  protected final String TEXT_18 = NL + "    ";
  protected final String TEXT_19 = " l = new Label(getImage());" + NL + "    l.setLabelAlignment(";
  protected final String TEXT_20 = ".CENTER);" + NL + "\treturn new ";
  protected final String TEXT_21 = "(l);";
  protected final String TEXT_22 = NL + "\t";
  protected final String TEXT_23 = " figure = new ";
  protected final String TEXT_24 = "();" + NL + "\treturn figure; ";
  protected final String TEXT_25 = NL + "  }" + NL + "" + NL + "  /**" + NL + "   * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#getContentPane()" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated   " + NL + "   */" + NL + "\tpublic IFigure getContentPane() {";
  protected final String TEXT_26 = NL + "    return ((";
  protected final String TEXT_27 = ") getFigure()).getContentPane();";
  protected final String TEXT_28 = NL + "\treturn getFigure(); ";
  protected final String TEXT_29 = NL + "  }" + NL + "" + NL + "  /**" + NL + "   * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#refreshVisuals()" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "\tpublic void refreshVisuals() {";
  protected final String TEXT_30 = NL + "    String name = getENode().getName();" + NL + "    if (name == null || name.trim().length() == 0)" + NL + "      name = getLabelProvider().getText(getENode().getEObject());";
  protected final String TEXT_31 = NL + "    ";
  protected final String TEXT_32 = " l = (Label) ((";
  protected final String TEXT_33 = ") getFigure()).getHeader();" + NL + "    l.setText(name);" + NL;
  protected final String TEXT_34 = NL + "    ";
  protected final String TEXT_35 = " loc = getENode().getLocation();";
  protected final String TEXT_36 = NL + "    ";
  protected final String TEXT_37 = " size = new Dimension((int) getENode().getWidth(), (int) getENode().getHeight());";
  protected final String TEXT_38 = NL + "    ";
  protected final String TEXT_39 = " r = new Rectangle(loc, size);" + NL + "" + NL + "\tif (getParent() instanceof ";
  protected final String TEXT_40 = ")" + NL + "    \t((GraphicalEditPart) getParent()).setLayoutConstraint(this, getFigure(), r);";
  protected final String TEXT_41 = NL + "\t// TODO : Implements the figure's visual refresh here." + NL + "\t// Ensure that you remove @generated or mark it @generated NOT" + NL + "\t";
  protected final String TEXT_42 = " figure = (";
  protected final String TEXT_43 = ") getFigure();" + NL + "\t";
  protected final String TEXT_44 = " loc = getENode().getLocation();" + NL + "    int w = (int) getENode().getWidth() == 0 ? 30 : (int) getENode().getWidth();" + NL + "    int h = (int) getENode().getHeight() == 0 ? 30 : (int) getENode().getHeight();";
  protected final String TEXT_45 = NL + "    ";
  protected final String TEXT_46 = " size = new Dimension(w, h);" + NL + "    " + NL + "    figure.setFill(true);" + NL + "    figure.setLocation(loc);" + NL + "    figure.setSize(size);";
  protected final String TEXT_47 = NL + "  }" + NL;
  protected final String TEXT_48 = NL + "  /**" + NL + "   * @see org.eclipse.gef.editparts.AbstractEditPart#createEditPolicies()" + NL + "   * <!-- begin-user-doc --> " + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected void createEditPolicies() {";
  protected final String TEXT_49 = NL + "\t\t// Node Container & Layout Edit Policy" + NL + "    installEditPolicy(";
  protected final String TEXT_50 = ".LAYOUT_ROLE, new ";
  protected final String TEXT_51 = "());";
  protected final String TEXT_52 = NL + "\t\t// Node Component Edit Policy" + NL + "\tinstallEditPolicy(";
  protected final String TEXT_53 = ".COMPONENT_ROLE, new ";
  protected final String TEXT_54 = "());";
  protected final String TEXT_55 = NL + "\t\t// Node Direct Edit Policy" + NL + "\tinstallEditPolicy(";
  protected final String TEXT_56 = ".DIRECT_EDIT_ROLE, new ";
  protected final String TEXT_57 = "());";
  protected final String TEXT_58 = NL + "\t\t// Node Graphical Node Edit Policy" + NL + "    installEditPolicy(";
  protected final String TEXT_59 = ".GRAPHICAL_NODE_ROLE, new ";
  protected final String TEXT_60 = "());";
  protected final String TEXT_61 = NL + "  }";
  protected final String TEXT_62 = NL + "}";

  public String generate(Object argument)
  {
    StringBuffer stringBuffer = new StringBuffer();
    
/**
 * Copyright (c) 2005 Joel Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

    GenNodeEditPart genEditPart = (GenNodeEditPart) argument; EClass ecoreClass = genEditPart.getEcoreClass(); EPackage ecorePackage = (EPackage) ecoreClass.getEPackage(); GenModel genModel = genEditPart.getGenGEFModel().getGenModel(); GenClass genClass = GenModelHelper.getGenClass(genModel, ecoreClass);
    stringBuffer.append(TEXT_1);
    stringBuffer.append(TEXT_2);
    stringBuffer.append("$");
    stringBuffer.append(TEXT_3);
    stringBuffer.append("$");
    stringBuffer.append(TEXT_4);
    stringBuffer.append(genEditPart.getPackageName());
    stringBuffer.append(TEXT_5);
    genModel.markImportLocation(stringBuffer);
    stringBuffer.append(TEXT_6);
    if (ecoreClass.isAbstract()) {
    stringBuffer.append(TEXT_7);
    }
    stringBuffer.append(TEXT_8);
    stringBuffer.append(ecoreClass.getName());
    stringBuffer.append(TEXT_9);
    stringBuffer.append(GenModelHelper.getNodeEditPartExtendsLitteral(genModel, genEditPart));
    stringBuffer.append(TEXT_10);
    stringBuffer.append(ecoreClass.getName());
    stringBuffer.append(TEXT_11);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.model.ENode"));
    stringBuffer.append(TEXT_12);
    stringBuffer.append(genModel.getImportedName("org.eclipse.emf.common.notify.AdapterFactory"));
    stringBuffer.append(TEXT_13);
    stringBuffer.append(genClass.getImportedClassName());
    stringBuffer.append(TEXT_14);
    stringBuffer.append(ecoreClass.getName());
    stringBuffer.append(TEXT_15);
    stringBuffer.append(genClass.getImportedClassName());
    stringBuffer.append(TEXT_16);
    stringBuffer.append(genModel.getImportedName("org.eclipse.draw2d.IFigure"));
    stringBuffer.append(TEXT_17);
    if (genEditPart.getGenFigure() == null || "com.metys.merlin.generation.gef.figures.ENodeFigure".equals(genEditPart.getGenFigure().getFigureClass())) {
    stringBuffer.append(TEXT_18);
    stringBuffer.append(genModel.getImportedName("org.eclipse.draw2d.Label"));
    stringBuffer.append(TEXT_19);
    stringBuffer.append(genModel.getImportedName("org.eclipse.draw2d.PositionConstants"));
    stringBuffer.append(TEXT_20);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.figures.ENodeFigure"));
    stringBuffer.append(TEXT_21);
    } else {
    stringBuffer.append(TEXT_22);
    stringBuffer.append(genModel.getImportedName(genEditPart.getGenFigure().getFigureClass()));
    stringBuffer.append(TEXT_23);
    stringBuffer.append(genModel.getImportedName(genEditPart.getGenFigure().getFigureClass()));
    stringBuffer.append(TEXT_24);
    }
    stringBuffer.append(TEXT_25);
    if (genEditPart.getGenFigure() == null || "com.metys.merlin.generation.gef.figures.ENodeFigure".equals(genEditPart.getGenFigure().getFigureClass())) {
    stringBuffer.append(TEXT_26);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.figures.ENodeFigure"));
    stringBuffer.append(TEXT_27);
    } else {
    stringBuffer.append(TEXT_28);
    }
    stringBuffer.append(TEXT_29);
    if (genEditPart.getGenFigure() == null || "com.metys.merlin.generation.gef.figures.ENodeFigure".equals(genEditPart.getGenFigure().getFigureClass())) {
    stringBuffer.append(TEXT_30);
    stringBuffer.append(TEXT_31);
    stringBuffer.append(genModel.getImportedName("org.eclipse.draw2d.Label"));
    stringBuffer.append(TEXT_32);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.figures.ENodeFigure"));
    stringBuffer.append(TEXT_33);
    stringBuffer.append(TEXT_34);
    stringBuffer.append(genModel.getImportedName("org.eclipse.draw2d.geometry.Point"));
    stringBuffer.append(TEXT_35);
    stringBuffer.append(TEXT_36);
    stringBuffer.append(genModel.getImportedName("org.eclipse.draw2d.geometry.Dimension"));
    stringBuffer.append(TEXT_37);
    stringBuffer.append(TEXT_38);
    stringBuffer.append(genModel.getImportedName("org.eclipse.draw2d.geometry.Rectangle"));
    stringBuffer.append(TEXT_39);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.GraphicalEditPart"));
    stringBuffer.append(TEXT_40);
    } else {
    stringBuffer.append(TEXT_41);
    stringBuffer.append(genModel.getImportedName(genEditPart.getGenFigure().getFigureClass()));
    stringBuffer.append(TEXT_42);
    stringBuffer.append(genModel.getImportedName(genEditPart.getGenFigure().getFigureClass()));
    stringBuffer.append(TEXT_43);
    stringBuffer.append(genModel.getImportedName("org.eclipse.draw2d.geometry.Point"));
    stringBuffer.append(TEXT_44);
    stringBuffer.append(TEXT_45);
    stringBuffer.append(genModel.getImportedName("org.eclipse.draw2d.geometry.Dimension"));
    stringBuffer.append(TEXT_46);
    }
    stringBuffer.append(TEXT_47);
     if (!genClass.isAbstract()) {
    stringBuffer.append(TEXT_48);
    if (genEditPart.isContainerEditPolicy()) {
    stringBuffer.append(TEXT_49);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.EditPolicy"));
    stringBuffer.append(TEXT_50);
    stringBuffer.append(genModel.getImportedName(genEditPart.getPackageName() + ".policies." + genEditPart.getName() + "LayoutEditPolicy"));
    stringBuffer.append(TEXT_51);
    }
    if (genEditPart.isComponentEditPolicy()) {
    stringBuffer.append(TEXT_52);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.EditPolicy"));
    stringBuffer.append(TEXT_53);
    stringBuffer.append(genModel.getImportedName(genEditPart.getPackageName() + ".policies." + genEditPart.getName() + "ComponentEditPolicy"));
    stringBuffer.append(TEXT_54);
    }
    if (genEditPart.isDirectEditPolicy()) {
    stringBuffer.append(TEXT_55);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.EditPolicy"));
    stringBuffer.append(TEXT_56);
    stringBuffer.append(genModel.getImportedName(genEditPart.getPackageName() + ".policies." + genEditPart.getName() + "DirectEditPolicy"));
    stringBuffer.append(TEXT_57);
    }
    if (genEditPart.isGraphicalEditPolicy()) {
    stringBuffer.append(TEXT_58);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.EditPolicy"));
    stringBuffer.append(TEXT_59);
    stringBuffer.append(genModel.getImportedName(genEditPart.getPackageName() + ".policies." + genEditPart.getName() + "GraphicalNodeEditPolicy"));
    stringBuffer.append(TEXT_60);
    }
    stringBuffer.append(TEXT_61);
    }
    stringBuffer.append(TEXT_62);
    genModel.emitSortedImports();
    return stringBuffer.toString();
  }
}
