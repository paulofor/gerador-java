/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.commands;

import java.util.Iterator;

import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.commands.Command;

import com.metys.merlin.generation.gef.model.ELink;
import com.metys.merlin.generation.gef.model.ENode;
import com.metys.merlin.generation.gef.model.EReferenceLink;
import com.metys.merlin.generation.gef.parts.ENodeEditPart;
import com.metys.merlin.generation.gef.policies.ENodeGraphicalNodeEditPolicy;

/**
 * @author Joel Cheuoua
 */
public class CreateConnectionCommand extends Command {

  protected ENodeEditPart sourceNodeEditPart;

  protected ENodeEditPart targetNodeEditPart;

  /** The link between source and target nodes * */
  protected ELink link;

  /** The source Node * */
  protected ENode source;

  /** The target Node * */
  protected ENode target;

  /**
   * @param sourceNodeEditPart
   * @param link
   */
  public CreateConnectionCommand(ENodeEditPart sourceNodeEditPart, ELink link) {
    this.sourceNodeEditPart = sourceNodeEditPart;
    this.source = sourceNodeEditPart.getENode();
    this.link = link;
  }

  /*
   * (non-Javadoc)
   * 
   * @see org.eclipse.gef.commands.Command#canExecute()
   */
  public boolean canExecute() {
    if (source.equals(target))
      return false;
    if (target == null)
      return false;
    if (!acceptLinkAsSource(sourceNodeEditPart, link))
      return false;
    if (!acceptLinkAsTarget(targetNodeEditPart, link))
      return false;

    // If the link is a reference link
    // Do not create the link if it already exists
    if (link instanceof EReferenceLink && linkExists(source, target, (EReferenceLink) link))
      return false;

    return true;
  }

  /**
   * Method acceptLinkAsSource.
   * 
   * @param aLink
   *          ELink
   * @return boolean
   */
  public boolean acceptLinkAsSource(ENodeEditPart editPart, ELink aLink) {
    EditPolicy graphicalNodeEditPolicy = editPart.getEditPolicy(EditPolicy.GRAPHICAL_NODE_ROLE);
    if (graphicalNodeEditPolicy instanceof ENodeGraphicalNodeEditPolicy) {
      return ((ENodeGraphicalNodeEditPolicy) graphicalNodeEditPolicy).acceptLinkAsSource(editPart.getENode(), aLink);
    }
    return false;
  }

  /**
   * Method acceptLinkAsTarget.
   * 
   * @param aLink
   *          ELink
   * @return boolean
   */
  public boolean acceptLinkAsTarget(ENodeEditPart editPart, ELink aLink) {
    EditPolicy graphicalNodeEditPolicy = editPart.getEditPolicy(EditPolicy.GRAPHICAL_NODE_ROLE);
    if (graphicalNodeEditPolicy instanceof ENodeGraphicalNodeEditPolicy) {
      return ((ENodeGraphicalNodeEditPolicy) graphicalNodeEditPolicy).acceptLinkAsTarget(editPart.getENode(), aLink);
    }
    return false;
  }

  /**
   * @param sourceNode
   * @param targetNode
   * @param candidateLink
   * @return
   */
  protected boolean linkExists(ENode sourceNode, ENode targetNode, EReferenceLink candidateLink) {
    boolean linkExists = false;
    for (Iterator iter = sourceNode.getOutgoingLinks().iterator(); iter.hasNext();) {
      ELink aLink = (ELink) iter.next();
      if (!(aLink instanceof EReferenceLink) || aLink.getTarget() != targetNode)
        continue;
      EReferenceLink refLink = (EReferenceLink) aLink;
      if (refLink.getEReference() == candidateLink.getEReference()) {
        linkExists = true;
        break;
      }
    }
    return linkExists;
  }

  /*
   * (non-Javadoc)
   * 
   * @see org.eclipse.gef.commands.Command#execute()
   */
  public void execute() {
    sourceNodeEditPart.disableNotifications();
    targetNodeEditPart.disableNotifications();
    link.setTarget(target);
    link.setSource(source);
    link.doLink();
    sourceNodeEditPart.refresh();
    targetNodeEditPart.refresh();
    sourceNodeEditPart.enableNotifications();
    targetNodeEditPart.enableNotifications();
  }

  /*
   * (non-Javadoc)
   * 
   * @see org.eclipse.gef.commands.Command#undo()
   */
  public void undo() {
    sourceNodeEditPart.disableNotifications();
    targetNodeEditPart.disableNotifications();
    link.doUnlink();
    link.setSource(null);
    link.setTarget(null);
    sourceNodeEditPart.refresh();
    targetNodeEditPart.refresh();
    sourceNodeEditPart.enableNotifications();
    targetNodeEditPart.enableNotifications();
  }

  /**
   * @return Returns the link.
   */
  public ELink getLink() {
    return link;
  }

  /**
   * @param targetNodeEditPart
   *          The targetNodeEditPart to set.
   */
  public void setTargetNodeEditPart(ENodeEditPart targetNodeEditPart) {
    this.targetNodeEditPart = targetNodeEditPart;
    this.target = targetNodeEditPart.getENode();
  }
}
