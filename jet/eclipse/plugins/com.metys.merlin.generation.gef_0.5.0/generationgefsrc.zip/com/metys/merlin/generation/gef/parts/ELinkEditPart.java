/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.parts;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.draw2d.Graphics;
import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.PolygonDecoration;
import org.eclipse.draw2d.PolylineConnection;
import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.gef.EditPolicy;

import com.metys.merlin.generation.gef.model.ELink;
import com.metys.merlin.generation.gef.model.EReferenceLink;
import com.metys.merlin.generation.gef.model.ModelPackage;
import com.metys.merlin.generation.gef.policies.ELinkBendpointEditPolicy;
import com.metys.merlin.generation.gef.policies.ELinkConnectionEditPolicy;
import com.metys.merlin.generation.gef.policies.ELinkEndpointEditPolicy;

/**
 * @author jcheuoua
 * @version $Revision: 1.1 $
 */
public class ELinkEditPart extends GraphicalConnectionEditPart {
  
  /**
   * Constructor for ELinkEditPart.
   * @param link ELink
   * @param adapterFactory AdapterFactory
   */
  public ELinkEditPart(ELink link, AdapterFactory adapterFactory) {
    super(adapterFactory);
    setModel(link);
  }
  
  /**
   * Method getELink.
   * @return ELink
   */
  public ELink getELink() {
    return (ELink) getModel();
  }
  
  protected void refreshVisuals() {
    getConnectionFigure().setRoutingConstraint(getELink().getBendpoints());
  }
  
  /**
   * @param msg
   */
  protected void handlePropertyChanged(Notification msg) {
    switch (msg.getFeatureID(ELink.class)) {
    case ModelPackage.ELINK__BENDPOINTS:
      refreshVisuals();
      break;
    case ModelPackage.ELINK__SOURCE:
      refreshSourceAnchor();
      break;
    case ModelPackage.ELINK__TARGET:
      refreshTargetAnchor();
      break;
    }
  }
  
  /**
   * @see org.eclipse.gef.editparts.AbstractEditPart#createEditPolicies()
   */
  protected void createEditPolicies() {
    installEditPolicy(EditPolicy.CONNECTION_ROLE, new ELinkConnectionEditPolicy());
    installEditPolicy(EditPolicy.CONNECTION_ENDPOINTS_ROLE, new ELinkEndpointEditPolicy());    
    installEditPolicy(EditPolicy.CONNECTION_BENDPOINTS_ROLE, new ELinkBendpointEditPolicy());
  }

  /**
   * @see org.eclipse.gef.editparts.AbstractConnectionEditPart#createFigure()
   */
  protected IFigure createFigure() {
    PolylineConnection conn = new PolylineConnection() {
      public void paint(Graphics graphics) {
        // ensure the line width is 1 if line style is custom
        if (getLineStyle() == Graphics.LINE_DASHDOTDOT)
          graphics.setLineWidth(1);
        super.paint(graphics);
      }
    };
    if (getELink() instanceof EReferenceLink) {
      EReferenceLink refLink = (EReferenceLink) getELink();
      EClass referenceType = refLink.getEReference().getEReferenceType();
      EClass sourceType = refLink.getSource() == null ? null : refLink.getSource().getEObject().eClass();
      EClass targetType = refLink.getTarget() == null ? null : refLink.getTarget().getEObject().eClass();    
      if (sourceType != null && referenceType.isSuperTypeOf(sourceType))
        conn.setSourceDecoration(new PolygonDecoration());
      else if (targetType != null && referenceType.isSuperTypeOf(targetType))
        conn.setTargetDecoration(new PolygonDecoration());
      if (refLink.getEReference().isContainer() || refLink.getEReference().isContainment()) {
        conn.setLineStyle(Graphics.LINE_SOLID);
        conn.setLineWidth(2);
        conn.setForegroundColor(ColorConstants.blue);
      } else {
        conn.setLineStyle(Graphics.LINE_DASHDOTDOT);
        conn.setForegroundColor(ColorConstants.black);
      }
    }
    conn.setRoutingConstraint(getELink().getBendpoints());
    return conn;
  }

}