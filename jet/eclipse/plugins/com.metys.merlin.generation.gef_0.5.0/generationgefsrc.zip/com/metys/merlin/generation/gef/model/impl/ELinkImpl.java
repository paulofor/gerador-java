/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.model.impl;

import java.util.Collection;

import org.eclipse.draw2d.Bendpoint;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;
import org.eclipse.emf.ecore.util.EcoreUtil;

import com.metys.merlin.generation.gef.model.ELink;
import com.metys.merlin.generation.gef.model.ENode;
import com.metys.merlin.generation.gef.model.ModelPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>ELink</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.gef.model.impl.ELinkImpl#getSource <em>Source</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.impl.ELinkImpl#getTarget <em>Target</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.impl.ELinkImpl#getBendpoints <em>Bendpoints</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.impl.ELinkImpl#getInvalidMessage <em>Invalid Message</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public abstract class ELinkImpl extends EObjectImpl implements ELink {
  /**
   * The cached value of the '{@link #getTarget() <em>Target</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTarget()
   * @generated
   * @ordered
   */
  protected ENode target = null;

  /**
   * The cached value of the '{@link #getBendpoints() <em>Bendpoints</em>}' attribute list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getBendpoints()
   * @generated
   * @ordered
   */
  protected EList bendpoints = null;

  /**
   * The default value of the '{@link #getInvalidMessage() <em>Invalid Message</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInvalidMessage()
   * @generated
   * @ordered
   */
  protected static final String INVALID_MESSAGE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getInvalidMessage() <em>Invalid Message</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInvalidMessage()
   * @generated
   * @ordered
   */
  protected String invalidMessage = INVALID_MESSAGE_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ELinkImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return ModelPackage.eINSTANCE.getELink();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ENode getSource() {
    if (eContainerFeatureID != ModelPackage.ELINK__SOURCE) return null;
    return (ENode)eContainer;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setSource(ENode newSource) {
    if (newSource != eContainer || (eContainerFeatureID != ModelPackage.ELINK__SOURCE && newSource != null)) {
      if (EcoreUtil.isAncestor(this, newSource))
        throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
      NotificationChain msgs = null;
      if (eContainer != null)
        msgs = eBasicRemoveFromContainer(msgs);
      if (newSource != null)
        msgs = ((InternalEObject)newSource).eInverseAdd(this, ModelPackage.ENODE__OUTGOING_LINKS, ENode.class, msgs);
      msgs = eBasicSetContainer((InternalEObject)newSource, ModelPackage.ELINK__SOURCE, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.ELINK__SOURCE, newSource, newSource));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ENode getTarget() {
    if (target != null && target.eIsProxy()) {
      ENode oldTarget = target;
      target = (ENode)eResolveProxy((InternalEObject)target);
      if (target != oldTarget) {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, ModelPackage.ELINK__TARGET, oldTarget, target));
      }
    }
    return target;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ENode basicGetTarget() {
    return target;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetTarget(ENode newTarget, NotificationChain msgs) {
    ENode oldTarget = target;
    target = newTarget;
    if (eNotificationRequired()) {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ModelPackage.ELINK__TARGET, oldTarget, newTarget);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTarget(ENode newTarget) {
    if (newTarget != target) {
      NotificationChain msgs = null;
      if (target != null)
        msgs = ((InternalEObject)target).eInverseRemove(this, ModelPackage.ENODE__INCOMING_LINKS, ENode.class, msgs);
      if (newTarget != null)
        msgs = ((InternalEObject)newTarget).eInverseAdd(this, ModelPackage.ENODE__INCOMING_LINKS, ENode.class, msgs);
      msgs = basicSetTarget(newTarget, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.ELINK__TARGET, newTarget, newTarget));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getBendpoints() {
    if (bendpoints == null) {
      bendpoints = new EDataTypeUniqueEList(Bendpoint.class, this, ModelPackage.ELINK__BENDPOINTS);
    }
    return bendpoints;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getInvalidMessage() {
    return invalidMessage;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setInvalidMessage(String newInvalidMessage) {
    String oldInvalidMessage = invalidMessage;
    invalidMessage = newInvalidMessage;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.ELINK__INVALID_MESSAGE, oldInvalidMessage, invalidMessage));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public abstract void doLink();

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public abstract void doUnlink();

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case ModelPackage.ELINK__SOURCE:
          if (eContainer != null)
            msgs = eBasicRemoveFromContainer(msgs);
          return eBasicSetContainer(otherEnd, ModelPackage.ELINK__SOURCE, msgs);
        case ModelPackage.ELINK__TARGET:
          if (target != null)
            msgs = ((InternalEObject)target).eInverseRemove(this, ModelPackage.ENODE__INCOMING_LINKS, ENode.class, msgs);
          return basicSetTarget((ENode)otherEnd, msgs);
        default:
          return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case ModelPackage.ELINK__SOURCE:
          return eBasicSetContainer(null, ModelPackage.ELINK__SOURCE, msgs);
        case ModelPackage.ELINK__TARGET:
          return basicSetTarget(null, msgs);
        default:
          return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
    if (eContainerFeatureID >= 0) {
      switch (eContainerFeatureID) {
        case ModelPackage.ELINK__SOURCE:
          return eContainer.eInverseRemove(this, ModelPackage.ENODE__OUTGOING_LINKS, ENode.class, msgs);
        default:
          return eDynamicBasicRemoveFromContainer(msgs);
      }
    }
    return eContainer.eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ModelPackage.ELINK__SOURCE:
        return getSource();
      case ModelPackage.ELINK__TARGET:
        if (resolve) return getTarget();
        return basicGetTarget();
      case ModelPackage.ELINK__BENDPOINTS:
        return getBendpoints();
      case ModelPackage.ELINK__INVALID_MESSAGE:
        return getInvalidMessage();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ModelPackage.ELINK__SOURCE:
        setSource((ENode)newValue);
        return;
      case ModelPackage.ELINK__TARGET:
        setTarget((ENode)newValue);
        return;
      case ModelPackage.ELINK__BENDPOINTS:
        getBendpoints().clear();
        getBendpoints().addAll((Collection)newValue);
        return;
      case ModelPackage.ELINK__INVALID_MESSAGE:
        setInvalidMessage((String)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ModelPackage.ELINK__SOURCE:
        setSource((ENode)null);
        return;
      case ModelPackage.ELINK__TARGET:
        setTarget((ENode)null);
        return;
      case ModelPackage.ELINK__BENDPOINTS:
        getBendpoints().clear();
        return;
      case ModelPackage.ELINK__INVALID_MESSAGE:
        setInvalidMessage(INVALID_MESSAGE_EDEFAULT);
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ModelPackage.ELINK__SOURCE:
        return getSource() != null;
      case ModelPackage.ELINK__TARGET:
        return target != null;
      case ModelPackage.ELINK__BENDPOINTS:
        return bendpoints != null && !bendpoints.isEmpty();
      case ModelPackage.ELINK__INVALID_MESSAGE:
        return INVALID_MESSAGE_EDEFAULT == null ? invalidMessage != null : !INVALID_MESSAGE_EDEFAULT.equals(invalidMessage);
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString() {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (bendpoints: ");
    result.append(bendpoints);
    result.append(", invalidMessage: ");
    result.append(invalidMessage);
    result.append(')');
    return result.toString();
  }

} //ELinkImpl
