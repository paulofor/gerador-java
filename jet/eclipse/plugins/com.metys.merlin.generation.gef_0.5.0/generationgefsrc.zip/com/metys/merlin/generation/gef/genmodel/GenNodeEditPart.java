/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.genmodel;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Gen Node Edit Part</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#getGenFigure <em>Gen Figure</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#getSubNodeReferences <em>Sub Node References</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#isComponentEditPolicy <em>Component Edit Policy</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#isContainerEditPolicy <em>Container Edit Policy</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#isGraphicalEditPolicy <em>Graphical Edit Policy</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#isDirectEditPolicy <em>Direct Edit Policy</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenNodeEditPart()
 * @model
 * @generated
 */
public interface GenNodeEditPart extends GenEditPart{
  /**
   * Returns the value of the '<em><b>Gen Figure</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Gen Figure</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Gen Figure</em>' containment reference.
   * @see #setGenFigure(GenFigure)
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenNodeEditPart_GenFigure()
   * @model containment="true"
   * @generated
   */
  GenFigure getGenFigure();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#getGenFigure <em>Gen Figure</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Gen Figure</em>' containment reference.
   * @see #getGenFigure()
   * @generated
   */
  void setGenFigure(GenFigure value);

  /**
   * Returns the value of the '<em><b>Sub Node References</b></em>' containment reference list.
   * The list contents are of type {@link com.metys.merlin.generation.gef.genmodel.GenSubNodeReference}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Sub Node References</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Sub Node References</em>' containment reference list.
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenNodeEditPart_SubNodeReferences()
   * @model type="com.metys.merlin.generation.gef.genmodel.GenSubNodeReference" containment="true"
   * @generated
   */
  EList getSubNodeReferences();

  /**
   * Returns the value of the '<em><b>Component Edit Policy</b></em>' attribute.
   * The default value is <code>"true"</code>.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Component Edit Policy</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Component Edit Policy</em>' attribute.
   * @see #setComponentEditPolicy(boolean)
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenNodeEditPart_ComponentEditPolicy()
   * @model default="true"
   * @generated
   */
  boolean isComponentEditPolicy();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#isComponentEditPolicy <em>Component Edit Policy</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Component Edit Policy</em>' attribute.
   * @see #isComponentEditPolicy()
   * @generated
   */
  void setComponentEditPolicy(boolean value);

  /**
   * Returns the value of the '<em><b>Container Edit Policy</b></em>' attribute.
   * The default value is <code>"true"</code>.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Container Edit Policy</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Container Edit Policy</em>' attribute.
   * @see #setContainerEditPolicy(boolean)
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenNodeEditPart_ContainerEditPolicy()
   * @model default="true"
   * @generated
   */
  boolean isContainerEditPolicy();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#isContainerEditPolicy <em>Container Edit Policy</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Container Edit Policy</em>' attribute.
   * @see #isContainerEditPolicy()
   * @generated
   */
  void setContainerEditPolicy(boolean value);

  /**
   * Returns the value of the '<em><b>Graphical Edit Policy</b></em>' attribute.
   * The default value is <code>"true"</code>.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Graphical Edit Policy</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Graphical Edit Policy</em>' attribute.
   * @see #setGraphicalEditPolicy(boolean)
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenNodeEditPart_GraphicalEditPolicy()
   * @model default="true"
   * @generated
   */
  boolean isGraphicalEditPolicy();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#isGraphicalEditPolicy <em>Graphical Edit Policy</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Graphical Edit Policy</em>' attribute.
   * @see #isGraphicalEditPolicy()
   * @generated
   */
  void setGraphicalEditPolicy(boolean value);

  /**
   * Returns the value of the '<em><b>Direct Edit Policy</b></em>' attribute.
   * The default value is <code>"true"</code>.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Direct Edit Policy</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Direct Edit Policy</em>' attribute.
   * @see #setDirectEditPolicy(boolean)
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenNodeEditPart_DirectEditPolicy()
   * @model default="true"
   * @generated
   */
  boolean isDirectEditPolicy();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#isDirectEditPolicy <em>Direct Edit Policy</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Direct Edit Policy</em>' attribute.
   * @see #isDirectEditPolicy()
   * @generated
   */
  void setDirectEditPolicy(boolean value);

} // GenNodeEditPart
