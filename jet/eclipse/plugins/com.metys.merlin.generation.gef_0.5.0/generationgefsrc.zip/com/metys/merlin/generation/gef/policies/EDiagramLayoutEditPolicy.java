/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.policies;

import java.util.List;

import org.eclipse.draw2d.geometry.Point;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.Request;
import org.eclipse.gef.commands.Command;
import org.eclipse.gef.commands.CompoundCommand;
import org.eclipse.gef.commands.UnexecutableCommand;
import org.eclipse.gef.editpolicies.XYLayoutEditPolicy;
import org.eclipse.gef.requests.CreateRequest;
import org.eclipse.gef.requests.GroupRequest;

import com.metys.merlin.generation.gef.commands.AddElementCommand;
import com.metys.merlin.generation.gef.commands.ChangeBoundsCommand;
import com.metys.merlin.generation.gef.commands.CreateElementCommand;
import com.metys.merlin.generation.gef.commands.OrphanNodeCommand;
import com.metys.merlin.generation.gef.commands.TransferLinkCommand;
import com.metys.merlin.generation.gef.model.EDiagram;
import com.metys.merlin.generation.gef.model.ELink;
import com.metys.merlin.generation.gef.model.ENode;
import com.metys.merlin.generation.gef.model.EObjectLink;
import com.metys.merlin.generation.gef.model.EReferenceLink;
import com.metys.merlin.generation.gef.model.ModelFactory;
import com.metys.merlin.generation.gef.outline.ClassLinkModel;
import com.metys.merlin.generation.gef.outline.LinkModel;
import com.metys.merlin.generation.gef.outline.ReferenceLinkModel;
import com.metys.merlin.generation.gef.parts.EDiagramEditPart;
import com.metys.merlin.generation.gef.parts.ENodeEditPart;
import com.metys.merlin.generation.gef.parts.GraphicalComponentEditPart;

/**
 * @author Jo�l
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class EDiagramLayoutEditPolicy extends XYLayoutEditPolicy {
  
  protected Command createAddCommand(EditPart childEditPart, Object constraint) {
    ENode child = (ENode) childEditPart.getModel();
    EDiagram parent = (EDiagram) (getHost().getModel());
    Point location = new Point();
    if (constraint instanceof Rectangle) {
      location.x = ((Rectangle) constraint).x;
      location.y = ((Rectangle) constraint).y;
    }
    AddElementCommand add = new AddElementCommand((GraphicalComponentEditPart)getHost(), child, location);
    return add;
  }

  protected Command createChangeConstraintCommand(EditPart child, Object constraint) {
    Rectangle rec = (Rectangle) constraint;
    Point newLocation = new Point(rec.x, rec.y);
    return new ChangeBoundsCommand((ENodeEditPart) child, newLocation, rec.width, rec.height);
  }
  
  /* (non javadoc)
   * @see org.eclipse.gef.editpolicies.LayoutEditPolicy#getOrphanChildrenCommand(org.eclipse.gef.requests.Request)
   */
  protected Command getOrphanChildrenCommand(Request request) {
    GroupRequest gRequest = (GroupRequest) request;
    List parts = gRequest.getEditParts();
    EDiagram parent = getDiagram();
    CompoundCommand result = new CompoundCommand();
    for (int i = 0; i < parts.size(); i++) {
      ENode model = (ENode) ((EditPart) parts.get(i)).getModel();
      OrphanNodeCommand orphan = new OrphanNodeCommand((GraphicalComponentEditPart)getHost(), model);
      result.add(orphan);      
    }
    return result.unwrap();
  }
  
  protected Command getCreateCommand(CreateRequest request) {
    Object newObject = request.getNewObject(); 
    if (newObject instanceof ENode) {
      Point loc = request.getLocation();
      getHostFigure().translateToRelative(loc);
      return new CreateElementCommand((GraphicalComponentEditPart)getHost(),(ENode)newObject, loc);
    } else if (newObject instanceof List) {
      List views = (List)newObject;      
      if (views.isEmpty())
        return UnexecutableCommand.INSTANCE;
      CompoundCommand command = new CompoundCommand("Drag from Outline");
      Point loc = request.getLocation();
      getHostFigure().translateToRelative(loc);
      for (int i = 0; i < views.size(); i++) {
        Object view = views.get(i);
        if (view instanceof EObject) {
          ENode node = ModelFactory.eINSTANCE.createENode();
          node.setEObject((EObject) view);
          GraphicalComponentEditPart hostComponentEditPart = (GraphicalComponentEditPart)getHost();
          command.add(new CreateElementCommand(hostComponentEditPart, node, loc.getTranslated(i * 40, i * 40)));        
        } else if (view instanceof LinkModel) {
          LinkModel linkModel = (LinkModel) view;
          EDiagram diagram = getDiagram();
          ENode sourceNode = diagram.getENode(linkModel.getEObject());
          ENode targetNode = diagram.getENode(linkModel.getRefEObject());
          
          // look for the edit parts in the contents of this diagram
          EDiagramEditPart diagramEditPart = null;
          EditPart parent = getHost();
          while (!(parent instanceof EDiagramEditPart) && parent != null)
            parent = parent.getParent();
          if (parent instanceof EDiagramEditPart)
            diagramEditPart = (EDiagramEditPart) parent;
          ENodeEditPart sourceEditPart = diagramEditPart.findNodeEditPart(sourceNode);
          ENodeEditPart targetEditPart = diagramEditPart.findNodeEditPart(targetNode);          
          ELink link = null;
          if (linkModel instanceof ReferenceLinkModel) {
            link = ModelFactory.eINSTANCE.createEReferenceLink();
            ((EReferenceLink)link).setEReference(((ReferenceLinkModel)linkModel).getEReference());
          } else if (linkModel instanceof ClassLinkModel) {
            link = ModelFactory.eINSTANCE.createEObjectLink();
            ((EObjectLink)link).setTransitionEObject(((ClassLinkModel)linkModel).getTransitionObject());
            ((EObjectLink)link).setSourceReference(((ClassLinkModel)linkModel).getSourceRef());
            ((EObjectLink)link).setTargetReference(((ClassLinkModel)linkModel).getTargetRef());
          }
          command.add(new TransferLinkCommand(link, sourceEditPart, targetEditPart));
        }
      }
      return command;
    }
    return UnexecutableCommand.INSTANCE;
  }
  
  public EDiagram getDiagram() {
    EDiagram diagram = (EDiagram) getHost().getModel();
    return diagram;
  }
  
  protected Command getDeleteDependantCommand(Request request) {
    return null;
  }
}
