/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.genmodel.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import com.metys.merlin.generation.gef.genmodel.GenFigure;
import com.metys.merlin.generation.gef.genmodel.GenGEFModel;
import com.metys.merlin.generation.gef.genmodel.GenModelPackage;
import com.metys.merlin.generation.gef.genmodel.GenNodeEditPart;
import com.metys.merlin.generation.gef.genmodel.GenSubNodeReference;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Gen Node Edit Part</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenNodeEditPartImpl#getGenFigure <em>Gen Figure</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenNodeEditPartImpl#getSubNodeReferences <em>Sub Node References</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenNodeEditPartImpl#isComponentEditPolicy <em>Component Edit Policy</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenNodeEditPartImpl#isContainerEditPolicy <em>Container Edit Policy</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenNodeEditPartImpl#isGraphicalEditPolicy <em>Graphical Edit Policy</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenNodeEditPartImpl#isDirectEditPolicy <em>Direct Edit Policy</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class GenNodeEditPartImpl extends GenEditPartImpl implements GenNodeEditPart {
  /**
   * The cached value of the '{@link #getGenFigure() <em>Gen Figure</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getGenFigure()
   * @generated
   * @ordered
   */
  protected GenFigure genFigure = null;

  /**
   * The cached value of the '{@link #getSubNodeReferences() <em>Sub Node References</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getSubNodeReferences()
   * @generated
   * @ordered
   */
  protected EList subNodeReferences = null;

  /**
   * The default value of the '{@link #isComponentEditPolicy() <em>Component Edit Policy</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isComponentEditPolicy()
   * @generated
   * @ordered
   */
  protected static final boolean COMPONENT_EDIT_POLICY_EDEFAULT = true;

  /**
   * The cached value of the '{@link #isComponentEditPolicy() <em>Component Edit Policy</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isComponentEditPolicy()
   * @generated
   * @ordered
   */
  protected boolean componentEditPolicy = COMPONENT_EDIT_POLICY_EDEFAULT;

  /**
   * The default value of the '{@link #isContainerEditPolicy() <em>Container Edit Policy</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isContainerEditPolicy()
   * @generated
   * @ordered
   */
  protected static final boolean CONTAINER_EDIT_POLICY_EDEFAULT = true;

  /**
   * The cached value of the '{@link #isContainerEditPolicy() <em>Container Edit Policy</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isContainerEditPolicy()
   * @generated
   * @ordered
   */
  protected boolean containerEditPolicy = CONTAINER_EDIT_POLICY_EDEFAULT;

  /**
   * The default value of the '{@link #isGraphicalEditPolicy() <em>Graphical Edit Policy</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isGraphicalEditPolicy()
   * @generated
   * @ordered
   */
  protected static final boolean GRAPHICAL_EDIT_POLICY_EDEFAULT = true;

  /**
   * The cached value of the '{@link #isGraphicalEditPolicy() <em>Graphical Edit Policy</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isGraphicalEditPolicy()
   * @generated
   * @ordered
   */
  protected boolean graphicalEditPolicy = GRAPHICAL_EDIT_POLICY_EDEFAULT;

  /**
   * The default value of the '{@link #isDirectEditPolicy() <em>Direct Edit Policy</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isDirectEditPolicy()
   * @generated
   * @ordered
   */
  protected static final boolean DIRECT_EDIT_POLICY_EDEFAULT = true;

  /**
   * The cached value of the '{@link #isDirectEditPolicy() <em>Direct Edit Policy</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isDirectEditPolicy()
   * @generated
   * @ordered
   */
  protected boolean directEditPolicy = DIRECT_EDIT_POLICY_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected GenNodeEditPartImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return GenModelPackage.eINSTANCE.getGenNodeEditPart();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenFigure getGenFigure() {
    return genFigure;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetGenFigure(GenFigure newGenFigure, NotificationChain msgs) {
    GenFigure oldGenFigure = genFigure;
    genFigure = newGenFigure;
    if (eNotificationRequired()) {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_NODE_EDIT_PART__GEN_FIGURE, oldGenFigure, newGenFigure);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setGenFigure(GenFigure newGenFigure) {
    if (newGenFigure != genFigure) {
      NotificationChain msgs = null;
      if (genFigure != null)
        msgs = ((InternalEObject)genFigure).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - GenModelPackage.GEN_NODE_EDIT_PART__GEN_FIGURE, null, msgs);
      if (newGenFigure != null)
        msgs = ((InternalEObject)newGenFigure).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - GenModelPackage.GEN_NODE_EDIT_PART__GEN_FIGURE, null, msgs);
      msgs = basicSetGenFigure(newGenFigure, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_NODE_EDIT_PART__GEN_FIGURE, newGenFigure, newGenFigure));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getSubNodeReferences() {
    if (subNodeReferences == null) {
      subNodeReferences = new EObjectContainmentEList(GenSubNodeReference.class, this, GenModelPackage.GEN_NODE_EDIT_PART__SUB_NODE_REFERENCES);
    }
    return subNodeReferences;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isComponentEditPolicy() {
    return componentEditPolicy;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setComponentEditPolicy(boolean newComponentEditPolicy) {
    boolean oldComponentEditPolicy = componentEditPolicy;
    componentEditPolicy = newComponentEditPolicy;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_NODE_EDIT_PART__COMPONENT_EDIT_POLICY, oldComponentEditPolicy, componentEditPolicy));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isContainerEditPolicy() {
    return containerEditPolicy;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setContainerEditPolicy(boolean newContainerEditPolicy) {
    boolean oldContainerEditPolicy = containerEditPolicy;
    containerEditPolicy = newContainerEditPolicy;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_NODE_EDIT_PART__CONTAINER_EDIT_POLICY, oldContainerEditPolicy, containerEditPolicy));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isGraphicalEditPolicy() {
    return graphicalEditPolicy;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setGraphicalEditPolicy(boolean newGraphicalEditPolicy) {
    boolean oldGraphicalEditPolicy = graphicalEditPolicy;
    graphicalEditPolicy = newGraphicalEditPolicy;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_NODE_EDIT_PART__GRAPHICAL_EDIT_POLICY, oldGraphicalEditPolicy, graphicalEditPolicy));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isDirectEditPolicy() {
    return directEditPolicy;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDirectEditPolicy(boolean newDirectEditPolicy) {
    boolean oldDirectEditPolicy = directEditPolicy;
    directEditPolicy = newDirectEditPolicy;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_NODE_EDIT_PART__DIRECT_EDIT_POLICY, oldDirectEditPolicy, directEditPolicy));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case GenModelPackage.GEN_NODE_EDIT_PART__GEN_GEF_MODEL:
          if (eContainer != null)
            msgs = eBasicRemoveFromContainer(msgs);
          return eBasicSetContainer(otherEnd, GenModelPackage.GEN_NODE_EDIT_PART__GEN_GEF_MODEL, msgs);
        default:
          return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case GenModelPackage.GEN_NODE_EDIT_PART__GEN_GEF_MODEL:
          return eBasicSetContainer(null, GenModelPackage.GEN_NODE_EDIT_PART__GEN_GEF_MODEL, msgs);
        case GenModelPackage.GEN_NODE_EDIT_PART__GEN_FIGURE:
          return basicSetGenFigure(null, msgs);
        case GenModelPackage.GEN_NODE_EDIT_PART__SUB_NODE_REFERENCES:
          return ((InternalEList)getSubNodeReferences()).basicRemove(otherEnd, msgs);
        default:
          return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
    if (eContainerFeatureID >= 0) {
      switch (eContainerFeatureID) {
        case GenModelPackage.GEN_NODE_EDIT_PART__GEN_GEF_MODEL:
          return eContainer.eInverseRemove(this, GenModelPackage.GEN_GEF_MODEL__GEN_EDIT_PARTS, GenGEFModel.class, msgs);
        default:
          return eDynamicBasicRemoveFromContainer(msgs);
      }
    }
    return eContainer.eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_NODE_EDIT_PART__NAME:
        return getName();
      case GenModelPackage.GEN_NODE_EDIT_PART__PACKAGE_NAME:
        return getPackageName();
      case GenModelPackage.GEN_NODE_EDIT_PART__ECORE_CLASS:
        if (resolve) return getEcoreClass();
        return basicGetEcoreClass();
      case GenModelPackage.GEN_NODE_EDIT_PART__GEN_GEF_MODEL:
        return getGenGEFModel();
      case GenModelPackage.GEN_NODE_EDIT_PART__GEN_FIGURE:
        return getGenFigure();
      case GenModelPackage.GEN_NODE_EDIT_PART__SUB_NODE_REFERENCES:
        return getSubNodeReferences();
      case GenModelPackage.GEN_NODE_EDIT_PART__COMPONENT_EDIT_POLICY:
        return isComponentEditPolicy() ? Boolean.TRUE : Boolean.FALSE;
      case GenModelPackage.GEN_NODE_EDIT_PART__CONTAINER_EDIT_POLICY:
        return isContainerEditPolicy() ? Boolean.TRUE : Boolean.FALSE;
      case GenModelPackage.GEN_NODE_EDIT_PART__GRAPHICAL_EDIT_POLICY:
        return isGraphicalEditPolicy() ? Boolean.TRUE : Boolean.FALSE;
      case GenModelPackage.GEN_NODE_EDIT_PART__DIRECT_EDIT_POLICY:
        return isDirectEditPolicy() ? Boolean.TRUE : Boolean.FALSE;
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_NODE_EDIT_PART__NAME:
        setName((String)newValue);
        return;
      case GenModelPackage.GEN_NODE_EDIT_PART__PACKAGE_NAME:
        setPackageName((String)newValue);
        return;
      case GenModelPackage.GEN_NODE_EDIT_PART__ECORE_CLASS:
        setEcoreClass((EClass)newValue);
        return;
      case GenModelPackage.GEN_NODE_EDIT_PART__GEN_GEF_MODEL:
        setGenGEFModel((GenGEFModel)newValue);
        return;
      case GenModelPackage.GEN_NODE_EDIT_PART__GEN_FIGURE:
        setGenFigure((GenFigure)newValue);
        return;
      case GenModelPackage.GEN_NODE_EDIT_PART__SUB_NODE_REFERENCES:
        getSubNodeReferences().clear();
        getSubNodeReferences().addAll((Collection)newValue);
        return;
      case GenModelPackage.GEN_NODE_EDIT_PART__COMPONENT_EDIT_POLICY:
        setComponentEditPolicy(((Boolean)newValue).booleanValue());
        return;
      case GenModelPackage.GEN_NODE_EDIT_PART__CONTAINER_EDIT_POLICY:
        setContainerEditPolicy(((Boolean)newValue).booleanValue());
        return;
      case GenModelPackage.GEN_NODE_EDIT_PART__GRAPHICAL_EDIT_POLICY:
        setGraphicalEditPolicy(((Boolean)newValue).booleanValue());
        return;
      case GenModelPackage.GEN_NODE_EDIT_PART__DIRECT_EDIT_POLICY:
        setDirectEditPolicy(((Boolean)newValue).booleanValue());
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_NODE_EDIT_PART__NAME:
        setName(NAME_EDEFAULT);
        return;
      case GenModelPackage.GEN_NODE_EDIT_PART__PACKAGE_NAME:
        setPackageName(PACKAGE_NAME_EDEFAULT);
        return;
      case GenModelPackage.GEN_NODE_EDIT_PART__ECORE_CLASS:
        setEcoreClass((EClass)null);
        return;
      case GenModelPackage.GEN_NODE_EDIT_PART__GEN_GEF_MODEL:
        setGenGEFModel((GenGEFModel)null);
        return;
      case GenModelPackage.GEN_NODE_EDIT_PART__GEN_FIGURE:
        setGenFigure((GenFigure)null);
        return;
      case GenModelPackage.GEN_NODE_EDIT_PART__SUB_NODE_REFERENCES:
        getSubNodeReferences().clear();
        return;
      case GenModelPackage.GEN_NODE_EDIT_PART__COMPONENT_EDIT_POLICY:
        setComponentEditPolicy(COMPONENT_EDIT_POLICY_EDEFAULT);
        return;
      case GenModelPackage.GEN_NODE_EDIT_PART__CONTAINER_EDIT_POLICY:
        setContainerEditPolicy(CONTAINER_EDIT_POLICY_EDEFAULT);
        return;
      case GenModelPackage.GEN_NODE_EDIT_PART__GRAPHICAL_EDIT_POLICY:
        setGraphicalEditPolicy(GRAPHICAL_EDIT_POLICY_EDEFAULT);
        return;
      case GenModelPackage.GEN_NODE_EDIT_PART__DIRECT_EDIT_POLICY:
        setDirectEditPolicy(DIRECT_EDIT_POLICY_EDEFAULT);
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_NODE_EDIT_PART__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case GenModelPackage.GEN_NODE_EDIT_PART__PACKAGE_NAME:
        return PACKAGE_NAME_EDEFAULT == null ? packageName != null : !PACKAGE_NAME_EDEFAULT.equals(packageName);
      case GenModelPackage.GEN_NODE_EDIT_PART__ECORE_CLASS:
        return ecoreClass != null;
      case GenModelPackage.GEN_NODE_EDIT_PART__GEN_GEF_MODEL:
        return getGenGEFModel() != null;
      case GenModelPackage.GEN_NODE_EDIT_PART__GEN_FIGURE:
        return genFigure != null;
      case GenModelPackage.GEN_NODE_EDIT_PART__SUB_NODE_REFERENCES:
        return subNodeReferences != null && !subNodeReferences.isEmpty();
      case GenModelPackage.GEN_NODE_EDIT_PART__COMPONENT_EDIT_POLICY:
        return componentEditPolicy != COMPONENT_EDIT_POLICY_EDEFAULT;
      case GenModelPackage.GEN_NODE_EDIT_PART__CONTAINER_EDIT_POLICY:
        return containerEditPolicy != CONTAINER_EDIT_POLICY_EDEFAULT;
      case GenModelPackage.GEN_NODE_EDIT_PART__GRAPHICAL_EDIT_POLICY:
        return graphicalEditPolicy != GRAPHICAL_EDIT_POLICY_EDEFAULT;
      case GenModelPackage.GEN_NODE_EDIT_PART__DIRECT_EDIT_POLICY:
        return directEditPolicy != DIRECT_EDIT_POLICY_EDEFAULT;
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString() {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (componentEditPolicy: ");
    result.append(componentEditPolicy);
    result.append(", containerEditPolicy: ");
    result.append(containerEditPolicy);
    result.append(", graphicalEditPolicy: ");
    result.append(graphicalEditPolicy);
    result.append(", directEditPolicy: ");
    result.append(directEditPolicy);
    result.append(')');
    return result.toString();
  }

} //GenNodeEditPartImpl
