/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.model.impl;

import org.eclipse.emf.codegen.ecore.genmodel.impl.GenModelPackageImpl;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.impl.EPackageImpl;
import org.eclipse.emf.ecore.impl.EcorePackageImpl;
import org.eclipse.emf.mapping.impl.MappingPackageImpl;

import com.metys.merlin.generation.gef.GefPackage;
import com.metys.merlin.generation.gef.genmodel.GenModelPackage;
import com.metys.merlin.generation.gef.impl.GefPackageImpl;
import com.metys.merlin.generation.gef.model.EDiagram;
import com.metys.merlin.generation.gef.model.ELink;
import com.metys.merlin.generation.gef.model.ENode;
import com.metys.merlin.generation.gef.model.EObjectLink;
import com.metys.merlin.generation.gef.model.EReferenceLink;
import com.metys.merlin.generation.gef.model.ModelFactory;
import com.metys.merlin.generation.gef.model.ModelPackage;
import com.metys.merlin.generation.templates.impl.JETTemplatePackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ModelPackageImpl extends EPackageImpl implements ModelPackage {
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eDiagramEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eNodeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eLinkEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eReferenceLinkEClass = null;

  /**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	private EClass eObjectLinkEClass = null;

  /**
   * Creates an instance of the model <b>Package</b>, registered with
   * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
   * package URI value.
   * <p>Note: the correct way to create the package is via the static
   * factory method {@link #init init()}, which also performs
   * initialization of the package, or returns the registered package,
   * if one already exists.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @see org.eclipse.emf.ecore.EPackage.Registry
   * @see com.metys.merlin.generation.gef.model.ModelPackage#eNS_URI
   * @see #init()
   * @generated
   */
	private ModelPackageImpl() {
    super(eNS_URI, ModelFactory.eINSTANCE);
  }

  /**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	private static boolean isInited = false;

  /**
   * Creates, registers, and initializes the <b>Package</b> for this
   * model, and for any others upon which it depends.  Simple
   * dependencies are satisfied by calling this method on all
   * dependent packages before doing anything else.  This method drives
   * initialization for interdependent packages directly, in parallel
   * with this package, itself.
   * <p>Of this package and its interdependencies, all packages which
   * have not yet been registered by their URI values are first created
   * and registered.  The packages are then initialized in two steps:
   * meta-model objects for all of the packages are created before any
   * are initialized, since one package's meta-model objects may refer to
   * those of another.
   * <p>Invocation of this method will not affect any packages that have
   * already been initialized.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @see #eNS_URI
   * @see #createPackageContents()
   * @see #initializePackageContents()
   * @generated
   */
	public static ModelPackage init() {
    if (isInited) return (ModelPackage)EPackage.Registry.INSTANCE.getEPackage(ModelPackage.eNS_URI);

    // Obtain or create and register package
    ModelPackageImpl theModelPackage = (ModelPackageImpl)(EPackage.Registry.INSTANCE.getEPackage(eNS_URI) instanceof ModelPackageImpl ? EPackage.Registry.INSTANCE.getEPackage(eNS_URI) : new ModelPackageImpl());

    isInited = true;

    // Initialize simple dependencies
    JETTemplatePackageImpl.init();
    EcorePackageImpl.init();
    GenModelPackageImpl.init();
    MappingPackageImpl.init();

    // Obtain or create and register interdependencies
    GefPackageImpl theGefPackage = (GefPackageImpl)(EPackage.Registry.INSTANCE.getEPackage(GefPackage.eNS_URI) instanceof GefPackageImpl ? EPackage.Registry.INSTANCE.getEPackage(GefPackage.eNS_URI) : GefPackage.eINSTANCE);
    com.metys.merlin.generation.gef.genmodel.impl.GenModelPackageImpl theGenModelPackage_1 = (com.metys.merlin.generation.gef.genmodel.impl.GenModelPackageImpl)(EPackage.Registry.INSTANCE.getEPackage(GenModelPackage.eNS_URI) instanceof com.metys.merlin.generation.gef.genmodel.impl.GenModelPackageImpl ? EPackage.Registry.INSTANCE.getEPackage(GenModelPackage.eNS_URI) : GenModelPackage.eINSTANCE);

    // Create package meta-data objects
    theModelPackage.createPackageContents();
    theGefPackage.createPackageContents();
    theGenModelPackage_1.createPackageContents();

    // Initialize created meta-data
    theModelPackage.initializePackageContents();
    theGefPackage.initializePackageContents();
    theGenModelPackage_1.initializePackageContents();

    // Mark meta-data to indicate it can't be changed
    theModelPackage.freeze();

    return theModelPackage;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEDiagram() {
    return eDiagramEClass;
  }

  /**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	public EAttribute getEDiagram_ModelResource() {
    return (EAttribute)eDiagramEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	public EAttribute getEDiagram_ImportedResources() {
    return (EAttribute)eDiagramEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEDiagram_Contents() {
    return (EReference)eDiagramEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	public EReference getEDiagram_AllNodes() {
    return (EReference)eDiagramEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getENode() {
    return eNodeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getENode_EObject() {
    return (EReference)eNodeEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getENode_Name() {
    return (EAttribute)eNodeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getENode_Location() {
    return (EAttribute)eNodeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getENode_Width() {
    return (EAttribute)eNodeEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getENode_Height() {
    return (EAttribute)eNodeEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getENode_IncomingLinks() {
    return (EReference)eNodeEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getENode_OutgoingLinks() {
    return (EReference)eNodeEClass.getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getENode_SubNodes() {
    return (EReference)eNodeEClass.getEStructuralFeatures().get(9);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getENode_InvalidMessage() {
    return (EAttribute)eNodeEClass.getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getENode_Diagram() {
    return (EReference)eNodeEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getELink() {
    return eLinkEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getELink_Source() {
    return (EReference)eLinkEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getELink_Target() {
    return (EReference)eLinkEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getELink_Bendpoints() {
    return (EAttribute)eLinkEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getELink_InvalidMessage() {
    return (EAttribute)eLinkEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEReferenceLink() {
    return eReferenceLinkEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEReferenceLink_EReference() {
    return (EReference)eReferenceLinkEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	public EClass getEObjectLink() {
    return eObjectLinkEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEObjectLink_TransitionEObject() {
    return (EReference)eObjectLinkEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEObjectLink_SourceReference() {
    return (EReference)eObjectLinkEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEObjectLink_TargetReference() {
    return (EReference)eObjectLinkEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	public ModelFactory getModelFactory() {
    return (ModelFactory)getEFactoryInstance();
  }

  /**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	private boolean isCreated = false;

  /**
   * Creates the meta-model objects for the package.  This method is
   * guarded to have no affect on any invocation but its first.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	public void createPackageContents() {
    if (isCreated) return;
    isCreated = true;

    // Create classes and their features
    eDiagramEClass = createEClass(EDIAGRAM);
    createEAttribute(eDiagramEClass, EDIAGRAM__MODEL_RESOURCE);
    createEAttribute(eDiagramEClass, EDIAGRAM__IMPORTED_RESOURCES);
    createEReference(eDiagramEClass, EDIAGRAM__CONTENTS);
    createEReference(eDiagramEClass, EDIAGRAM__ALL_NODES);

    eNodeEClass = createEClass(ENODE);
    createEAttribute(eNodeEClass, ENODE__NAME);
    createEAttribute(eNodeEClass, ENODE__LOCATION);
    createEAttribute(eNodeEClass, ENODE__WIDTH);
    createEAttribute(eNodeEClass, ENODE__HEIGHT);
    createEReference(eNodeEClass, ENODE__EOBJECT);
    createEReference(eNodeEClass, ENODE__DIAGRAM);
    createEReference(eNodeEClass, ENODE__INCOMING_LINKS);
    createEReference(eNodeEClass, ENODE__OUTGOING_LINKS);
    createEAttribute(eNodeEClass, ENODE__INVALID_MESSAGE);
    createEReference(eNodeEClass, ENODE__SUB_NODES);

    eLinkEClass = createEClass(ELINK);
    createEReference(eLinkEClass, ELINK__SOURCE);
    createEReference(eLinkEClass, ELINK__TARGET);
    createEAttribute(eLinkEClass, ELINK__BENDPOINTS);
    createEAttribute(eLinkEClass, ELINK__INVALID_MESSAGE);

    eReferenceLinkEClass = createEClass(EREFERENCE_LINK);
    createEReference(eReferenceLinkEClass, EREFERENCE_LINK__EREFERENCE);

    eObjectLinkEClass = createEClass(EOBJECT_LINK);
    createEReference(eObjectLinkEClass, EOBJECT_LINK__TRANSITION_EOBJECT);
    createEReference(eObjectLinkEClass, EOBJECT_LINK__SOURCE_REFERENCE);
    createEReference(eObjectLinkEClass, EOBJECT_LINK__TARGET_REFERENCE);
  }

  /**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	private boolean isInitialized = false;

  /**
   * Complete the initialization of the package and its meta-model.  This
   * method is guarded to have no affect on any invocation but its first.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	public void initializePackageContents() {
    if (isInitialized) return;
    isInitialized = true;

    // Initialize package
    setName(eNAME);
    setNsPrefix(eNS_PREFIX);
    setNsURI(eNS_URI);

    // Obtain other dependent packages
    GefPackageImpl theGefPackage = (GefPackageImpl)EPackage.Registry.INSTANCE.getEPackage(GefPackage.eNS_URI);
    EcorePackageImpl theEcorePackage = (EcorePackageImpl)EPackage.Registry.INSTANCE.getEPackage(EcorePackage.eNS_URI);

    // Add supertypes to classes
    eReferenceLinkEClass.getESuperTypes().add(this.getELink());
    eObjectLinkEClass.getESuperTypes().add(this.getELink());

    // Initialize classes and features; add operations and parameters
    initEClass(eDiagramEClass, EDiagram.class, "EDiagram", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getEDiagram_ModelResource(), theGefPackage.getURI(), "modelResource", null, 0, 1, EDiagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getEDiagram_ImportedResources(), theGefPackage.getURI(), "importedResources", null, 0, -1, EDiagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getEDiagram_Contents(), this.getENode(), null, "contents", null, 0, -1, EDiagram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getEDiagram_AllNodes(), this.getENode(), this.getENode_Diagram(), "allNodes", null, 0, -1, EDiagram.class, IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    EOperation op = addEOperation(eDiagramEClass, this.getENode(), "getENode");
    addEParameter(op, theEcorePackage.getEObject(), "eObject");

    initEClass(eNodeEClass, ENode.class, "ENode", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getENode_Name(), ecorePackage.getEString(), "name", null, 0, 1, ENode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getENode_Location(), theGefPackage.getPoint(), "location", null, 0, 1, ENode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getENode_Width(), ecorePackage.getELong(), "width", null, 0, 1, ENode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getENode_Height(), ecorePackage.getELong(), "height", null, 0, 1, ENode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getENode_EObject(), theEcorePackage.getEObject(), null, "eObject", null, 1, 1, ENode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getENode_Diagram(), this.getEDiagram(), this.getEDiagram_AllNodes(), "diagram", null, 0, 1, ENode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getENode_IncomingLinks(), this.getELink(), this.getELink_Target(), "incomingLinks", null, 0, -1, ENode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getENode_OutgoingLinks(), this.getELink(), this.getELink_Source(), "outgoingLinks", null, 0, -1, ENode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getENode_InvalidMessage(), ecorePackage.getEString(), "invalidMessage", null, 0, 1, ENode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getENode_SubNodes(), this.getENode(), null, "subNodes", null, 0, -1, ENode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    op = addEOperation(eNodeEClass, ecorePackage.getEBoolean(), "acceptLinkAsSource");
    addEParameter(op, this.getELink(), "link");

    op = addEOperation(eNodeEClass, ecorePackage.getEBoolean(), "acceptLinkAsTarget");
    addEParameter(op, this.getELink(), "link");

    initEClass(eLinkEClass, ELink.class, "ELink", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getELink_Source(), this.getENode(), this.getENode_OutgoingLinks(), "source", null, 0, 1, ELink.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getELink_Target(), this.getENode(), this.getENode_IncomingLinks(), "target", null, 0, 1, ELink.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getELink_Bendpoints(), theGefPackage.getBendpoint(), "bendpoints", null, 0, -1, ELink.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getELink_InvalidMessage(), ecorePackage.getEString(), "invalidMessage", null, 0, 1, ELink.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    addEOperation(eLinkEClass, null, "doLink");

    addEOperation(eLinkEClass, null, "doUnlink");

    initEClass(eReferenceLinkEClass, EReferenceLink.class, "EReferenceLink", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getEReferenceLink_EReference(), theEcorePackage.getEReference(), null, "eReference", null, 0, 1, EReferenceLink.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(eObjectLinkEClass, EObjectLink.class, "EObjectLink", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getEObjectLink_TransitionEObject(), theEcorePackage.getEObject(), null, "transitionEObject", null, 0, 1, EObjectLink.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getEObjectLink_SourceReference(), theEcorePackage.getEReference(), null, "sourceReference", null, 0, 1, EObjectLink.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getEObjectLink_TargetReference(), theEcorePackage.getEReference(), null, "targetReference", null, 0, 1, EObjectLink.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
  }

} //ModelPackageImpl
