/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.commands;

import java.util.List;

import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.commands.Command;

import com.metys.merlin.generation.gef.model.ELink;
import com.metys.merlin.generation.gef.model.ENode;
import com.metys.merlin.generation.gef.parts.ENodeEditPart;
import com.metys.merlin.generation.gef.policies.ENodeGraphicalNodeEditPolicy;

/**
 * @author Joel Cheuoua
 */
public class ReconnectSourceCommand extends Command {

  private ENodeEditPart sourceEditPart;
	/** source node * */
	protected ENode source;
	/** target node * */
	protected ENode target;
	/** link between source and target * */
	protected ELink link;
	/** previous source prior to command execution * */
	protected ENode oldSource;

	/**
	 * @param source
	 * @param link
	 */
	public ReconnectSourceCommand(ENodeEditPart sourceEditPart,  ELink link) {
		this.sourceEditPart = sourceEditPart;
    this.link = link;
    this.source = sourceEditPart.getENode();
		this.target = link.getTarget();
		this.oldSource = link.getSource();		
	}
	
	/**
	 * @see org.eclipse.gef.commands.Command#canExecute()
	 */
	public boolean canExecute() {
		if (link.getSource().equals(source))
			return false;
    if (!acceptLinkAsSource(sourceEditPart,link))
      return false;
		List transitions = source.getOutgoingLinks();
		for (int i = 0; i < transitions.size(); i++) {
			ELink trans = (ELink) (transitions.get(i));
			if (trans.getTarget().equals(target) && !trans.getSource().equals(oldSource))
				return false;
		}
		return true;
	}
  
  /**
   * Method acceptLinkAsSource.
   * @param link ELink
   * @return boolean
   */
  public boolean acceptLinkAsSource(ENodeEditPart editPart, ELink link) {
    EditPolicy graphicalNodeEditPolicy = editPart.getEditPolicy(EditPolicy.GRAPHICAL_NODE_ROLE);
    if (graphicalNodeEditPolicy instanceof ENodeGraphicalNodeEditPolicy) {
      return ((ENodeGraphicalNodeEditPolicy)graphicalNodeEditPolicy).acceptLinkAsSource(editPart.getENode(), link);
    }
    return false;    
  }
	
	/**
	 * @see org.eclipse.gef.commands.Command#execute()
	 */
	public void execute() {
		if (source != null) {
			link.doUnlink();
			link.setSource(source);
			link.doLink();					
		}
	}
	
	/**
	 * @see org.eclipse.gef.commands.Command#undo()
	 */
	public void undo() {
		link.doUnlink();
		link.setSource(oldSource);
		link.doLink();				
	}
	
}
