package com.metys.merlin.generation.gef.compiledtemplates.policies;

import java.util.Iterator;
import com.metys.merlin.generation.gef.genmodel.*;
import com.metys.merlin.generation.gef.genmodel.util.*;
import org.eclipse.emf.ecore.*;
import org.eclipse.emf.codegen.ecore.genmodel.*;

public class NodeLayoutEditPolicy
{
  protected static String nl;
  public static synchronized NodeLayoutEditPolicy create(String lineSeparator)
  {
    nl = lineSeparator;
    NodeLayoutEditPolicy result = new NodeLayoutEditPolicy();
    nl = null;
    return result;
  }

  protected final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = "/**" + NL + " * <copyright>" + NL + " * </copyright>" + NL + " *" + NL + " * ";
  protected final String TEXT_3 = "Id";
  protected final String TEXT_4 = NL + " */" + NL + "" + NL + "package ";
  protected final String TEXT_5 = ".policies;" + NL;
  protected final String TEXT_6 = NL + NL + "/**" + NL + " * <!-- begin-user-doc -->" + NL + " * <!-- end-user-doc -->" + NL + " * @generated" + NL + " */" + NL + "public ";
  protected final String TEXT_7 = "abstract ";
  protected final String TEXT_8 = "class ";
  protected final String TEXT_9 = "LayoutEditPolicy";
  protected final String TEXT_10 = "{" + NL + "\t" + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected ";
  protected final String TEXT_11 = " createChangeConstraintCommand(";
  protected final String TEXT_12 = " child, Object constraint) {";
  protected final String TEXT_13 = NL + "    ";
  protected final String TEXT_14 = " rec = (Rectangle) constraint;";
  protected final String TEXT_15 = NL + "    ";
  protected final String TEXT_16 = " newLocation = new Point(rec.x, rec.y);" + NL + "    return new ";
  protected final String TEXT_17 = "((";
  protected final String TEXT_18 = ")child, newLocation, rec.width, rec.height);" + NL + "  }" + NL + "  " + NL + "  /**" + NL + "\t * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected Command createAddCommand(";
  protected final String TEXT_19 = " childEditPart, Object constraint) {";
  protected final String TEXT_20 = NL + "    ";
  protected final String TEXT_21 = " child = (ENode) childEditPart.getModel();" + NL + "    Point location = new Point();" + NL + "    if (constraint instanceof Rectangle) {" + NL + "      location.x = ((Rectangle) constraint).x;" + NL + "      location.y = ((Rectangle) constraint).y;" + NL + "    }";
  protected final String TEXT_22 = NL + "    ";
  protected final String TEXT_23 = " add = new AddElementCommand((";
  protected final String TEXT_24 = ")getHost(), child, location);" + NL + "    return add;" + NL + "  }" + NL + "  " + NL + "  /**" + NL + "\t * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected Command getCreateCommand(";
  protected final String TEXT_25 = " request) {";
  protected final String TEXT_26 = NL + "    ";
  protected final String TEXT_27 = " hostEditPart = (";
  protected final String TEXT_28 = ")getHost();" + NL + "    Point loc = request.getLocation();" + NL + "    if (request.getNewObject() instanceof ENode) {      " + NL + "      hostEditPart.getContentPane().translateToRelative(loc);" + NL + "      return new ";
  protected final String TEXT_29 = "(hostEditPart,(ENode)request.getNewObject(), loc);" + NL + "    } else if (request.getNewObject() instanceof ";
  protected final String TEXT_30 = ") {" + NL + "      ENode node = ";
  protected final String TEXT_31 = ".eINSTANCE.createENode();" + NL + "      node.setEObject((EObject) request.getNewObject());" + NL + "      return new CreateElementCommand(hostEditPart, node, loc);        " + NL + "    } else if (request.getNewObject() instanceof ";
  protected final String TEXT_32 = ") {" + NL + "      List views = (List)request.getNewObject();      " + NL + "      if (views.isEmpty())" + NL + "        return ";
  protected final String TEXT_33 = ".INSTANCE;";
  protected final String TEXT_34 = NL + "      ";
  protected final String TEXT_35 = " command = new CompoundCommand();" + NL + "      hostEditPart.getContentPane().translateToRelative(loc);" + NL + "      for (int i = 0; i < views.size(); i++) {" + NL + "        Object view = views.get(i);" + NL + "        if (view instanceof ENode) {" + NL + "          hostEditPart.getContentPane().translateToRelative(loc);" + NL + "          command.add(new ";
  protected final String TEXT_36 = "(hostEditPart,(ENode)view, loc.getTranslated(i * 40, i * 40)));" + NL + "        } else if (view instanceof EObject) {" + NL + "          ENode node = ";
  protected final String TEXT_37 = ".eINSTANCE.createENode();" + NL + "          node.setEObject((EObject) view);" + NL + "          command.add(new CreateElementCommand(hostEditPart, node, loc.getTranslated(i * 40, i * 40)));        " + NL + "        } else if (view instanceof ";
  protected final String TEXT_38 = ") {" + NL + "          LinkModel linkModel = (LinkModel) view;";
  protected final String TEXT_39 = NL + "          ";
  protected final String TEXT_40 = " diagram = getDiagram();" + NL + "          ENode sourceNode = diagram.getENode(linkModel.getEObject());" + NL + "          ENode targetNode = diagram.getENode(linkModel.getRefEObject());" + NL + "          // Look for the edit parts in the contents of this parent";
  protected final String TEXT_41 = NL + "          ";
  protected final String TEXT_42 = " diagramEditPart = null;" + NL + "          EditPart parent = hostEditPart;" + NL + "          while (!(parent instanceof EDiagramEditPart) && parent != null)" + NL + "            parent = parent.getParent();" + NL + "          if (parent instanceof EDiagramEditPart)" + NL + "            diagramEditPart = (EDiagramEditPart) parent;" + NL + "          ENodeEditPart sourceEditPart = diagramEditPart.findNodeEditPart(sourceNode);" + NL + "          ENodeEditPart targetEditPart = diagramEditPart.findNodeEditPart(targetNode);          ";
  protected final String TEXT_43 = NL + "          ";
  protected final String TEXT_44 = " link = null;" + NL + "          if (linkModel instanceof ";
  protected final String TEXT_45 = ") {" + NL + "            link = ModelFactory.eINSTANCE.createEReferenceLink();" + NL + "            ((";
  protected final String TEXT_46 = ")link).setEReference(((ReferenceLinkModel)linkModel).getEReference());" + NL + "          } else if (linkModel instanceof ";
  protected final String TEXT_47 = ") {" + NL + "            link = ModelFactory.eINSTANCE.createEObjectLink();" + NL + "            ((";
  protected final String TEXT_48 = ")link).setTransitionEObject(((ClassLinkModel)linkModel).getTransitionObject());" + NL + "            ((EObjectLink)link).setSourceReference(((ClassLinkModel)linkModel).getSourceRef());" + NL + "            ((EObjectLink)link).setTargetReference(((ClassLinkModel)linkModel).getTargetRef());" + NL + "          }" + NL + "          command.add(new ";
  protected final String TEXT_49 = "(link, sourceEditPart, targetEditPart));" + NL + "        }" + NL + "      }" + NL + "      return command;" + NL + "    }" + NL + "    return UnexecutableCommand.INSTANCE;" + NL + "  }" + NL + "  " + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected Command getOrphanChildrenCommand(";
  protected final String TEXT_50 = " request) {";
  protected final String TEXT_51 = NL + "    ";
  protected final String TEXT_52 = " gRequest = (GroupRequest) request;" + NL + "    List parts = gRequest.getEditParts();" + NL + "    CompoundCommand result = new CompoundCommand();" + NL + "    for (int i = 0; i < parts.size(); i++) {" + NL + "      ENode child = (ENode) ((EditPart) parts.get(i)).getModel();           ";
  protected final String TEXT_53 = NL + "      ";
  protected final String TEXT_54 = " orphan " + NL + "      \t= new OrphanNodeCommand((";
  protected final String TEXT_55 = ")getHost(), child);" + NL + "      result.add(orphan);" + NL + "    }" + NL + "    return result.unwrap();" + NL + "  }" + NL + "" + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  public boolean acceptAdd(ENode child) {";
  protected final String TEXT_56 = NL + "    if (";
  protected final String TEXT_57 = "().getEReferenceType().isInstance(child.getEObject()))" + NL + "        return true;";
  protected final String TEXT_58 = NL + "    return super.acceptAdd(child);    " + NL + "  }" + NL + "" + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  public boolean acceptRemove(ENode child) {" + NL + "    return super.acceptRemove(child);" + NL + "  }" + NL + "  " + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  public void handleNodeAdded(ENode parent, ENode child) {  \t";
  protected final String TEXT_59 = NL + "\t{" + NL + "\t  ";
  protected final String TEXT_60 = " object = (";
  protected final String TEXT_61 = ") parent.getEObject();" + NL + "      if (";
  protected final String TEXT_62 = "().getEReferenceType().isInstance(child.getEObject())) {";
  protected final String TEXT_63 = NL + "\t\t((";
  protected final String TEXT_64 = ")object.eGet(";
  protected final String TEXT_65 = "())).add(child.getEObject());\t\t\t\t";
  protected final String TEXT_66 = NL + "     \tobject.eSet(";
  protected final String TEXT_67 = "(), child.getEObject());";
  protected final String TEXT_68 = NL + "\t  }" + NL + "\t}";
  protected final String TEXT_69 = NL + "\tsuper.handleNodeAdded(parent, child);" + NL + "  }" + NL + "  " + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  public void handleNodeRemoved(ENode parent, ENode child) {";
  protected final String TEXT_70 = NL + "\t{" + NL + "\t  ";
  protected final String TEXT_71 = " object = (";
  protected final String TEXT_72 = ") parent.getEObject();" + NL + "      if (";
  protected final String TEXT_73 = "().getEReferenceType().isInstance(child.getEObject())) {";
  protected final String TEXT_74 = NL + "\t\t((";
  protected final String TEXT_75 = ")object.eGet(";
  protected final String TEXT_76 = "())).remove(child.getEObject());     \t  ";
  protected final String TEXT_77 = NL + "     \tobject.eSet(";
  protected final String TEXT_78 = "(), null);";
  protected final String TEXT_79 = NL + "\t  }" + NL + "\t}";
  protected final String TEXT_80 = NL + "\tsuper.handleNodeRemoved(parent, child);" + NL + "  }" + NL + "}";

  public String generate(Object argument)
  {
    StringBuffer stringBuffer = new StringBuffer();
    
/**
 * Copyright (c) 2005 Joel Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

    GenNodeEditPart genEditPart = (GenNodeEditPart) argument; EClass ecoreClass = genEditPart.getEcoreClass(); GenModel genModel = genEditPart.getGenGEFModel().getGenModel(); GenClass genClass = GenModelHelper.getGenClass(genModel, ecoreClass);
    stringBuffer.append(TEXT_1);
    stringBuffer.append(TEXT_2);
    stringBuffer.append("$");
    stringBuffer.append(TEXT_3);
    stringBuffer.append("$");
    stringBuffer.append(TEXT_4);
    stringBuffer.append(genEditPart.getPackageName());
    stringBuffer.append(TEXT_5);
    genModel.markImportLocation(stringBuffer);
    stringBuffer.append(TEXT_6);
    if (ecoreClass.isAbstract()) {
    stringBuffer.append(TEXT_7);
    }
    stringBuffer.append(TEXT_8);
    stringBuffer.append(ecoreClass.getName());
    stringBuffer.append(TEXT_9);
    stringBuffer.append(GenModelHelper.getLayoutEditPolicyExtendsLitteral(genModel, genEditPart));
    stringBuffer.append(TEXT_10);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.commands.Command"));
    stringBuffer.append(TEXT_11);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.EditPart"));
    stringBuffer.append(TEXT_12);
    stringBuffer.append(TEXT_13);
    stringBuffer.append(genModel.getImportedName("org.eclipse.draw2d.geometry.Rectangle"));
    stringBuffer.append(TEXT_14);
    stringBuffer.append(TEXT_15);
    stringBuffer.append(genModel.getImportedName("org.eclipse.draw2d.geometry.Point"));
    stringBuffer.append(TEXT_16);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.commands.ChangeBoundsCommand"));
    stringBuffer.append(TEXT_17);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.parts.ENodeEditPart"));
    stringBuffer.append(TEXT_18);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.EditPart"));
    stringBuffer.append(TEXT_19);
    stringBuffer.append(TEXT_20);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.model.ENode"));
    stringBuffer.append(TEXT_21);
    stringBuffer.append(TEXT_22);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.commands.AddElementCommand"));
    stringBuffer.append(TEXT_23);
    stringBuffer.append(GenModelHelper.getImportedQualifiedEditPartClass(genModel, genEditPart));
    stringBuffer.append(TEXT_24);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.requests.CreateRequest"));
    stringBuffer.append(TEXT_25);
    stringBuffer.append(TEXT_26);
    stringBuffer.append(GenModelHelper.getImportedQualifiedEditPartClass(genModel, genEditPart));
    stringBuffer.append(TEXT_27);
    stringBuffer.append(GenModelHelper.getImportedQualifiedEditPartClass(genModel, genEditPart));
    stringBuffer.append(TEXT_28);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.commands.CreateElementCommand"));
    stringBuffer.append(TEXT_29);
    stringBuffer.append(genModel.getImportedName("org.eclipse.emf.ecore.EObject"));
    stringBuffer.append(TEXT_30);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.model.ModelFactory"));
    stringBuffer.append(TEXT_31);
    stringBuffer.append(genModel.getImportedName("java.util.List"));
    stringBuffer.append(TEXT_32);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.commands.UnexecutableCommand"));
    stringBuffer.append(TEXT_33);
    stringBuffer.append(TEXT_34);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.commands.CompoundCommand"));
    stringBuffer.append(TEXT_35);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.commands.CreateElementCommand"));
    stringBuffer.append(TEXT_36);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.model.ModelFactory"));
    stringBuffer.append(TEXT_37);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.outline.LinkModel"));
    stringBuffer.append(TEXT_38);
    stringBuffer.append(TEXT_39);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.model.EDiagram"));
    stringBuffer.append(TEXT_40);
    stringBuffer.append(TEXT_41);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.parts.EDiagramEditPart"));
    stringBuffer.append(TEXT_42);
    stringBuffer.append(TEXT_43);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.model.ELink"));
    stringBuffer.append(TEXT_44);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.outline.ReferenceLinkModel"));
    stringBuffer.append(TEXT_45);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.model.EReferenceLink"));
    stringBuffer.append(TEXT_46);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.outline.ClassLinkModel"));
    stringBuffer.append(TEXT_47);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.model.EObjectLink"));
    stringBuffer.append(TEXT_48);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.commands.TransferLinkCommand"));
    stringBuffer.append(TEXT_49);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.Request"));
    stringBuffer.append(TEXT_50);
    stringBuffer.append(TEXT_51);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.requests.GroupRequest"));
    stringBuffer.append(TEXT_52);
    stringBuffer.append(TEXT_53);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.commands.OrphanNodeCommand"));
    stringBuffer.append(TEXT_54);
    stringBuffer.append(GenModelHelper.getImportedQualifiedEditPartClass(genModel, genEditPart));
    stringBuffer.append(TEXT_55);
    for (Iterator it = genEditPart.getSubNodeReferences().iterator(); it.hasNext();) { GenSubNodeReference genSubNodeFeature = (GenSubNodeReference) it.next(); GenFeature genFeature = GenModelHelper.getGenFeature(genModel, genSubNodeFeature.getReference());
    stringBuffer.append(TEXT_56);
    stringBuffer.append(genFeature.getQualifiedFeatureAccessorName());
    stringBuffer.append(TEXT_57);
    }
    stringBuffer.append(TEXT_58);
    for (Iterator it = genEditPart.getSubNodeReferences().iterator(); it.hasNext();) { GenSubNodeReference genSubNodeFeature = (GenSubNodeReference) it.next(); GenFeature genFeature = GenModelHelper.getGenFeature(genModel, genSubNodeFeature.getReference());
    stringBuffer.append(TEXT_59);
    stringBuffer.append(genClass.getImportedClassName());
    stringBuffer.append(TEXT_60);
    stringBuffer.append(genClass.getImportedClassName());
    stringBuffer.append(TEXT_61);
    stringBuffer.append(genFeature.getQualifiedFeatureAccessorName());
    stringBuffer.append(TEXT_62);
    if (genFeature.getEcoreFeature().isMany()) {
    stringBuffer.append(TEXT_63);
    stringBuffer.append(genModel.getImportedName("java.util.Collection"));
    stringBuffer.append(TEXT_64);
    stringBuffer.append(genFeature.getQualifiedFeatureAccessorName());
    stringBuffer.append(TEXT_65);
    } else {
    stringBuffer.append(TEXT_66);
    stringBuffer.append(genFeature.getQualifiedFeatureAccessorName());
    stringBuffer.append(TEXT_67);
    }
    stringBuffer.append(TEXT_68);
    }
    stringBuffer.append(TEXT_69);
    for (Iterator it = genEditPart.getSubNodeReferences().iterator(); it.hasNext();) { GenSubNodeReference genSubNodeFeature = (GenSubNodeReference) it.next(); GenFeature genFeature = GenModelHelper.getGenFeature(genModel, genSubNodeFeature.getReference());
    stringBuffer.append(TEXT_70);
    stringBuffer.append(genClass.getImportedClassName());
    stringBuffer.append(TEXT_71);
    stringBuffer.append(genClass.getImportedClassName());
    stringBuffer.append(TEXT_72);
    stringBuffer.append(genFeature.getQualifiedFeatureAccessorName());
    stringBuffer.append(TEXT_73);
    if (genFeature.getEcoreFeature().isMany()) {
    stringBuffer.append(TEXT_74);
    stringBuffer.append(genModel.getImportedName("java.util.Collection"));
    stringBuffer.append(TEXT_75);
    stringBuffer.append(genFeature.getQualifiedFeatureAccessorName());
    stringBuffer.append(TEXT_76);
    } else {
    stringBuffer.append(TEXT_77);
    stringBuffer.append(genFeature.getQualifiedFeatureAccessorName());
    stringBuffer.append(TEXT_78);
    }
    stringBuffer.append(TEXT_79);
    }
    stringBuffer.append(TEXT_80);
    genModel.emitSortedImports();
    return stringBuffer.toString();
  }
}
