package com.metys.merlin.generation.gef.compiledtemplates.plugin;

import com.metys.merlin.generation.gef.genmodel.*;
import com.metys.merlin.generation.gef.genmodel.util.GenModelHelper;
import org.eclipse.emf.codegen.ecore.genmodel.*;

public class PluginClass
{
  protected static String nl;
  public static synchronized PluginClass create(String lineSeparator)
  {
    nl = lineSeparator;
    PluginClass result = new PluginClass();
    nl = null;
    return result;
  }

  protected final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = NL;
  protected final String TEXT_3 = "/**" + NL + " * <copyright>" + NL + " * </copyright>" + NL + " *" + NL + " * ";
  protected final String TEXT_4 = "Id";
  protected final String TEXT_5 = NL + " */" + NL;
  protected final String TEXT_6 = NL + "package ";
  protected final String TEXT_7 = ";";
  protected final String TEXT_8 = NL + NL + "import org.eclipse.ui.plugin.AbstractUIPlugin;" + NL + "" + NL + "import java.net.MalformedURLException;" + NL + "import java.net.URL;" + NL;
  protected final String TEXT_9 = NL + NL + "/**" + NL + " * GEF Plugin class." + NL + " * <!-- begin-user-doc -->" + NL + " * <!-- end-user-doc -->" + NL + " * @generated" + NL + " */" + NL + "public class ";
  protected final String TEXT_10 = " extends AbstractUIPlugin {" + NL + "\t" + NL + "\tprivate static ";
  protected final String TEXT_11 = " plugin;" + NL + "\t" + NL + "\t/**" + NL + "\t * Returns the singleton instance of the Eclipse plugin." + NL + "\t * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "\t * @return the singleton instance." + NL + "\t * @generated" + NL + "\t */" + NL + "  public static ";
  protected final String TEXT_12 = " getPlugin() {" + NL + "\t\treturn plugin;" + NL + "\t}" + NL + "\t" + NL + "\t/**" + NL + "\t * Creates a new ";
  protected final String TEXT_13 = "Plugin" + NL + "\t * <!-- begin-user-doc -->" + NL + "\t * <!-- end-user-doc -->" + NL + "\t * @generated" + NL + "\t */" + NL + "\tpublic ";
  protected final String TEXT_14 = "() {" + NL + "\t\tsuper();" + NL + "\t\tplugin = this;" + NL + "\t}" + NL + "\t" + NL + "\t/**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */\t" + NL + "  public URL getResource(String resourcePath) {" + NL + "    try {" + NL + "\t\t  URL url = new URL(getBundle().getEntry(\"/\") + resourcePath);" + NL + "\t\t  return url;" + NL + "\t\t} catch (MalformedURLException e) {\t\t" + NL + "\t\t}" + NL + "\t\treturn null;" + NL + "  }" + NL + "}";

  public String generate(Object argument)
  {
    StringBuffer stringBuffer = new StringBuffer();
    
/**
 * Copyright (c) 2005 Joel Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

    GenGEFModel genGEFModel = (GenGEFModel) argument; GenModel genModel= genGEFModel.getGenModel();String packageName = GenModelHelper.containerQName(genGEFModel.getPluginClass()); String className = GenModelHelper.shortName(genGEFModel.getPluginClass()); 
    stringBuffer.append(TEXT_1);
    stringBuffer.append(TEXT_2);
    stringBuffer.append(TEXT_3);
    stringBuffer.append("$");
    stringBuffer.append(TEXT_4);
    stringBuffer.append("$");
    stringBuffer.append(TEXT_5);
     if (genModel.getModelPluginID() != null) {
    stringBuffer.append(TEXT_6);
    stringBuffer.append(packageName);
    stringBuffer.append(TEXT_7);
    }
    stringBuffer.append(TEXT_8);
    genModel.markImportLocation(stringBuffer);
    stringBuffer.append(TEXT_9);
    stringBuffer.append(className);
    stringBuffer.append(TEXT_10);
    stringBuffer.append(className);
    stringBuffer.append(TEXT_11);
    stringBuffer.append(className);
    stringBuffer.append(TEXT_12);
    stringBuffer.append(genModel.getModelName());
    stringBuffer.append(TEXT_13);
    stringBuffer.append(className);
    stringBuffer.append(TEXT_14);
    genModel.emitSortedImports();
    return stringBuffer.toString();
  }
}
