/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.outline;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;

import com.metys.merlin.generation.gef.editor.ClassLinkInfo;
import com.metys.merlin.generation.gef.model.EDiagram;
import com.metys.merlin.generation.gef.model.ModelPackage;

/**
 * @author jcheuoua
 * @version $Revision: 1.1 $
 */
public class EDiagramTreeEditPart extends BaseTreeEditPart {
  private Resource modelResource;
	/**
	 * Constructor for EDiagramTreeEditPart.
	 * @param model EDiagram
	 * @param modelResource Resource
	 * @param adapterFactory AdapterFactory
	 */
	public EDiagramTreeEditPart(EDiagram model, Resource modelResource, AdapterFactory adapterFactory) {
		super(model, adapterFactory);
    this.modelResource = modelResource;
	}
	/**
	 * Method getDiagram.
	 * @return EDiagram
	 */
	private EDiagram getDiagram() {
		return (EDiagram)getModel();
	}
	/**
	 * Method getModelChildren.
	 * @return List
	 */
	protected List getModelChildren() {
	  if (modelResource != null) {
      List children = new ArrayList();
	    for (Iterator iter = modelResource.getContents().iterator(); iter.hasNext();) {
        EObject element = (EObject) iter.next();
        if (adapterFactory.adapt(element, ClassLinkInfo.class) != null) {
          ClassLinkInfo classLinkInfo = (ClassLinkInfo) adapterFactory.adapt(element, ClassLinkInfo.class);
          EObject source = (EObject) element.eGet(classLinkInfo.getSourceReference());
          EObject target = (EObject) element.eGet(classLinkInfo.getTargetReference());
          ClassLinkModel linkModel = new ClassLinkModel(source, target, element, classLinkInfo.getSourceReference(), classLinkInfo.getTargetReference());
          children.add(linkModel);
        } else
          children.add(element);        
      }
      return children;
    }
    return Collections.EMPTY_LIST;
	}
	/**
	 * Method handlePropertyChanged.
	 * @param msg Notification
	 */
	protected void handlePropertyChanged(Notification msg) {
		switch (msg.getFeatureID(EDiagram.class)) {
			case ModelPackage.EDIAGRAM__CONTENTS:
			  refreshChildren();
		}
	}
}