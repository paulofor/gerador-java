/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.outline;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.edit.ui.provider.AdapterFactoryLabelProvider;
import org.eclipse.swt.graphics.Image;

import com.metys.merlin.generation.gef.editor.ClassLinkInfo;

/**
 * @author jcheuoua
 * @version $Revision: 1.1 $
 */
public class EObjectTreeEditPart extends BaseTreeEditPart {
  
  protected AdapterFactoryLabelProvider labelProvider;
  
	/**
	 * Constructor for EObjectTreeEditPart.
	 * @param model EObject
	 * @param adapterFactory AdapterFactory
	 */
	public EObjectTreeEditPart(EObject model, AdapterFactory adapterFactory) {
		super(model, adapterFactory);
    labelProvider = new AdapterFactoryLabelProvider(adapterFactory);
	}
	/**
	 * Method getEObject.
	 * @return EObject
	 */
	private EObject getEObject() {
		return (EObject)getModel();
	}
	/**
	 * Method getImage.
	 * @return Image
	 */
	protected Image getImage() {
    return labelProvider.getImage(getEObject());
	}
	/**
	 * Method getText.
	 * @return String
	 */
	protected String getText() {
    return labelProvider.getText(getEObject());
	}
	/**
	 * Method getModelChildren.
	 * @return List
	 */
	protected List getModelChildren() {
		if (getModel() instanceof EObject) {
      EObject eObject = (EObject)getModel();
			List children = new ArrayList();
			EClass eObjectType = eObject.eClass();
      List references = eObjectType.getEAllReferences();
			for (Iterator iter = references.iterator(); iter.hasNext();) {
        EReference ref = (EReference) iter.next();
        if (ref.isContainer() || ref.isContainment())
          continue;
        Object value = eObject.eGet(ref);
        List listValues = new ArrayList();
        if (value != null)
          listValues = ref.isMany() ? (List) value : Collections.singletonList(value);        
        for (Iterator valuesIt = listValues.iterator(); valuesIt.hasNext();) {
          EObject refObject = (EObject) valuesIt.next();
          if (adapterFactory.adapt(refObject, ClassLinkInfo.class) != null) {
            ClassLinkInfo classLinkInfo = (ClassLinkInfo) adapterFactory.adapt(refObject, ClassLinkInfo.class);
            EObject source = (EObject) refObject.eGet(classLinkInfo.getSourceReference());
            EObject target = (EObject) refObject.eGet(classLinkInfo.getTargetReference());
            children.add(new ClassLinkModel(source, target, eObject, classLinkInfo.getSourceReference(), classLinkInfo.getTargetReference()));
          } else
            children.add(new ReferenceLinkModel(eObject, refObject, ref));          
        }          
			}
      for (Iterator iter = eObject.eContents().iterator(); iter.hasNext();) {
        EObject element = (EObject) iter.next();
        if (adapterFactory.adapt(element, ClassLinkInfo.class) != null) {
          ClassLinkInfo classLinkInfo = (ClassLinkInfo) adapterFactory.adapt(element, ClassLinkInfo.class);
          EObject source = (EObject) element.eGet(classLinkInfo.getSourceReference());
          EObject target = (EObject) element.eGet(classLinkInfo.getTargetReference());
          ClassLinkModel linkModel = new ClassLinkModel(source, target, element, classLinkInfo.getSourceReference(), classLinkInfo.getTargetReference());
          children.add(linkModel);
        } else
          children.add(element);
      }			
			return children;
		}
		return super.getModelChildren();
	}
	/**
	 * Method handlePropertyChanged.
	 * @param msg Notification
	 */
	protected void handlePropertyChanged(Notification msg) {		
		if (msg.getFeature() instanceof EReference) {
      BaseTreeEditPart parentPart = this;
      parentPart.refresh();
      EReference reference = (EReference)msg.getFeature(); 
      if (reference.isContainment() || reference.isContainer()) {
        while (parentPart.getParent() instanceof BaseTreeEditPart) {
          parentPart = (BaseTreeEditPart) parentPart.getParent();
          parentPart.refresh();
        }
      }
		} else
      refreshVisuals();    
	}
}