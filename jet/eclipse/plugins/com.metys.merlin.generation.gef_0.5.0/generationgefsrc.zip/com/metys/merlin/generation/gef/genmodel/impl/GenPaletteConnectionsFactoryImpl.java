/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.genmodel.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.EcoreUtil;

import com.metys.merlin.generation.gef.genmodel.GenEditor;
import com.metys.merlin.generation.gef.genmodel.GenLinkEditPart;
import com.metys.merlin.generation.gef.genmodel.GenModelPackage;
import com.metys.merlin.generation.gef.genmodel.GenPaletteConnectionsFactory;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Gen Palette Connections Factory</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenPaletteConnectionsFactoryImpl#getName <em>Name</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenPaletteConnectionsFactoryImpl#getGenLinkParts <em>Gen Link Parts</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenPaletteConnectionsFactoryImpl#getGenEditor <em>Gen Editor</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class GenPaletteConnectionsFactoryImpl extends EObjectImpl implements GenPaletteConnectionsFactory {
  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * The cached value of the '{@link #getGenLinkParts() <em>Gen Link Parts</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getGenLinkParts()
   * @generated
   * @ordered
   */
  protected EList genLinkParts = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected GenPaletteConnectionsFactoryImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return GenModelPackage.eINSTANCE.getGenPaletteConnectionsFactory();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName() {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(String newName) {
    String oldName = name;
    name = newName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getGenLinkParts() {
    if (genLinkParts == null) {
      genLinkParts = new EObjectResolvingEList(GenLinkEditPart.class, this, GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__GEN_LINK_PARTS);
    }
    return genLinkParts;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenEditor getGenEditor() {
    if (eContainerFeatureID != GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__GEN_EDITOR) return null;
    return (GenEditor)eContainer;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setGenEditor(GenEditor newGenEditor) {
    if (newGenEditor != eContainer || (eContainerFeatureID != GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__GEN_EDITOR && newGenEditor != null)) {
      if (EcoreUtil.isAncestor(this, newGenEditor))
        throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
      NotificationChain msgs = null;
      if (eContainer != null)
        msgs = eBasicRemoveFromContainer(msgs);
      if (newGenEditor != null)
        msgs = ((InternalEObject)newGenEditor).eInverseAdd(this, GenModelPackage.GEN_EDITOR__GEN_PALETTE_CONNECTIONS_FACTORIES, GenEditor.class, msgs);
      msgs = eBasicSetContainer((InternalEObject)newGenEditor, GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__GEN_EDITOR, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__GEN_EDITOR, newGenEditor, newGenEditor));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__GEN_EDITOR:
          if (eContainer != null)
            msgs = eBasicRemoveFromContainer(msgs);
          return eBasicSetContainer(otherEnd, GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__GEN_EDITOR, msgs);
        default:
          return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__GEN_EDITOR:
          return eBasicSetContainer(null, GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__GEN_EDITOR, msgs);
        default:
          return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
    if (eContainerFeatureID >= 0) {
      switch (eContainerFeatureID) {
        case GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__GEN_EDITOR:
          return eContainer.eInverseRemove(this, GenModelPackage.GEN_EDITOR__GEN_PALETTE_CONNECTIONS_FACTORIES, GenEditor.class, msgs);
        default:
          return eDynamicBasicRemoveFromContainer(msgs);
      }
    }
    return eContainer.eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__NAME:
        return getName();
      case GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__GEN_LINK_PARTS:
        return getGenLinkParts();
      case GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__GEN_EDITOR:
        return getGenEditor();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__NAME:
        setName((String)newValue);
        return;
      case GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__GEN_LINK_PARTS:
        getGenLinkParts().clear();
        getGenLinkParts().addAll((Collection)newValue);
        return;
      case GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__GEN_EDITOR:
        setGenEditor((GenEditor)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__NAME:
        setName(NAME_EDEFAULT);
        return;
      case GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__GEN_LINK_PARTS:
        getGenLinkParts().clear();
        return;
      case GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__GEN_EDITOR:
        setGenEditor((GenEditor)null);
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__GEN_LINK_PARTS:
        return genLinkParts != null && !genLinkParts.isEmpty();
      case GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY__GEN_EDITOR:
        return getGenEditor() != null;
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString() {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (name: ");
    result.append(name);
    result.append(')');
    return result.toString();
  }

} //GenPaletteConnectionsFactoryImpl
