package com.metys.merlin.generation.gef.compiledtemplates.parts;

import com.metys.merlin.generation.gef.genmodel.*;
import com.metys.merlin.generation.gef.genmodel.util.*;
import org.eclipse.emf.ecore.*;
import org.eclipse.emf.codegen.ecore.genmodel.*;
import java.util.*;

public class EditPartFactory
{
  protected static String nl;
  public static synchronized EditPartFactory create(String lineSeparator)
  {
    nl = lineSeparator;
    EditPartFactory result = new EditPartFactory();
    nl = null;
    return result;
  }

  protected final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = "/**" + NL + " * <copyright>" + NL + " * </copyright>" + NL + " *" + NL + " * ";
  protected final String TEXT_3 = "Id";
  protected final String TEXT_4 = NL + " */" + NL + "" + NL + "package ";
  protected final String TEXT_5 = ";" + NL + "" + NL + "import org.eclipse.gef.EditPart;" + NL + "import org.eclipse.gef.EditPartFactory;" + NL;
  protected final String TEXT_6 = NL + NL + "/**" + NL + " * <!-- begin-user-doc -->" + NL + " * <!-- end-user-doc -->" + NL + " * @generated" + NL + " */" + NL + "public class ";
  protected final String TEXT_7 = " implements EditPartFactory {" + NL + "" + NL + "\t/**" + NL + " \t * <!-- begin-user-doc -->" + NL + " \t * <!-- end-user-doc -->" + NL + " \t * @generated" + NL + " \t */" + NL + "\tprivate ";
  protected final String TEXT_8 = " adapterFactory;" + NL + "\t" + NL + "\t/**" + NL + " \t * <!-- begin-user-doc -->" + NL + " \t * <!-- end-user-doc -->" + NL + " \t * @generated" + NL + " \t */" + NL + "\tprivate ";
  protected final String TEXT_9 = " modelResource;" + NL + "\t" + NL + "\t/**" + NL + " \t * <!-- begin-user-doc -->" + NL + " \t * <!-- end-user-doc -->" + NL + " \t * @generated" + NL + " \t */" + NL + "\tpublic ";
  protected final String TEXT_10 = "(AdapterFactory adapterFactory, Resource modelResource) {" + NL + "\t\tthis.adapterFactory = adapterFactory;" + NL + "\t\tthis.modelResource = modelResource;" + NL + "\t}" + NL + "\t";
  protected final String TEXT_11 = NL + "\t/**" + NL + "\t * This creates an edit part for a {@link ";
  protected final String TEXT_12 = "}." + NL + "\t * <!-- begin-user-doc -->" + NL + "\t * <!-- end-user-doc -->" + NL + "\t * @generated" + NL + "\t */" + NL + "\tpublic EditPart create";
  protected final String TEXT_13 = "EditPart(";
  protected final String TEXT_14 = " model)" + NL + "\t{" + NL + "\t\treturn new ";
  protected final String TEXT_15 = "(model, adapterFactory);" + NL + "\t}";
  protected final String TEXT_16 = NL;
  protected final String TEXT_17 = NL + "    /**" + NL + "     * This creates an edit part for a {@link ";
  protected final String TEXT_18 = "}." + NL + "     * <!-- begin-user-doc -->" + NL + "     * <!-- end-user-doc -->" + NL + "     * @generated" + NL + "     */" + NL + "    public EditPart create";
  protected final String TEXT_19 = "LinkEditPart(";
  protected final String TEXT_20 = " model)" + NL + "    {" + NL + "    \treturn new ";
  protected final String TEXT_21 = "(model, adapterFactory);" + NL + "    }";
  protected final String TEXT_22 = NL + "\t" + NL + "\t/**" + NL + "\t * This creates an edit part for any " + NL + "   \t * model object." + NL + "\t * <!-- begin-user-doc -->" + NL + "   \t * <!-- end-user-doc -->" + NL + "   \t * @generated" + NL + "   \t */" + NL + "\tpublic EditPart createEditPart(EditPart context, Object model) {" + NL + "\t\tEditPart part = null;" + NL + "\t\tif (model instanceof ";
  protected final String TEXT_23 = ") {" + NL + "\t\t\tpart = new ";
  protected final String TEXT_24 = "((EDiagram) model, adapterFactory, modelResource);" + NL + "\t\t} else if (model instanceof ";
  protected final String TEXT_25 = ") {" + NL + "\t\t\tpart = new ";
  protected final String TEXT_26 = "((EReferenceLink) model, adapterFactory);" + NL + "\t\t} else if (model instanceof ";
  protected final String TEXT_27 = ") {";
  protected final String TEXT_28 = " \t\t" + NL + "\t\t\t";
  protected final String TEXT_29 = " ecoreClass = ((EObjectLink)model).getTransitionEObject().eClass();\t\t\t\t\t\t";
  protected final String TEXT_30 = NL + "\t\t\tif (ecoreClass == ";
  protected final String TEXT_31 = ".eINSTANCE.get";
  protected final String TEXT_32 = "())" + NL + "\t\t\t\tpart = create";
  protected final String TEXT_33 = "LinkEditPart((EObjectLink) model);";
  protected final String TEXT_34 = NL + "\t\t} else if (model instanceof ";
  protected final String TEXT_35 = "){";
  protected final String TEXT_36 = NL + "\t\t\t";
  protected final String TEXT_37 = " ecoreClass = ((ENode)model).getEObject().eClass();";
  protected final String TEXT_38 = NL + "\t\t\tif (ecoreClass == ";
  protected final String TEXT_39 = ".eINSTANCE.get";
  protected final String TEXT_40 = "())" + NL + "\t\t\t\tpart = create";
  protected final String TEXT_41 = "EditPart((ENode) model);";
  protected final String TEXT_42 = NL + "\t\t}" + NL + "\t\treturn part;" + NL + "\t}\t" + NL + "}";

  public String generate(Object argument)
  {
    StringBuffer stringBuffer = new StringBuffer();
    
/**
 * Copyright (c) 2005 Joel Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

    GenEditPartFactory genEditPartFactory = (GenEditPartFactory) argument; GenModel genModel = genEditPartFactory.getGenGEFModel().getGenModel();
    stringBuffer.append(TEXT_1);
    stringBuffer.append(TEXT_2);
    stringBuffer.append("$");
    stringBuffer.append(TEXT_3);
    stringBuffer.append("$");
    stringBuffer.append(TEXT_4);
    stringBuffer.append(genEditPartFactory.getPackageName());
    stringBuffer.append(TEXT_5);
    genModel.markImportLocation(stringBuffer);
    stringBuffer.append(TEXT_6);
    stringBuffer.append(genEditPartFactory.getName());
    stringBuffer.append(TEXT_7);
    stringBuffer.append(genModel.getImportedName("org.eclipse.emf.common.notify.AdapterFactory"));
    stringBuffer.append(TEXT_8);
    stringBuffer.append(genModel.getImportedName("org.eclipse.emf.ecore.resource.Resource"));
    stringBuffer.append(TEXT_9);
    stringBuffer.append(genEditPartFactory.getName());
    stringBuffer.append(TEXT_10);
    for (Iterator i=GenModelHelper.getGenNodeEditParts(genEditPartFactory.getGenEditParts()).iterator(); i.hasNext();) { GenNodeEditPart genEditPart = (GenNodeEditPart)i.next(); EClass ecoreClass = ((GenNodeEditPart)genEditPart).getEcoreClass(); if (ecoreClass.isAbstract()) continue;
    stringBuffer.append(TEXT_11);
    stringBuffer.append(ecoreClass.getName());
    stringBuffer.append(TEXT_12);
    stringBuffer.append(ecoreClass.getName());
    stringBuffer.append(TEXT_13);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.model.ENode"));
    stringBuffer.append(TEXT_14);
    stringBuffer.append(GenModelHelper.getImportedQualifiedEditPartClass(genModel, genEditPart));
    stringBuffer.append(TEXT_15);
    } //for
    stringBuffer.append(TEXT_16);
    for (Iterator i=GenModelHelper.getGenLinkEditParts(genEditPartFactory.getGenEditParts()).iterator(); i.hasNext();) { GenLinkEditPart genEditPart = (GenLinkEditPart)i.next(); EClass ecoreClass = genEditPart.getEcoreClass(); if (ecoreClass.isAbstract()) continue;
    stringBuffer.append(TEXT_17);
    stringBuffer.append(ecoreClass.getName());
    stringBuffer.append(TEXT_18);
    stringBuffer.append(ecoreClass.getName());
    stringBuffer.append(TEXT_19);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.model.EObjectLink"));
    stringBuffer.append(TEXT_20);
    stringBuffer.append(GenModelHelper.getImportedQualifiedLinkEditPartClass(genModel, genEditPart));
    stringBuffer.append(TEXT_21);
    } //for
    stringBuffer.append(TEXT_22);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.model.EDiagram"));
    stringBuffer.append(TEXT_23);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.parts.EDiagramEditPart"));
    stringBuffer.append(TEXT_24);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.model.EReferenceLink"));
    stringBuffer.append(TEXT_25);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.parts.ELinkEditPart"));
    stringBuffer.append(TEXT_26);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.model.EObjectLink"));
    stringBuffer.append(TEXT_27);
    if (!GenModelHelper.getGenLinkEditParts(genEditPartFactory.getGenEditParts()).isEmpty()) {
    stringBuffer.append(TEXT_28);
    stringBuffer.append(genModel.getImportedName("org.eclipse.emf.ecore.EClass"));
    stringBuffer.append(TEXT_29);
    for (Iterator i=GenModelHelper.getGenLinkEditParts(genEditPartFactory.getGenEditParts()).iterator(); i.hasNext();) { GenEditPart genEditPart = (GenEditPart)i.next(); EClass ecoreClass = genEditPart.getEcoreClass();  if (ecoreClass.isAbstract()) continue;
    stringBuffer.append(TEXT_30);
    stringBuffer.append(GenModelHelper.getGenClass(genModel, ecoreClass).getGenPackage().getImportedPackageInterfaceName());
    stringBuffer.append(TEXT_31);
    stringBuffer.append(GenModelHelper.getGenClass(genModel, ecoreClass).getClassifierAccessorName());
    stringBuffer.append(TEXT_32);
    stringBuffer.append(ecoreClass.getName());
    stringBuffer.append(TEXT_33);
    } //for
    } //if
    stringBuffer.append(TEXT_34);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.model.ENode"));
    stringBuffer.append(TEXT_35);
    if (!GenModelHelper.getGenNodeEditParts(genEditPartFactory.getGenEditParts()).isEmpty()) {
    stringBuffer.append(TEXT_36);
    stringBuffer.append(genModel.getImportedName("org.eclipse.emf.ecore.EClass"));
    stringBuffer.append(TEXT_37);
    for (Iterator i=GenModelHelper.getGenNodeEditParts(genEditPartFactory.getGenEditParts()).iterator(); i.hasNext();) { GenNodeEditPart genEditPart = (GenNodeEditPart)i.next(); EClass ecoreClass = genEditPart.getEcoreClass();  if (ecoreClass.isAbstract()) continue;
    stringBuffer.append(TEXT_38);
    stringBuffer.append(GenModelHelper.getGenClass(genModel, ecoreClass).getGenPackage().getImportedPackageInterfaceName());
    stringBuffer.append(TEXT_39);
    stringBuffer.append(GenModelHelper.getGenClass(genModel, ecoreClass).getClassifierAccessorName());
    stringBuffer.append(TEXT_40);
    stringBuffer.append(ecoreClass.getName());
    stringBuffer.append(TEXT_41);
    } //for
    } //if
    stringBuffer.append(TEXT_42);
    genModel.emitSortedImports();
    return stringBuffer.toString();
  }
}
