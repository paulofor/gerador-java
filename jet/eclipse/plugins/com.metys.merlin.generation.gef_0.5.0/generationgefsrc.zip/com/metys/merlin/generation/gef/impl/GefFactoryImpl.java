/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.impl;

import java.util.List;
import java.util.StringTokenizer;

import org.eclipse.draw2d.AbsoluteBendpoint;
import org.eclipse.draw2d.Bendpoint;
import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.geometry.Point;
import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.impl.EFactoryImpl;

import com.metys.merlin.generation.gef.GefFactory;
import com.metys.merlin.generation.gef.GefPackage;
import com.metys.merlin.generation.gef.parts.ELinkEditPart;
import com.metys.merlin.generation.gef.parts.ENodeEditPart;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class GefFactoryImpl extends EFactoryImpl implements GefFactory {
  /**
   * Creates an instance of the factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GefFactoryImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EObject create(EClass eClass) {
    switch (eClass.getClassifierID()) {
      default:
        throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object createFromString(EDataType eDataType, String initialValue) {
    switch (eDataType.getClassifierID()) {
      case GefPackage.LIST:
        return createListFromString(eDataType, initialValue);
      case GefPackage.POINT:
        return createPointFromString(eDataType, initialValue);
      case GefPackage.FIGURE:
        return createFigureFromString(eDataType, initialValue);
      case GefPackage.BENDPOINT:
        return createBendpointFromString(eDataType, initialValue);
      case GefPackage.URI:
        return createURIFromString(eDataType, initialValue);
      case GefPackage.NOTIFICATION:
        return createNotificationFromString(eDataType, initialValue);
      case GefPackage.ADAPTER_FACTORY:
        return createAdapterFactoryFromString(eDataType, initialValue);
      case GefPackage.ENODE_EDIT_PART:
        return createENodeEditPartFromString(eDataType, initialValue);
      case GefPackage.ELINK_EDIT_PART:
        return createELinkEditPartFromString(eDataType, initialValue);
      default:
        throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertToString(EDataType eDataType, Object instanceValue) {
    switch (eDataType.getClassifierID()) {
      case GefPackage.LIST:
        return convertListToString(eDataType, instanceValue);
      case GefPackage.POINT:
        return convertPointToString(eDataType, instanceValue);
      case GefPackage.FIGURE:
        return convertFigureToString(eDataType, instanceValue);
      case GefPackage.BENDPOINT:
        return convertBendpointToString(eDataType, instanceValue);
      case GefPackage.URI:
        return convertURIToString(eDataType, instanceValue);
      case GefPackage.NOTIFICATION:
        return convertNotificationToString(eDataType, instanceValue);
      case GefPackage.ADAPTER_FACTORY:
        return convertAdapterFactoryToString(eDataType, instanceValue);
      case GefPackage.ENODE_EDIT_PART:
        return convertENodeEditPartToString(eDataType, instanceValue);
      case GefPackage.ELINK_EDIT_PART:
        return convertELinkEditPartToString(eDataType, instanceValue);
      default:
        throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public Point createPointFromString(EDataType eDataType, String initialValue) {
    if (initialValue == null || initialValue.length() == 0)
      return new Point();
    
    initialValue = initialValue.trim();
    StringTokenizer tokenizer = new StringTokenizer(initialValue, ","); //$NON-NLS-1$
    int x = 0, y = 0;
    try {
      x = new Integer(tokenizer.nextToken().trim()).intValue();
      y = new Integer(tokenizer.nextToken().trim()).intValue();
    } catch (NumberFormatException nfe) {}
    return new Point(x, y);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public String convertPointToString(EDataType eDataType, Object instanceValue) {
    if (instanceValue == null)
      return "0,0";
    Point p = (Point)instanceValue;
    return p.x + "," + p.y;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public Bendpoint createBendpointFromString(EDataType eDataType, String initialValue) {
    return new AbsoluteBendpoint(createPointFromString(null, initialValue));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public String convertBendpointToString(EDataType eDataType, Object instanceValue) {
    return convertPointToString(null, ((Bendpoint)instanceValue).getLocation());
  }

  /**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated NOT
   */
	public URI createURIFromString(EDataType eDataType, String initialValue) {
    return URI.createURI(initialValue);
  }

  /**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated NOT
   */
	public String convertURIToString(EDataType eDataType, Object instanceValue) {
    return ((URI)instanceValue).toString();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Figure createFigureFromString(EDataType eDataType, String initialValue) {
    return (Figure)super.createFromString(eDataType, initialValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertFigureToString(EDataType eDataType, Object instanceValue) {
    return super.convertToString(eDataType, instanceValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Notification createNotificationFromString(EDataType eDataType, String initialValue) {
    return (Notification)super.createFromString(eDataType, initialValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertNotificationToString(EDataType eDataType, Object instanceValue) {
    return super.convertToString(eDataType, instanceValue);
  }

  /**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	public AdapterFactory createAdapterFactoryFromString(EDataType eDataType, String initialValue) {
    return (AdapterFactory)super.createFromString(eDataType, initialValue);
  }

  /**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	public String convertAdapterFactoryToString(EDataType eDataType, Object instanceValue) {
    return super.convertToString(eDataType, instanceValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ENodeEditPart createENodeEditPartFromString(EDataType eDataType, String initialValue) {
    return (ENodeEditPart)super.createFromString(eDataType, initialValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertENodeEditPartToString(EDataType eDataType, Object instanceValue) {
    return super.convertToString(eDataType, instanceValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ELinkEditPart createELinkEditPartFromString(EDataType eDataType, String initialValue) {
    return (ELinkEditPart)super.createFromString(eDataType, initialValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertELinkEditPartToString(EDataType eDataType, Object instanceValue) {
    return super.convertToString(eDataType, instanceValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List createListFromString(EDataType eDataType, String initialValue) {
    return (List)super.createFromString(eDataType, initialValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertListToString(EDataType eDataType, Object instanceValue) {
    return super.convertToString(eDataType, instanceValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GefPackage getGefPackage() {
    return (GefPackage)getEPackage();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @deprecated
   * @generated
   */
  public static GefPackage getPackage() {
    return GefPackage.eINSTANCE;
  }

} //GefFactoryImpl
