/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package com.metys.merlin.generation.gef.genmodel;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Gen Viewer</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenViewer#getGenEditPartFactory <em>Gen Edit Part Factory</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenViewer#getGenGEFModel <em>Gen GEF Model</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenViewer()
 * @model
 * @generated
 */
public interface GenViewer extends GenGEFBase{
  /**
   * Returns the value of the '<em><b>Gen Edit Part Factory</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Gen Edit Part Factory</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Gen Edit Part Factory</em>' reference.
   * @see #setGenEditPartFactory(GenEditPartFactory)
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenViewer_GenEditPartFactory()
   * @model required="true"
   * @generated
   */
  GenEditPartFactory getGenEditPartFactory();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.genmodel.GenViewer#getGenEditPartFactory <em>Gen Edit Part Factory</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Gen Edit Part Factory</em>' reference.
   * @see #getGenEditPartFactory()
   * @generated
   */
  void setGenEditPartFactory(GenEditPartFactory value);

  /**
   * Returns the value of the '<em><b>Gen GEF Model</b></em>' container reference.
   * It is bidirectional and its opposite is '{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getGenViewers <em>Gen Viewers</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Gen GEF Model</em>' container reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Gen GEF Model</em>' container reference.
   * @see #setGenGEFModel(GenGEFModel)
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenViewer_GenGEFModel()
   * @see com.metys.merlin.generation.gef.genmodel.GenGEFModel#getGenViewers
   * @model opposite="genViewers" required="true"
   * @generated
   */
  GenGEFModel getGenGEFModel();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.genmodel.GenViewer#getGenGEFModel <em>Gen GEF Model</em>}' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Gen GEF Model</em>' container reference.
   * @see #getGenGEFModel()
   * @generated
   */
  void setGenGEFModel(GenGEFModel value);

} // GenViewer
