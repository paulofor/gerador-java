/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gef.editpolicies.GraphicalNodeEditPolicy;
import org.eclipse.gef.requests.CreateConnectionRequest;
import org.eclipse.gef.requests.ReconnectRequest;

import com.metys.merlin.generation.gef.commands.CreateConnectionCommand;
import com.metys.merlin.generation.gef.commands.ReconnectSourceCommand;
import com.metys.merlin.generation.gef.commands.ReconnectTargetCommand;
import com.metys.merlin.generation.gef.model.ELink;
import com.metys.merlin.generation.gef.model.ENode;
import com.metys.merlin.generation.gef.parts.ENodeEditPart;


/**
 * @author jcheuoua
 */
public class ENodeGraphicalNodeEditPolicy extends GraphicalNodeEditPolicy {

  /* (non javadoc)
   * @see GraphicalNodeEditPolicy#getConnectionCompleteCommand(CreateConnectionRequest)
   */
  protected Command getConnectionCompleteCommand(CreateConnectionRequest request) {
    if (request.getStartCommand() instanceof CreateConnectionCommand) {
      CreateConnectionCommand cmd = (CreateConnectionCommand) request.getStartCommand();
      ENodeEditPart targetNodeEditPart = (ENodeEditPart) getHost();
      ENode target = targetNodeEditPart.getENode();
      ELink link = cmd.getLink();
      if (acceptLinkAsTarget(target, link)) {
        cmd.setTargetNodeEditPart(targetNodeEditPart);
        return cmd;
      }
    }
    return null;
  }

  /* (non javadoc)
   * @see GraphicalNodeEditPolicy#getConnectionCreateCommand(CreateConnectionRequest)
   */
  protected Command getConnectionCreateCommand(CreateConnectionRequest request) {
    ENodeEditPart sourceNodeEditPart = (ENodeEditPart) getHost();
    ENode source = sourceNodeEditPart.getENode();
    ELink link = (ELink) request.getNewObject();
    if (acceptLinkAsSource(source, link)) {
      CreateConnectionCommand cmd = new CreateConnectionCommand(sourceNodeEditPart, link);
      request.setStartCommand(cmd);
      return cmd;
    }
    return null;
  }

  /* (non javadoc)
   * @see GraphicalNodeEditPolicy#getReconnectSourceCommand(ReconnectRequest)
   */
  protected Command getReconnectSourceCommand(ReconnectRequest request) {
    ENodeEditPart sourceNodeEditPart = (ENodeEditPart) getHost();
    ELink link = (ELink) request.getConnectionEditPart().getModel();
    ENode source = sourceNodeEditPart.getENode();
    if (acceptLinkAsSource(source, link)) {
      ReconnectSourceCommand cmd = new ReconnectSourceCommand(sourceNodeEditPart, link);
      return cmd;
    }
    return null;
  }

  /* (non javadoc)
   * @see GraphicalNodeEditPolicy#getReconnectTargetCommand(ReconnectRequest)
   */
  protected Command getReconnectTargetCommand(ReconnectRequest request) {
    ENodeEditPart targetNodeEditPart = (ENodeEditPart) getHost();
    ELink link = (ELink) request.getConnectionEditPart().getModel();
    ENode target = targetNodeEditPart.getENode();
    if (acceptLinkAsTarget(target, link)) {
      ReconnectTargetCommand cmd = new ReconnectTargetCommand(targetNodeEditPart, link);
      return cmd;
    }
    return null;
  }
  
  public boolean acceptLinkAsTarget(ENode target, ELink link) {
    return target.acceptLinkAsTarget(link);
  }
  
  public boolean acceptLinkAsSource(ENode source, ELink link) {
    return source.acceptLinkAsSource(link);
  }
}