/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.editor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EventObject;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.edit.provider.ComposedAdapterFactory;
import org.eclipse.emf.edit.provider.ReflectiveItemProviderAdapterFactory;
import org.eclipse.emf.edit.provider.resource.ResourceItemProviderAdapterFactory;
import org.eclipse.emf.edit.ui.provider.AdapterFactoryContentProvider;
import org.eclipse.gef.DefaultEditDomain;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.GraphicalViewer;
import org.eclipse.gef.KeyHandler;
import org.eclipse.gef.KeyStroke;
import org.eclipse.gef.dnd.TemplateTransferDragSourceListener;
import org.eclipse.gef.editparts.ZoomManager;
import org.eclipse.gef.palette.MarqueeToolEntry;
import org.eclipse.gef.palette.PaletteContainer;
import org.eclipse.gef.palette.PaletteEntry;
import org.eclipse.gef.palette.PaletteGroup;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.palette.PaletteSeparator;
import org.eclipse.gef.palette.PaletteStack;
import org.eclipse.gef.palette.SelectionToolEntry;
import org.eclipse.gef.palette.ToolEntry;
import org.eclipse.gef.tools.ConnectionCreationTool;
import org.eclipse.gef.ui.actions.ActionRegistry;
import org.eclipse.gef.ui.actions.DirectEditAction;
import org.eclipse.gef.ui.actions.GEFActionConstants;
import org.eclipse.gef.ui.palette.PaletteCustomizer;
import org.eclipse.gef.ui.palette.PaletteViewer;
import org.eclipse.gef.ui.palette.PaletteViewerProvider;
import org.eclipse.gef.ui.palette.FlyoutPaletteComposite.FlyoutPreferences;
import org.eclipse.gef.ui.parts.GraphicalEditorWithFlyoutPalette;
import org.eclipse.gef.ui.parts.SelectionSynchronizer;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.actions.ActionFactory;
import org.eclipse.ui.actions.WorkspaceModifyOperation;
import org.eclipse.ui.dialogs.SaveAsDialog;
import org.eclipse.ui.part.FileEditorInput;
import org.eclipse.ui.views.contentoutline.IContentOutlinePage;
import org.eclipse.ui.views.properties.IPropertySheetPage;
import org.eclipse.ui.views.properties.IPropertySource;
import org.eclipse.ui.views.properties.PropertySheetPage;

import com.metys.merlin.generation.gef.GefPlugin;
import com.metys.merlin.generation.gef.dnd.EDiagramOutlineDropTargetListener;
import com.metys.merlin.generation.gef.dnd.EObjectTemplateTransferDropTargetListener;
import com.metys.merlin.generation.gef.model.EDiagram;
import com.metys.merlin.generation.gef.model.ENode;
import com.metys.merlin.generation.gef.model.EObjectLink;
import com.metys.merlin.generation.gef.model.ModelFactory;
import com.metys.merlin.generation.gef.model.ModelPackage;
import com.metys.merlin.generation.gef.outline.EDiagramOutlinePage;
import com.metys.merlin.generation.gef.outline.OutlineToDiagramTransfer;
import com.metys.merlin.generation.gef.parts.EDiagramEditPart;
/**
 * 
 * @author Jo�l Created on Jun 27, 2003
 */
public abstract class GEFEditor extends GraphicalEditorWithFlyoutPalette {
  public static final String PALETTE_DOCK_LOCATION = "DockLocation"; //$NON-NLS-1$
  public static final String PALETTE_SIZE = "PaletteSize"; //$NON-NLS-1$
  public static final String PALETTE_STATE = "PaletteState"; //$NON-NLS-1$
  
  protected Resource diagramResource;
  protected Resource modelResource;
  protected EDiagram diagram;
  protected EDiagramEditPart diagramEditPart;
  
  protected IPropertySheetPage propertySheetPage;
  protected IContentOutlinePage outlinePage;
  
  protected AdapterFactory adapterFactory;
  private PaletteRoot root;
  private KeyHandler sharedKeyHandler;
  private boolean savePreviouslyNeeded = false;
  private Transfer transfer;
  
  public GEFEditor() {
    DefaultEditDomain defaultEditDomain = new DefaultEditDomain(this);
    defaultEditDomain.setActiveTool(new ConnectionCreationTool());
    setEditDomain(defaultEditDomain);
  }
  
  //====================== Editor's input management
  
  /* (non javadoc)
   * @see org.eclipse.ui.part.EditorPart#setInput(org.eclipse.ui.IEditorInput)
   */
  protected void setInput(IEditorInput input) {
    super.setInput(input);
    IFile file = ((IFileEditorInput) input).getFile();
    // Register the GEF generation package if not registered
    ModelPackage.eINSTANCE.getNsURI();
    ResourceSet resourceSet = diagramResource == null ? new ResourceSetImpl() : diagramResource
        .getResourceSet();
    try {
      URI inputURI = URI.createPlatformResourceURI(file.getFullPath().toString());
      Resource inputResource = resourceSet.getResource(inputURI, true);
      URI modelUri = inputURI;
      URI diagramUri = inputURI;
      if (!inputResource.getContents().isEmpty()
          && inputResource.getContents().get(0) instanceof EDiagram) {
        // EDiagram file
        diagramResource = inputResource;
        diagram = (EDiagram) inputResource.getContents().get(0);
        modelUri = diagram.getModelResource();
        if (modelUri != null)
          modelResource = resourceSet.getResource(modelUri, true);
      } else {
        // Simple model file
        modelResource = inputResource;
        IFile diagramFile = ResourcesPlugin.getWorkspace().getRoot().getFile(
            new Path(file.getFullPath().toString() + ".gef"));
        diagramUri = URI.createPlatformResourceURI(diagramFile.getFullPath().toString());
        if (diagramFile.exists()) {
          diagramResource = resourceSet.getResource(diagramUri, true);
          diagram = (EDiagram) diagramResource.getContents().get(0);
        } else
          diagramResource = resourceSet.createResource(diagramUri);
      }
    } catch (Exception e) {
      GefPlugin.getPlugin().logInError(e, null);
    }
  }
  /* (non javadoc)
   * @see org.eclipse.gef.commands.CommandStackListener#commandStackChanged(java.util.EventObject)
   */
  public void commandStackChanged(EventObject event) {
    if (isDirty()) {
      if (!savePreviouslyNeeded()) {
        setSavePreviouslyNeeded(true);
        firePropertyChange(IEditorPart.PROP_DIRTY);
      }
    } else {
      setSavePreviouslyNeeded(false);
      firePropertyChange(IEditorPart.PROP_DIRTY);
    }
    super.commandStackChanged(event);
  }
  /* (non javadoc)
   * @see org.eclipse.ui.ISaveablePart#doSave(org.eclipse.core.runtime.IProgressMonitor)
   */
  public void doSave(IProgressMonitor monitor) {
    try {
      if (diagramResource != null)
        diagramResource.save(null);
      if (modelResource != null)
        modelResource.save(null);
      getCommandStack().markSaveLocation();
    } catch (Exception e) {
      GefPlugin.getPlugin().logInError(e, "Cannot Save Editor");
    }
  }
  /* (non javadoc)
   * @see org.eclipse.ui.ISaveablePart#doSaveAs()
   */
  public void doSaveAs() {
    SaveAsDialog dialog = new SaveAsDialog(getSite().getWorkbenchWindow().getShell());
    dialog.setOriginalFile(((IFileEditorInput) getEditorInput()).getFile());
    dialog.open();
    IPath path = dialog.getResult();
    if (path == null)
      return;
    IWorkspace workspace = ResourcesPlugin.getWorkspace();
    final IFile file = workspace.getRoot().getFile(path);
    WorkspaceModifyOperation op = new WorkspaceModifyOperation() {
      public void execute(final IProgressMonitor monitor) throws CoreException {
        try {
          URI uri = URI.createPlatformResourceURI(file.getFullPath().toString());
          ResourceSet resourceSet = diagramResource == null
              ? new ResourceSetImpl()
              : diagramResource.getResourceSet();
          Resource oldResource = diagramResource;
          diagramResource = resourceSet.getResource(uri, false);
          if (oldResource != null)
            diagramResource.getContents().addAll(oldResource.getContents());
          diagramResource.save(null);
        } catch (Exception e) {
          GefPlugin.getPlugin().logInError(e, null);
        }
      }
    };
    try {
      new ProgressMonitorDialog(getSite().getWorkbenchWindow().getShell()).run(false, true, op);
      setInput(new FileEditorInput((IFile) file));
      getCommandStack().markSaveLocation();
    } catch (Exception e) {
      GefPlugin.getPlugin().logInError(e, "Cannot Save Editor");
    }
  }
  /* (non javadoc)
   * @see org.eclipse.ui.ISaveablePart#isDirty()
   */
  public boolean isDirty() {
    return isSaveOnCloseNeeded();
  }
  /* (non javadoc)
   * @see org.eclipse.ui.ISaveablePart#isSaveAsAllowed()
   */
  public boolean isSaveAsAllowed() {
    return true;
  }
  /* (non javadoc)
   * @see org.eclipse.ui.ISaveablePart#isSaveOnCloseNeeded()
   */
  public boolean isSaveOnCloseNeeded() {
    return getCommandStack().isDirty();
  }
  private boolean savePreviouslyNeeded() {
    return savePreviouslyNeeded;
  }
  private void setSavePreviouslyNeeded(boolean value) {
    savePreviouslyNeeded = value;
  }
  
  public EDiagram getDiagram() {
    return diagram;
  }  
  public Resource getDiagramResource() {
    return diagramResource;
  }
  public Resource getModelResource() {
    return modelResource;
  }
  
  //====================== Editor Actions
  
  /* (non javadoc)
   * @see org.eclipse.gef.ui.parts.GraphicalEditor#createActions()
   */
  protected void createActions() {
    super.createActions();
    ActionRegistry registry = getActionRegistry();
    IAction action;
    action = new DirectEditAction((IWorkbenchPart) this);
    registry.registerAction(action);
    getSelectionActions().add(action.getId());
  }
  
  
  //====================== Editor's viewer configurations    
  protected void initializeDiagram() {
    if (diagram == null) {
      diagram = ModelFactory.eINSTANCE.createEDiagram();
      diagram.setModelResource(modelResource.getURI());
      diagramResource.getContents().add(diagram);
    }
  }
  /* (non javadoc)
   * @see org.eclipse.gef.ui.parts.GraphicalEditor#initializeGraphicalViewer()
   */
  protected void initializeGraphicalViewer() {
    initializeDiagram();
    getGraphicalViewer().setContents(diagram);
    getGraphicalViewer().addDropTargetListener(
        new EDiagramOutlineDropTargetListener(getGraphicalViewer(), diagram, getTransferInstance()));
    getGraphicalViewer().addDropTargetListener(
        new EObjectTemplateTransferDropTargetListener(getGraphicalViewer()));
  }
  public AdapterFactory getAdapterFactory() {
    if (adapterFactory == null)
      adapterFactory = createAdapterFactory();
    adapterFactory = new ComposedAdapterFactory(new AdapterFactory[] 
           {adapterFactory, 
            new ClassLinkInfoAdapterFactory(getTransitionClasses())});
    return adapterFactory;
  }
  protected AdapterFactory createAdapterFactory() {
    List factories = new ArrayList();
    factories.add(new ResourceItemProviderAdapterFactory());
    factories.add(new ReflectiveItemProviderAdapterFactory());
    ComposedAdapterFactory adapterFactory = new ComposedAdapterFactory(factories);
    return adapterFactory;
  }
  public Object getAdapter(Class type) {
    AdapterFactory adapterFactory = getAdapterFactory();
    if (type == IPropertySheetPage.class) {
      if (propertySheetPage == null) {
        propertySheetPage = createPropertySheetPage();
      }
      return propertySheetPage;
    } else if (type == IContentOutlinePage.class) {
      if (outlinePage == null) {
        outlinePage = createOutlinePage();
      }
      return outlinePage;
    } else if (type == ZoomManager.class)
      return getGraphicalViewer().getProperty(ZoomManager.class.toString());
    return super.getAdapter(type);
  }
  public void setOutlinePage(IContentOutlinePage page) {
    this.outlinePage = page;
  }
  protected IContentOutlinePage createOutlinePage() {
    return new EDiagramOutlinePage(this, adapterFactory);
  }
  public Transfer getTransferInstance() {
    if (transfer == null)
      transfer = new OutlineToDiagramTransfer();    
    return transfer;
  }
  protected IPropertySheetPage createPropertySheetPage() {
    PropertySheetPage page = new PropertySheetPage();
    page.setPropertySourceProvider(new PropertySheetContentProvider(adapterFactory));
    return page;
  }    
  public KeyHandler getCommonKeyHandler() {
    if (sharedKeyHandler == null) {
      sharedKeyHandler = new KeyHandler();
      sharedKeyHandler.put(KeyStroke.getPressed(SWT.DEL, 127, 0), getActionRegistry().getAction(
          ActionFactory.DELETE.getId()));
      sharedKeyHandler.put(KeyStroke.getPressed(SWT.F2, 0), getActionRegistry().getAction(
          GEFActionConstants.DIRECT_EDIT));
    }
    return sharedKeyHandler;
  }
  public EDiagramEditPart getDiagramEditPart() {
    if (diagramEditPart == null) {
      for (Iterator iter = getGraphicalViewer().getRootEditPart().getChildren().iterator(); iter
          .hasNext();) {
        EditPart childrenPart = (EditPart) iter.next();
        if (childrenPart instanceof EDiagramEditPart) {
          diagramEditPart = (EDiagramEditPart) childrenPart;
        }
      }
    }
    return diagramEditPart;
  }  
  protected PaletteViewerProvider createPaletteViewerProvider() {
    return new PaletteViewerProvider(getEditDomain()) {
      protected void configurePaletteViewer(PaletteViewer viewer) {
        super.configurePaletteViewer(viewer);
        viewer.setCustomizer(new PaletteCustomizer() {
          public void revertToSaved() {
          }
          public void save() {
          }
        });
        viewer.addDragSourceListener(new TemplateTransferDragSourceListener(viewer));
      }
    };
  }
  protected FlyoutPreferences getPalettePreferences() {
    return new FlyoutPreferences() {
      public int getDockLocation() {
        return GefPlugin.getPlugin().getPluginPreferences().getInt(PALETTE_DOCK_LOCATION);
      }
      public int getPaletteState() {
        return GefPlugin.getPlugin().getPluginPreferences().getInt(PALETTE_STATE);
      }
      public int getPaletteWidth() {
        return GefPlugin.getPlugin().getPluginPreferences().getInt(PALETTE_SIZE);
      }
      public void setDockLocation(int location) {
        GefPlugin.getPlugin().getPluginPreferences().setValue(PALETTE_DOCK_LOCATION, location);
      }
      public void setPaletteState(int state) {
        GefPlugin.getPlugin().getPluginPreferences().setValue(PALETTE_STATE, state);
      }
      public void setPaletteWidth(int width) {
        GefPlugin.getPlugin().getPluginPreferences().setValue(PALETTE_SIZE, width);
      }
    };
  }
  /* (non javadoc)
   * @see org.eclipse.gef.ui.parts.GraphicalEditorWithPalette#getPaletteRoot()
   */
  protected PaletteRoot getPaletteRoot() {
    if (root == null)
      root = createPaletteRoot();
    return root;
  }
  
  protected PaletteRoot createPaletteRoot() {
    PaletteRoot paletteRoot = new PaletteRoot();
    createControlGroup(paletteRoot);
    createConnectionGroup(paletteRoot);
    createComponentsGroup(paletteRoot);
    return paletteRoot;
  }
  
  protected void createControlGroup(PaletteRoot paletteRoot) {
    PaletteGroup controlGroup = new PaletteGroup("Control Group");
    ToolEntry tool = new SelectionToolEntry();
    controlGroup.add(tool);
    paletteRoot.setDefaultEntry(tool);
    tool = new MarqueeToolEntry();
    controlGroup.add(tool);
    PaletteSeparator sep = new PaletteSeparator(GefPlugin.ID + ".sep1");
    sep.setUserModificationPermission(PaletteEntry.PERMISSION_NO_MODIFICATION);
    controlGroup.add(sep);
    paletteRoot.add(controlGroup);
  }
  
  protected void createConnectionGroup(PaletteRoot paletteRoot) {
    PaletteGroup connectionGroup = new PaletteGroup("Connection Group");
    PaletteStack referenceConnections = new PaletteStack("Reference Links", 
        "Create Reference Links",
        ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/connection16.gif")));
    createReferenceConnectionEntries(referenceConnections);
    if (!referenceConnections.getChildren().isEmpty())
      connectionGroup.add(referenceConnections);    
    createClassConnectionEntries(connectionGroup);
    paletteRoot.add(connectionGroup);
  }
  
  protected void createComponentsGroup(PaletteRoot paletteRoot) {
    PaletteGroup componentsGroup = new PaletteGroup("Components Group");
    createComponentsDrawerEntries(componentsGroup);
    paletteRoot.add(componentsGroup);
  }  
  
  //===== customizable editor's methods
  
  protected Map getTransitionClasses() {
    return Collections.EMPTY_MAP;
  }
  protected abstract void createComponentsDrawerEntries(PaletteContainer container);
  protected abstract void createReferenceConnectionEntries(PaletteContainer container);
  protected abstract void createClassConnectionEntries(PaletteContainer container);  
  
  //===== Overidden for increase of visibility
  
  public GraphicalViewer getGraphicalViewer() {
    return super.getGraphicalViewer();
  }
  public SelectionSynchronizer getSelectionSynchronizer() {
    return super.getSelectionSynchronizer();
  }  
  public DefaultEditDomain getEditDomain() {
    return super.getEditDomain();
  }
  public ActionRegistry getActionRegistry() {
    return super.getActionRegistry();
  }
  
  //====== Nested utility classes
  private class PropertySheetContentProvider extends AdapterFactoryContentProvider {

    public PropertySheetContentProvider(AdapterFactory adapterFactory) {
      super(adapterFactory);
    }

    public IPropertySource getPropertySource(Object object) {
      if (object instanceof EditPart) {
        object = ((EditPart) object).getModel();
        if (object instanceof ENode)
          object = ((ENode)object).getEObject();
        if (object instanceof EObjectLink)
          object = ((EObjectLink) object).getTransitionEObject();
      }
      return super.getPropertySource(object);
    }

  }  
}