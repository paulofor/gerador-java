/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.genmodel.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;

import com.metys.merlin.generation.gef.genmodel.GenEditPart;
import com.metys.merlin.generation.gef.genmodel.GenGEFModel;
import com.metys.merlin.generation.gef.genmodel.GenModelPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Gen Edit Part</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenEditPartImpl#getEcoreClass <em>Ecore Class</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenEditPartImpl#getGenGEFModel <em>Gen GEF Model</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public abstract class GenEditPartImpl extends GenGEFBaseImpl implements GenEditPart {
  /**
   * The cached value of the '{@link #getEcoreClass() <em>Ecore Class</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getEcoreClass()
   * @generated
   * @ordered
   */
  protected EClass ecoreClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected GenEditPartImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return GenModelPackage.eINSTANCE.getGenEditPart();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEcoreClass() {
    if (ecoreClass != null && ecoreClass.eIsProxy()) {
      EClass oldEcoreClass = ecoreClass;
      ecoreClass = (EClass)eResolveProxy((InternalEObject)ecoreClass);
      if (ecoreClass != oldEcoreClass) {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, GenModelPackage.GEN_EDIT_PART__ECORE_CLASS, oldEcoreClass, ecoreClass));
      }
    }
    return ecoreClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass basicGetEcoreClass() {
    return ecoreClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setEcoreClass(EClass newEcoreClass) {
    EClass oldEcoreClass = ecoreClass;
    ecoreClass = newEcoreClass;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_EDIT_PART__ECORE_CLASS, oldEcoreClass, ecoreClass));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenGEFModel getGenGEFModel() {
    if (eContainerFeatureID != GenModelPackage.GEN_EDIT_PART__GEN_GEF_MODEL) return null;
    return (GenGEFModel)eContainer;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setGenGEFModel(GenGEFModel newGenGEFModel) {
    if (newGenGEFModel != eContainer || (eContainerFeatureID != GenModelPackage.GEN_EDIT_PART__GEN_GEF_MODEL && newGenGEFModel != null)) {
      if (EcoreUtil.isAncestor(this, newGenGEFModel))
        throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
      NotificationChain msgs = null;
      if (eContainer != null)
        msgs = eBasicRemoveFromContainer(msgs);
      if (newGenGEFModel != null)
        msgs = ((InternalEObject)newGenGEFModel).eInverseAdd(this, GenModelPackage.GEN_GEF_MODEL__GEN_EDIT_PARTS, GenGEFModel.class, msgs);
      msgs = eBasicSetContainer((InternalEObject)newGenGEFModel, GenModelPackage.GEN_EDIT_PART__GEN_GEF_MODEL, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_EDIT_PART__GEN_GEF_MODEL, newGenGEFModel, newGenGEFModel));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case GenModelPackage.GEN_EDIT_PART__GEN_GEF_MODEL:
          if (eContainer != null)
            msgs = eBasicRemoveFromContainer(msgs);
          return eBasicSetContainer(otherEnd, GenModelPackage.GEN_EDIT_PART__GEN_GEF_MODEL, msgs);
        default:
          return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case GenModelPackage.GEN_EDIT_PART__GEN_GEF_MODEL:
          return eBasicSetContainer(null, GenModelPackage.GEN_EDIT_PART__GEN_GEF_MODEL, msgs);
        default:
          return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
    if (eContainerFeatureID >= 0) {
      switch (eContainerFeatureID) {
        case GenModelPackage.GEN_EDIT_PART__GEN_GEF_MODEL:
          return eContainer.eInverseRemove(this, GenModelPackage.GEN_GEF_MODEL__GEN_EDIT_PARTS, GenGEFModel.class, msgs);
        default:
          return eDynamicBasicRemoveFromContainer(msgs);
      }
    }
    return eContainer.eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_EDIT_PART__NAME:
        return getName();
      case GenModelPackage.GEN_EDIT_PART__PACKAGE_NAME:
        return getPackageName();
      case GenModelPackage.GEN_EDIT_PART__ECORE_CLASS:
        if (resolve) return getEcoreClass();
        return basicGetEcoreClass();
      case GenModelPackage.GEN_EDIT_PART__GEN_GEF_MODEL:
        return getGenGEFModel();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_EDIT_PART__NAME:
        setName((String)newValue);
        return;
      case GenModelPackage.GEN_EDIT_PART__PACKAGE_NAME:
        setPackageName((String)newValue);
        return;
      case GenModelPackage.GEN_EDIT_PART__ECORE_CLASS:
        setEcoreClass((EClass)newValue);
        return;
      case GenModelPackage.GEN_EDIT_PART__GEN_GEF_MODEL:
        setGenGEFModel((GenGEFModel)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_EDIT_PART__NAME:
        setName(NAME_EDEFAULT);
        return;
      case GenModelPackage.GEN_EDIT_PART__PACKAGE_NAME:
        setPackageName(PACKAGE_NAME_EDEFAULT);
        return;
      case GenModelPackage.GEN_EDIT_PART__ECORE_CLASS:
        setEcoreClass((EClass)null);
        return;
      case GenModelPackage.GEN_EDIT_PART__GEN_GEF_MODEL:
        setGenGEFModel((GenGEFModel)null);
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_EDIT_PART__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case GenModelPackage.GEN_EDIT_PART__PACKAGE_NAME:
        return PACKAGE_NAME_EDEFAULT == null ? packageName != null : !PACKAGE_NAME_EDEFAULT.equals(packageName);
      case GenModelPackage.GEN_EDIT_PART__ECORE_CLASS:
        return ecoreClass != null;
      case GenModelPackage.GEN_EDIT_PART__GEN_GEF_MODEL:
        return getGenGEFModel() != null;
    }
    return eDynamicIsSet(eFeature);
  }

} //GenEditPartImpl
