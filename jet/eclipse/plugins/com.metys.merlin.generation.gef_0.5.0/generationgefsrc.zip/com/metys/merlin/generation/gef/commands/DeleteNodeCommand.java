/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.commands;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.commands.Command;

import com.metys.merlin.generation.gef.model.EDiagram;
import com.metys.merlin.generation.gef.model.ELink;
import com.metys.merlin.generation.gef.model.ENode;
import com.metys.merlin.generation.gef.parts.ENodeEditPart;
import com.metys.merlin.generation.gef.parts.GraphicalComponentEditPart;
import com.metys.merlin.generation.gef.policies.ENodeLayoutEditPolicy;

/**
 * @author Joel Cheuoua
 */
public class DeleteNodeCommand extends Command {

  private GraphicalComponentEditPart parentEditPart;
  private ENodeEditPart nodeEditPart;
	private ENode child;
	private EObject parent;
  private int index = -1;
	private List sourceConnections = new ArrayList();
	private List targetConnections = new ArrayList();
	
	/**
	 * @param child
	 */
	public DeleteNodeCommand(GraphicalComponentEditPart parentEditPart, ENodeEditPart nodeEditPart) {
		this.nodeEditPart = nodeEditPart;
    this.parentEditPart = parentEditPart;
		this.child = nodeEditPart.getENode();		
	}
	
	public boolean canExecute() {
    if (parentEditPart == null)
      return true;
    EditPolicy layoutEditPolicy = parentEditPart.getEditPolicy(EditPolicy.LAYOUT_ROLE);
    if (layoutEditPolicy instanceof ENodeLayoutEditPolicy) {
      return ((ENodeLayoutEditPolicy)layoutEditPolicy).acceptRemove(child);
    }
    return true;
  }

  /* (non-Javadoc)
	 * @see org.eclipse.gef.commands.Command#execute()
	 */
	public void execute() {
	  parent = child.eContainer();
		List children = parent instanceof ENode ? 
        ((ENode)parent).getSubNodes() :
        ((EDiagram) parent).getContents();
    index = children.indexOf(child);
    children.remove(child);
    child.setDiagram(null);
    deleteConnections();
    EditPolicy layoutEditPolicy = parentEditPart.getEditPolicy(EditPolicy.LAYOUT_ROLE);
    if (layoutEditPolicy instanceof ENodeLayoutEditPolicy) {
      ((ENodeLayoutEditPolicy)layoutEditPolicy).handleNodeRemoved((ENode)parent, child);
    }
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.gef.commands.Command#undo()
	 */
	public void undo() {
    List children = parent instanceof ENode ? 
        ((ENode)parent).getSubNodes() :
        ((EDiagram) parent).getContents();
		children.add(child);
    child.setDiagram(parent instanceof ENode ?
        ((ENode)parent).getDiagram() :
        ((EDiagram)parent));
		restoreConnections();
    EditPolicy layoutEditPolicy = parentEditPart.getEditPolicy(EditPolicy.LAYOUT_ROLE);
    if (layoutEditPolicy instanceof ENodeLayoutEditPolicy) {
      ((ENodeLayoutEditPolicy)layoutEditPolicy).handleNodeAdded((ENode)parent, child);
    }
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.gef.commands.Command#redo()
	 */
	public void redo() {
    List children = parent instanceof ENode ? 
        ((ENode)parent).getSubNodes() :
        ((EDiagram) parent).getContents();
    index = children.indexOf(child);
		children.remove(child);
    child.setDiagram(null);
		deleteConnections();
    EditPolicy layoutEditPolicy = parentEditPart.getEditPolicy(EditPolicy.LAYOUT_ROLE);
    if (layoutEditPolicy instanceof ENodeLayoutEditPolicy) {
      ((ENodeLayoutEditPolicy)layoutEditPolicy).handleNodeRemoved((ENode)parent, child);
    }
	}
	
	private void deleteConnections() {
    sourceConnections.addAll(child.getOutgoingLinks());
    targetConnections.addAll(child.getIncomingLinks());
		for (int i = 0; i < sourceConnections.size(); i++) {
			ELink t = (ELink) sourceConnections.get(i);
			t.doUnlink();
		}
		for (int i = 0; i < targetConnections.size(); i++) {
			ELink t = (ELink) targetConnections.get(i);
			t.doUnlink();
		}
	}

	private void restoreConnections() {
		for (int i = 0; i < sourceConnections.size(); i++) {
			ELink t = (ELink) sourceConnections.get(i);
			t.doLink();						
		}
		sourceConnections.clear();
		for (int i = 0; i < targetConnections.size(); i++) {
			ELink t = (ELink) targetConnections.get(i);
			t.doLink();
		}
		targetConnections.clear();
	}

}
