package com.metys.merlin.generation.gef.compiledtemplates.viewer;

import com.metys.merlin.generation.gef.genmodel.*;
import com.metys.merlin.generation.gef.genmodel.util.GenModelHelper;
import java.util.*;
import org.eclipse.emf.ecore.*;
import org.eclipse.emf.codegen.ecore.genmodel.*;

public class Viewer
{
  protected static String nl;
  public static synchronized Viewer create(String lineSeparator)
  {
    nl = lineSeparator;
    Viewer result = new Viewer();
    nl = null;
    return result;
  }

  protected final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = "/**" + NL + " * <copyright>" + NL + " * </copyright>" + NL + " *" + NL + " * ";
  protected final String TEXT_3 = "Id";
  protected final String TEXT_4 = NL + " */" + NL + "" + NL + "package ";
  protected final String TEXT_5 = ";" + NL;
  protected final String TEXT_6 = NL + NL + "/**" + NL + " * <!-- begin-user-doc -->" + NL + " * <!-- end-user-doc -->" + NL + " * @generated" + NL + " */" + NL + "public class ";
  protected final String TEXT_7 = " extends ";
  protected final String TEXT_8 = " {" + NL + "\t" + NL + "\t/**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  private ";
  protected final String TEXT_9 = " adapterFactory;" + NL + "" + NL + "\t/**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  public ";
  protected final String TEXT_10 = "(";
  protected final String TEXT_11 = " parent) {" + NL + "    super(parent);" + NL + "  }" + NL + "    " + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected ";
  protected final String TEXT_12 = " createAdapterFactory() {";
  protected final String TEXT_13 = NL + "    ";
  protected final String TEXT_14 = " factories = new ";
  protected final String TEXT_15 = "();" + NL + "\t\tfactories.add(new ";
  protected final String TEXT_16 = "());";
  protected final String TEXT_17 = NL + "\t\tfactories.add(new ";
  protected final String TEXT_18 = "());";
  protected final String TEXT_19 = NL + "\t\tfactories.add(new ";
  protected final String TEXT_20 = "());";
  protected final String TEXT_21 = NL + "\t\tfactories.add(new ";
  protected final String TEXT_22 = "());" + NL + "\t\tadapterFactory = new ";
  protected final String TEXT_23 = "(factories);" + NL + "    return adapterFactory;" + NL + "  }" + NL + "" + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected ";
  protected final String TEXT_24 = " getTransitionClasses() {";
  protected final String TEXT_25 = NL + "\t\treturn ";
  protected final String TEXT_26 = ".EMPTY_MAP;";
  protected final String TEXT_27 = NL + "  \t";
  protected final String TEXT_28 = " transitionClasses = new ";
  protected final String TEXT_29 = "();" + NL + "  \t";
  protected final String TEXT_30 = " refList = new ";
  protected final String TEXT_31 = "();";
  protected final String TEXT_32 = NL + "\t\trefList.clear();" + NL + "\t\trefList.add(";
  protected final String TEXT_33 = "());" + NL + "\t\trefList.add(";
  protected final String TEXT_34 = "());" + NL + "\t\ttransitionClasses.put(";
  protected final String TEXT_35 = ".eINSTANCE.get";
  protected final String TEXT_36 = "()," + NL + "\t\t\trefList);";
  protected final String TEXT_37 = NL + "\t\treturn transitionClasses;";
  protected final String TEXT_38 = NL + "  }" + NL + "  " + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected ";
  protected final String TEXT_39 = " createEditPartFactory() {" + NL + "  \treturn new ";
  protected final String TEXT_40 = "(createAdapterFactory(), null);" + NL + "  }" + NL + "}";

  public String generate(Object argument)
  {
    StringBuffer stringBuffer = new StringBuffer();
    
/**
 * Copyright (c) 2005 Joel Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

    GenViewer genViewer = (GenViewer) argument; GenModel genModel = genViewer.getGenGEFModel().getGenModel();
    stringBuffer.append(TEXT_1);
    stringBuffer.append(TEXT_2);
    stringBuffer.append("$");
    stringBuffer.append(TEXT_3);
    stringBuffer.append("$");
    stringBuffer.append(TEXT_4);
    stringBuffer.append(genViewer.getPackageName());
    stringBuffer.append(TEXT_5);
    genModel.markImportLocation(stringBuffer);
    stringBuffer.append(TEXT_6);
    stringBuffer.append(genViewer.getName());
    stringBuffer.append(TEXT_7);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.viewer.GEFGraphicalViewer"));
    stringBuffer.append(TEXT_8);
    stringBuffer.append(genModel.getImportedName("org.eclipse.emf.common.notify.AdapterFactory"));
    stringBuffer.append(TEXT_9);
    stringBuffer.append(genViewer.getName());
    stringBuffer.append(TEXT_10);
    stringBuffer.append(genModel.getImportedName("org.eclipse.swt.widgets.Composite"));
    stringBuffer.append(TEXT_11);
    stringBuffer.append(genModel.getImportedName("org.eclipse.emf.common.notify.AdapterFactory"));
    stringBuffer.append(TEXT_12);
    stringBuffer.append(TEXT_13);
    stringBuffer.append(genModel.getImportedName("java.util.List"));
    stringBuffer.append(TEXT_14);
    stringBuffer.append(genModel.getImportedName("java.util.ArrayList"));
    stringBuffer.append(TEXT_15);
    stringBuffer.append(genModel.getImportedName("org.eclipse.emf.edit.provider.resource.ResourceItemProviderAdapterFactory"));
    stringBuffer.append(TEXT_16);
    for (Iterator i = genModel.getAllGenPackagesWithClassifiers().iterator(); i.hasNext(); ) { GenPackage aGenPackage = (GenPackage)i.next();
    if (aGenPackage.getGenModel().hasEditSupport()) {
    stringBuffer.append(TEXT_17);
    stringBuffer.append(aGenPackage.getImportedItemProviderAdapterFactoryClassName());
    stringBuffer.append(TEXT_18);
    }
    }
    for (Iterator i = genModel.getAllUsedGenPackagesWithClassifiers().iterator(); i.hasNext(); ) { GenPackage aGenPackage = (GenPackage)i.next();
    if (aGenPackage.getGenModel().hasEditSupport()) {
    stringBuffer.append(TEXT_19);
    stringBuffer.append(aGenPackage.getImportedItemProviderAdapterFactoryClassName());
    stringBuffer.append(TEXT_20);
    }
    }
    stringBuffer.append(TEXT_21);
    stringBuffer.append(genModel.getImportedName("org.eclipse.emf.edit.provider.ReflectiveItemProviderAdapterFactory"));
    stringBuffer.append(TEXT_22);
    stringBuffer.append(genModel.getImportedName("org.eclipse.emf.edit.provider.ComposedAdapterFactory"));
    stringBuffer.append(TEXT_23);
    stringBuffer.append(genModel.getImportedName("java.util.Map"));
    stringBuffer.append(TEXT_24);
     if (GenModelHelper.getGenLinkEditParts(genViewer.getGenEditPartFactory().getGenEditParts()).isEmpty()) {
    stringBuffer.append(TEXT_25);
    stringBuffer.append(genModel.getImportedName("java.util.Collections"));
    stringBuffer.append(TEXT_26);
    } else {
    stringBuffer.append(TEXT_27);
    stringBuffer.append(genModel.getImportedName("java.util.Map"));
    stringBuffer.append(TEXT_28);
    stringBuffer.append(genModel.getImportedName("java.util.HashMap"));
    stringBuffer.append(TEXT_29);
    stringBuffer.append(genModel.getImportedName("java.util.List"));
    stringBuffer.append(TEXT_30);
    stringBuffer.append(genModel.getImportedName("java.util.ArrayList"));
    stringBuffer.append(TEXT_31);
    for (Iterator i=GenModelHelper.getGenLinkEditParts(genViewer.getGenEditPartFactory().getGenEditParts()).iterator(); i.hasNext();) { GenLinkEditPart genEditPart = (GenLinkEditPart)i.next(); EClass ecoreClass = genEditPart.getEcoreClass(); GenClass genClass = GenModelHelper.getGenClass(genModel, ecoreClass);GenPackage genPackage = genClass.getGenPackage();
    stringBuffer.append(TEXT_32);
    stringBuffer.append(GenModelHelper.getGenFeature(genModel, genEditPart.getSourceReference()).getQualifiedFeatureAccessorName());
    stringBuffer.append(TEXT_33);
    stringBuffer.append(GenModelHelper.getGenFeature(genModel, genEditPart.getTargetReference()).getQualifiedFeatureAccessorName());
    stringBuffer.append(TEXT_34);
    stringBuffer.append(genPackage.getImportedPackageInterfaceName());
    stringBuffer.append(TEXT_35);
    stringBuffer.append(genClass.getClassifierAccessorName());
    stringBuffer.append(TEXT_36);
    } //for
    stringBuffer.append(TEXT_37);
    } //if
    stringBuffer.append(TEXT_38);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.EditPartFactory"));
    stringBuffer.append(TEXT_39);
    stringBuffer.append(genModel.getImportedName(genViewer.getGenEditPartFactory().getPackageName() + "." + genViewer.getGenEditPartFactory().getName()));
    stringBuffer.append(TEXT_40);
    genModel.emitSortedImports();
    return stringBuffer.toString();
  }
}
