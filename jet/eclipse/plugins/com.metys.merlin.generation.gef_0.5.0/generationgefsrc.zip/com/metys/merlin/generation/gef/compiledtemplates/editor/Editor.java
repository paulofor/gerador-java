package com.metys.merlin.generation.gef.compiledtemplates.editor;

import com.metys.merlin.generation.gef.genmodel.*;
import com.metys.merlin.generation.gef.genmodel.util.GenModelHelper;
import java.util.*;
import org.eclipse.emf.ecore.*;
import org.eclipse.emf.codegen.ecore.genmodel.*;

public class Editor
{
  protected static String nl;
  public static synchronized Editor create(String lineSeparator)
  {
    nl = lineSeparator;
    Editor result = new Editor();
    nl = null;
    return result;
  }

  protected final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = "/**" + NL + " * <copyright>" + NL + " * </copyright>" + NL + " *" + NL + " * ";
  protected final String TEXT_3 = "Id";
  protected final String TEXT_4 = NL + " */" + NL + "" + NL + "package ";
  protected final String TEXT_5 = ";" + NL;
  protected final String TEXT_6 = NL + NL + "/**" + NL + " * The ";
  protected final String TEXT_7 = " GEF editor." + NL + " * <!-- begin-user-doc -->" + NL + " * <!-- end-user-doc -->" + NL + " * @generated" + NL + " */" + NL + "public class ";
  protected final String TEXT_8 = " extends ";
  protected final String TEXT_9 = " {" + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected void createComponentsDrawerEntries(";
  protected final String TEXT_10 = " container) {";
  protected final String TEXT_11 = "  \t" + NL + "  \t";
  protected final String TEXT_12 = " drawer = null;";
  protected final String TEXT_13 = NL + "    ";
  protected final String TEXT_14 = " combined = null;";
  protected final String TEXT_15 = NL + "    ";
  protected final String TEXT_16 = " eClass = null;";
  protected final String TEXT_17 = "\t\t    \t\t" + NL + "\t\tdrawer = new PaletteDrawer(\"";
  protected final String TEXT_18 = "\", null);        ";
  protected final String TEXT_19 = NL + "\t\teClass = ";
  protected final String TEXT_20 = ".eINSTANCE.get";
  protected final String TEXT_21 = "();" + NL + "\t\tcombined = new CombinedTemplateCreationEntry(" + NL + "  \t\t\"";
  protected final String TEXT_22 = "\"," + NL + "  \t\t\"Create a new ";
  protected final String TEXT_23 = "\"," + NL + "  \t\teClass," + NL + "  \t\tnew ";
  protected final String TEXT_24 = "(eClass)," + NL + "  \t\t\t";
  protected final String TEXT_25 = ".createFromURL(";
  protected final String TEXT_26 = ".getPlugin().getBundle().getEntry(\"icons/full/obj16/";
  protected final String TEXT_27 = ".gif\"))," + NL + "  \t\t\tImageDescriptor.createFromURL(";
  protected final String TEXT_28 = ".getPlugin().getBundle().getEntry(\"icons/full/obj16/";
  protected final String TEXT_29 = ".gif\")));" + NL + "  \tdrawer.add(combined);\t";
  protected final String TEXT_30 = NL + "\t\tif (!drawer.getChildren().isEmpty())" + NL + "\t\t\tcontainer.add(drawer);";
  protected final String TEXT_31 = NL + "  }" + NL + "" + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected void createClassConnectionEntries(";
  protected final String TEXT_32 = " container) {";
  protected final String TEXT_33 = NL + "    ";
  protected final String TEXT_34 = " paletteStack = null;";
  protected final String TEXT_35 = NL + "    ";
  protected final String TEXT_36 = " tool = null;";
  protected final String TEXT_37 = NL + "    ";
  protected final String TEXT_38 = " eClass = null;";
  protected final String TEXT_39 = NL + "\t\tpaletteStack = new PaletteStack(\"";
  protected final String TEXT_40 = "\", " + NL + "        \"";
  protected final String TEXT_41 = "\"," + NL + "        ImageDescriptor.createFromURL(";
  protected final String TEXT_42 = ".getPlugin().getBundle().getEntry(\"icons/group16.gif\")));";
  protected final String TEXT_43 = NL + "\t\teClass = ";
  protected final String TEXT_44 = ".eINSTANCE.get";
  protected final String TEXT_45 = "();" + NL + "\t\ttool = new ConnectionCreationToolEntry(" + NL + "\t\t\t\"";
  protected final String TEXT_46 = "\"," + NL + "\t\t\t\"Creating ";
  protected final String TEXT_47 = " connection\"," + NL + "\t\t\tnew ";
  protected final String TEXT_48 = "(eClass," + NL + "\t\t\t\t";
  protected final String TEXT_49 = "()," + NL + "\t\t\t\t";
  protected final String TEXT_50 = "())," + NL + "\t\t\tImageDescriptor.createFromURL(";
  protected final String TEXT_51 = ".getPlugin().getBundle().getEntry(\"icons/classLink.gif\"))," + NL + "\t\t\tImageDescriptor.createFromURL(";
  protected final String TEXT_52 = ".getPlugin().getBundle().getEntry(\"icons/classLink.gif\")));" + NL + "\t\tpaletteStack.add(tool);";
  protected final String TEXT_53 = NL + "    if (!paletteStack.getChildren().isEmpty())" + NL + "      container.add(paletteStack);    ";
  protected final String TEXT_54 = NL + "  }" + NL + "  " + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected void createReferenceConnectionEntries(";
  protected final String TEXT_55 = " container) {";
  protected final String TEXT_56 = "  ";
  protected final String TEXT_57 = NL + "    ";
  protected final String TEXT_58 = " tool = null;";
  protected final String TEXT_59 = NL + "\t\ttool = new ConnectionCreationToolEntry(" + NL + "  \t\t\"";
  protected final String TEXT_60 = " 2 ";
  protected final String TEXT_61 = "\"," + NL + "  \t\t\"Creating ";
  protected final String TEXT_62 = " connection\"," + NL + "  \t\tnew ";
  protected final String TEXT_63 = "(";
  protected final String TEXT_64 = "())," + NL + "  \t\t\tImageDescriptor.createFromURL(";
  protected final String TEXT_65 = ".getPlugin().getBundle().getEntry(\"icons/referenceLink.gif\"))," + NL + "  \t\t\tImageDescriptor.createFromURL(";
  protected final String TEXT_66 = ".getPlugin().getBundle().getEntry(\"icons/referenceLink.gif\")));" + NL + "  \tcontainer.add(tool);";
  protected final String TEXT_67 = "\t\t";
  protected final String TEXT_68 = "\t\t    ";
  protected final String TEXT_69 = NL + "  }  " + NL + "  " + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected ";
  protected final String TEXT_70 = " getTransitionClasses() {";
  protected final String TEXT_71 = NL + "\t\treturn ";
  protected final String TEXT_72 = ".EMPTY_MAP;";
  protected final String TEXT_73 = NL + "  \t";
  protected final String TEXT_74 = " transitionClasses = new ";
  protected final String TEXT_75 = "();" + NL + "  \t";
  protected final String TEXT_76 = " refList = new ";
  protected final String TEXT_77 = "();";
  protected final String TEXT_78 = NL + "\t\trefList.clear();" + NL + "\t\trefList.add(";
  protected final String TEXT_79 = "());" + NL + "\t\trefList.add(";
  protected final String TEXT_80 = "());" + NL + "\t\ttransitionClasses.put(";
  protected final String TEXT_81 = ".eINSTANCE.get";
  protected final String TEXT_82 = "()," + NL + "\t\t\trefList);";
  protected final String TEXT_83 = NL + "\t\treturn transitionClasses;";
  protected final String TEXT_84 = NL + "  }" + NL + "  " + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected ";
  protected final String TEXT_85 = " createEditPartFactory() {" + NL + "  \treturn new ";
  protected final String TEXT_86 = "(createAdapterFactory(), modelResource);" + NL + "  }" + NL + "" + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected void configureGraphicalViewer() {" + NL + "    getGraphicalViewer().getControl().setBackground(";
  protected final String TEXT_87 = ".listBackground);" + NL + "    getGraphicalViewer().setRootEditPart(new ";
  protected final String TEXT_88 = "());" + NL + "    getGraphicalViewer().setEditPartFactory(createEditPartFactory());" + NL + "    getGraphicalViewer().setKeyHandler(new ";
  protected final String TEXT_89 = "(getGraphicalViewer()).setParent(getCommonKeyHandler()));" + NL;
  protected final String TEXT_90 = NL + "    ";
  protected final String TEXT_91 = " provider " + NL + "      = new ";
  protected final String TEXT_92 = "(getGraphicalViewer(), getActionRegistry());" + NL + "    getGraphicalViewer().setContextMenu(provider);" + NL + "    getSite().registerContextMenu(\"";
  protected final String TEXT_93 = "\", //$NON-NLS-1$" + NL + "        provider, getGraphicalViewer());" + NL + "  }" + NL + "  " + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected ";
  protected final String TEXT_94 = " createAdapterFactory() {";
  protected final String TEXT_95 = NL + "    ";
  protected final String TEXT_96 = " factories = new ";
  protected final String TEXT_97 = "();" + NL + "\t\tfactories.add(new ";
  protected final String TEXT_98 = "());";
  protected final String TEXT_99 = NL + "\t\tfactories.add(new ";
  protected final String TEXT_100 = "());";
  protected final String TEXT_101 = NL + "\t\tfactories.add(new ";
  protected final String TEXT_102 = "());";
  protected final String TEXT_103 = NL + "\t\tfactories.add(new ";
  protected final String TEXT_104 = "());" + NL + "\t\tadapterFactory = new ";
  protected final String TEXT_105 = "(factories);" + NL + "    return adapterFactory;" + NL + "  }" + NL + "}";

  public String generate(Object argument)
  {
    StringBuffer stringBuffer = new StringBuffer();
    
/**
 * Copyright (c) 2005 Joel Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

    GenEditor genEditor = (GenEditor) argument; GenModel genModel = genEditor.getGenGEFModel().getGenModel();
    stringBuffer.append(TEXT_1);
    stringBuffer.append(TEXT_2);
    stringBuffer.append("$");
    stringBuffer.append(TEXT_3);
    stringBuffer.append("$");
    stringBuffer.append(TEXT_4);
    stringBuffer.append(genEditor.getPackageName());
    stringBuffer.append(TEXT_5);
    genModel.markImportLocation(stringBuffer);
    stringBuffer.append(TEXT_6);
    stringBuffer.append(genEditor.getName());
    stringBuffer.append(TEXT_7);
    stringBuffer.append(genEditor.getName());
    stringBuffer.append(TEXT_8);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.editor.GEFEditor"));
    stringBuffer.append(TEXT_9);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.palette.PaletteContainer"));
    stringBuffer.append(TEXT_10);
    if (!genEditor.getGenPaletteComponentsFactories().isEmpty()) {
    stringBuffer.append(TEXT_11);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.palette.PaletteDrawer"));
    stringBuffer.append(TEXT_12);
    stringBuffer.append(TEXT_13);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.palette.CombinedTemplateCreationEntry"));
    stringBuffer.append(TEXT_14);
    stringBuffer.append(TEXT_15);
    stringBuffer.append(genModel.getImportedName("org.eclipse.emf.ecore.EClass"));
    stringBuffer.append(TEXT_16);
    for (Iterator i=genEditor.getGenPaletteComponentsFactories().iterator(); i.hasNext();) { GenPaletteComponentsFactory genPaletteComponentsFactory = (GenPaletteComponentsFactory)i.next();
    stringBuffer.append(TEXT_17);
    stringBuffer.append(genPaletteComponentsFactory.getName()==null ? "<Components>" : genPaletteComponentsFactory.getName());
    stringBuffer.append(TEXT_18);
    for (Iterator parts=genPaletteComponentsFactory.getGenNodeParts().iterator(); parts.hasNext();) { GenNodeEditPart genEditPart = (GenNodeEditPart)parts.next(); GenPackage genPackage = GenModelHelper.getGenPackage(genModel, genEditPart.getEcoreClass().getEPackage());
    stringBuffer.append(TEXT_19);
    stringBuffer.append(genPackage.getImportedPackageInterfaceName());
    stringBuffer.append(TEXT_20);
    stringBuffer.append(GenModelHelper.getGenClass(genModel, genEditPart.getEcoreClass()).getClassifierAccessorName());
    stringBuffer.append(TEXT_21);
    stringBuffer.append(genEditPart.getEcoreClass().getName());
    stringBuffer.append(TEXT_22);
    stringBuffer.append(genEditPart.getEcoreClass().getName());
    stringBuffer.append(TEXT_23);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.dnd.EObjectTemplateCreationFactory"));
    stringBuffer.append(TEXT_24);
    stringBuffer.append(genModel.getImportedName("org.eclipse.jface.resource.ImageDescriptor"));
    stringBuffer.append(TEXT_25);
    stringBuffer.append(genModel.getImportedName(genModel.getQualifiedEditPluginClassName()));
    stringBuffer.append(TEXT_26);
    stringBuffer.append(genEditPart.getEcoreClass().getName());
    stringBuffer.append(TEXT_27);
    stringBuffer.append(genModel.getImportedName(genModel.getQualifiedEditPluginClassName()));
    stringBuffer.append(TEXT_28);
    stringBuffer.append(genEditPart.getEcoreClass().getName());
    stringBuffer.append(TEXT_29);
    } //for
    stringBuffer.append(TEXT_30);
    } //for
    } //if
    stringBuffer.append(TEXT_31);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.palette.PaletteContainer"));
    stringBuffer.append(TEXT_32);
    if (!genEditor.getGenPaletteConnectionsFactories().isEmpty()) {
    stringBuffer.append(TEXT_33);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.palette.PaletteStack"));
    stringBuffer.append(TEXT_34);
    stringBuffer.append(TEXT_35);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.palette.ConnectionCreationToolEntry"));
    stringBuffer.append(TEXT_36);
    stringBuffer.append(TEXT_37);
    stringBuffer.append(genModel.getImportedName("org.eclipse.emf.ecore.EClass"));
    stringBuffer.append(TEXT_38);
    for (Iterator i=genEditor.getGenPaletteConnectionsFactories().iterator(); i.hasNext();) { GenPaletteConnectionsFactory genPaletteConnectionsFactory = (GenPaletteConnectionsFactory)i.next();
    stringBuffer.append(TEXT_39);
    stringBuffer.append(genPaletteConnectionsFactory.getName()==null ? "<Components>" : genPaletteConnectionsFactory.getName());
    stringBuffer.append(TEXT_40);
    stringBuffer.append(genPaletteConnectionsFactory.getName()==null ? "<Components>" : genPaletteConnectionsFactory.getName());
    stringBuffer.append(TEXT_41);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.GefPlugin"));
    stringBuffer.append(TEXT_42);
    for (Iterator parts=genPaletteConnectionsFactory.getGenLinkParts().iterator(); parts.hasNext();) { GenLinkEditPart genEditPart = (GenLinkEditPart)parts.next(); EClass ecoreClass = genEditPart.getEcoreClass(); GenClass genClass = GenModelHelper.getGenClass(genModel, ecoreClass);GenPackage genPackage = genClass.getGenPackage();
    stringBuffer.append(TEXT_43);
    stringBuffer.append(genPackage.getImportedPackageInterfaceName());
    stringBuffer.append(TEXT_44);
    stringBuffer.append(genClass.getClassifierAccessorName());
    stringBuffer.append(TEXT_45);
    stringBuffer.append(genClass.getClassifierAccessorName());
    stringBuffer.append(TEXT_46);
    stringBuffer.append(genClass.getClassifierAccessorName());
    stringBuffer.append(TEXT_47);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.dnd.EObjectLinkTemplateCreationFactory"));
    stringBuffer.append(TEXT_48);
    stringBuffer.append(GenModelHelper.getGenFeature(genModel, genEditPart.getSourceReference()).getQualifiedFeatureAccessorName());
    stringBuffer.append(TEXT_49);
    stringBuffer.append(GenModelHelper.getGenFeature(genModel, genEditPart.getTargetReference()).getQualifiedFeatureAccessorName());
    stringBuffer.append(TEXT_50);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.GefPlugin"));
    stringBuffer.append(TEXT_51);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.GefPlugin"));
    stringBuffer.append(TEXT_52);
    } //for
    stringBuffer.append(TEXT_53);
    } //for
    } //if
    stringBuffer.append(TEXT_54);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.palette.PaletteContainer"));
    stringBuffer.append(TEXT_55);
    if (!genEditor.getGenPaletteComponentsFactories().isEmpty()) {
    stringBuffer.append(TEXT_56);
    stringBuffer.append(TEXT_57);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.palette.ConnectionCreationToolEntry"));
    stringBuffer.append(TEXT_58);
    HashSet processedReferences = new HashSet();
    for (Iterator i=genEditor.getGenPaletteComponentsFactories().iterator(); i.hasNext();) { GenPaletteComponentsFactory genPaletteComponentsFactory = (GenPaletteComponentsFactory)i.next();
    for (Iterator parts=genPaletteComponentsFactory.getGenNodeParts().iterator(); parts.hasNext();) { GenNodeEditPart genEditPart = (GenNodeEditPart)parts.next(); EClass ecoreClass = genEditPart.getEcoreClass();
    for (Iterator references=ecoreClass.getEAllReferences().iterator(); references.hasNext();) { EReference ref = (EReference)references.next(); GenFeature genReference = GenModelHelper.getGenFeature(genModel, ref);
    if (genReference.isContainer() || genReference.isContains() || processedReferences.contains(genReference)) continue; processedReferences.add(genReference);
    stringBuffer.append(TEXT_59);
    stringBuffer.append(genReference.getGenClass().getName());
    stringBuffer.append(TEXT_60);
    stringBuffer.append(genReference.getEcoreFeature().getEType().getName());
    stringBuffer.append(TEXT_61);
    stringBuffer.append(genReference.getCapName());
    stringBuffer.append(TEXT_62);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.dnd.EReferenceLinkTemplateCreationFactory"));
    stringBuffer.append(TEXT_63);
    stringBuffer.append(genReference.getQualifiedFeatureAccessorName());
    stringBuffer.append(TEXT_64);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.GefPlugin"));
    stringBuffer.append(TEXT_65);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.GefPlugin"));
    stringBuffer.append(TEXT_66);
    } //for
    stringBuffer.append(TEXT_67);
    } //for
    stringBuffer.append(TEXT_68);
    } //for
    } //if
    stringBuffer.append(TEXT_69);
    stringBuffer.append(genModel.getImportedName("java.util.Map"));
    stringBuffer.append(TEXT_70);
     if (GenModelHelper.getGenLinkEditParts(genEditor.getGenEditPartFactory().getGenEditParts()).isEmpty()) {
    stringBuffer.append(TEXT_71);
    stringBuffer.append(genModel.getImportedName("java.util.Collections"));
    stringBuffer.append(TEXT_72);
    } else {
    stringBuffer.append(TEXT_73);
    stringBuffer.append(genModel.getImportedName("java.util.Map"));
    stringBuffer.append(TEXT_74);
    stringBuffer.append(genModel.getImportedName("java.util.HashMap"));
    stringBuffer.append(TEXT_75);
    stringBuffer.append(genModel.getImportedName("java.util.List"));
    stringBuffer.append(TEXT_76);
    stringBuffer.append(genModel.getImportedName("java.util.ArrayList"));
    stringBuffer.append(TEXT_77);
    for (Iterator i=GenModelHelper.getGenLinkEditParts(genEditor.getGenEditPartFactory().getGenEditParts()).iterator(); i.hasNext();) { GenLinkEditPart genEditPart = (GenLinkEditPart)i.next(); EClass ecoreClass = genEditPart.getEcoreClass(); GenClass genClass = GenModelHelper.getGenClass(genModel, ecoreClass);GenPackage genPackage = genClass.getGenPackage();
    stringBuffer.append(TEXT_78);
    stringBuffer.append(GenModelHelper.getGenFeature(genModel, genEditPart.getSourceReference()).getQualifiedFeatureAccessorName());
    stringBuffer.append(TEXT_79);
    stringBuffer.append(GenModelHelper.getGenFeature(genModel, genEditPart.getTargetReference()).getQualifiedFeatureAccessorName());
    stringBuffer.append(TEXT_80);
    stringBuffer.append(genPackage.getImportedPackageInterfaceName());
    stringBuffer.append(TEXT_81);
    stringBuffer.append(genClass.getClassifierAccessorName());
    stringBuffer.append(TEXT_82);
    } //for
    stringBuffer.append(TEXT_83);
    } //if
    stringBuffer.append(TEXT_84);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.EditPartFactory"));
    stringBuffer.append(TEXT_85);
    stringBuffer.append(genModel.getImportedName(genEditor.getGenEditPartFactory().getPackageName() + "." + genEditor.getGenEditPartFactory().getName()));
    stringBuffer.append(TEXT_86);
    stringBuffer.append(genModel.getImportedName("org.eclipse.draw2d.ColorConstants"));
    stringBuffer.append(TEXT_87);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.editparts.ScalableFreeformRootEditPart"));
    stringBuffer.append(TEXT_88);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.ui.parts.GraphicalViewerKeyHandler"));
    stringBuffer.append(TEXT_89);
    stringBuffer.append(TEXT_90);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.ContextMenuProvider"));
    stringBuffer.append(TEXT_91);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.editor.GEFEditorContextMenuProvider"));
    stringBuffer.append(TEXT_92);
    stringBuffer.append(genEditor.getName() + ".gef.editor.contextmenu");
    stringBuffer.append(TEXT_93);
    stringBuffer.append(genModel.getImportedName("org.eclipse.emf.common.notify.AdapterFactory"));
    stringBuffer.append(TEXT_94);
    stringBuffer.append(TEXT_95);
    stringBuffer.append(genModel.getImportedName("java.util.List"));
    stringBuffer.append(TEXT_96);
    stringBuffer.append(genModel.getImportedName("java.util.ArrayList"));
    stringBuffer.append(TEXT_97);
    stringBuffer.append(genModel.getImportedName("org.eclipse.emf.edit.provider.resource.ResourceItemProviderAdapterFactory"));
    stringBuffer.append(TEXT_98);
    for (Iterator i = genModel.getAllGenPackagesWithClassifiers().iterator(); i.hasNext(); ) { GenPackage aGenPackage = (GenPackage)i.next();
    if (aGenPackage.getGenModel().hasEditSupport()) {
    stringBuffer.append(TEXT_99);
    stringBuffer.append(aGenPackage.getImportedItemProviderAdapterFactoryClassName());
    stringBuffer.append(TEXT_100);
    }
    }
    for (Iterator i = genModel.getAllUsedGenPackagesWithClassifiers().iterator(); i.hasNext(); ) { GenPackage aGenPackage = (GenPackage)i.next();
    if (aGenPackage.getGenModel().hasEditSupport()) {
    stringBuffer.append(TEXT_101);
    stringBuffer.append(aGenPackage.getImportedItemProviderAdapterFactoryClassName());
    stringBuffer.append(TEXT_102);
    }
    }
    stringBuffer.append(TEXT_103);
    stringBuffer.append(genModel.getImportedName("org.eclipse.emf.edit.provider.ReflectiveItemProviderAdapterFactory"));
    stringBuffer.append(TEXT_104);
    stringBuffer.append(genModel.getImportedName("org.eclipse.emf.edit.provider.ComposedAdapterFactory"));
    stringBuffer.append(TEXT_105);
    genModel.emitSortedImports();
    return stringBuffer.toString();
  }
}
