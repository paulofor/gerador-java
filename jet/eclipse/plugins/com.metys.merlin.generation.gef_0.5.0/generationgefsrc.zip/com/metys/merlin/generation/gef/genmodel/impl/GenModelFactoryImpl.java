/**
 * <copyright>
 * </copyright>
 *
 * $Id: GenModelFactoryImpl.java,v 1.6 2005/07/08 23:58:37 jcheuoua Exp $
 */
package com.metys.merlin.generation.gef.genmodel.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.impl.EFactoryImpl;

import com.metys.merlin.generation.gef.genmodel.GenEditPartFactory;
import com.metys.merlin.generation.gef.genmodel.GenEditor;
import com.metys.merlin.generation.gef.genmodel.GenFigure;
import com.metys.merlin.generation.gef.genmodel.GenGEFModel;
import com.metys.merlin.generation.gef.genmodel.GenLinkEditPart;
import com.metys.merlin.generation.gef.genmodel.GenModelFactory;
import com.metys.merlin.generation.gef.genmodel.GenModelPackage;
import com.metys.merlin.generation.gef.genmodel.GenNodeEditPart;
import com.metys.merlin.generation.gef.genmodel.GenPaletteComponentsFactory;
import com.metys.merlin.generation.gef.genmodel.GenPaletteConnectionsFactory;
import com.metys.merlin.generation.gef.genmodel.GenSubNodeReference;
import com.metys.merlin.generation.gef.genmodel.GenViewer;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class GenModelFactoryImpl extends EFactoryImpl implements GenModelFactory {
  /**
   * Creates an instance of the factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenModelFactoryImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EObject create(EClass eClass) {
    switch (eClass.getClassifierID()) {
      case GenModelPackage.GEN_GEF_MODEL: return createGenGEFModel();
      case GenModelPackage.GEN_EDITOR: return createGenEditor();
      case GenModelPackage.GEN_VIEWER: return createGenViewer();
      case GenModelPackage.GEN_EDIT_PART_FACTORY: return createGenEditPartFactory();
      case GenModelPackage.GEN_NODE_EDIT_PART: return createGenNodeEditPart();
      case GenModelPackage.GEN_SUB_NODE_REFERENCE: return createGenSubNodeReference();
      case GenModelPackage.GEN_LINK_EDIT_PART: return createGenLinkEditPart();
      case GenModelPackage.GEN_FIGURE: return createGenFigure();
      case GenModelPackage.GEN_PALETTE_COMPONENTS_FACTORY: return createGenPaletteComponentsFactory();
      case GenModelPackage.GEN_PALETTE_CONNECTIONS_FACTORY: return createGenPaletteConnectionsFactory();
      default:
        throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenGEFModel createGenGEFModel() {
    GenGEFModelImpl genGEFModel = new GenGEFModelImpl();
    return genGEFModel;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenEditor createGenEditor() {
    GenEditorImpl genEditor = new GenEditorImpl();
    return genEditor;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenViewer createGenViewer() {
    GenViewerImpl genViewer = new GenViewerImpl();
    return genViewer;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenEditPartFactory createGenEditPartFactory() {
    GenEditPartFactoryImpl genEditPartFactory = new GenEditPartFactoryImpl();
    return genEditPartFactory;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenNodeEditPart createGenNodeEditPart() {
    GenNodeEditPartImpl genNodeEditPart = new GenNodeEditPartImpl();
    return genNodeEditPart;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenSubNodeReference createGenSubNodeReference() {
    GenSubNodeReferenceImpl genSubNodeReference = new GenSubNodeReferenceImpl();
    return genSubNodeReference;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenLinkEditPart createGenLinkEditPart() {
    GenLinkEditPartImpl genLinkEditPart = new GenLinkEditPartImpl();
    return genLinkEditPart;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenPaletteComponentsFactory createGenPaletteComponentsFactory() {
    GenPaletteComponentsFactoryImpl genPaletteComponentsFactory = new GenPaletteComponentsFactoryImpl();
    return genPaletteComponentsFactory;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenPaletteConnectionsFactory createGenPaletteConnectionsFactory() {
    GenPaletteConnectionsFactoryImpl genPaletteConnectionsFactory = new GenPaletteConnectionsFactoryImpl();
    return genPaletteConnectionsFactory;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenFigure createGenFigure() {
    GenFigureImpl genFigure = new GenFigureImpl();
    return genFigure;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenModelPackage getGenModelPackage() {
    return (GenModelPackage)getEPackage();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @deprecated
   * @generated
   */
  public static GenModelPackage getPackage() {
    return GenModelPackage.eINSTANCE;
  }

} //GenModelFactoryImpl
