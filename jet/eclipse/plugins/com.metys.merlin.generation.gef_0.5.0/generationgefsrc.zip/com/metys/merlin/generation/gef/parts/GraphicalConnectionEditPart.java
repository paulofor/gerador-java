/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.parts;

import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.PolylineConnection;
import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.Notifier;
import org.eclipse.emf.common.notify.impl.AdapterImpl;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.editparts.AbstractConnectionEditPart;

/**
 * @author jcheuoua
 * @version $Revision: 1.1 $
 */
public abstract class GraphicalConnectionEditPart extends AbstractConnectionEditPart {
  protected AdapterFactory adapterFactory;
  protected boolean notificationsEnabled = true;
  
  protected Adapter modelListener = new AdapterImpl() {
    public void notifyChanged(Notification msg) {
      if (!notificationsEnabled)
        return;
      try {
        notificationsEnabled = false;
        handlePropertyChanged(msg);
      } finally {
        notificationsEnabled = true;
      }
    }
  };
  private EditPart sourceEditPart;
  private EditPart targetEditPart;

  /**
   * Constructor for GraphicalConnectionEditPart.
   * @param adapterFactory AdapterFactory
   */
  public GraphicalConnectionEditPart(AdapterFactory adapterFactory) {
    this.adapterFactory = adapterFactory;
  }
  
  /**
   * Activates the Figure representing this, by setting up
   * the start and end connections, and adding the figure
   * to the Connection Layer.
   * 
   * @see #deactivate()
   */
  protected void activateFigure() {
    if (getParent() instanceof ENodeEditPart) {
      ((ENodeEditPart) getParent()).getConnectionLayer().add(getFigure());
    }
    else
      super.activateFigure();
  }  

  /**
   * Deactivates the Figure representing this, by removing
   * it from the connection layer, and resetting the 
   * source and target connections to <code>null</code>.
   */
  protected void deactivateFigure() {
    if (getParent() instanceof ENodeEditPart) {
      ((ENodeEditPart) getParent()).getConnectionLayer().remove(getFigure());
      getConnectionFigure().setSourceAnchor(null);
      getConnectionFigure().setTargetAnchor(null);    
    } else
      super.deactivateFigure();    
  }
  
  /**
   * Sets the source EditPart of this connection.
   *
   * @param editPart  EditPart which is the source.
   * @see org.eclipse.gef.ConnectionEditPart#setSource(EditPart)
   */
  public void setSource(EditPart editPart) {
    if (sourceEditPart == editPart)
      return;
    sourceEditPart = editPart;
    if (sourceEditPart != null)
      setParent(sourceEditPart.getParent());
    else if (getTarget() == null)
      setParent(null);
    if (sourceEditPart != null && targetEditPart != null)
      refresh();
  }

  /**
   * Sets the target EditPart of this connection.
   *
   * @param editPart  EditPart which is the target.
   * @see org.eclipse.gef.ConnectionEditPart#setTarget(EditPart)
   */
  public void setTarget(EditPart editPart) {
    if (targetEditPart == editPart)
      return;
    targetEditPart = editPart;
    if (editPart != null)
      setParent(editPart.getParent());
    else if (getSource() == null)
      setParent(null);
    if (sourceEditPart != null && targetEditPart != null)
      refresh();
  }
  
  /**
   * @see org.eclipse.gef.ConnectionEditPart#getSource()
   */
  public EditPart getSource() {
    return sourceEditPart;
  }

  /**
   * @see org.eclipse.gef.ConnectionEditPart#getTarget()
   */
  public EditPart getTarget() {
    return targetEditPart;
  }
  
  /**
   * @return Returns the modelListener.
   */
  public Adapter getModelListener() {
    return modelListener;
  }
  /**
   * @return Returns the adapterFactory.
   */
  public AdapterFactory getAdapterFactory() {
    return adapterFactory;
  }
  /**
   * @param adapterFactory The adapterFactory to set.
   */
  public void setAdapterFactory(AdapterFactory adapterFactory) {
    this.adapterFactory = adapterFactory;
  }
  /**
   * @param msg
   */
  protected abstract void handlePropertyChanged(Notification msg);

  /**
   * Method activate.
   * @see org.eclipse.gef.EditPart#activate()
   */
  public void activate() {
    super.activate();
    ((Notifier) getModel()).eAdapters().add(modelListener);
  }

  /**
   * Method deactivate.
   * @see org.eclipse.gef.EditPart#deactivate()
   */
  public void deactivate() {
    ((Notifier) getModel()).eAdapters().remove(modelListener);
    super.deactivate();
  }

  /**
   * Method createFigure.
   * @return IFigure
   */
  protected IFigure createFigure() {
    return new PolylineConnection() {
      protected boolean useLocalCoordinates() {
        return true;
      } 
    };
  }

  protected void createEditPolicies() {
    // TODO Auto-generated method stub
    
  }

  /**
   * @see org.eclipse.gef.EditPart#setSelected(int)
   */
  public void setSelected(int value) {
    super.setSelected(value);
    if (value != EditPart.SELECTED_NONE) {
      ((PolylineConnection) getFigure()).setLineWidth(2);      
    }
    else {
      ((PolylineConnection) getFigure()).setLineWidth(1);
    }
  }
}