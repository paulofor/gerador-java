package com.metys.merlin.generation.gef.compiledtemplates.policies;

import com.metys.merlin.generation.gef.genmodel.*;
import com.metys.merlin.generation.gef.genmodel.util.*;
import org.eclipse.emf.ecore.*;
import org.eclipse.emf.codegen.ecore.genmodel.*;

public class NodeDirectEditPolicy
{
  protected static String nl;
  public static synchronized NodeDirectEditPolicy create(String lineSeparator)
  {
    nl = lineSeparator;
    NodeDirectEditPolicy result = new NodeDirectEditPolicy();
    nl = null;
    return result;
  }

  protected final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = "/**" + NL + " * <copyright>" + NL + " * </copyright>" + NL + " *" + NL + " * ";
  protected final String TEXT_3 = "Id";
  protected final String TEXT_4 = NL + " */" + NL + "" + NL + "package ";
  protected final String TEXT_5 = ".policies;" + NL;
  protected final String TEXT_6 = NL + NL + "/**" + NL + " * <!-- begin-user-doc -->" + NL + " * <!-- end-user-doc -->" + NL + " * @generated" + NL + " */" + NL + "public ";
  protected final String TEXT_7 = "abstract ";
  protected final String TEXT_8 = "class ";
  protected final String TEXT_9 = "DirectEditPolicy";
  protected final String TEXT_10 = "{" + NL + "\t" + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected ";
  protected final String TEXT_11 = " getDirectEditCommand(";
  protected final String TEXT_12 = " request) {" + NL + "    String name = (String) request.getCellEditor().getValue();" + NL + "\t";
  protected final String TEXT_13 = " cmd = new RenameCommand((";
  protected final String TEXT_14 = ")getHost(), name);\t\t" + NL + "\treturn cmd;" + NL + "  }" + NL + "" + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected void showCurrentEditValue(DirectEditRequest request) {" + NL + "\t";
  protected final String TEXT_15 = " hostEditPart = (";
  protected final String TEXT_16 = ") getHost();" + NL + "   \thostEditPart.refreshVisuals();" + NL + "  }" + NL + "\t" + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected boolean isDirectEditLocation(";
  protected final String TEXT_17 = " requestLoc) {" + NL + "    Point locationCopy = requestLoc.getCopy();";
  protected final String TEXT_18 = NL + "    ";
  protected final String TEXT_19 = " hostEditPart = (";
  protected final String TEXT_20 = ") getHost();";
  protected final String TEXT_21 = NL + "    ";
  protected final String TEXT_22 = " header = ((";
  protected final String TEXT_23 = ") hostEditPart.getFigure()).getHeader();" + NL + "    header.translateToRelative(locationCopy);" + NL + "    if (header.containsPoint(locationCopy))" + NL + "      return true;" + NL + "    return false;" + NL + "  }" + NL + "" + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected void performDirectEdit() {" + NL + "  \t";
  protected final String TEXT_24 = " hostEditPart = (";
  protected final String TEXT_25 = ") getHost();" + NL + "\t";
  protected final String TEXT_26 = " header = ((ENodeFigure) hostEditPart.getFigure()).getHeader();" + NL + "    if (manager == null)" + NL + "      manager = new ";
  protected final String TEXT_27 = "(hostEditPart, ";
  protected final String TEXT_28 = ".class, new ";
  protected final String TEXT_29 = "(header), header);    " + NL + "    manager.show();" + NL + "  }" + NL + "\t" + NL + "  /**" + NL + "   * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "\tpublic void handleNodeNameChanged(";
  protected final String TEXT_30 = " node, String newName, String oldName) {";
  protected final String TEXT_31 = NL + "    ";
  protected final String TEXT_32 = " object = (";
  protected final String TEXT_33 = ") node.getEObject();";
  protected final String TEXT_34 = NL + "    ";
  protected final String TEXT_35 = " labelFeature = ";
  protected final String TEXT_36 = NL + "      ";
  protected final String TEXT_37 = "(); " + NL + "    object.eSet(labelFeature, newName);";
  protected final String TEXT_38 = NL + "\t\t// TODO : Implements this method to react to node name change" + NL + "\t\t// Ensure that you remove @generated or mark it @generated NOT";
  protected final String TEXT_39 = "\t\t" + NL + "  }" + NL + "}";

  public String generate(Object argument)
  {
    StringBuffer stringBuffer = new StringBuffer();
    
/**
 * Copyright (c) 2005 Joel Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

    GenNodeEditPart genEditPart = (GenNodeEditPart) argument; EClass ecoreClass = genEditPart.getEcoreClass(); EPackage ecorePackage = (EPackage) ecoreClass.getEPackage(); GenModel genModel = genEditPart.getGenGEFModel().getGenModel(); GenClass genClass = GenModelHelper.getGenClass(genModel, ecoreClass);
    stringBuffer.append(TEXT_1);
    stringBuffer.append(TEXT_2);
    stringBuffer.append("$");
    stringBuffer.append(TEXT_3);
    stringBuffer.append("$");
    stringBuffer.append(TEXT_4);
    stringBuffer.append(genEditPart.getPackageName());
    stringBuffer.append(TEXT_5);
    genModel.markImportLocation(stringBuffer);
    stringBuffer.append(TEXT_6);
    if (ecoreClass.isAbstract()) {
    stringBuffer.append(TEXT_7);
    }
    stringBuffer.append(TEXT_8);
    stringBuffer.append(ecoreClass.getName());
    stringBuffer.append(TEXT_9);
    stringBuffer.append(GenModelHelper.getDirectEditPolicyExtendsLitteral(genModel, genEditPart));
    stringBuffer.append(TEXT_10);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.commands.Command"));
    stringBuffer.append(TEXT_11);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.requests.DirectEditRequest"));
    stringBuffer.append(TEXT_12);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.commands.RenameCommand"));
    stringBuffer.append(TEXT_13);
    stringBuffer.append(GenModelHelper.getImportedQualifiedEditPartClass(genModel, genEditPart));
    stringBuffer.append(TEXT_14);
    stringBuffer.append(GenModelHelper.getImportedQualifiedEditPartClass(genModel, genEditPart));
    stringBuffer.append(TEXT_15);
    stringBuffer.append(GenModelHelper.getImportedQualifiedEditPartClass(genModel, genEditPart));
    stringBuffer.append(TEXT_16);
    stringBuffer.append(genModel.getImportedName("org.eclipse.draw2d.geometry.Point"));
    stringBuffer.append(TEXT_17);
    stringBuffer.append(TEXT_18);
    stringBuffer.append(GenModelHelper.getImportedQualifiedEditPartClass(genModel, genEditPart));
    stringBuffer.append(TEXT_19);
    stringBuffer.append(GenModelHelper.getImportedQualifiedEditPartClass(genModel, genEditPart));
    stringBuffer.append(TEXT_20);
    stringBuffer.append(TEXT_21);
    stringBuffer.append(genModel.getImportedName("org.eclipse.draw2d.IFigure"));
    stringBuffer.append(TEXT_22);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.figures.ENodeFigure"));
    stringBuffer.append(TEXT_23);
    stringBuffer.append(GenModelHelper.getImportedQualifiedEditPartClass(genModel, genEditPart));
    stringBuffer.append(TEXT_24);
    stringBuffer.append(GenModelHelper.getImportedQualifiedEditPartClass(genModel, genEditPart));
    stringBuffer.append(TEXT_25);
    stringBuffer.append(genModel.getImportedName("org.eclipse.draw2d.Label"));
    stringBuffer.append(TEXT_26);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.figures.EObjectDirectEditManager"));
    stringBuffer.append(TEXT_27);
    stringBuffer.append(genModel.getImportedName("org.eclipse.jface.viewers.TextCellEditor"));
    stringBuffer.append(TEXT_28);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.figures.EObjectCellEditorLocator"));
    stringBuffer.append(TEXT_29);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.model.ENode"));
    stringBuffer.append(TEXT_30);
     if (genClass.getLabelFeature() != null) {
    stringBuffer.append(TEXT_31);
    stringBuffer.append(genClass.getImportedClassName());
    stringBuffer.append(TEXT_32);
    stringBuffer.append(genClass.getImportedClassName());
    stringBuffer.append(TEXT_33);
    stringBuffer.append(TEXT_34);
    stringBuffer.append(genModel.getImportedName("org.eclipse.emf.ecore.EStructuralFeature"));
    stringBuffer.append(TEXT_35);
    stringBuffer.append(TEXT_36);
    stringBuffer.append(genClass.getLabelFeature().getQualifiedFeatureAccessorName());
    stringBuffer.append(TEXT_37);
    } else {
    stringBuffer.append(TEXT_38);
    }
    stringBuffer.append(TEXT_39);
    genModel.emitSortedImports();
    return stringBuffer.toString();
  }
}
