/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package com.metys.merlin.generation.gef.genmodel;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Gen Edit Part Factory</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenEditPartFactory#getGenEditParts <em>Gen Edit Parts</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenEditPartFactory#getGenGEFModel <em>Gen GEF Model</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenEditPartFactory()
 * @model
 * @generated
 */
public interface GenEditPartFactory extends GenGEFBase{
  /**
   * Returns the value of the '<em><b>Gen Edit Parts</b></em>' reference list.
   * The list contents are of type {@link com.metys.merlin.generation.gef.genmodel.GenEditPart}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Gen Edit Parts</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Gen Edit Parts</em>' reference list.
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenEditPartFactory_GenEditParts()
   * @model type="com.metys.merlin.generation.gef.genmodel.GenEditPart"
   * @generated
   */
  EList getGenEditParts();

  /**
   * Returns the value of the '<em><b>Gen GEF Model</b></em>' container reference.
   * It is bidirectional and its opposite is '{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getGenEditPartFactories <em>Gen Edit Part Factories</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Gen GEF Model</em>' container reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Gen GEF Model</em>' container reference.
   * @see #setGenGEFModel(GenGEFModel)
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenEditPartFactory_GenGEFModel()
   * @see com.metys.merlin.generation.gef.genmodel.GenGEFModel#getGenEditPartFactories
   * @model opposite="genEditPartFactories" required="true"
   * @generated
   */
  GenGEFModel getGenGEFModel();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.genmodel.GenEditPartFactory#getGenGEFModel <em>Gen GEF Model</em>}' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Gen GEF Model</em>' container reference.
   * @see #getGenGEFModel()
   * @generated
   */
  void setGenGEFModel(GenGEFModel value);

} // GenEditPartFactory
