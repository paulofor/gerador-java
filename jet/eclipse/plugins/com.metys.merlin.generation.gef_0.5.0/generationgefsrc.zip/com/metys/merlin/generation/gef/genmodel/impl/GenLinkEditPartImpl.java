/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.genmodel.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;

import com.metys.merlin.generation.gef.genmodel.GenFigure;
import com.metys.merlin.generation.gef.genmodel.GenGEFModel;
import com.metys.merlin.generation.gef.genmodel.GenLinkEditPart;
import com.metys.merlin.generation.gef.genmodel.GenModelPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Gen Link Edit Part</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenLinkEditPartImpl#getSourceReference <em>Source Reference</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenLinkEditPartImpl#getTargetReference <em>Target Reference</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenLinkEditPartImpl#getGenFigure <em>Gen Figure</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class GenLinkEditPartImpl extends GenEditPartImpl implements GenLinkEditPart {
  /**
   * The cached value of the '{@link #getSourceReference() <em>Source Reference</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getSourceReference()
   * @generated
   * @ordered
   */
  protected EReference sourceReference = null;

  /**
   * The cached value of the '{@link #getTargetReference() <em>Target Reference</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTargetReference()
   * @generated
   * @ordered
   */
  protected EReference targetReference = null;

  /**
   * The cached value of the '{@link #getGenFigure() <em>Gen Figure</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getGenFigure()
   * @generated
   * @ordered
   */
  protected GenFigure genFigure = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected GenLinkEditPartImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return GenModelPackage.eINSTANCE.getGenLinkEditPart();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getSourceReference() {
    if (sourceReference != null && sourceReference.eIsProxy()) {
      EReference oldSourceReference = sourceReference;
      sourceReference = (EReference)eResolveProxy((InternalEObject)sourceReference);
      if (sourceReference != oldSourceReference) {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, GenModelPackage.GEN_LINK_EDIT_PART__SOURCE_REFERENCE, oldSourceReference, sourceReference));
      }
    }
    return sourceReference;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference basicGetSourceReference() {
    return sourceReference;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setSourceReference(EReference newSourceReference) {
    EReference oldSourceReference = sourceReference;
    sourceReference = newSourceReference;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_LINK_EDIT_PART__SOURCE_REFERENCE, oldSourceReference, sourceReference));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTargetReference() {
    if (targetReference != null && targetReference.eIsProxy()) {
      EReference oldTargetReference = targetReference;
      targetReference = (EReference)eResolveProxy((InternalEObject)targetReference);
      if (targetReference != oldTargetReference) {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, GenModelPackage.GEN_LINK_EDIT_PART__TARGET_REFERENCE, oldTargetReference, targetReference));
      }
    }
    return targetReference;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference basicGetTargetReference() {
    return targetReference;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTargetReference(EReference newTargetReference) {
    EReference oldTargetReference = targetReference;
    targetReference = newTargetReference;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_LINK_EDIT_PART__TARGET_REFERENCE, oldTargetReference, targetReference));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenFigure getGenFigure() {
    return genFigure;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetGenFigure(GenFigure newGenFigure, NotificationChain msgs) {
    GenFigure oldGenFigure = genFigure;
    genFigure = newGenFigure;
    if (eNotificationRequired()) {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_LINK_EDIT_PART__GEN_FIGURE, oldGenFigure, newGenFigure);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setGenFigure(GenFigure newGenFigure) {
    if (newGenFigure != genFigure) {
      NotificationChain msgs = null;
      if (genFigure != null)
        msgs = ((InternalEObject)genFigure).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - GenModelPackage.GEN_LINK_EDIT_PART__GEN_FIGURE, null, msgs);
      if (newGenFigure != null)
        msgs = ((InternalEObject)newGenFigure).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - GenModelPackage.GEN_LINK_EDIT_PART__GEN_FIGURE, null, msgs);
      msgs = basicSetGenFigure(newGenFigure, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_LINK_EDIT_PART__GEN_FIGURE, newGenFigure, newGenFigure));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case GenModelPackage.GEN_LINK_EDIT_PART__GEN_GEF_MODEL:
          if (eContainer != null)
            msgs = eBasicRemoveFromContainer(msgs);
          return eBasicSetContainer(otherEnd, GenModelPackage.GEN_LINK_EDIT_PART__GEN_GEF_MODEL, msgs);
        default:
          return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case GenModelPackage.GEN_LINK_EDIT_PART__GEN_GEF_MODEL:
          return eBasicSetContainer(null, GenModelPackage.GEN_LINK_EDIT_PART__GEN_GEF_MODEL, msgs);
        case GenModelPackage.GEN_LINK_EDIT_PART__GEN_FIGURE:
          return basicSetGenFigure(null, msgs);
        default:
          return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
    if (eContainerFeatureID >= 0) {
      switch (eContainerFeatureID) {
        case GenModelPackage.GEN_LINK_EDIT_PART__GEN_GEF_MODEL:
          return eContainer.eInverseRemove(this, GenModelPackage.GEN_GEF_MODEL__GEN_EDIT_PARTS, GenGEFModel.class, msgs);
        default:
          return eDynamicBasicRemoveFromContainer(msgs);
      }
    }
    return eContainer.eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_LINK_EDIT_PART__NAME:
        return getName();
      case GenModelPackage.GEN_LINK_EDIT_PART__PACKAGE_NAME:
        return getPackageName();
      case GenModelPackage.GEN_LINK_EDIT_PART__ECORE_CLASS:
        if (resolve) return getEcoreClass();
        return basicGetEcoreClass();
      case GenModelPackage.GEN_LINK_EDIT_PART__GEN_GEF_MODEL:
        return getGenGEFModel();
      case GenModelPackage.GEN_LINK_EDIT_PART__SOURCE_REFERENCE:
        if (resolve) return getSourceReference();
        return basicGetSourceReference();
      case GenModelPackage.GEN_LINK_EDIT_PART__TARGET_REFERENCE:
        if (resolve) return getTargetReference();
        return basicGetTargetReference();
      case GenModelPackage.GEN_LINK_EDIT_PART__GEN_FIGURE:
        return getGenFigure();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_LINK_EDIT_PART__NAME:
        setName((String)newValue);
        return;
      case GenModelPackage.GEN_LINK_EDIT_PART__PACKAGE_NAME:
        setPackageName((String)newValue);
        return;
      case GenModelPackage.GEN_LINK_EDIT_PART__ECORE_CLASS:
        setEcoreClass((EClass)newValue);
        return;
      case GenModelPackage.GEN_LINK_EDIT_PART__GEN_GEF_MODEL:
        setGenGEFModel((GenGEFModel)newValue);
        return;
      case GenModelPackage.GEN_LINK_EDIT_PART__SOURCE_REFERENCE:
        setSourceReference((EReference)newValue);
        return;
      case GenModelPackage.GEN_LINK_EDIT_PART__TARGET_REFERENCE:
        setTargetReference((EReference)newValue);
        return;
      case GenModelPackage.GEN_LINK_EDIT_PART__GEN_FIGURE:
        setGenFigure((GenFigure)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_LINK_EDIT_PART__NAME:
        setName(NAME_EDEFAULT);
        return;
      case GenModelPackage.GEN_LINK_EDIT_PART__PACKAGE_NAME:
        setPackageName(PACKAGE_NAME_EDEFAULT);
        return;
      case GenModelPackage.GEN_LINK_EDIT_PART__ECORE_CLASS:
        setEcoreClass((EClass)null);
        return;
      case GenModelPackage.GEN_LINK_EDIT_PART__GEN_GEF_MODEL:
        setGenGEFModel((GenGEFModel)null);
        return;
      case GenModelPackage.GEN_LINK_EDIT_PART__SOURCE_REFERENCE:
        setSourceReference((EReference)null);
        return;
      case GenModelPackage.GEN_LINK_EDIT_PART__TARGET_REFERENCE:
        setTargetReference((EReference)null);
        return;
      case GenModelPackage.GEN_LINK_EDIT_PART__GEN_FIGURE:
        setGenFigure((GenFigure)null);
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_LINK_EDIT_PART__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case GenModelPackage.GEN_LINK_EDIT_PART__PACKAGE_NAME:
        return PACKAGE_NAME_EDEFAULT == null ? packageName != null : !PACKAGE_NAME_EDEFAULT.equals(packageName);
      case GenModelPackage.GEN_LINK_EDIT_PART__ECORE_CLASS:
        return ecoreClass != null;
      case GenModelPackage.GEN_LINK_EDIT_PART__GEN_GEF_MODEL:
        return getGenGEFModel() != null;
      case GenModelPackage.GEN_LINK_EDIT_PART__SOURCE_REFERENCE:
        return sourceReference != null;
      case GenModelPackage.GEN_LINK_EDIT_PART__TARGET_REFERENCE:
        return targetReference != null;
      case GenModelPackage.GEN_LINK_EDIT_PART__GEN_FIGURE:
        return genFigure != null;
    }
    return eDynamicIsSet(eFeature);
  }

} //GenLinkEditPartImpl
