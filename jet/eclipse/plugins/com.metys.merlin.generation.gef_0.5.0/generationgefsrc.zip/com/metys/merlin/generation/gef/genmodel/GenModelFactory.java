/**
 * <copyright>
 * </copyright>
 *
 * $Id: GenModelFactory.java,v 1.5 2005/07/08 23:51:28 jcheuoua Exp $
 */
package com.metys.merlin.generation.gef.genmodel;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage
 * @generated
 */
public interface GenModelFactory extends EFactory{
  /**
   * The singleton instance of the factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  GenModelFactory eINSTANCE = new com.metys.merlin.generation.gef.genmodel.impl.GenModelFactoryImpl();

  /**
   * Returns a new object of class '<em>Gen GEF Model</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Gen GEF Model</em>'.
   * @generated
   */
  GenGEFModel createGenGEFModel();

  /**
   * Returns a new object of class '<em>Gen Editor</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Gen Editor</em>'.
   * @generated
   */
  GenEditor createGenEditor();

  /**
   * Returns a new object of class '<em>Gen Viewer</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Gen Viewer</em>'.
   * @generated
   */
  GenViewer createGenViewer();

  /**
   * Returns a new object of class '<em>Gen Edit Part Factory</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Gen Edit Part Factory</em>'.
   * @generated
   */
  GenEditPartFactory createGenEditPartFactory();

  /**
   * Returns a new object of class '<em>Gen Node Edit Part</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Gen Node Edit Part</em>'.
   * @generated
   */
  GenNodeEditPart createGenNodeEditPart();

  /**
   * Returns a new object of class '<em>Gen Sub Node Reference</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Gen Sub Node Reference</em>'.
   * @generated
   */
  GenSubNodeReference createGenSubNodeReference();

  /**
   * Returns a new object of class '<em>Gen Link Edit Part</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Gen Link Edit Part</em>'.
   * @generated
   */
  GenLinkEditPart createGenLinkEditPart();

  /**
   * Returns a new object of class '<em>Gen Palette Components Factory</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Gen Palette Components Factory</em>'.
   * @generated
   */
  GenPaletteComponentsFactory createGenPaletteComponentsFactory();

  /**
   * Returns a new object of class '<em>Gen Palette Connections Factory</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Gen Palette Connections Factory</em>'.
   * @generated
   */
  GenPaletteConnectionsFactory createGenPaletteConnectionsFactory();

  /**
   * Returns a new object of class '<em>Gen Figure</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return a new object of class '<em>Gen Figure</em>'.
   * @generated
   */
  GenFigure createGenFigure();

  /**
   * Returns the package supported by this factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the package supported by this factory.
   * @generated
   */
  GenModelPackage getGenModelPackage();

} //GenModelFactory
