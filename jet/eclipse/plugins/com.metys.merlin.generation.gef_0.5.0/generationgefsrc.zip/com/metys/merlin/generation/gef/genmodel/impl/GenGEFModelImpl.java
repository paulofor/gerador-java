/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.genmodel.impl;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Collection;
import java.util.Iterator;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.SubProgressMonitor;
import org.eclipse.emf.codegen.ecore.genmodel.GenModel;
import org.eclipse.emf.codegen.ecore.genmodel.impl.GenBaseImpl;
import org.eclipse.emf.codegen.util.ImportManager;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EModelElement;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentWithInverseEList;
import org.eclipse.emf.ecore.util.InternalEList;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceImpl;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.osgi.framework.Bundle;

import com.metys.merlin.generation.gef.GefPlugin;
import com.metys.merlin.generation.gef.genmodel.GenEditPart;
import com.metys.merlin.generation.gef.genmodel.GenEditPartFactory;
import com.metys.merlin.generation.gef.genmodel.GenEditor;
import com.metys.merlin.generation.gef.genmodel.GenGEFModel;
import com.metys.merlin.generation.gef.genmodel.GenLinkEditPart;
import com.metys.merlin.generation.gef.genmodel.GenModelPackage;
import com.metys.merlin.generation.gef.genmodel.GenNodeEditPart;
import com.metys.merlin.generation.gef.genmodel.GenPaletteComponentsFactory;
import com.metys.merlin.generation.gef.genmodel.GenPaletteConnectionsFactory;
import com.metys.merlin.generation.gef.genmodel.GenViewer;
import com.metys.merlin.generation.mappingmodel.MappingModelPackage;
import com.metys.merlin.generation.mappingmodel.mapping.MappingFactory;
import com.metys.merlin.generation.mappingmodel.mapping.Transformer;
import com.metys.merlin.generation.mappingmodel.mapping.TypeMappingRoot;
import com.metys.merlin.generation.mappingmodel.util.MappingModelUtil;
import com.metys.merlin.generation.templates.JETTemplate;
import com.metys.merlin.generation.templates.JETTemplateContainer;
import com.metys.merlin.generation.templates.JETTemplateFactory;
import com.metys.merlin.generation.templates.JETTemplatesPlugin;
import com.metys.merlin.generation.templates.jetmapping.JETMappingFactory;
import com.metys.merlin.generation.templates.jetmapping.JETTemplateMappingRoot;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Gen GEF Model</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenGEFModelImpl#getOutputDirectoryPath <em>Output Directory Path</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenGEFModelImpl#getCopyrightText <em>Copyright Text</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenGEFModelImpl#getPluginID <em>Plugin ID</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenGEFModelImpl#getPluginClass <em>Plugin Class</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenGEFModelImpl#getGenModel <em>Gen Model</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenGEFModelImpl#getGenEditPartFactories <em>Gen Edit Part Factories</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenGEFModelImpl#getGenEditors <em>Gen Editors</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenGEFModelImpl#getGenViewers <em>Gen Viewers</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenGEFModelImpl#getGenEditParts <em>Gen Edit Parts</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenGEFModelImpl#getTemplateDirectory <em>Template Directory</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class GenGEFModelImpl extends GenGEFBaseImpl implements GenGEFModel {
  /**
   * The default value of the '{@link #getOutputDirectoryPath() <em>Output Directory Path</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOutputDirectoryPath()
   * @generated
   * @ordered
   */
  protected static final String OUTPUT_DIRECTORY_PATH_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getOutputDirectoryPath() <em>Output Directory Path</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOutputDirectoryPath()
   * @generated
   * @ordered
   */
  protected String outputDirectoryPath = OUTPUT_DIRECTORY_PATH_EDEFAULT;

  /**
   * The default value of the '{@link #getCopyrightText() <em>Copyright Text</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCopyrightText()
   * @generated
   * @ordered
   */
  protected static final String COPYRIGHT_TEXT_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getCopyrightText() <em>Copyright Text</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getCopyrightText()
   * @generated
   * @ordered
   */
  protected String copyrightText = COPYRIGHT_TEXT_EDEFAULT;

  /**
   * The default value of the '{@link #getPluginID() <em>Plugin ID</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPluginID()
   * @generated
   * @ordered
   */
  protected static final String PLUGIN_ID_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getPluginID() <em>Plugin ID</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPluginID()
   * @generated
   * @ordered
   */
  protected String pluginID = PLUGIN_ID_EDEFAULT;

  /**
   * The default value of the '{@link #getPluginClass() <em>Plugin Class</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPluginClass()
   * @generated
   * @ordered
   */
  protected static final String PLUGIN_CLASS_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getPluginClass() <em>Plugin Class</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPluginClass()
   * @generated
   * @ordered
   */
  protected String pluginClass = PLUGIN_CLASS_EDEFAULT;

  /**
   * The cached value of the '{@link #getGenModel() <em>Gen Model</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getGenModel()
   * @generated
   * @ordered
   */
  protected GenModel genModel = null;

  /**
   * The cached value of the '{@link #getGenEditPartFactories() <em>Gen Edit Part Factories</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getGenEditPartFactories()
   * @generated
   * @ordered
   */
  protected EList genEditPartFactories = null;

  /**
   * The cached value of the '{@link #getGenEditors() <em>Gen Editors</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getGenEditors()
   * @generated
   * @ordered
   */
  protected EList genEditors = null;

  /**
   * The cached value of the '{@link #getGenViewers() <em>Gen Viewers</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getGenViewers()
   * @generated
   * @ordered
   */
  protected EList genViewers = null;

  /**
   * The cached value of the '{@link #getGenEditParts() <em>Gen Edit Parts</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getGenEditParts()
   * @generated
   * @ordered
   */
  protected EList genEditParts = null;

  /**
   * The default value of the '{@link #getTemplateDirectory() <em>Template Directory</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTemplateDirectory()
   * @generated
   * @ordered
   */
  protected static final String TEMPLATE_DIRECTORY_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getTemplateDirectory() <em>Template Directory</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTemplateDirectory()
   * @generated
   * @ordered
   */
  protected String templateDirectory = TEMPLATE_DIRECTORY_EDEFAULT;

  private JETTemplateMappingRoot instanceMappingRoot;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected GenGEFModelImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return GenModelPackage.eINSTANCE.getGenGEFModel();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case GenModelPackage.GEN_GEF_MODEL__GEN_EDIT_PART_FACTORIES:
          return ((InternalEList)getGenEditPartFactories()).basicAdd(otherEnd, msgs);
        case GenModelPackage.GEN_GEF_MODEL__GEN_EDITORS:
          return ((InternalEList)getGenEditors()).basicAdd(otherEnd, msgs);
        case GenModelPackage.GEN_GEF_MODEL__GEN_VIEWERS:
          return ((InternalEList)getGenViewers()).basicAdd(otherEnd, msgs);
        case GenModelPackage.GEN_GEF_MODEL__GEN_EDIT_PARTS:
          return ((InternalEList)getGenEditParts()).basicAdd(otherEnd, msgs);
        default:
          return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getGenEditors() {
    if (genEditors == null) {
      genEditors = new EObjectContainmentWithInverseEList(GenEditor.class, this, GenModelPackage.GEN_GEF_MODEL__GEN_EDITORS, GenModelPackage.GEN_EDITOR__GEN_GEF_MODEL);
    }
    return genEditors;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getGenEditParts() {
    if (genEditParts == null) {
      genEditParts = new EObjectContainmentWithInverseEList(GenEditPart.class, this, GenModelPackage.GEN_GEF_MODEL__GEN_EDIT_PARTS, GenModelPackage.GEN_EDIT_PART__GEN_GEF_MODEL);
    }
    return genEditParts;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getTemplateDirectory() {
    return templateDirectory;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTemplateDirectory(String newTemplateDirectory) {
    String oldTemplateDirectory = templateDirectory;
    templateDirectory = newTemplateDirectory;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_GEF_MODEL__TEMPLATE_DIRECTORY, oldTemplateDirectory, templateDirectory));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getGenViewers() {
    if (genViewers == null) {
      genViewers = new EObjectContainmentWithInverseEList(GenViewer.class, this, GenModelPackage.GEN_GEF_MODEL__GEN_VIEWERS, GenModelPackage.GEN_VIEWER__GEN_GEF_MODEL);
    }
    return genViewers;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getGenEditPartFactories() {
    if (genEditPartFactories == null) {
      genEditPartFactories = new EObjectContainmentWithInverseEList(GenEditPartFactory.class, this, GenModelPackage.GEN_GEF_MODEL__GEN_EDIT_PART_FACTORIES, GenModelPackage.GEN_EDIT_PART_FACTORY__GEN_GEF_MODEL);
    }
    return genEditPartFactories;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public void registerPartInAllEditors(GenEditPart editPart) {
    for (Iterator iter = getGenEditors().iterator(); iter.hasNext();) {
      GenEditor genEditor = (GenEditor) iter.next();
      if (editPart instanceof GenNodeEditPart && !genEditor.getGenPaletteComponentsFactories().isEmpty())
        ((GenPaletteComponentsFactory)genEditor.getGenPaletteComponentsFactories().get(0)).getGenNodeParts().add(editPart);
      else if (editPart instanceof GenLinkEditPart && !genEditor.getGenPaletteConnectionsFactories().isEmpty())
        ((GenPaletteConnectionsFactory)genEditor.getGenPaletteConnectionsFactories().get(0)).getGenLinkParts().add(editPart);
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public void registerAllPartsInEditor(GenEditor editor) {
    for (Iterator iter = getGenEditParts().iterator(); iter.hasNext();) {
      GenEditPart editPart = (GenEditPart) iter.next();
      if (editPart instanceof GenNodeEditPart && !editor.getGenPaletteComponentsFactories().isEmpty())
        ((GenPaletteComponentsFactory)editor.getGenPaletteComponentsFactories().get(0)).getGenNodeParts().add(editPart);
      else if (editPart instanceof GenLinkEditPart && !editor.getGenPaletteConnectionsFactories().isEmpty())
        ((GenPaletteConnectionsFactory)editor.getGenPaletteConnectionsFactories().get(0)).getGenLinkParts().add(editPart);
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public JETTemplateMappingRoot getTemplatesInstanceMapping(IProgressMonitor progressMonitor) {
    progressMonitor.beginTask("Fetching JET Instances Mappings", 2);
    ResourceSet resourceSet = new ResourceSetImpl();
    Bundle bundle = GefPlugin.getPlugin().getBundle();
    
    // Ensure the MappingModel Package is loaded
    MappingModelPackage.eINSTANCE.getNsURI();
    // Create JET mappings
    URL mappingResourceURL = bundle.getEntry("/resources/gefgenmodel2jettemplate.mapping");
    URI mappingResourceURI = URI.createURI(mappingResourceURL.toString());
    Resource emfMappingFileResource = resourceSet.getResource(mappingResourceURI, true);
    
    progressMonitor.worked(1);
    
    TypeMappingRoot defaultTypeMappingRoot = (TypeMappingRoot) emfMappingFileResource.getContents().get(0);
    instanceMappingRoot = JETMappingFactory.eINSTANCE.createJETTemplateMappingRoot();
    instanceMappingRoot.setTypeMapping(defaultTypeMappingRoot);
    
    Transformer transformer = MappingFactory.eINSTANCE.createTransformer();
    transformer.setMappingRoot(instanceMappingRoot);
    Resource res = eResource();
    boolean fake = false;
    if (res == null) {
      fake = true;
      res = new XMIResourceImpl();
      res.getContents().add(this);
    }
    transformer.transform(res, null, new SubProgressMonitor(progressMonitor, 1));
    if (fake) {
      res.getContents().remove(this);
    }
    Collection results = MappingModelUtil.allOutputs(instanceMappingRoot);
    instanceMappingRoot = (JETTemplateMappingRoot) transformer.getMappingRoot();
    
    if (results.isEmpty()) {
      Error error = new Error("Error generating JET mapping outputs");
      GefPlugin.getPlugin().logInError(error, "Failed to create JET Template mappings for " + getName());
      throw error;
    }
    
    // Set custom directory for redefined templates
    if (getTemplateDirectory() != null && getTemplateDirectory().trim().length() > 0) {      
      IPath containerPath = null;
      IPath templateSourcePath = new Path(getTemplateDirectory());
      String projectString = templateSourcePath.segment(0);
      IPath folderPath = templateSourcePath.removeFirstSegments(1);
      Bundle templateBundle = Platform.getBundle(projectString);
      IProject project = ResourcesPlugin.getWorkspace().getRoot().getProject(projectString);
      IJavaProject javaProject = JavaCore.create(project);
      if (javaProject.exists())
        containerPath = project.getFullPath().append(folderPath);
      else if (templateBundle != null) {
        try {
          URL nativeURL = Platform.resolve(templateBundle.getEntry("/"));
          String rootDir = nativeURL.getFile();
          containerPath = new Path(rootDir).append(folderPath);
        } catch (IOException e) {
          JETTemplatesPlugin.getPlugin().logInError(e, "Cannot resolve bundle entry " + templateBundle.getSymbolicName());          
        }              
      }
      if (containerPath != null) {
        JETTemplateContainer customTemplateContainer = JETTemplateFactory.eINSTANCE.createJETTemplateContainer();
        customTemplateContainer.setJavaJETSource(getTemplateDirectory());
        for (Iterator iter = results.iterator(); iter.hasNext();) {
          EObject element = (EObject) iter.next();
          if (element instanceof JETTemplate) {
            JETTemplate jetTemplate = (JETTemplate) element;
            IPath templateFilePath = Path.fromPortableString(jetTemplate.getTemplateFilePath());
            if (templateFilePath.getDevice() != null)
              continue;
            
            IPath resourcePath = containerPath.append(templateFilePath);
            
            IResource resource = null;
            String location = null;
            if (resourcePath.getDevice() != null) {
              location = resourcePath.toString();
            } else {
              resource = ResourcesPlugin.getWorkspace().getRoot().findMember(resourcePath);
              if (resource != null && resource.exists())
                location = resource.getLocation().toString();
            }
            if (location != null) {
              File file = new File(location);
              if (file.exists()) {
                customTemplateContainer.getJetTemplates().add(jetTemplate);              
              }
            }
          }
        }
      }      
    }
    progressMonitor.done();
    return instanceMappingRoot;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getOutputDirectoryPath() {
    return outputDirectoryPath;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setOutputDirectoryPath(String newOutputDirectoryPath) {
    String oldOutputDirectoryPath = outputDirectoryPath;
    outputDirectoryPath = newOutputDirectoryPath;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_GEF_MODEL__OUTPUT_DIRECTORY_PATH, oldOutputDirectoryPath, outputDirectoryPath));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getCopyrightText() {
    return copyrightText;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setCopyrightText(String newCopyrightText) {
    String oldCopyrightText = copyrightText;
    copyrightText = newCopyrightText;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_GEF_MODEL__COPYRIGHT_TEXT, oldCopyrightText, copyrightText));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getPluginID() {
    return pluginID;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPluginID(String newPluginID) {
    String oldPluginID = pluginID;
    pluginID = newPluginID;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_GEF_MODEL__PLUGIN_ID, oldPluginID, pluginID));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getPluginClass() {
    return pluginClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPluginClass(String newPluginClass) {
    String oldPluginClass = pluginClass;
    pluginClass = newPluginClass;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_GEF_MODEL__PLUGIN_CLASS, oldPluginClass, pluginClass));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public GenModel getGenModel() {
    if (genModel != null && genModel.eIsProxy()) {
      GenModel oldGenModel = genModel;
      genModel = (GenModel)eResolveProxy((InternalEObject)genModel);
      if (genModel != oldGenModel) {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, GenModelPackage.GEN_GEF_MODEL__GEN_MODEL, oldGenModel, genModel));
      }
    }
    // TODO : this is a hack to initialize the import manager of the imported GenModel.
    if (genModel != null) {
      class MyGenBase extends GenBaseImpl {
        private GenModel returnGenModel;
        public void initializeImportManager(GenModel genModel) {
          returnGenModel = genModel;
          ImportManager importManager = new ImportManager("");
          setImportManager(importManager);
        }
        public GenModel getGenModel() {return returnGenModel;}
        public String getName() {return null;}
        public EModelElement getEcoreModelElement() {return null;}
        public boolean reconcile() {return false;}      
      }
      MyGenBase genBase = new MyGenBase();
      genBase.initializeImportManager(genModel);
    }
    return genModel;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenModel basicGetGenModel() {
    return genModel;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setGenModel(GenModel newGenModel) {
    GenModel oldGenModel = genModel;
    genModel = newGenModel;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_GEF_MODEL__GEN_MODEL, oldGenModel, genModel));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case GenModelPackage.GEN_GEF_MODEL__GEN_EDIT_PART_FACTORIES:
          return ((InternalEList)getGenEditPartFactories()).basicRemove(otherEnd, msgs);
        case GenModelPackage.GEN_GEF_MODEL__GEN_EDITORS:
          return ((InternalEList)getGenEditors()).basicRemove(otherEnd, msgs);
        case GenModelPackage.GEN_GEF_MODEL__GEN_VIEWERS:
          return ((InternalEList)getGenViewers()).basicRemove(otherEnd, msgs);
        case GenModelPackage.GEN_GEF_MODEL__GEN_EDIT_PARTS:
          return ((InternalEList)getGenEditParts()).basicRemove(otherEnd, msgs);
        default:
          return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_GEF_MODEL__NAME:
        return getName();
      case GenModelPackage.GEN_GEF_MODEL__PACKAGE_NAME:
        return getPackageName();
      case GenModelPackage.GEN_GEF_MODEL__OUTPUT_DIRECTORY_PATH:
        return getOutputDirectoryPath();
      case GenModelPackage.GEN_GEF_MODEL__COPYRIGHT_TEXT:
        return getCopyrightText();
      case GenModelPackage.GEN_GEF_MODEL__PLUGIN_ID:
        return getPluginID();
      case GenModelPackage.GEN_GEF_MODEL__PLUGIN_CLASS:
        return getPluginClass();
      case GenModelPackage.GEN_GEF_MODEL__GEN_MODEL:
        if (resolve) return getGenModel();
        return basicGetGenModel();
      case GenModelPackage.GEN_GEF_MODEL__GEN_EDIT_PART_FACTORIES:
        return getGenEditPartFactories();
      case GenModelPackage.GEN_GEF_MODEL__GEN_EDITORS:
        return getGenEditors();
      case GenModelPackage.GEN_GEF_MODEL__GEN_VIEWERS:
        return getGenViewers();
      case GenModelPackage.GEN_GEF_MODEL__GEN_EDIT_PARTS:
        return getGenEditParts();
      case GenModelPackage.GEN_GEF_MODEL__TEMPLATE_DIRECTORY:
        return getTemplateDirectory();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_GEF_MODEL__NAME:
        setName((String)newValue);
        return;
      case GenModelPackage.GEN_GEF_MODEL__PACKAGE_NAME:
        setPackageName((String)newValue);
        return;
      case GenModelPackage.GEN_GEF_MODEL__OUTPUT_DIRECTORY_PATH:
        setOutputDirectoryPath((String)newValue);
        return;
      case GenModelPackage.GEN_GEF_MODEL__COPYRIGHT_TEXT:
        setCopyrightText((String)newValue);
        return;
      case GenModelPackage.GEN_GEF_MODEL__PLUGIN_ID:
        setPluginID((String)newValue);
        return;
      case GenModelPackage.GEN_GEF_MODEL__PLUGIN_CLASS:
        setPluginClass((String)newValue);
        return;
      case GenModelPackage.GEN_GEF_MODEL__GEN_MODEL:
        setGenModel((GenModel)newValue);
        return;
      case GenModelPackage.GEN_GEF_MODEL__GEN_EDIT_PART_FACTORIES:
        getGenEditPartFactories().clear();
        getGenEditPartFactories().addAll((Collection)newValue);
        return;
      case GenModelPackage.GEN_GEF_MODEL__GEN_EDITORS:
        getGenEditors().clear();
        getGenEditors().addAll((Collection)newValue);
        return;
      case GenModelPackage.GEN_GEF_MODEL__GEN_VIEWERS:
        getGenViewers().clear();
        getGenViewers().addAll((Collection)newValue);
        return;
      case GenModelPackage.GEN_GEF_MODEL__GEN_EDIT_PARTS:
        getGenEditParts().clear();
        getGenEditParts().addAll((Collection)newValue);
        return;
      case GenModelPackage.GEN_GEF_MODEL__TEMPLATE_DIRECTORY:
        setTemplateDirectory((String)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_GEF_MODEL__NAME:
        setName(NAME_EDEFAULT);
        return;
      case GenModelPackage.GEN_GEF_MODEL__PACKAGE_NAME:
        setPackageName(PACKAGE_NAME_EDEFAULT);
        return;
      case GenModelPackage.GEN_GEF_MODEL__OUTPUT_DIRECTORY_PATH:
        setOutputDirectoryPath(OUTPUT_DIRECTORY_PATH_EDEFAULT);
        return;
      case GenModelPackage.GEN_GEF_MODEL__COPYRIGHT_TEXT:
        setCopyrightText(COPYRIGHT_TEXT_EDEFAULT);
        return;
      case GenModelPackage.GEN_GEF_MODEL__PLUGIN_ID:
        setPluginID(PLUGIN_ID_EDEFAULT);
        return;
      case GenModelPackage.GEN_GEF_MODEL__PLUGIN_CLASS:
        setPluginClass(PLUGIN_CLASS_EDEFAULT);
        return;
      case GenModelPackage.GEN_GEF_MODEL__GEN_MODEL:
        setGenModel((GenModel)null);
        return;
      case GenModelPackage.GEN_GEF_MODEL__GEN_EDIT_PART_FACTORIES:
        getGenEditPartFactories().clear();
        return;
      case GenModelPackage.GEN_GEF_MODEL__GEN_EDITORS:
        getGenEditors().clear();
        return;
      case GenModelPackage.GEN_GEF_MODEL__GEN_VIEWERS:
        getGenViewers().clear();
        return;
      case GenModelPackage.GEN_GEF_MODEL__GEN_EDIT_PARTS:
        getGenEditParts().clear();
        return;
      case GenModelPackage.GEN_GEF_MODEL__TEMPLATE_DIRECTORY:
        setTemplateDirectory(TEMPLATE_DIRECTORY_EDEFAULT);
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_GEF_MODEL__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case GenModelPackage.GEN_GEF_MODEL__PACKAGE_NAME:
        return PACKAGE_NAME_EDEFAULT == null ? packageName != null : !PACKAGE_NAME_EDEFAULT.equals(packageName);
      case GenModelPackage.GEN_GEF_MODEL__OUTPUT_DIRECTORY_PATH:
        return OUTPUT_DIRECTORY_PATH_EDEFAULT == null ? outputDirectoryPath != null : !OUTPUT_DIRECTORY_PATH_EDEFAULT.equals(outputDirectoryPath);
      case GenModelPackage.GEN_GEF_MODEL__COPYRIGHT_TEXT:
        return COPYRIGHT_TEXT_EDEFAULT == null ? copyrightText != null : !COPYRIGHT_TEXT_EDEFAULT.equals(copyrightText);
      case GenModelPackage.GEN_GEF_MODEL__PLUGIN_ID:
        return PLUGIN_ID_EDEFAULT == null ? pluginID != null : !PLUGIN_ID_EDEFAULT.equals(pluginID);
      case GenModelPackage.GEN_GEF_MODEL__PLUGIN_CLASS:
        return PLUGIN_CLASS_EDEFAULT == null ? pluginClass != null : !PLUGIN_CLASS_EDEFAULT.equals(pluginClass);
      case GenModelPackage.GEN_GEF_MODEL__GEN_MODEL:
        return genModel != null;
      case GenModelPackage.GEN_GEF_MODEL__GEN_EDIT_PART_FACTORIES:
        return genEditPartFactories != null && !genEditPartFactories.isEmpty();
      case GenModelPackage.GEN_GEF_MODEL__GEN_EDITORS:
        return genEditors != null && !genEditors.isEmpty();
      case GenModelPackage.GEN_GEF_MODEL__GEN_VIEWERS:
        return genViewers != null && !genViewers.isEmpty();
      case GenModelPackage.GEN_GEF_MODEL__GEN_EDIT_PARTS:
        return genEditParts != null && !genEditParts.isEmpty();
      case GenModelPackage.GEN_GEF_MODEL__TEMPLATE_DIRECTORY:
        return TEMPLATE_DIRECTORY_EDEFAULT == null ? templateDirectory != null : !TEMPLATE_DIRECTORY_EDEFAULT.equals(templateDirectory);
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString() {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (outputDirectoryPath: ");
    result.append(outputDirectoryPath);
    result.append(", copyrightText: ");
    result.append(copyrightText);
    result.append(", pluginID: ");
    result.append(pluginID);
    result.append(", pluginClass: ");
    result.append(pluginClass);
    result.append(", templateDirectory: ");
    result.append(templateDirectory);
    result.append(')');
    return result.toString();
  }

} //GenGEFModelImpl
