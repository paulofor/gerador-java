/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.genmodel;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.codegen.ecore.genmodel.GenModel;
import org.eclipse.emf.common.util.EList;

import com.metys.merlin.generation.templates.jetmapping.JETTemplateMappingRoot;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Gen GEF Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getOutputDirectoryPath <em>Output Directory Path</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getCopyrightText <em>Copyright Text</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getPluginID <em>Plugin ID</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getPluginClass <em>Plugin Class</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getGenModel <em>Gen Model</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getGenEditPartFactories <em>Gen Edit Part Factories</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getGenEditors <em>Gen Editors</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getGenViewers <em>Gen Viewers</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getGenEditParts <em>Gen Edit Parts</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getTemplateDirectory <em>Template Directory</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenGEFModel()
 * @model
 * @generated
 */
public interface GenGEFModel extends GenGEFBase {
  /**
   * Returns the value of the '<em><b>Gen Editors</b></em>' containment reference list.
   * The list contents are of type {@link com.metys.merlin.generation.gef.genmodel.GenEditor}.
   * It is bidirectional and its opposite is '{@link com.metys.merlin.generation.gef.genmodel.GenEditor#getGenGEFModel <em>Gen GEF Model</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Gen Editors</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Gen Editors</em>' containment reference list.
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenGEFModel_GenEditors()
   * @see com.metys.merlin.generation.gef.genmodel.GenEditor#getGenGEFModel
   * @model type="com.metys.merlin.generation.gef.genmodel.GenEditor" opposite="genGEFModel" containment="true"
   * @generated
   */
  EList getGenEditors();

  /**
   * Returns the value of the '<em><b>Gen Edit Parts</b></em>' containment reference list.
   * The list contents are of type {@link com.metys.merlin.generation.gef.genmodel.GenEditPart}.
   * It is bidirectional and its opposite is '{@link com.metys.merlin.generation.gef.genmodel.GenEditPart#getGenGEFModel <em>Gen GEF Model</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Gen Edit Parts</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Gen Edit Parts</em>' containment reference list.
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenGEFModel_GenEditParts()
   * @see com.metys.merlin.generation.gef.genmodel.GenEditPart#getGenGEFModel
   * @model type="com.metys.merlin.generation.gef.genmodel.GenEditPart" opposite="genGEFModel" containment="true"
   * @generated
   */
  EList getGenEditParts();

  /**
   * Returns the value of the '<em><b>Template Directory</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Template Directory</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Template Directory</em>' attribute.
   * @see #setTemplateDirectory(String)
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenGEFModel_TemplateDirectory()
   * @model
   * @generated
   */
  String getTemplateDirectory();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getTemplateDirectory <em>Template Directory</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Template Directory</em>' attribute.
   * @see #getTemplateDirectory()
   * @generated
   */
  void setTemplateDirectory(String value);

  /**
   * Returns the value of the '<em><b>Gen Viewers</b></em>' containment reference list.
   * The list contents are of type {@link com.metys.merlin.generation.gef.genmodel.GenViewer}.
   * It is bidirectional and its opposite is '{@link com.metys.merlin.generation.gef.genmodel.GenViewer#getGenGEFModel <em>Gen GEF Model</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Gen Viewers</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Gen Viewers</em>' containment reference list.
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenGEFModel_GenViewers()
   * @see com.metys.merlin.generation.gef.genmodel.GenViewer#getGenGEFModel
   * @model type="com.metys.merlin.generation.gef.genmodel.GenViewer" opposite="genGEFModel" containment="true"
   * @generated
   */
  EList getGenViewers();

  /**
   * Returns the value of the '<em><b>Gen Edit Part Factories</b></em>' containment reference list.
   * The list contents are of type {@link com.metys.merlin.generation.gef.genmodel.GenEditPartFactory}.
   * It is bidirectional and its opposite is '{@link com.metys.merlin.generation.gef.genmodel.GenEditPartFactory#getGenGEFModel <em>Gen GEF Model</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Gen Edit Part Factories</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Gen Edit Part Factories</em>' containment reference list.
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenGEFModel_GenEditPartFactories()
   * @see com.metys.merlin.generation.gef.genmodel.GenEditPartFactory#getGenGEFModel
   * @model type="com.metys.merlin.generation.gef.genmodel.GenEditPartFactory" opposite="genGEFModel" containment="true"
   * @generated
   */
  EList getGenEditPartFactories();

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model
   * @generated
   */
  void registerPartInAllEditors(GenEditPart editPart);

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model
   * @generated
   */
  void registerAllPartsInEditor(GenEditor editor);

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model progressMonitorDataType="com.metys.merlin.generation.gef.ProgressMonitor"
   * @generated
   */
  JETTemplateMappingRoot getTemplatesInstanceMapping(IProgressMonitor progressMonitor);

  /**
   * Returns the value of the '<em><b>Output Directory Path</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Output Directory Path</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Output Directory Path</em>' attribute.
   * @see #setOutputDirectoryPath(String)
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenGEFModel_OutputDirectoryPath()
   * @model
   * @generated
   */
  String getOutputDirectoryPath();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getOutputDirectoryPath <em>Output Directory Path</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Output Directory Path</em>' attribute.
   * @see #getOutputDirectoryPath()
   * @generated
   */
  void setOutputDirectoryPath(String value);

  /**
   * Returns the value of the '<em><b>Copyright Text</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Copyright Text</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Copyright Text</em>' attribute.
   * @see #setCopyrightText(String)
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenGEFModel_CopyrightText()
   * @model
   * @generated
   */
  String getCopyrightText();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getCopyrightText <em>Copyright Text</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Copyright Text</em>' attribute.
   * @see #getCopyrightText()
   * @generated
   */
  void setCopyrightText(String value);

  /**
   * Returns the value of the '<em><b>Plugin ID</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Plugin ID</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Plugin ID</em>' attribute.
   * @see #setPluginID(String)
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenGEFModel_PluginID()
   * @model
   * @generated
   */
  String getPluginID();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getPluginID <em>Plugin ID</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Plugin ID</em>' attribute.
   * @see #getPluginID()
   * @generated
   */
  void setPluginID(String value);

  /**
   * Returns the value of the '<em><b>Plugin Class</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Plugin Class</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Plugin Class</em>' attribute.
   * @see #setPluginClass(String)
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenGEFModel_PluginClass()
   * @model
   * @generated
   */
  String getPluginClass();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getPluginClass <em>Plugin Class</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Plugin Class</em>' attribute.
   * @see #getPluginClass()
   * @generated
   */
  void setPluginClass(String value);

  /**
   * Returns the value of the '<em><b>Gen Model</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Gen Model</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Gen Model</em>' reference.
   * @see #setGenModel(GenModel)
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#getGenGEFModel_GenModel()
   * @model required="true"
   * @generated
   */
  GenModel getGenModel();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getGenModel <em>Gen Model</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Gen Model</em>' reference.
   * @see #getGenModel()
   * @generated
   */
  void setGenModel(GenModel value);

} // GenGEFModel
