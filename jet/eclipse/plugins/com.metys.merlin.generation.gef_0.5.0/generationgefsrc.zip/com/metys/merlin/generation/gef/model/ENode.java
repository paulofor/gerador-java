/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.model;

import org.eclipse.draw2d.geometry.Point;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>ENode</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.gef.model.ENode#getName <em>Name</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.ENode#getLocation <em>Location</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.ENode#getWidth <em>Width</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.ENode#getHeight <em>Height</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.ENode#getEObject <em>EObject</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.ENode#getDiagram <em>Diagram</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.ENode#getIncomingLinks <em>Incoming Links</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.ENode#getOutgoingLinks <em>Outgoing Links</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.ENode#getInvalidMessage <em>Invalid Message</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.ENode#getSubNodes <em>Sub Nodes</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.metys.merlin.generation.gef.model.ModelPackage#getENode()
 * @model
 * @generated
 */
public interface ENode extends EObject{
  /**
   * Returns the value of the '<em><b>EObject</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>EObject</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>EObject</em>' reference.
   * @see #setEObject(EObject)
   * @see com.metys.merlin.generation.gef.model.ModelPackage#getENode_EObject()
   * @model required="true"
   * @generated
   */
  EObject getEObject();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.model.ENode#getEObject <em>EObject</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>EObject</em>' reference.
   * @see #getEObject()
   * @generated
   */
  void setEObject(EObject value);

  /**
   * Returns the value of the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name</em>' attribute.
   * @see #setName(String)
   * @see com.metys.merlin.generation.gef.model.ModelPackage#getENode_Name()
   * @model
   * @generated
   */
  String getName();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.model.ENode#getName <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Name</em>' attribute.
   * @see #getName()
   * @generated
   */
  void setName(String value);

  /**
   * Returns the value of the '<em><b>Location</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Location</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Location</em>' attribute.
   * @see #setLocation(Point)
   * @see com.metys.merlin.generation.gef.model.ModelPackage#getENode_Location()
   * @model dataType="com.metys.merlin.generation.gef.Point"
   * @generated
   */
  Point getLocation();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.model.ENode#getLocation <em>Location</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Location</em>' attribute.
   * @see #getLocation()
   * @generated
   */
  void setLocation(Point value);

  /**
   * Returns the value of the '<em><b>Width</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Width</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Width</em>' attribute.
   * @see #setWidth(long)
   * @see com.metys.merlin.generation.gef.model.ModelPackage#getENode_Width()
   * @model
   * @generated
   */
  long getWidth();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.model.ENode#getWidth <em>Width</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Width</em>' attribute.
   * @see #getWidth()
   * @generated
   */
  void setWidth(long value);

  /**
   * Returns the value of the '<em><b>Height</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Height</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Height</em>' attribute.
   * @see #setHeight(long)
   * @see com.metys.merlin.generation.gef.model.ModelPackage#getENode_Height()
   * @model
   * @generated
   */
  long getHeight();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.model.ENode#getHeight <em>Height</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Height</em>' attribute.
   * @see #getHeight()
   * @generated
   */
  void setHeight(long value);

  /**
   * Returns the value of the '<em><b>Incoming Links</b></em>' reference list.
   * The list contents are of type {@link com.metys.merlin.generation.gef.model.ELink}.
   * It is bidirectional and its opposite is '{@link com.metys.merlin.generation.gef.model.ELink#getTarget <em>Target</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Incoming Links</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Incoming Links</em>' reference list.
   * @see com.metys.merlin.generation.gef.model.ModelPackage#getENode_IncomingLinks()
   * @see com.metys.merlin.generation.gef.model.ELink#getTarget
   * @model type="com.metys.merlin.generation.gef.model.ELink" opposite="target"
   * @generated
   */
  EList getIncomingLinks();

  /**
   * Returns the value of the '<em><b>Outgoing Links</b></em>' containment reference list.
   * The list contents are of type {@link com.metys.merlin.generation.gef.model.ELink}.
   * It is bidirectional and its opposite is '{@link com.metys.merlin.generation.gef.model.ELink#getSource <em>Source</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Outgoing Links</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Outgoing Links</em>' containment reference list.
   * @see com.metys.merlin.generation.gef.model.ModelPackage#getENode_OutgoingLinks()
   * @see com.metys.merlin.generation.gef.model.ELink#getSource
   * @model type="com.metys.merlin.generation.gef.model.ELink" opposite="source" containment="true"
   * @generated
   */
  EList getOutgoingLinks();

  /**
   * Returns the value of the '<em><b>Sub Nodes</b></em>' containment reference list.
   * The list contents are of type {@link com.metys.merlin.generation.gef.model.ENode}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Sub Nodes</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Sub Nodes</em>' containment reference list.
   * @see com.metys.merlin.generation.gef.model.ModelPackage#getENode_SubNodes()
   * @model type="com.metys.merlin.generation.gef.model.ENode" containment="true"
   * @generated
   */
  EList getSubNodes();

  /**
   * Returns the value of the '<em><b>Invalid Message</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Invalid Message</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Invalid Message</em>' attribute.
   * @see #setInvalidMessage(String)
   * @see com.metys.merlin.generation.gef.model.ModelPackage#getENode_InvalidMessage()
   * @model
   * @generated
   */
  String getInvalidMessage();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.model.ENode#getInvalidMessage <em>Invalid Message</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Invalid Message</em>' attribute.
   * @see #getInvalidMessage()
   * @generated
   */
  void setInvalidMessage(String value);

  /**
   * Returns the value of the '<em><b>Diagram</b></em>' reference.
   * It is bidirectional and its opposite is '{@link com.metys.merlin.generation.gef.model.EDiagram#getAllNodes <em>All Nodes</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Diagram</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Diagram</em>' reference.
   * @see #setDiagram(EDiagram)
   * @see com.metys.merlin.generation.gef.model.ModelPackage#getENode_Diagram()
   * @see com.metys.merlin.generation.gef.model.EDiagram#getAllNodes
   * @model opposite="allNodes"
   * @generated
   */
  EDiagram getDiagram();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.gef.model.ENode#getDiagram <em>Diagram</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Diagram</em>' reference.
   * @see #getDiagram()
   * @generated
   */
  void setDiagram(EDiagram value);

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model
   * @generated
   */
  boolean acceptLinkAsSource(ELink link);

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model
   * @generated
   */
  boolean acceptLinkAsTarget(ELink link);

} // ENode
