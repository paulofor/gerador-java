/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.parts;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.eclipse.draw2d.ConnectionLayer;
import org.eclipse.draw2d.FanRouter;
import org.eclipse.draw2d.Figure;
import org.eclipse.draw2d.FreeformLayer;
import org.eclipse.draw2d.FreeformLayout;
import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.ShortestPathConnectionRouter;
import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.GraphicalEditPart;
import org.eclipse.gef.LayerConstants;
import org.eclipse.gef.editpolicies.RootComponentEditPolicy;

import com.metys.merlin.generation.gef.model.EDiagram;
import com.metys.merlin.generation.gef.model.ENode;
import com.metys.merlin.generation.gef.model.ModelPackage;
import com.metys.merlin.generation.gef.policies.EDiagramLayoutEditPolicy;

/**
 * @author jcheuoua
 * @version $Revision: 1.4 $
 */
public class EDiagramEditPart extends GraphicalComponentEditPart {
  private ShortestPathConnectionRouter spRouter;
  protected Resource modelResource;
  
  /**
   * Constructor for EDiagramEditPart.
   * @param diagram EDiagram
   * @param adapterFactory AdapterFactory
   * @param modelResource Resource
   */
  public EDiagramEditPart(EDiagram diagram, AdapterFactory adapterFactory, Resource modelResource) {
    super(adapterFactory);
    setModel(diagram);
    this.modelResource = modelResource;
  }
  
  /**
   * Constructor for EDiagramEditPart.
   * @param diagram EDiagram
   * @param adapterFactory AdapterFactory
   */
  public EDiagramEditPart(EDiagram diagram, AdapterFactory adapterFactory) {
    super(adapterFactory);
    setModel(diagram);
  }

  /**
   * Method getModelResource.
   * @return Resource
   */
  public Resource getModelResource() {
    return modelResource;
  }
  
  /**
   * Method setModelResource.
   * @param modelResource Resource
   */
  public void setModelResource(Resource modelResource) {
    this.modelResource = modelResource;
  }

  /**
   * Method createFigure.
   * @return IFigure
   */
  protected IFigure createFigure() {
    Figure f = new FreeformLayer();
    f.setLayoutManager(new FreeformLayout());
    return f;
  }

  protected void refreshVisuals() {
    if (spRouter == null) {
      ConnectionLayer cLayer = (ConnectionLayer) getLayer(LayerConstants.CONNECTION_LAYER);
      FanRouter router = new FanRouter();
      router.setSeparation(30);
      spRouter = new ShortestPathConnectionRouter(getFigure()); 
      router.setNextRouter(spRouter);
      cLayer.setConnectionRouter(router);
    }
  }
  
  /**
   * Method handlePropertyChanged.
   * @param notification Notification
   */
  public void handlePropertyChanged(Notification notification) {
    switch (notification.getFeatureID(EDiagram.class)) {
    case ModelPackage.EDIAGRAM__CONTENTS:
      refreshChildren();
      if (notification.getEventType() == Notification.ADD) {
        ENode newNode = (ENode) notification.getNewValue();
        EObject eObject = newNode.getEObject();
        if (modelResource != null && eObject.eResource() == null) {
          modelResource.getContents().add(eObject);
        }
      }
    }
  }

  /**
   * @see org.eclipse.gef.examples.flow.parts.StateVertexPart#createEditPolicies()
   */
  protected void createEditPolicies() {
    // Non graphical roles
    installEditPolicy(EditPolicy.COMPONENT_ROLE, new RootComponentEditPolicy());
    installEditPolicy(EditPolicy.NODE_ROLE, null);
    // Graphical roles
    installEditPolicy(EditPolicy.LAYOUT_ROLE, new EDiagramLayoutEditPolicy());
    installEditPolicy(EditPolicy.GRAPHICAL_NODE_ROLE, null);
    installEditPolicy(EditPolicy.SELECTION_FEEDBACK_ROLE, null);
  }

  /**
   * Returns the Diagram model associated with this EditPart
   * @return the StateMachine model
   */
  protected EDiagram getDiagram() {
    return (EDiagram) getModel();
  }

  /* (non-Javadoc)
   * @see com.metys.merlin.spem.foundation.activitygraphs.flow.parts.AbstractGraphRootDiagramPart#fetchChildren()
   */
  /**
   * Method getModelChildren.
   * @return List
   */
  protected List getModelChildren() {
    return getDiagram().getContents();
  }

  /**
   * @see org.eclipse.gef.editparts.AbstractEditPart#isSelectable()
   */
  public boolean isSelectable() {
    return false;
  }

  public ENodeEditPart findNodeEditPart(ENode eNode) {
    ENodeEditPart found = null;
    ArrayList partsListCandidates = new ArrayList();
    partsListCandidates.add(this);
    while (!partsListCandidates.isEmpty() && found == null) {
      ArrayList candidatesCopy = new ArrayList(partsListCandidates);
      partsListCandidates.clear();
      for (Iterator candidates = candidatesCopy.iterator(); candidates.hasNext();) {
        EditPart parentPart = (EditPart) candidates.next();
        for (Iterator iter = ((GraphicalEditPart)parentPart).getChildren().iterator(); iter.hasNext();) {
          EditPart childPart = (EditPart) iter.next();
          if (childPart.getModel() == eNode) {
            found = (ENodeEditPart) childPart;
            break;
          }
          else
            partsListCandidates.add(childPart);            
        };
        if (found != null)
          break;
      }
    }
    return found;
  }
}