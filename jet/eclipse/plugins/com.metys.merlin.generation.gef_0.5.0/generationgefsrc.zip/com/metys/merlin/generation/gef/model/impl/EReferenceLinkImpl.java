/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.model.impl;
import java.util.Collection;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.notify.impl.AdapterImpl;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;

import com.metys.merlin.generation.gef.model.ENode;
import com.metys.merlin.generation.gef.model.EReferenceLink;
import com.metys.merlin.generation.gef.model.ModelPackage;
/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>EReference Link</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.gef.model.impl.EReferenceLinkImpl#getEReference <em>EReference</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class EReferenceLinkImpl extends ELinkImpl implements EReferenceLink {
  /**
   * The cached value of the '{@link #getEReference() <em>EReference</em>}' reference. <!--
   * begin-user-doc --> <!-- end-user-doc -->
   * 
   * @see #getEReference()
   * @generated
   * @ordered
   */
  protected EReference eReference = null;
  
  private Adapter sourceAdapter = new AdapterImpl() {
    public void notifyChanged(Notification msg)
    {
      if (msg.getFeature() == getEReference() &&
          EReferenceLinkImpl.this.getTarget() != null &&
          EReferenceLinkImpl.this.getTarget().getEObject() != null) {
        if (msg.getEventType() == Notification.REMOVE && 
            msg.getOldValue() == EReferenceLinkImpl.this.getTarget().getEObject()) {
          EReferenceLinkImpl.this.setSource(null);
          EReferenceLinkImpl.this.setTarget(null);
        }
        if (msg.getEventType() == Notification.SET &&
            msg.getNewValue() != EReferenceLinkImpl.this.getTarget().getEObject()) {
          EReferenceLinkImpl.this.setSource(null);
          EReferenceLinkImpl.this.setTarget(null);
        }
      }
    }
  };
  
  private Adapter targetAdapter = new AdapterImpl() {
    public void notifyChanged(Notification msg)
    {
      if (msg.getFeature() == getEReference() &&
          EReferenceLinkImpl.this.getSource() != null &&
          EReferenceLinkImpl.this.getSource().getEObject() != null) {
        if (msg.getEventType() == Notification.REMOVE && 
            msg.getOldValue() == EReferenceLinkImpl.this.getSource().getEObject()) {
          EReferenceLinkImpl.this.setSource(null);
          EReferenceLinkImpl.this.setTarget(null);
        }
        if (msg.getEventType() == Notification.SET &&
            msg.getNewValue() != EReferenceLinkImpl.this.getSource().getEObject()) {
          EReferenceLinkImpl.this.setSource(null);
          EReferenceLinkImpl.this.setTarget(null);
        }
      }
    }
  };
  
  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated NOT
   */
  protected EReferenceLinkImpl() {
    super();
    eAdapters().add(new AdapterImpl() {
      public void notifyChanged(Notification msg)
      {
        if (msg.getFeature() == ModelPackage.eINSTANCE.getELink_Source()) {
          ENode oldSource = (ENode) msg.getOldValue();
          ENode newSource = (ENode) msg.getNewValue();
          if (oldSource != null && oldSource.getEObject() != null) 
            oldSource.getEObject().eAdapters().remove(sourceAdapter);
          if (newSource != null  && newSource.getEObject() != null)
            newSource.getEObject().eAdapters().add(sourceAdapter);
        }
        
        if (msg.getFeature() == ModelPackage.eINSTANCE.getELink_Target()) {
          ENode oldTarget = (ENode) msg.getOldValue();
          ENode newTarget = (ENode) msg.getNewValue();
          if (oldTarget != null && oldTarget.getEObject() != null) 
            oldTarget.getEObject().eAdapters().remove(targetAdapter);
          if (newTarget != null  && newTarget.getEObject() != null)
            newTarget.getEObject().eAdapters().add(targetAdapter);
        }        
      }
    });
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return ModelPackage.eINSTANCE.getEReferenceLink();
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public EReference getEReference() {
    if (eReference != null && eReference.eIsProxy()) {
      EReference oldEReference = eReference;
      eReference = (EReference)eResolveProxy((InternalEObject)eReference);
      if (eReference != oldEReference) {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, ModelPackage.EREFERENCE_LINK__EREFERENCE, oldEReference, eReference));
      }
    }
    return eReference;
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public EReference basicGetEReference() {
    return eReference;
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public void setEReference(EReference newEReference) {
    EReference oldEReference = eReference;
    eReference = newEReference;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.EREFERENCE_LINK__EREFERENCE, oldEReference, eReference));
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case ModelPackage.EREFERENCE_LINK__SOURCE:
          if (eContainer != null)
            msgs = eBasicRemoveFromContainer(msgs);
          return eBasicSetContainer(otherEnd, ModelPackage.EREFERENCE_LINK__SOURCE, msgs);
        case ModelPackage.EREFERENCE_LINK__TARGET:
          if (target != null)
            msgs = ((InternalEObject)target).eInverseRemove(this, ModelPackage.ENODE__INCOMING_LINKS, ENode.class, msgs);
          return basicSetTarget((ENode)otherEnd, msgs);
        default:
          return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case ModelPackage.EREFERENCE_LINK__SOURCE:
          return eBasicSetContainer(null, ModelPackage.EREFERENCE_LINK__SOURCE, msgs);
        case ModelPackage.EREFERENCE_LINK__TARGET:
          return basicSetTarget(null, msgs);
        default:
          return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
    if (eContainerFeatureID >= 0) {
      switch (eContainerFeatureID) {
        case ModelPackage.EREFERENCE_LINK__SOURCE:
          return eContainer.eInverseRemove(this, ModelPackage.ENODE__OUTGOING_LINKS, ENode.class, msgs);
        default:
          return eDynamicBasicRemoveFromContainer(msgs);
      }
    }
    return eContainer.eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ModelPackage.EREFERENCE_LINK__SOURCE:
        return getSource();
      case ModelPackage.EREFERENCE_LINK__TARGET:
        if (resolve) return getTarget();
        return basicGetTarget();
      case ModelPackage.EREFERENCE_LINK__BENDPOINTS:
        return getBendpoints();
      case ModelPackage.EREFERENCE_LINK__INVALID_MESSAGE:
        return getInvalidMessage();
      case ModelPackage.EREFERENCE_LINK__EREFERENCE:
        if (resolve) return getEReference();
        return basicGetEReference();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ModelPackage.EREFERENCE_LINK__SOURCE:
        setSource((ENode)newValue);
        return;
      case ModelPackage.EREFERENCE_LINK__TARGET:
        setTarget((ENode)newValue);
        return;
      case ModelPackage.EREFERENCE_LINK__BENDPOINTS:
        getBendpoints().clear();
        getBendpoints().addAll((Collection)newValue);
        return;
      case ModelPackage.EREFERENCE_LINK__INVALID_MESSAGE:
        setInvalidMessage((String)newValue);
        return;
      case ModelPackage.EREFERENCE_LINK__EREFERENCE:
        setEReference((EReference)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ModelPackage.EREFERENCE_LINK__SOURCE:
        setSource((ENode)null);
        return;
      case ModelPackage.EREFERENCE_LINK__TARGET:
        setTarget((ENode)null);
        return;
      case ModelPackage.EREFERENCE_LINK__BENDPOINTS:
        getBendpoints().clear();
        return;
      case ModelPackage.EREFERENCE_LINK__INVALID_MESSAGE:
        setInvalidMessage(INVALID_MESSAGE_EDEFAULT);
        return;
      case ModelPackage.EREFERENCE_LINK__EREFERENCE:
        setEReference((EReference)null);
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ModelPackage.EREFERENCE_LINK__SOURCE:
        return getSource() != null;
      case ModelPackage.EREFERENCE_LINK__TARGET:
        return target != null;
      case ModelPackage.EREFERENCE_LINK__BENDPOINTS:
        return bendpoints != null && !bendpoints.isEmpty();
      case ModelPackage.EREFERENCE_LINK__INVALID_MESSAGE:
        return INVALID_MESSAGE_EDEFAULT == null ? invalidMessage != null : !INVALID_MESSAGE_EDEFAULT.equals(invalidMessage);
      case ModelPackage.EREFERENCE_LINK__EREFERENCE:
        return eReference != null;
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc --> 
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public void doLink() {
    ENode source = getSource();
    ENode target = getTarget();
    EReference ref = getEReference();
    if (!ref.isChangeable())
      return;
    EObject sourceObject = source.getEObject();
    EObject targetObject = target.getEObject();
    if (ref.isMany())
      ((Collection) sourceObject.eGet(ref)).add(targetObject);
    else 
      sourceObject.eSet(ref, targetObject);    
  }
  /**
   * <!-- begin-user-doc --> 
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public void doUnlink() {
    ENode source = getSource();
    ENode target = getTarget();
    EReference ref = getEReference();
    if (!ref.isChangeable() || (!ref.isMany() && !ref.isUnsettable()))
      return;
    EObject sourceObject = source.getEObject();
    EObject targetObject = target.getEObject();
    
    // remove the listeners on the objects
    sourceObject.eAdapters().remove(sourceAdapter);
    targetObject.eAdapters().remove(targetAdapter);
    
    if (ref.isMany())
      ((Collection) sourceObject.eGet(ref)).remove(targetObject);
    else
      sourceObject.eUnset(ref);
  }
} // EReferenceLinkImpl
