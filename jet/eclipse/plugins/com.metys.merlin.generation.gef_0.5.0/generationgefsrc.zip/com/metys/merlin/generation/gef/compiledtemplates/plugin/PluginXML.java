package com.metys.merlin.generation.gef.compiledtemplates.plugin;

import com.metys.merlin.generation.gef.genmodel.*;
import java.util.*;
import org.eclipse.emf.codegen.ecore.genmodel.*;

public class PluginXML
{
  protected static String nl;
  public static synchronized PluginXML create(String lineSeparator)
  {
    nl = lineSeparator;
    PluginXML result = new PluginXML();
    nl = null;
    return result;
  }

  protected final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + NL + "<?eclipse version=\"3.0\"?>" + NL + "" + NL + "<plugin" + NL + "    name = \"%pluginName\"" + NL + "    id = \"";
  protected final String TEXT_2 = "\"" + NL + "    version = \"1.0.0\"" + NL + "    provider-name = \"%providerName\"" + NL + "    class = \"";
  protected final String TEXT_3 = "\">" + NL + "" + NL + "  <requires>" + NL + "  \t<import plugin=\"";
  protected final String TEXT_4 = "\"/>" + NL + "  \t<import plugin=\"";
  protected final String TEXT_5 = "\"/>" + NL + "    <import plugin=\"org.eclipse.draw2d\"/>" + NL + "    <import plugin=\"org.eclipse.gef\"/>" + NL + "    <import plugin=\"org.eclipse.swt\"/>" + NL + "    <import plugin=\"org.eclipse.emf.ecore\"/>" + NL + "    <import plugin=\"org.eclipse.emf.ecore.edit\"/>" + NL + "    <import plugin=\"org.eclipse.jface\"/>" + NL + "    <import plugin=\"org.eclipse.ui\"/>" + NL + "    <import plugin=\"org.eclipse.ui.ide\"/>" + NL + "    <import plugin=\"org.eclipse.ui.views\"/>" + NL + "    <import plugin=\"org.eclipse.core.runtime\"/>" + NL + "    <import plugin=\"org.eclipse.core.resources\"/>" + NL + "    <import plugin=\"com.metys.merlin.generation.gef\"/>    " + NL + "  </requires>" + NL + "" + NL + "  <runtime>" + NL + "    <library name=\"";
  protected final String TEXT_6 = "gef.jar\">" + NL + "      <export name=\"*\"/>" + NL + "    </library>" + NL + "  </runtime>" + NL + "  <extension point=\"org.eclipse.ui.editors\">" + NL + "  \t";
  protected final String TEXT_7 = NL + "     <editor" + NL + "        id = \"";
  protected final String TEXT_8 = ".";
  protected final String TEXT_9 = "ID\"" + NL + "        name = \"%_UI_";
  protected final String TEXT_10 = "_label\"" + NL + "        icon = \"icons/full/obj16/";
  protected final String TEXT_11 = ".gif\"" + NL + "        extensions = \"";
  protected final String TEXT_12 = ", ";
  protected final String TEXT_13 = ".gef\"" + NL + "        class = \"";
  protected final String TEXT_14 = ".";
  protected final String TEXT_15 = "\"" + NL + "        contributorClass=\"";
  protected final String TEXT_16 = ".";
  protected final String TEXT_17 = "ActionBarContributor\"/>";
  protected final String TEXT_18 = NL + "  </extension>" + NL + "</plugin>";

  public String generate(Object argument)
  {
    StringBuffer stringBuffer = new StringBuffer();
    
/**
 * Copyright (c) 2005 Joel Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

    

    GenGEFModel genGEFModel = (GenGEFModel) argument; GenModel genModel= genGEFModel.getGenModel();
    stringBuffer.append(TEXT_1);
    stringBuffer.append(genGEFModel.getPluginID());
    stringBuffer.append(TEXT_2);
    stringBuffer.append(genGEFModel.getPluginClass());
    stringBuffer.append(TEXT_3);
    stringBuffer.append(genModel.getModelPluginID());
    stringBuffer.append(TEXT_4);
    stringBuffer.append(genModel.getEditPluginID());
    stringBuffer.append(TEXT_5);
    stringBuffer.append(genModel.getModelPluginID());
    stringBuffer.append(TEXT_6);
     for (Iterator i = genGEFModel.getGenEditors().iterator(); i.hasNext(); ) { GenEditor genEditor = (GenEditor)i.next();
    stringBuffer.append(TEXT_7);
    stringBuffer.append(genEditor.getPackageName());
    stringBuffer.append(TEXT_8);
    stringBuffer.append(genEditor.getName());
    stringBuffer.append(TEXT_9);
    stringBuffer.append(genEditor.getName());
    stringBuffer.append(TEXT_10);
    stringBuffer.append(genEditor.getName());
    stringBuffer.append(TEXT_11);
    stringBuffer.append(genEditor.getName().replaceFirst("Editor","").toLowerCase());
    stringBuffer.append(TEXT_12);
    stringBuffer.append(genEditor.getName().replaceFirst("Editor","").toLowerCase());
    stringBuffer.append(TEXT_13);
    stringBuffer.append(genEditor.getPackageName());
    stringBuffer.append(TEXT_14);
    stringBuffer.append(genEditor.getName());
    stringBuffer.append(TEXT_15);
    stringBuffer.append(genEditor.getPackageName());
    stringBuffer.append(TEXT_16);
    stringBuffer.append(genEditor.getName());
    stringBuffer.append(TEXT_17);
    }
    stringBuffer.append(TEXT_18);
    return stringBuffer.toString();
  }
}
