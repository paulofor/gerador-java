package com.metys.merlin.generation.gef.compiledtemplates.policies;

import com.metys.merlin.generation.gef.genmodel.*;
import com.metys.merlin.generation.gef.genmodel.util.*;
import org.eclipse.emf.ecore.*;
import org.eclipse.emf.codegen.ecore.genmodel.*;

public class NodeGraphicalNodeEditPolicy
{
  protected static String nl;
  public static synchronized NodeGraphicalNodeEditPolicy create(String lineSeparator)
  {
    nl = lineSeparator;
    NodeGraphicalNodeEditPolicy result = new NodeGraphicalNodeEditPolicy();
    nl = null;
    return result;
  }

  protected final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = "/**" + NL + " * <copyright>" + NL + " * </copyright>" + NL + " *" + NL + " * ";
  protected final String TEXT_3 = "Id";
  protected final String TEXT_4 = NL + " */" + NL + "" + NL + "package ";
  protected final String TEXT_5 = ".policies;" + NL;
  protected final String TEXT_6 = NL + NL + "/**" + NL + " * <!-- begin-user-doc -->" + NL + " * <!-- end-user-doc -->" + NL + " * @generated" + NL + " */" + NL + "public ";
  protected final String TEXT_7 = "abstract ";
  protected final String TEXT_8 = "class ";
  protected final String TEXT_9 = "GraphicalNodeEditPolicy";
  protected final String TEXT_10 = "{" + NL + "\t" + NL + "\t/**" + NL + "\t * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected ";
  protected final String TEXT_11 = " getConnectionCompleteCommand(";
  protected final String TEXT_12 = " request) {" + NL + "    if (request.getStartCommand() instanceof ";
  protected final String TEXT_13 = ") {" + NL + "      CreateConnectionCommand cmd = (CreateConnectionCommand) request.getStartCommand();";
  protected final String TEXT_14 = NL + "      ";
  protected final String TEXT_15 = " targetNodeEditPart = (";
  protected final String TEXT_16 = ") getHost();";
  protected final String TEXT_17 = NL + "      ";
  protected final String TEXT_18 = " target = targetNodeEditPart.getENode();";
  protected final String TEXT_19 = NL + "      ";
  protected final String TEXT_20 = " link = cmd.getLink();" + NL + "      if (acceptLinkAsTarget(target, link)) {" + NL + "        cmd.setTargetNodeEditPart(targetNodeEditPart);" + NL + "        return cmd;" + NL + "      }" + NL + "    }" + NL + "    return null;" + NL + "  }" + NL + "" + NL + "  /**" + NL + "\t * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected Command getConnectionCreateCommand(CreateConnectionRequest request) {";
  protected final String TEXT_21 = NL + "    ";
  protected final String TEXT_22 = " sourceNodeEditPart = (";
  protected final String TEXT_23 = ") getHost();" + NL + "    ENode source = sourceNodeEditPart.getENode();" + NL + "    ELink link = (ELink) request.getNewObject();" + NL + "    if (acceptLinkAsSource(source, link)) {" + NL + "      CreateConnectionCommand cmd = new CreateConnectionCommand(sourceNodeEditPart, link);" + NL + "      request.setStartCommand(cmd);" + NL + "      return cmd;" + NL + "    }" + NL + "    return null;" + NL + "  }" + NL + "" + NL + "  /**" + NL + "\t * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected Command getReconnectSourceCommand(";
  protected final String TEXT_24 = " request) {";
  protected final String TEXT_25 = NL + "    ";
  protected final String TEXT_26 = " sourceNodeEditPart = (";
  protected final String TEXT_27 = ") getHost();" + NL + "    ELink link = (ELink) request.getConnectionEditPart().getModel();" + NL + "    ENode source = sourceNodeEditPart.getENode();" + NL + "    if (acceptLinkAsSource(source, link)) {";
  protected final String TEXT_28 = NL + "      ";
  protected final String TEXT_29 = " cmd = new ReconnectSourceCommand(sourceNodeEditPart, link);" + NL + "      return cmd;" + NL + "    }" + NL + "    return null;" + NL + "  }" + NL + "" + NL + "  /**" + NL + "\t * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  protected Command getReconnectTargetCommand(ReconnectRequest request) {";
  protected final String TEXT_30 = NL + "    ";
  protected final String TEXT_31 = " targetNodeEditPart = (";
  protected final String TEXT_32 = ") getHost();" + NL + "    ELink link = (ELink) request.getConnectionEditPart().getModel();" + NL + "    ENode target = targetNodeEditPart.getENode();" + NL + "    if (acceptLinkAsTarget(target, link)) {";
  protected final String TEXT_33 = NL + "      ";
  protected final String TEXT_34 = " cmd = new ReconnectTargetCommand(targetNodeEditPart, link);" + NL + "      return cmd;" + NL + "    }" + NL + "    return null;" + NL + "  }" + NL + "  " + NL + "  /**" + NL + "\t * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  public boolean acceptLinkAsTarget(ENode target, ELink link) {" + NL + "    return target.acceptLinkAsTarget(link);" + NL + "  }" + NL + "  " + NL + "  /**" + NL + "\t * <!-- begin-user-doc -->" + NL + "   * <!-- end-user-doc -->" + NL + "   * @generated" + NL + "   */" + NL + "  public boolean acceptLinkAsSource(ENode source, ELink link) {" + NL + "    return source.acceptLinkAsSource(link);" + NL + "  }" + NL + "}";

  public String generate(Object argument)
  {
    StringBuffer stringBuffer = new StringBuffer();
    
/**
 * Copyright (c) 2005 Joel Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

    GenNodeEditPart genEditPart = (GenNodeEditPart) argument; EClass ecoreClass = genEditPart.getEcoreClass(); EPackage ecorePackage = (EPackage) ecoreClass.getEPackage(); GenModel genModel = genEditPart.getGenGEFModel().getGenModel(); GenClass genClass = GenModelHelper.getGenClass(genModel, ecoreClass);
    stringBuffer.append(TEXT_1);
    stringBuffer.append(TEXT_2);
    stringBuffer.append("$");
    stringBuffer.append(TEXT_3);
    stringBuffer.append("$");
    stringBuffer.append(TEXT_4);
    stringBuffer.append(genEditPart.getPackageName());
    stringBuffer.append(TEXT_5);
    genModel.markImportLocation(stringBuffer);
    stringBuffer.append(TEXT_6);
    if (ecoreClass.isAbstract()) {
    stringBuffer.append(TEXT_7);
    }
    stringBuffer.append(TEXT_8);
    stringBuffer.append(ecoreClass.getName());
    stringBuffer.append(TEXT_9);
    stringBuffer.append(GenModelHelper.getGraphicalNodeEditPolicyExtendsLitteral(genModel, genEditPart));
    stringBuffer.append(TEXT_10);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.commands.Command"));
    stringBuffer.append(TEXT_11);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.requests.CreateConnectionRequest"));
    stringBuffer.append(TEXT_12);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.commands.CreateConnectionCommand"));
    stringBuffer.append(TEXT_13);
    stringBuffer.append(TEXT_14);
    stringBuffer.append(GenModelHelper.getImportedQualifiedEditPartClass(genModel, genEditPart));
    stringBuffer.append(TEXT_15);
    stringBuffer.append(GenModelHelper.getImportedQualifiedEditPartClass(genModel, genEditPart));
    stringBuffer.append(TEXT_16);
    stringBuffer.append(TEXT_17);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.model.ENode"));
    stringBuffer.append(TEXT_18);
    stringBuffer.append(TEXT_19);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.model.ELink"));
    stringBuffer.append(TEXT_20);
    stringBuffer.append(TEXT_21);
    stringBuffer.append(GenModelHelper.getImportedQualifiedEditPartClass(genModel, genEditPart));
    stringBuffer.append(TEXT_22);
    stringBuffer.append(GenModelHelper.getImportedQualifiedEditPartClass(genModel, genEditPart));
    stringBuffer.append(TEXT_23);
    stringBuffer.append(genModel.getImportedName("org.eclipse.gef.requests.ReconnectRequest"));
    stringBuffer.append(TEXT_24);
    stringBuffer.append(TEXT_25);
    stringBuffer.append(GenModelHelper.getImportedQualifiedEditPartClass(genModel, genEditPart));
    stringBuffer.append(TEXT_26);
    stringBuffer.append(GenModelHelper.getImportedQualifiedEditPartClass(genModel, genEditPart));
    stringBuffer.append(TEXT_27);
    stringBuffer.append(TEXT_28);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.commands.ReconnectSourceCommand"));
    stringBuffer.append(TEXT_29);
    stringBuffer.append(TEXT_30);
    stringBuffer.append(GenModelHelper.getImportedQualifiedEditPartClass(genModel, genEditPart));
    stringBuffer.append(TEXT_31);
    stringBuffer.append(GenModelHelper.getImportedQualifiedEditPartClass(genModel, genEditPart));
    stringBuffer.append(TEXT_32);
    stringBuffer.append(TEXT_33);
    stringBuffer.append(genModel.getImportedName("com.metys.merlin.generation.gef.commands.ReconnectTargetCommand"));
    stringBuffer.append(TEXT_34);
    genModel.emitSortedImports();
    return stringBuffer.toString();
  }
}
