/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.model.impl;

import java.util.Collection;
import java.util.Iterator;

import org.eclipse.draw2d.geometry.Point;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectContainmentWithInverseEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import com.metys.merlin.generation.gef.model.EDiagram;
import com.metys.merlin.generation.gef.model.ELink;
import com.metys.merlin.generation.gef.model.ENode;
import com.metys.merlin.generation.gef.model.EObjectLink;
import com.metys.merlin.generation.gef.model.EReferenceLink;
import com.metys.merlin.generation.gef.model.ModelPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>ENode</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.gef.model.impl.ENodeImpl#getName <em>Name</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.impl.ENodeImpl#getLocation <em>Location</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.impl.ENodeImpl#getWidth <em>Width</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.impl.ENodeImpl#getHeight <em>Height</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.impl.ENodeImpl#getEObject <em>EObject</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.impl.ENodeImpl#getDiagram <em>Diagram</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.impl.ENodeImpl#getIncomingLinks <em>Incoming Links</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.impl.ENodeImpl#getOutgoingLinks <em>Outgoing Links</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.impl.ENodeImpl#getInvalidMessage <em>Invalid Message</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.impl.ENodeImpl#getSubNodes <em>Sub Nodes</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ENodeImpl extends EObjectImpl implements ENode {
  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * The default value of the '{@link #getLocation() <em>Location</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLocation()
   * @generated
   * @ordered
   */
  protected static final Point LOCATION_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getLocation() <em>Location</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLocation()
   * @generated
   * @ordered
   */
  protected Point location = LOCATION_EDEFAULT;

  /**
   * The default value of the '{@link #getWidth() <em>Width</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getWidth()
   * @generated
   * @ordered
   */
  protected static final long WIDTH_EDEFAULT = 0L;

  /**
   * The cached value of the '{@link #getWidth() <em>Width</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getWidth()
   * @generated
   * @ordered
   */
  protected long width = WIDTH_EDEFAULT;

  /**
   * The default value of the '{@link #getHeight() <em>Height</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getHeight()
   * @generated
   * @ordered
   */
  protected static final long HEIGHT_EDEFAULT = 0L;

  /**
   * The cached value of the '{@link #getHeight() <em>Height</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getHeight()
   * @generated
   * @ordered
   */
  protected long height = HEIGHT_EDEFAULT;

  /**
   * The cached value of the '{@link #getEObject() <em>EObject</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getEObject()
   * @generated
   * @ordered
   */
  protected EObject eObject = null;

  /**
   * The cached value of the '{@link #getDiagram() <em>Diagram</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getDiagram()
   * @generated
   * @ordered
   */
  protected EDiagram diagram = null;

  /**
   * The cached value of the '{@link #getIncomingLinks() <em>Incoming Links</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIncomingLinks()
   * @generated
   * @ordered
   */
  protected EList incomingLinks = null;

  /**
   * The cached value of the '{@link #getOutgoingLinks() <em>Outgoing Links</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getOutgoingLinks()
   * @generated
   * @ordered
   */
  protected EList outgoingLinks = null;

  /**
   * The default value of the '{@link #getInvalidMessage() <em>Invalid Message</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInvalidMessage()
   * @generated
   * @ordered
   */
  protected static final String INVALID_MESSAGE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getInvalidMessage() <em>Invalid Message</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getInvalidMessage()
   * @generated
   * @ordered
   */
  protected String invalidMessage = INVALID_MESSAGE_EDEFAULT;

  /**
   * The cached value of the '{@link #getSubNodes() <em>Sub Nodes</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getSubNodes()
   * @generated
   * @ordered
   */
  protected EList subNodes = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ENodeImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return ModelPackage.eINSTANCE.getENode();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EObject getEObject() {
    if (eObject != null && eObject.eIsProxy()) {
      EObject oldEObject = eObject;
      eObject = (EObject)eResolveProxy((InternalEObject)eObject);
      if (eObject != oldEObject) {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, ModelPackage.ENODE__EOBJECT, oldEObject, eObject));
      }
    }
    return eObject;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EObject basicGetEObject() {
    return eObject;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setEObject(EObject newEObject) {
    EObject oldEObject = eObject;
    eObject = newEObject;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.ENODE__EOBJECT, oldEObject, eObject));
  }

  public EAttribute getLabelFeature(EClass eClass) {
    EAttribute labelFeature = null;
    for (Iterator iter = eClass.getEAllAttributes().iterator(); iter.hasNext();) {
      EAttribute feature = (EAttribute) iter.next();
      if (!feature.isMany() && 
          !feature.isTransient() &&
          feature.isChangeable() &&
          feature.getEType().getInstanceClass() == String.class) {
        String featureName = feature.getName();
        if (featureName != null) {
          if (featureName.equalsIgnoreCase("name")) {
            labelFeature = feature;
          } else if (featureName.equalsIgnoreCase("id")) {
            if (labelFeature == null || !labelFeature.getName().toLowerCase().endsWith("name")) {
              labelFeature = feature;
            }
          } else if (featureName.toLowerCase().endsWith("name")) {
            if (labelFeature == null || !labelFeature.getName().toLowerCase().endsWith("name")
                && !labelFeature.getName().equalsIgnoreCase("id")) {
              labelFeature = feature;
            }
          } else if (featureName.toLowerCase().indexOf("name") != -1) {
            if (labelFeature == null || labelFeature.getName().toLowerCase().indexOf("name") == -1
                && !labelFeature.getName().equalsIgnoreCase("id")) {
              labelFeature = feature;
            }
          } else if (labelFeature == null) {
            labelFeature = feature;
          }
        }
      }
    }
    return labelFeature;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public String getName() {
    if (name == null) {
      if (getEObject() != null) {
        EClass eClass = getEObject().eClass();
        EAttribute labelFeature = getLabelFeature(eClass);
        if (labelFeature != null)
          name = (String) getEObject().eGet(labelFeature);
      }
    }
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public void setName(String newName) {
    String oldName = name;
    name = newName;

    if (getEObject() != null) {
      EClass eClass = getEObject().eClass();
      EAttribute labelFeature = getLabelFeature(eClass);
      if (labelFeature != null)
        getEObject().eSet(labelFeature, newName);
    }

    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.ENODE__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Point getLocation() {
    return location;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLocation(Point newLocation) {
    Point oldLocation = location;
    location = newLocation;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.ENODE__LOCATION, oldLocation, location));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public long getWidth() {
    return width;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setWidth(long newWidth) {
    long oldWidth = width;
    width = newWidth;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.ENODE__WIDTH, oldWidth, width));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public long getHeight() {
    return height;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setHeight(long newHeight) {
    long oldHeight = height;
    height = newHeight;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.ENODE__HEIGHT, oldHeight, height));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getIncomingLinks() {
    if (incomingLinks == null) {
      incomingLinks = new EObjectWithInverseResolvingEList(ELink.class, this, ModelPackage.ENODE__INCOMING_LINKS, ModelPackage.ELINK__TARGET);
    }
    return incomingLinks;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getOutgoingLinks() {
    if (outgoingLinks == null) {
      outgoingLinks = new EObjectContainmentWithInverseEList(ELink.class, this, ModelPackage.ENODE__OUTGOING_LINKS, ModelPackage.ELINK__SOURCE);
    }
    return outgoingLinks;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getSubNodes() {
    if (subNodes == null) {
      subNodes = new EObjectContainmentEList(ENode.class, this, ModelPackage.ENODE__SUB_NODES);
    }
    return subNodes;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getInvalidMessage() {
    return invalidMessage;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setInvalidMessage(String newInvalidMessage) {
    String oldInvalidMessage = invalidMessage;
    invalidMessage = newInvalidMessage;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.ENODE__INVALID_MESSAGE, oldInvalidMessage, invalidMessage));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EDiagram getDiagram() {
    if (diagram != null && diagram.eIsProxy()) {
      EDiagram oldDiagram = diagram;
      diagram = (EDiagram)eResolveProxy((InternalEObject)diagram);
      if (diagram != oldDiagram) {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, ModelPackage.ENODE__DIAGRAM, oldDiagram, diagram));
      }
    }
    return diagram;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EDiagram basicGetDiagram() {
    return diagram;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetDiagram(EDiagram newDiagram, NotificationChain msgs) {
    EDiagram oldDiagram = diagram;
    diagram = newDiagram;
    if (eNotificationRequired()) {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ModelPackage.ENODE__DIAGRAM, oldDiagram, newDiagram);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setDiagram(EDiagram newDiagram) {
    if (newDiagram != diagram) {
      NotificationChain msgs = null;
      if (diagram != null)
        msgs = ((InternalEObject)diagram).eInverseRemove(this, ModelPackage.EDIAGRAM__ALL_NODES, EDiagram.class, msgs);
      if (newDiagram != null)
        msgs = ((InternalEObject)newDiagram).eInverseAdd(this, ModelPackage.EDIAGRAM__ALL_NODES, EDiagram.class, msgs);
      msgs = basicSetDiagram(newDiagram, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.ENODE__DIAGRAM, newDiagram, newDiagram));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public boolean acceptLinkAsSource(ELink link) {
    EObject sourceObject = getEObject();
    return acceptLink(link, sourceObject, null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public boolean acceptLinkAsTarget(ELink link) {
    EObject targetObject = getEObject();
    return acceptLink(link, null, targetObject);
  }

  /**
   * @param link
   * @param sourceObject
   * @param targetObject
   * @return
   */
  private boolean acceptLink(ELink link, EObject sourceObject, EObject targetObject) {
    if (link instanceof EReferenceLink) {
      EReferenceLink refLink = (EReferenceLink) link;
      EReference ref = refLink.getEReference();
      if (sourceObject != null && !ref.getEContainingClass().isInstance(sourceObject))
        return false;
      if (targetObject != null && !ref.getEReferenceType().isInstance(targetObject))
        return false;
    } else if (link instanceof EObjectLink) {
      EObjectLink objectLink = (EObjectLink) link;
      EObject transitionObject = objectLink.getTransitionEObject();
      EReference sourceRef = objectLink.getSourceReference();
      EReference targetRef = objectLink.getTargetReference();
      if (sourceObject != null && !sourceRef.getEReferenceType().isInstance(sourceObject))
        return false;
      if (targetObject != null && !targetRef.getEReferenceType().isInstance(targetObject))
        return false;
    }
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case ModelPackage.ENODE__DIAGRAM:
          if (diagram != null)
            msgs = ((InternalEObject)diagram).eInverseRemove(this, ModelPackage.EDIAGRAM__ALL_NODES, EDiagram.class, msgs);
          return basicSetDiagram((EDiagram)otherEnd, msgs);
        case ModelPackage.ENODE__INCOMING_LINKS:
          return ((InternalEList)getIncomingLinks()).basicAdd(otherEnd, msgs);
        case ModelPackage.ENODE__OUTGOING_LINKS:
          return ((InternalEList)getOutgoingLinks()).basicAdd(otherEnd, msgs);
        default:
          return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case ModelPackage.ENODE__DIAGRAM:
          return basicSetDiagram(null, msgs);
        case ModelPackage.ENODE__INCOMING_LINKS:
          return ((InternalEList)getIncomingLinks()).basicRemove(otherEnd, msgs);
        case ModelPackage.ENODE__OUTGOING_LINKS:
          return ((InternalEList)getOutgoingLinks()).basicRemove(otherEnd, msgs);
        case ModelPackage.ENODE__SUB_NODES:
          return ((InternalEList)getSubNodes()).basicRemove(otherEnd, msgs);
        default:
          return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ModelPackage.ENODE__NAME:
        return getName();
      case ModelPackage.ENODE__LOCATION:
        return getLocation();
      case ModelPackage.ENODE__WIDTH:
        return new Long(getWidth());
      case ModelPackage.ENODE__HEIGHT:
        return new Long(getHeight());
      case ModelPackage.ENODE__EOBJECT:
        if (resolve) return getEObject();
        return basicGetEObject();
      case ModelPackage.ENODE__DIAGRAM:
        if (resolve) return getDiagram();
        return basicGetDiagram();
      case ModelPackage.ENODE__INCOMING_LINKS:
        return getIncomingLinks();
      case ModelPackage.ENODE__OUTGOING_LINKS:
        return getOutgoingLinks();
      case ModelPackage.ENODE__INVALID_MESSAGE:
        return getInvalidMessage();
      case ModelPackage.ENODE__SUB_NODES:
        return getSubNodes();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ModelPackage.ENODE__NAME:
        setName((String)newValue);
        return;
      case ModelPackage.ENODE__LOCATION:
        setLocation((Point)newValue);
        return;
      case ModelPackage.ENODE__WIDTH:
        setWidth(((Long)newValue).longValue());
        return;
      case ModelPackage.ENODE__HEIGHT:
        setHeight(((Long)newValue).longValue());
        return;
      case ModelPackage.ENODE__EOBJECT:
        setEObject((EObject)newValue);
        return;
      case ModelPackage.ENODE__DIAGRAM:
        setDiagram((EDiagram)newValue);
        return;
      case ModelPackage.ENODE__INCOMING_LINKS:
        getIncomingLinks().clear();
        getIncomingLinks().addAll((Collection)newValue);
        return;
      case ModelPackage.ENODE__OUTGOING_LINKS:
        getOutgoingLinks().clear();
        getOutgoingLinks().addAll((Collection)newValue);
        return;
      case ModelPackage.ENODE__INVALID_MESSAGE:
        setInvalidMessage((String)newValue);
        return;
      case ModelPackage.ENODE__SUB_NODES:
        getSubNodes().clear();
        getSubNodes().addAll((Collection)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ModelPackage.ENODE__NAME:
        setName(NAME_EDEFAULT);
        return;
      case ModelPackage.ENODE__LOCATION:
        setLocation(LOCATION_EDEFAULT);
        return;
      case ModelPackage.ENODE__WIDTH:
        setWidth(WIDTH_EDEFAULT);
        return;
      case ModelPackage.ENODE__HEIGHT:
        setHeight(HEIGHT_EDEFAULT);
        return;
      case ModelPackage.ENODE__EOBJECT:
        setEObject((EObject)null);
        return;
      case ModelPackage.ENODE__DIAGRAM:
        setDiagram((EDiagram)null);
        return;
      case ModelPackage.ENODE__INCOMING_LINKS:
        getIncomingLinks().clear();
        return;
      case ModelPackage.ENODE__OUTGOING_LINKS:
        getOutgoingLinks().clear();
        return;
      case ModelPackage.ENODE__INVALID_MESSAGE:
        setInvalidMessage(INVALID_MESSAGE_EDEFAULT);
        return;
      case ModelPackage.ENODE__SUB_NODES:
        getSubNodes().clear();
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ModelPackage.ENODE__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case ModelPackage.ENODE__LOCATION:
        return LOCATION_EDEFAULT == null ? location != null : !LOCATION_EDEFAULT.equals(location);
      case ModelPackage.ENODE__WIDTH:
        return width != WIDTH_EDEFAULT;
      case ModelPackage.ENODE__HEIGHT:
        return height != HEIGHT_EDEFAULT;
      case ModelPackage.ENODE__EOBJECT:
        return eObject != null;
      case ModelPackage.ENODE__DIAGRAM:
        return diagram != null;
      case ModelPackage.ENODE__INCOMING_LINKS:
        return incomingLinks != null && !incomingLinks.isEmpty();
      case ModelPackage.ENODE__OUTGOING_LINKS:
        return outgoingLinks != null && !outgoingLinks.isEmpty();
      case ModelPackage.ENODE__INVALID_MESSAGE:
        return INVALID_MESSAGE_EDEFAULT == null ? invalidMessage != null : !INVALID_MESSAGE_EDEFAULT.equals(invalidMessage);
      case ModelPackage.ENODE__SUB_NODES:
        return subNodes != null && !subNodes.isEmpty();
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString() {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (name: ");
    result.append(name);
    result.append(", location: ");
    result.append(location);
    result.append(", width: ");
    result.append(width);
    result.append(", height: ");
    result.append(height);
    result.append(", invalidMessage: ");
    result.append(invalidMessage);
    result.append(')');
    return result.toString();
  }

} //ENodeImpl
