/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.model.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.draw2d.AbsoluteBendpoint;
import org.eclipse.draw2d.geometry.Insets;
import org.eclipse.draw2d.geometry.Point;
import org.eclipse.draw2d.graph.CompoundDirectedGraph;
import org.eclipse.draw2d.graph.CompoundDirectedGraphLayout;
import org.eclipse.draw2d.graph.Edge;
import org.eclipse.draw2d.graph.Node;
import org.eclipse.draw2d.graph.NodeList;
import org.eclipse.draw2d.graph.Subgraph;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import com.metys.merlin.generation.gef.model.EDiagram;
import com.metys.merlin.generation.gef.model.ELink;
import com.metys.merlin.generation.gef.model.ENode;
import com.metys.merlin.generation.gef.model.EObjectLink;
import com.metys.merlin.generation.gef.model.EReferenceLink;
import com.metys.merlin.generation.gef.model.ModelFactory;
import com.metys.merlin.generation.gef.model.ModelPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>EDiagram</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.gef.model.impl.EDiagramImpl#getModelResource <em>Model Resource</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.impl.EDiagramImpl#getImportedResources <em>Imported Resources</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.impl.EDiagramImpl#getContents <em>Contents</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.model.impl.EDiagramImpl#getAllNodes <em>All Nodes</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class EDiagramImpl extends EObjectImpl implements EDiagram {
  static final Insets PADDING = new Insets(8, 6, 8, 6);
  static final Insets INNER_PADDING = new Insets(0);
  
  /**
   * The default value of the '{@link #getModelResource() <em>Model Resource</em>}' attribute.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @see #getModelResource()
   * @generated
   * @ordered
   */
	protected static final URI MODEL_RESOURCE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getModelResource() <em>Model Resource</em>}' attribute.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @see #getModelResource()
   * @generated
   * @ordered
   */
	protected URI modelResource = MODEL_RESOURCE_EDEFAULT;

  /**
   * The cached value of the '{@link #getImportedResources() <em>Imported Resources</em>}' attribute list.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @see #getImportedResources()
   * @generated
   * @ordered
   */
	protected EList importedResources = null;

  /**
   * The cached value of the '{@link #getContents() <em>Contents</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getContents()
   * @generated
   * @ordered
   */
  protected EList contents = null;

  /**
   * The cached value of the '{@link #getAllNodes() <em>All Nodes</em>}' reference list.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @see #getAllNodes()
   * @generated
   * @ordered
   */
	protected EList allNodes = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EDiagramImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return ModelPackage.eINSTANCE.getEDiagram();
  }

  /**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	public URI getModelResource() {
    return modelResource;
  }

  /**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	public void setModelResource(URI newModelResource) {
    URI oldModelResource = modelResource;
    modelResource = newModelResource;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.EDIAGRAM__MODEL_RESOURCE, oldModelResource, modelResource));
  }

  /**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	public EList getImportedResources() {
    if (importedResources == null) {
      importedResources = new EDataTypeUniqueEList(URI.class, this, ModelPackage.EDIAGRAM__IMPORTED_RESOURCES);
    }
    return importedResources;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getContents() {
    if (contents == null) {
      contents = new EObjectContainmentEList(ENode.class, this, ModelPackage.EDIAGRAM__CONTENTS);
    }
    return contents;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getAllNodes() {
    if (allNodes == null) {
      allNodes = new EObjectWithInverseResolvingEList(ENode.class, this, ModelPackage.EDIAGRAM__ALL_NODES, ModelPackage.ENODE__DIAGRAM);
    }
    return allNodes;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public ENode getENode(EObject eObject) {
    if (eObject == null)
      return null;
    for (Iterator it = getAllNodes().iterator();it.hasNext(); ){
      ENode node = (ENode) it.next();
      if (eObject.equals(node.getEObject()))
        return node;
    }
    return null;
  }

  public void populateDiagram(Collection rootEObjects) {
    populateDiagram(rootEObjects, false, Collections.EMPTY_MAP);    
  }
  
  public void populateDiagram(Collection rootEObjects, boolean linkForContainments) {
    populateDiagram(rootEObjects, linkForContainments, Collections.EMPTY_MAP);    
  }
  
  public void populateDiagram(Collection rootEObjects, Map transitionClasses) {
    populateDiagram(rootEObjects, false, transitionClasses);    
  }
  
  public void populateDiagram(Collection rootEObjects, boolean linkForContainments, Map transitionClasses) {
    // first pass : popuplate the nodes
    populateDiagramNodes(rootEObjects, linkForContainments, transitionClasses);
    // second pass : populate the links
    populateDiagramLinks(rootEObjects, linkForContainments, transitionClasses);
    // Use the Graph layout algorithms to give initial positions for the objects
    CompoundDirectedGraph graph = new CompoundDirectedGraph();
    Map map = new HashMap();
    contributeNodesToGraph(graph, map);
    contributeEdgesToGraph(graph, map);
    new CompoundDirectedGraphLayout().visit(graph);
    applyGraphResults(graph, map);
  }
  
  private void contributeEdgesToGraph(CompoundDirectedGraph graph, Map map) {
    for (int i = 0; i < getContents().size(); i++) {
      ENode node = (ENode)getContents().get(i);
      contributeEdgesToGraph(node, graph, map);
    }
  }

  private void contributeNodesToGraph(CompoundDirectedGraph graph, Map map) {
    Subgraph me = new Subgraph(this);
    me.outgoingOffset = 5;
    me.incomingOffset = 5;
    me.innerPadding = INNER_PADDING;
    me.setPadding(PADDING);
    map.put(this, me);
    graph.nodes.add(me);
    for (int i = 0; i < getContents().size(); i++) {
      ENode node = (ENode)getContents().get(i);
      contributeNodesToGraph(node, graph, me, map);
    }
  }

  private void contributeEdgesToGraph(ENode parentNode, CompoundDirectedGraph graph, Map map) {
    List outgoing = parentNode.getOutgoingLinks();
    for (int i = 0; i < outgoing.size(); i++) {
      ELink link = (ELink) outgoing.get(i);
      contributeEdgesToGraph(link, graph, map);
    }
    for (int i = 0; i < parentNode.getSubNodes().size(); i++) {
      ENode node = (ENode)parentNode.getSubNodes().get(i);
      contributeEdgesToGraph(node, graph, map);
    }
  }

  private void contributeNodesToGraph(ENode parentNode, CompoundDirectedGraph graph, Subgraph s, Map map) {
    Subgraph me = new Subgraph(parentNode, s);
    me.outgoingOffset = 5;
    me.incomingOffset = 5;
    
    me.width = (int) parentNode.getWidth();
    me.insets.top = (int) parentNode.getHeight();
    me.insets.bottom = (int) parentNode.getHeight();
    me.insets.left = 0;
    
    me.innerPadding = INNER_PADDING;
    me.setPadding(PADDING);
    map.put(parentNode, me);
    graph.nodes.add(me);
    for (int i = 0; i < parentNode.getSubNodes().size(); i++) {
      ENode subNode = (ENode)parentNode.getSubNodes().get(i);
      contributeNodesToGraph(subNode, graph, me, map);
    }
  }

  private void contributeEdgesToGraph(ELink link, CompoundDirectedGraph graph, Map map) {
    Node source = (Node)map.get(link.getSource());
    Node target = (Node)map.get(link.getTarget());
    Edge e = new Edge(link, source, target);
    if (link instanceof EObjectLink)
      e.weight = 2;
    graph.edges.add(e);
    map.put(link, e);
  }
  
  private void applyGraphResults(CompoundDirectedGraph graph, Map map) {
    for (int i = 0; i < getContents().size(); i++) {
      ENode node = (ENode)getContents().get(i);
      applyGraphResults(node, graph, map);
    }
  }
  private void applyGraphResults(ENode parentNode, CompoundDirectedGraph graph, Map map) {
    Node n = (Node)map.get(parentNode);
    parentNode.setLocation(new Point(n.x, n.y));
    parentNode.setWidth(n.width);
    parentNode.setHeight(n.height);
    
    List outgoing = parentNode.getOutgoingLinks();
    for (int i = 0; i < outgoing.size(); i++) {
      ELink trans = (ELink) outgoing.get(i);
      applyGraphResults(trans, graph, map);
    }
    for (int i = 0; i < parentNode.getSubNodes().size(); i++) {
      ENode node = (ENode)parentNode.getSubNodes().get(i);
      applyGraphResults(node, graph, map);
    }
  }

  private void applyGraphResults(ELink link, CompoundDirectedGraph graph, Map map) {
    Edge e = (Edge)map.get(link);
    NodeList nodes = e.vNodes;
    if (nodes != null) {
      List bends = new ArrayList();
      for (int i = 0; i < nodes.size(); i++) {
        Node vn = nodes.getNode(i);
        int x = vn.x;
        int y = vn.y;
        if (e.isFeedback) {
          bends.add(new AbsoluteBendpoint(x, y + vn.height));
          bends.add(new AbsoluteBendpoint(x, y));

        } else {
          bends.add(new AbsoluteBendpoint(x, y));
          bends.add(new AbsoluteBendpoint(x, y + vn.height));
        }
      }
      link.getBendpoints().addAll(bends);
    }
  }
  
  public void populateNode(ENode node) {
    populateNode(node, false, Collections.EMPTY_MAP);    
  }
  
  public void populateNode(ENode node, boolean linkForContainments) {
    populateNode(node, linkForContainments, Collections.EMPTY_MAP);
  }
  
  public void populateNode(ENode node, Map transitionClasses) {
    populateNode(node, false, transitionClasses);
  }
  
  public void populateNode(ENode node, boolean linkForContainments, Map transitionClasses) {
    // first pass : popuplate the nodes
    populateDiagramNodes(node, linkForContainments, transitionClasses);
    // second pass : populate the links
    populateDiagramLinks(node.getEObject().eContents(), linkForContainments, transitionClasses);
    // Use the Graph layout algorithms to give initial positions for the objects
    CompoundDirectedGraph graph = new CompoundDirectedGraph();
    Map map = new HashMap();
    contributeNodesToGraph(node, graph, null, map);
    contributeEdgesToGraph(node, graph, map);
    new CompoundDirectedGraphLayout().visit(graph);
    applyGraphResults(node, graph, map);
  }
  
  protected void populateDiagramNodes(Collection rootEObjects, boolean linkForContainments, Map transitionClasses) {
    Iterator it = rootEObjects.iterator();    
    while (it.hasNext()) {
      EObject eObject = (EObject) it.next();
      EClass eClass = eObject.eClass();
      if (getENode(eObject) != null) 
        continue;
      if (transitionClasses.keySet().contains(eClass))
        continue;
      ENode eNode = ModelFactory.eINSTANCE.createENode();
      eNode.setEObject(eObject);
      eNode.setDiagram(this);
      this.getContents().add(eNode);      
      populateDiagramNodes(eNode, linkForContainments, transitionClasses);
    }
  }
  
  protected void populateDiagramNodes(ENode parentNode, boolean linkForContainments, Map transitionClasses) {
    Iterator it = parentNode.getEObject().eContents().iterator();    
    while (it.hasNext()) {
      EObject eObject = (EObject) it.next();
      EClass eClass = eObject.eClass();
      if (getENode(eObject) != null) 
        continue;
      if (transitionClasses.keySet().contains(eClass))
        continue;
      ENode eNode = ModelFactory.eINSTANCE.createENode();
      eNode.setEObject(eObject);
      eNode.setDiagram(this);
      parentNode.getSubNodes().add(eNode);      
      populateDiagramNodes(eNode, linkForContainments, transitionClasses);
    }
  }
  
  protected void populateDiagramLinks(Collection rootEObjects, boolean linkForContainments, Map transitionClasses) {
    Iterator it = rootEObjects.iterator();    
    while (it.hasNext()) {
      EObject eObject = (EObject) it.next();
      ENode eNode = getENode(eObject);
      if (getENode(eObject) == null) 
        continue;
      EClass eClass = eObject.eClass();
      // Transition Classes Links
      if (transitionClasses.keySet().contains(eClass)) {
        List transitionReferences = (List) transitionClasses.get(eClass);
        if (transitionReferences.size() != 2)
          continue;
        EReference sourceRef = (EReference) transitionReferences.get(0);
        EReference targetRef = (EReference) transitionReferences.get(1);
        createObjectLink(eObject, sourceRef, targetRef);
      } else { // Reference Links
        for (Iterator references = eClass.getEAllReferences().iterator(); references.hasNext();) {
          EReference ref = (EReference) references.next();
          Object value = eObject.eGet(ref);
          if (value != null) {
            List listValue = new ArrayList();
            if (ref.isMany())
              listValue = (List) value;
            else 
              listValue.add(value);          
            for (Iterator values = listValue.iterator(); values.hasNext();) {
              EObject refObjectValue = (EObject) values.next();
              ENode refObjectENode = getENode(refObjectValue);
              if (!linkForContainments && 
                  (ref.isContainer() || ref.isContainment()))
                continue;
              if (transitionClasses.keySet().contains(refObjectValue.eClass()))
                continue;
              if (refObjectENode == null)
                continue;
              createReferenceLink(eObject, ref, refObjectValue);
            }            
          }          
        }
      }
      populateDiagramLinks(eObject.eContents(), linkForContainments, transitionClasses);
    }
  }
  
  /**
   * @param eObject
   * @param ref
   * @param refObject
   */
  protected void createReferenceLink(EObject object, EReference ref, EObject refObject) {
   EReferenceLink link = ModelFactory.eINSTANCE.createEReferenceLink();
    ENode sourceNode = getENode(object);    
    ENode targetNode = getENode(refObject);    
    
    link.setEReference(ref);
    link.setSource(sourceNode);      
    link.setTarget(targetNode);    
  }
  
  /**
   * @param eObject
   * @param ref
   * @param refObject
   */
  protected void createObjectLink(EObject transitionObject, EReference sourceReference, EReference targetReference) {
    if (sourceReference == null || targetReference == null)
      return;
    if (sourceReference.isMany() || targetReference.isMany())
      return;
    
    EObject sourceObject = (EObject) transitionObject.eGet(sourceReference);
    EObject targetObject = (EObject) transitionObject.eGet(targetReference);
    
    ENode sourceNode = getENode(sourceObject);
    ENode targetNode = getENode(targetObject);
    
    if (sourceNode == null || targetNode == null)
      return;
    
    EObjectLink link = ModelFactory.eINSTANCE.createEObjectLink();
    
    link.setTransitionEObject(transitionObject);
    link.setSourceReference(sourceReference);
    link.setTargetReference(targetReference);
    link.setSource(sourceNode);        
    link.setTarget(targetNode);      
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case ModelPackage.EDIAGRAM__ALL_NODES:
          return ((InternalEList)getAllNodes()).basicAdd(otherEnd, msgs);
        default:
          return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case ModelPackage.EDIAGRAM__CONTENTS:
          return ((InternalEList)getContents()).basicRemove(otherEnd, msgs);
        case ModelPackage.EDIAGRAM__ALL_NODES:
          return ((InternalEList)getAllNodes()).basicRemove(otherEnd, msgs);
        default:
          return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ModelPackage.EDIAGRAM__MODEL_RESOURCE:
        return getModelResource();
      case ModelPackage.EDIAGRAM__IMPORTED_RESOURCES:
        return getImportedResources();
      case ModelPackage.EDIAGRAM__CONTENTS:
        return getContents();
      case ModelPackage.EDIAGRAM__ALL_NODES:
        return getAllNodes();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ModelPackage.EDIAGRAM__MODEL_RESOURCE:
        setModelResource((URI)newValue);
        return;
      case ModelPackage.EDIAGRAM__IMPORTED_RESOURCES:
        getImportedResources().clear();
        getImportedResources().addAll((Collection)newValue);
        return;
      case ModelPackage.EDIAGRAM__CONTENTS:
        getContents().clear();
        getContents().addAll((Collection)newValue);
        return;
      case ModelPackage.EDIAGRAM__ALL_NODES:
        getAllNodes().clear();
        getAllNodes().addAll((Collection)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ModelPackage.EDIAGRAM__MODEL_RESOURCE:
        setModelResource(MODEL_RESOURCE_EDEFAULT);
        return;
      case ModelPackage.EDIAGRAM__IMPORTED_RESOURCES:
        getImportedResources().clear();
        return;
      case ModelPackage.EDIAGRAM__CONTENTS:
        getContents().clear();
        return;
      case ModelPackage.EDIAGRAM__ALL_NODES:
        getAllNodes().clear();
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ModelPackage.EDIAGRAM__MODEL_RESOURCE:
        return MODEL_RESOURCE_EDEFAULT == null ? modelResource != null : !MODEL_RESOURCE_EDEFAULT.equals(modelResource);
      case ModelPackage.EDIAGRAM__IMPORTED_RESOURCES:
        return importedResources != null && !importedResources.isEmpty();
      case ModelPackage.EDIAGRAM__CONTENTS:
        return contents != null && !contents.isEmpty();
      case ModelPackage.EDIAGRAM__ALL_NODES:
        return allNodes != null && !allNodes.isEmpty();
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	public String toString() {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (modelResource: ");
    result.append(modelResource);
    result.append(", importedResources: ");
    result.append(importedResources);
    result.append(')');
    return result.toString();
  }

} //EDiagramImpl
