/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.figures;

import org.eclipse.draw2d.AbstractBorder;
import org.eclipse.draw2d.ColorConstants;
import org.eclipse.draw2d.ConnectionLayer;
import org.eclipse.draw2d.FanRouter;
import org.eclipse.draw2d.FreeformLayer;
import org.eclipse.draw2d.FreeformLayeredPane;
import org.eclipse.draw2d.FreeformLayout;
import org.eclipse.draw2d.FreeformViewport;
import org.eclipse.draw2d.Graphics;
import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.Panel;
import org.eclipse.draw2d.PositionConstants;
import org.eclipse.draw2d.ScrollPane;
import org.eclipse.draw2d.ShortestPathConnectionRouter;
import org.eclipse.draw2d.ToolbarLayout;
import org.eclipse.draw2d.geometry.Insets;
import org.eclipse.draw2d.geometry.PointList;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.swt.graphics.Color;

/**
 * @author jcheuoua
 * @version $Revision: 1.2 $
 */
public class ENodeFigure extends Panel {

  protected Label header;

  protected FreeformLayer contents;

  protected ConnectionLayer cLayer;

  /**
   * Constructor for ENodeFigure.
   * @param label Label
   */
  public ENodeFigure(Label label) {
    setLayoutManager(new ToolbarLayout());
    setBackgroundColor(new Color(null, 245, 245, 255));
    setBorder(new FoldedBorder());

    ScrollPane scrollpane = new ScrollPane();
    this.header = label;

    this.header.setOpaque(true);
    this.header.setBackgroundColor(ColorConstants.menuBackgroundSelected);
    this.header.setForegroundColor(ColorConstants.menuForegroundSelected);
    this.header.setLabelAlignment(PositionConstants.CENTER);

    add(this.header);
    add(scrollpane);

    scrollpane.setViewport(new FreeformViewport());
    FreeformLayeredPane innerLayers = new FreeformLayeredPane();
    this.contents = new FreeformLayer();
    this.contents.setOpaque(true);
    this.contents.setLayoutManager(new FreeformLayout());

    this.cLayer = new ConnectionLayer();
    FanRouter router = new FanRouter();
    router.setSeparation(30);
    ShortestPathConnectionRouter spRouter = new ShortestPathConnectionRouter(contents); 
    router.setNextRouter(spRouter);
    cLayer.setConnectionRouter(router);    

    innerLayers.add(contents);
    innerLayers.add(cLayer);

    scrollpane.setContents(innerLayers);
  }

  /**
   * Method getConnectionLayer.
   * @return ConnectionLayer
   */
  public ConnectionLayer getConnectionLayer() {
    return cLayer;
  }

  /**
   * Method useLocalCoordinates.
   * @return boolean
   */
  protected boolean useLocalCoordinates() {
    return true;
  }

  /**
   * Method getContentPane.
   * @return FreeformLayer
   */
  public FreeformLayer getContentPane() {
    return contents;
  }

  /**
   * Method getHeader.
   * @return Label
   */
  public Label getHeader() {
    return header;
  }

  /**
   */
  private class FoldedBorder extends AbstractBorder {
    PointList corner_erase;

    PointList corner_paint;

    int corner_size = 7;

    Color corner1 = new Color(null, 200, 208, 223);

    Color corner2 = new Color(null, 160, 172, 200);

    Color blue = new Color(null, 152, 168, 200);

    Insets insets = new Insets(corner_size, 2, 4, 4);

    public FoldedBorder() {
      corner_erase = new PointList(3);
      corner_erase.addPoint(1, 0);
      corner_erase.addPoint(1, corner_size + 1);
      corner_erase.addPoint(-corner_size, 0);
      corner_paint = new PointList(3);
      corner_paint.addPoint(-corner_size, 0);
      corner_paint.addPoint(0, corner_size);
      corner_paint.addPoint(-corner_size, corner_size);
    }

    /**
     * Method getInsets.
     * @param figure IFigure
     * @return Insets
     * @see org.eclipse.draw2d.Border#getInsets(IFigure)
     */
    public Insets getInsets(IFigure figure) {
      return insets;
    }

    /**
     * Method paint.
     * @param figure IFigure
     * @param g Graphics
     * @param insets Insets
     * @see org.eclipse.draw2d.Border#paint(IFigure, Graphics, Insets)
     */
    public void paint(IFigure figure, Graphics g, Insets insets) {
      Rectangle r = getPaintRectangle(figure, insets);

      r.resize(-2, -2);
      g.setForegroundColor(blue);
      g.drawLine(r.x + 3, r.bottom(), r.right() - 1, r.bottom());
      g.drawLine(r.right() + 1, r.y + 3 + corner_size, r.right() + 1, r.bottom() - 1);

      g.restoreState();
      r.resize(-1, -1);
      g.drawRectangle(r);
      g.setForegroundColor(blue);
      g.drawRectangle(r.x + 1, r.y + 1, r.width - 2, r.height - 2);
      g.translate(r.getTopRight());
      g.fillPolygon(corner_erase);
      g.setBackgroundColor(corner1);
      g.fillPolygon(corner_paint);
      g.setForegroundColor(figure.getForegroundColor());
      g.drawPolygon(corner_paint);
      g.restoreState();
      g.setForegroundColor(corner2);
      g.drawLine(r.right() - corner_size + 1, r.y + 2, r.right() - 2, r.y + corner_size - 1);
    }
  }
}