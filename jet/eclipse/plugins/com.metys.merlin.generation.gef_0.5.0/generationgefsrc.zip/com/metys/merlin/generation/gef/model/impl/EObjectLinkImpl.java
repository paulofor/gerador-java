/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.model.impl;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;

import com.metys.merlin.generation.gef.model.ENode;
import com.metys.merlin.generation.gef.model.EObjectLink;
import com.metys.merlin.generation.gef.model.ModelPackage;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>EObject Link</b></em>'. <!-- end-user-doc
 * -->
 * <p>
 * The following features are implemented:
 * <ul>
 * <li>{@link com.metys.merlin.generation.gef.model.impl.EObjectLinkImpl#getTransitionEObject <em>Transition EObject</em>}</li>
 * <li>{@link com.metys.merlin.generation.gef.model.impl.EObjectLinkImpl#getSourceReference <em>Source Reference</em>}</li>
 * <li>{@link com.metys.merlin.generation.gef.model.impl.EObjectLinkImpl#getTargetReference <em>Target Reference</em>}</li>
 * </ul>
 * </p>
 * 
 * @generated
 */
public class EObjectLinkImpl extends ELinkImpl implements EObjectLink {

  /**
   * The cached value of the '{@link #getTransitionEObject() <em>Transition EObject</em>}' reference. <!--
   * begin-user-doc --> <!-- end-user-doc -->
   * 
   * @see #getTransitionEObject()
   * @generated
   * @ordered
   */
  protected EObject transitionEObject = null;

  /**
   * The cached value of the '{@link #getSourceReference() <em>Source Reference</em>}' reference.
   * <!-- begin-user-doc
   * --> <!-- end-user-doc -->
   * @see #getSourceReference()
   * @generated
   * @ordered
   */
  protected EReference sourceReference = null;

  /**
   * The cached value of the '{@link #getTargetReference() <em>Target Reference</em>}' reference.
   * <!-- begin-user-doc
   * --> <!-- end-user-doc -->
   * @see #getTargetReference()
   * @generated
   * @ordered
   */
  protected EReference targetReference = null;

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  protected EObjectLinkImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return ModelPackage.eINSTANCE.getEObjectLink();
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public EObject getTransitionEObject() {
    if (transitionEObject != null && transitionEObject.eIsProxy()) {
      EObject oldTransitionEObject = transitionEObject;
      transitionEObject = (EObject)eResolveProxy((InternalEObject)transitionEObject);
      if (transitionEObject != oldTransitionEObject) {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, ModelPackage.EOBJECT_LINK__TRANSITION_EOBJECT, oldTransitionEObject, transitionEObject));
      }
    }
    return transitionEObject;
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public EObject basicGetTransitionEObject() {
    return transitionEObject;
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public void setTransitionEObject(EObject newTransitionEObject) {
    EObject oldTransitionEObject = transitionEObject;
    transitionEObject = newTransitionEObject;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.EOBJECT_LINK__TRANSITION_EOBJECT, oldTransitionEObject, transitionEObject));
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public EReference getSourceReference() {
    if (sourceReference != null && sourceReference.eIsProxy()) {
      EReference oldSourceReference = sourceReference;
      sourceReference = (EReference)eResolveProxy((InternalEObject)sourceReference);
      if (sourceReference != oldSourceReference) {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, ModelPackage.EOBJECT_LINK__SOURCE_REFERENCE, oldSourceReference, sourceReference));
      }
    }
    return sourceReference;
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public EReference basicGetSourceReference() {
    return sourceReference;
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public void setSourceReference(EReference newSourceReference) {
    EReference oldSourceReference = sourceReference;
    sourceReference = newSourceReference;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.EOBJECT_LINK__SOURCE_REFERENCE, oldSourceReference, sourceReference));
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public EReference getTargetReference() {
    if (targetReference != null && targetReference.eIsProxy()) {
      EReference oldTargetReference = targetReference;
      targetReference = (EReference)eResolveProxy((InternalEObject)targetReference);
      if (targetReference != oldTargetReference) {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, ModelPackage.EOBJECT_LINK__TARGET_REFERENCE, oldTargetReference, targetReference));
      }
    }
    return targetReference;
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public EReference basicGetTargetReference() {
    return targetReference;
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public void setTargetReference(EReference newTargetReference) {
    EReference oldTargetReference = targetReference;
    targetReference = newTargetReference;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, ModelPackage.EOBJECT_LINK__TARGET_REFERENCE, oldTargetReference, targetReference));
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case ModelPackage.EOBJECT_LINK__SOURCE:
          if (eContainer != null)
            msgs = eBasicRemoveFromContainer(msgs);
          return eBasicSetContainer(otherEnd, ModelPackage.EOBJECT_LINK__SOURCE, msgs);
        case ModelPackage.EOBJECT_LINK__TARGET:
          if (target != null)
            msgs = ((InternalEObject)target).eInverseRemove(this, ModelPackage.ENODE__INCOMING_LINKS, ENode.class, msgs);
          return basicSetTarget((ENode)otherEnd, msgs);
        default:
          return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
        case ModelPackage.EOBJECT_LINK__SOURCE:
          return eBasicSetContainer(null, ModelPackage.EOBJECT_LINK__SOURCE, msgs);
        case ModelPackage.EOBJECT_LINK__TARGET:
          return basicSetTarget(null, msgs);
        default:
          return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
    if (eContainerFeatureID >= 0) {
      switch (eContainerFeatureID) {
        case ModelPackage.EOBJECT_LINK__SOURCE:
          return eContainer.eInverseRemove(this, ModelPackage.ENODE__OUTGOING_LINKS, ENode.class, msgs);
        default:
          return eDynamicBasicRemoveFromContainer(msgs);
      }
    }
    return eContainer.eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
  }

  /**
   * <!-- begin-user-doc --> 
   * <!-- end-user-doc -->
   * 
   * @generated NOT
   */
  public void doLink() {
    if (getSourceReference().isMany()) {
      ((List) getTransitionEObject().eGet(getSourceReference())).add(getSource().getEObject());
    } else {
      getTransitionEObject().eSet(getSourceReference(), getSource().getEObject());
    }
    if (getTargetReference().isMany()) {
      ((List) getTransitionEObject().eGet(getTargetReference())).add(getTarget().getEObject());
    } else {
      getTransitionEObject().eSet(getTargetReference(), getTarget().getEObject());
    }
    if (getSource().getEObject().eResource() != null && getTransitionEObject().eResource() == null)
      getSource().getEObject().eResource().getContents().add(getTransitionEObject());
  }

  /**
   * <!-- begin-user-doc --> 
   * <!-- end-user-doc -->
   * 
   * @generated NOT
   */
  public void doUnlink() {
    EcoreUtil.remove(getTransitionEObject());
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ModelPackage.EOBJECT_LINK__SOURCE:
        return getSource();
      case ModelPackage.EOBJECT_LINK__TARGET:
        if (resolve) return getTarget();
        return basicGetTarget();
      case ModelPackage.EOBJECT_LINK__BENDPOINTS:
        return getBendpoints();
      case ModelPackage.EOBJECT_LINK__INVALID_MESSAGE:
        return getInvalidMessage();
      case ModelPackage.EOBJECT_LINK__TRANSITION_EOBJECT:
        if (resolve) return getTransitionEObject();
        return basicGetTransitionEObject();
      case ModelPackage.EOBJECT_LINK__SOURCE_REFERENCE:
        if (resolve) return getSourceReference();
        return basicGetSourceReference();
      case ModelPackage.EOBJECT_LINK__TARGET_REFERENCE:
        if (resolve) return getTargetReference();
        return basicGetTargetReference();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ModelPackage.EOBJECT_LINK__SOURCE:
        setSource((ENode)newValue);
        return;
      case ModelPackage.EOBJECT_LINK__TARGET:
        setTarget((ENode)newValue);
        return;
      case ModelPackage.EOBJECT_LINK__BENDPOINTS:
        getBendpoints().clear();
        getBendpoints().addAll((Collection)newValue);
        return;
      case ModelPackage.EOBJECT_LINK__INVALID_MESSAGE:
        setInvalidMessage((String)newValue);
        return;
      case ModelPackage.EOBJECT_LINK__TRANSITION_EOBJECT:
        setTransitionEObject((EObject)newValue);
        return;
      case ModelPackage.EOBJECT_LINK__SOURCE_REFERENCE:
        setSourceReference((EReference)newValue);
        return;
      case ModelPackage.EOBJECT_LINK__TARGET_REFERENCE:
        setTargetReference((EReference)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ModelPackage.EOBJECT_LINK__SOURCE:
        setSource((ENode)null);
        return;
      case ModelPackage.EOBJECT_LINK__TARGET:
        setTarget((ENode)null);
        return;
      case ModelPackage.EOBJECT_LINK__BENDPOINTS:
        getBendpoints().clear();
        return;
      case ModelPackage.EOBJECT_LINK__INVALID_MESSAGE:
        setInvalidMessage(INVALID_MESSAGE_EDEFAULT);
        return;
      case ModelPackage.EOBJECT_LINK__TRANSITION_EOBJECT:
        setTransitionEObject((EObject)null);
        return;
      case ModelPackage.EOBJECT_LINK__SOURCE_REFERENCE:
        setSourceReference((EReference)null);
        return;
      case ModelPackage.EOBJECT_LINK__TARGET_REFERENCE:
        setTargetReference((EReference)null);
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case ModelPackage.EOBJECT_LINK__SOURCE:
        return getSource() != null;
      case ModelPackage.EOBJECT_LINK__TARGET:
        return target != null;
      case ModelPackage.EOBJECT_LINK__BENDPOINTS:
        return bendpoints != null && !bendpoints.isEmpty();
      case ModelPackage.EOBJECT_LINK__INVALID_MESSAGE:
        return INVALID_MESSAGE_EDEFAULT == null ? invalidMessage != null : !INVALID_MESSAGE_EDEFAULT.equals(invalidMessage);
      case ModelPackage.EOBJECT_LINK__TRANSITION_EOBJECT:
        return transitionEObject != null;
      case ModelPackage.EOBJECT_LINK__SOURCE_REFERENCE:
        return sourceReference != null;
      case ModelPackage.EOBJECT_LINK__TARGET_REFERENCE:
        return targetReference != null;
    }
    return eDynamicIsSet(eFeature);
  }

} // EObjectLinkImpl
