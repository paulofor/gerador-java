/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef;

import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see com.metys.merlin.generation.gef.GefFactory
 * @model kind="package"
 * @generated
 */
public interface GefPackage extends EPackage{
  /**
   * The package name.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	String eNAME = "gef";

  /**
   * The package namespace URI.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	String eNS_URI = "http://www.metys.com/merlin/generation/gef.ecore";

  /**
   * The package namespace name.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	String eNS_PREFIX = "gef";

  /**
   * The singleton instance of the package.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	GefPackage eINSTANCE = com.metys.merlin.generation.gef.impl.GefPackageImpl.init();

  /**
   * The meta object id for the '<em>Point</em>' data type.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.eclipse.draw2d.geometry.Point
   * @see com.metys.merlin.generation.gef.impl.GefPackageImpl#getPoint()
   * @generated
   */
  int POINT = 1;

  /**
   * The meta object id for the '<em>Bendpoint</em>' data type.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.eclipse.draw2d.Bendpoint
   * @see com.metys.merlin.generation.gef.impl.GefPackageImpl#getBendpoint()
   * @generated
   */
  int BENDPOINT = 3;


  /**
   * The meta object id for the '<em>URI</em>' data type.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @see org.eclipse.emf.common.util.URI
   * @see com.metys.merlin.generation.gef.impl.GefPackageImpl#getURI()
   * @generated
   */
	int URI = 4;

  /**
   * The meta object id for the '<em>Figure</em>' data type.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.eclipse.draw2d.Figure
   * @see com.metys.merlin.generation.gef.impl.GefPackageImpl#getFigure()
   * @generated
   */
  int FIGURE = 2;

  /**
   * The meta object id for the '<em>Notification</em>' data type.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.eclipse.emf.common.notify.Notification
   * @see com.metys.merlin.generation.gef.impl.GefPackageImpl#getNotification()
   * @generated
   */
  int NOTIFICATION = 5;

  /**
   * The meta object id for the '<em>Adapter Factory</em>' data type.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @see org.eclipse.emf.common.notify.AdapterFactory
   * @see com.metys.merlin.generation.gef.impl.GefPackageImpl#getAdapterFactory()
   * @generated
   */
	int ADAPTER_FACTORY = 6;


  /**
   * The meta object id for the '<em>ENode Edit Part</em>' data type.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.gef.parts.ENodeEditPart
   * @see com.metys.merlin.generation.gef.impl.GefPackageImpl#getENodeEditPart()
   * @generated
   */
  int ENODE_EDIT_PART = 7;

  /**
   * The meta object id for the '<em>ELink Edit Part</em>' data type.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.gef.parts.ELinkEditPart
   * @see com.metys.merlin.generation.gef.impl.GefPackageImpl#getELinkEditPart()
   * @generated
   */
  int ELINK_EDIT_PART = 8;


  /**
   * The meta object id for the '<em>Progress Monitor</em>' data type.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.eclipse.core.runtime.IProgressMonitor
   * @see com.metys.merlin.generation.gef.impl.GefPackageImpl#getProgressMonitor()
   * @generated
   */
  int PROGRESS_MONITOR = 9;


  /**
   * The meta object id for the '<em>List</em>' data type.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see java.util.List
   * @see com.metys.merlin.generation.gef.impl.GefPackageImpl#getList()
   * @generated
   */
  int LIST = 0;


  /**
   * Returns the meta object for data type '{@link org.eclipse.draw2d.geometry.Point <em>Point</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for data type '<em>Point</em>'.
   * @see org.eclipse.draw2d.geometry.Point
   * @model instanceClass="org.eclipse.draw2d.geometry.Point"
   * @generated
   */
  EDataType getPoint();

  /**
   * Returns the meta object for data type '{@link org.eclipse.draw2d.Bendpoint <em>Bendpoint</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for data type '<em>Bendpoint</em>'.
   * @see org.eclipse.draw2d.Bendpoint
   * @model instanceClass="org.eclipse.draw2d.Bendpoint"
   * @generated
   */
  EDataType getBendpoint();

  /**
   * Returns the meta object for data type '{@link org.eclipse.emf.common.util.URI <em>URI</em>}'.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @return the meta object for data type '<em>URI</em>'.
   * @see org.eclipse.emf.common.util.URI
   * @model instanceClass="org.eclipse.emf.common.util.URI"
   * @generated
   */
	EDataType getURI();

  /**
   * Returns the meta object for data type '{@link org.eclipse.draw2d.Figure <em>Figure</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for data type '<em>Figure</em>'.
   * @see org.eclipse.draw2d.Figure
   * @model instanceClass="org.eclipse.draw2d.Figure"
   * @generated
   */
  EDataType getFigure();

  /**
   * Returns the meta object for data type '{@link org.eclipse.emf.common.notify.Notification <em>Notification</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for data type '<em>Notification</em>'.
   * @see org.eclipse.emf.common.notify.Notification
   * @model instanceClass="org.eclipse.emf.common.notify.Notification"
   * @generated
   */
  EDataType getNotification();

  /**
   * Returns the meta object for data type '{@link org.eclipse.emf.common.notify.AdapterFactory <em>Adapter Factory</em>}'.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @return the meta object for data type '<em>Adapter Factory</em>'.
   * @see org.eclipse.emf.common.notify.AdapterFactory
   * @model instanceClass="org.eclipse.emf.common.notify.AdapterFactory"
   * @generated
   */
	EDataType getAdapterFactory();

  /**
   * Returns the meta object for data type '{@link com.metys.merlin.generation.gef.parts.ENodeEditPart <em>ENode Edit Part</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for data type '<em>ENode Edit Part</em>'.
   * @see com.metys.merlin.generation.gef.parts.ENodeEditPart
   * @model instanceClass="com.metys.merlin.generation.gef.parts.ENodeEditPart"
   * @generated
   */
  EDataType getENodeEditPart();

  /**
   * Returns the meta object for data type '{@link com.metys.merlin.generation.gef.parts.ELinkEditPart <em>ELink Edit Part</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for data type '<em>ELink Edit Part</em>'.
   * @see com.metys.merlin.generation.gef.parts.ELinkEditPart
   * @model instanceClass="com.metys.merlin.generation.gef.parts.ELinkEditPart"
   * @generated
   */
  EDataType getELinkEditPart();

  /**
   * Returns the meta object for data type '{@link org.eclipse.core.runtime.IProgressMonitor <em>Progress Monitor</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for data type '<em>Progress Monitor</em>'.
   * @see org.eclipse.core.runtime.IProgressMonitor
   * @model instanceClass="org.eclipse.core.runtime.IProgressMonitor" serializable="false"
   * @generated
   */
  EDataType getProgressMonitor();

  /**
   * Returns the meta object for data type '{@link java.util.List <em>List</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for data type '<em>List</em>'.
   * @see java.util.List
   * @model instanceClass="java.util.List"
   * @generated
   */
  EDataType getList();

  /**
   * Returns the factory that creates the instances of the model.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @return the factory that creates the instances of the model.
   * @generated
   */
	GefFactory getGefFactory();

} //GefPackage
