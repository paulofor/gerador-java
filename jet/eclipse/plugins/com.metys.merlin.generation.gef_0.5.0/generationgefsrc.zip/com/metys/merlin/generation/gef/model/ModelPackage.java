/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.model;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see com.metys.merlin.generation.gef.model.ModelFactory
 * @model kind="package"
 * @generated
 */
public interface ModelPackage extends EPackage{
  /**
   * The package name.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	String eNAME = "model";

  /**
   * The package namespace URI.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	String eNS_URI = "http://www.metys.com/merlin/generation/gef/model.ecore";

  /**
   * The package namespace name.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	String eNS_PREFIX = "gef.model";

  /**
   * The singleton instance of the package.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   */
	ModelPackage eINSTANCE = com.metys.merlin.generation.gef.model.impl.ModelPackageImpl.init();

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.gef.model.impl.EDiagramImpl <em>EDiagram</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.gef.model.impl.EDiagramImpl
   * @see com.metys.merlin.generation.gef.model.impl.ModelPackageImpl#getEDiagram()
   * @generated
   */
  int EDIAGRAM = 0;

  /**
   * The feature id for the '<em><b>Model Resource</b></em>' attribute.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
	int EDIAGRAM__MODEL_RESOURCE = 0;

  /**
   * The feature id for the '<em><b>Imported Resources</b></em>' attribute list.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
	int EDIAGRAM__IMPORTED_RESOURCES = 1;

  /**
   * The feature id for the '<em><b>Contents</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EDIAGRAM__CONTENTS = 2;

  /**
   * The feature id for the '<em><b>All Nodes</b></em>' reference list.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
	int EDIAGRAM__ALL_NODES = 3;

  /**
   * The number of structural features of the the '<em>EDiagram</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EDIAGRAM_FEATURE_COUNT = 4;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.gef.model.impl.ENodeImpl <em>ENode</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.gef.model.impl.ENodeImpl
   * @see com.metys.merlin.generation.gef.model.impl.ModelPackageImpl#getENode()
   * @generated
   */
  int ENODE = 1;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENODE__NAME = 0;

  /**
   * The feature id for the '<em><b>Location</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENODE__LOCATION = 1;

  /**
   * The feature id for the '<em><b>Width</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENODE__WIDTH = 2;

  /**
   * The feature id for the '<em><b>Height</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENODE__HEIGHT = 3;

  /**
   * The feature id for the '<em><b>EObject</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENODE__EOBJECT = 4;

  /**
   * The feature id for the '<em><b>Diagram</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENODE__DIAGRAM = 5;

  /**
   * The feature id for the '<em><b>Incoming Links</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENODE__INCOMING_LINKS = 6;

  /**
   * The feature id for the '<em><b>Outgoing Links</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENODE__OUTGOING_LINKS = 7;

  /**
   * The feature id for the '<em><b>Invalid Message</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENODE__INVALID_MESSAGE = 8;

  /**
   * The feature id for the '<em><b>Sub Nodes</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENODE__SUB_NODES = 9;

  /**
   * The number of structural features of the the '<em>ENode</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENODE_FEATURE_COUNT = 10;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.gef.model.impl.ELinkImpl <em>ELink</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.gef.model.impl.ELinkImpl
   * @see com.metys.merlin.generation.gef.model.impl.ModelPackageImpl#getELink()
   * @generated
   */
  int ELINK = 2;

  /**
   * The feature id for the '<em><b>Source</b></em>' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ELINK__SOURCE = 0;

  /**
   * The feature id for the '<em><b>Target</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ELINK__TARGET = 1;

  /**
   * The feature id for the '<em><b>Bendpoints</b></em>' attribute list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ELINK__BENDPOINTS = 2;

  /**
   * The feature id for the '<em><b>Invalid Message</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ELINK__INVALID_MESSAGE = 3;

  /**
   * The number of structural features of the the '<em>ELink</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ELINK_FEATURE_COUNT = 4;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.gef.model.impl.EReferenceLinkImpl <em>EReference Link</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.gef.model.impl.EReferenceLinkImpl
   * @see com.metys.merlin.generation.gef.model.impl.ModelPackageImpl#getEReferenceLink()
   * @generated
   */
  int EREFERENCE_LINK = 3;

  /**
   * The feature id for the '<em><b>Source</b></em>' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EREFERENCE_LINK__SOURCE = ELINK__SOURCE;

  /**
   * The feature id for the '<em><b>Target</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EREFERENCE_LINK__TARGET = ELINK__TARGET;

  /**
   * The feature id for the '<em><b>Bendpoints</b></em>' attribute list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EREFERENCE_LINK__BENDPOINTS = ELINK__BENDPOINTS;

  /**
   * The feature id for the '<em><b>Invalid Message</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EREFERENCE_LINK__INVALID_MESSAGE = ELINK__INVALID_MESSAGE;

  /**
   * The feature id for the '<em><b>EReference</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EREFERENCE_LINK__EREFERENCE = ELINK_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the the '<em>EReference Link</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EREFERENCE_LINK_FEATURE_COUNT = ELINK_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.gef.model.impl.EObjectLinkImpl <em>EObject Link</em>}' class.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.gef.model.impl.EObjectLinkImpl
   * @see com.metys.merlin.generation.gef.model.impl.ModelPackageImpl#getEObjectLink()
   * @generated
   */
	int EOBJECT_LINK = 4;

  /**
   * The feature id for the '<em><b>Source</b></em>' container reference.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
	int EOBJECT_LINK__SOURCE = ELINK__SOURCE;

  /**
   * The feature id for the '<em><b>Target</b></em>' reference.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
	int EOBJECT_LINK__TARGET = ELINK__TARGET;

  /**
   * The feature id for the '<em><b>Bendpoints</b></em>' attribute list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EOBJECT_LINK__BENDPOINTS = ELINK__BENDPOINTS;

  /**
   * The feature id for the '<em><b>Invalid Message</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EOBJECT_LINK__INVALID_MESSAGE = ELINK__INVALID_MESSAGE;

  /**
   * The feature id for the '<em><b>Transition EObject</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EOBJECT_LINK__TRANSITION_EOBJECT = ELINK_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Source Reference</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EOBJECT_LINK__SOURCE_REFERENCE = ELINK_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Target Reference</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EOBJECT_LINK__TARGET_REFERENCE = ELINK_FEATURE_COUNT + 2;

  /**
   * The number of structural features of the the '<em>EObject Link</em>' class.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
	int EOBJECT_LINK_FEATURE_COUNT = ELINK_FEATURE_COUNT + 3;

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.gef.model.EDiagram <em>EDiagram</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>EDiagram</em>'.
   * @see com.metys.merlin.generation.gef.model.EDiagram
   * @generated
   */
  EClass getEDiagram();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.model.EDiagram#getModelResource <em>Model Resource</em>}'.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Model Resource</em>'.
   * @see com.metys.merlin.generation.gef.model.EDiagram#getModelResource()
   * @see #getEDiagram()
   * @generated
   */
	EAttribute getEDiagram_ModelResource();

  /**
   * Returns the meta object for the attribute list '{@link com.metys.merlin.generation.gef.model.EDiagram#getImportedResources <em>Imported Resources</em>}'.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @return the meta object for the attribute list '<em>Imported Resources</em>'.
   * @see com.metys.merlin.generation.gef.model.EDiagram#getImportedResources()
   * @see #getEDiagram()
   * @generated
   */
	EAttribute getEDiagram_ImportedResources();

  /**
   * Returns the meta object for the containment reference list '{@link com.metys.merlin.generation.gef.model.EDiagram#getContents <em>Contents</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Contents</em>'.
   * @see com.metys.merlin.generation.gef.model.EDiagram#getContents()
   * @see #getEDiagram()
   * @generated
   */
  EReference getEDiagram_Contents();

  /**
   * Returns the meta object for the reference list '{@link com.metys.merlin.generation.gef.model.EDiagram#getAllNodes <em>All Nodes</em>}'.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @return the meta object for the reference list '<em>All Nodes</em>'.
   * @see com.metys.merlin.generation.gef.model.EDiagram#getAllNodes()
   * @see #getEDiagram()
   * @generated
   */
	EReference getEDiagram_AllNodes();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.gef.model.ENode <em>ENode</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>ENode</em>'.
   * @see com.metys.merlin.generation.gef.model.ENode
   * @generated
   */
  EClass getENode();

  /**
   * Returns the meta object for the reference '{@link com.metys.merlin.generation.gef.model.ENode#getEObject <em>EObject</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>EObject</em>'.
   * @see com.metys.merlin.generation.gef.model.ENode#getEObject()
   * @see #getENode()
   * @generated
   */
  EReference getENode_EObject();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.model.ENode#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see com.metys.merlin.generation.gef.model.ENode#getName()
   * @see #getENode()
   * @generated
   */
  EAttribute getENode_Name();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.model.ENode#getLocation <em>Location</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Location</em>'.
   * @see com.metys.merlin.generation.gef.model.ENode#getLocation()
   * @see #getENode()
   * @generated
   */
  EAttribute getENode_Location();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.model.ENode#getWidth <em>Width</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Width</em>'.
   * @see com.metys.merlin.generation.gef.model.ENode#getWidth()
   * @see #getENode()
   * @generated
   */
  EAttribute getENode_Width();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.model.ENode#getHeight <em>Height</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Height</em>'.
   * @see com.metys.merlin.generation.gef.model.ENode#getHeight()
   * @see #getENode()
   * @generated
   */
  EAttribute getENode_Height();

  /**
   * Returns the meta object for the reference list '{@link com.metys.merlin.generation.gef.model.ENode#getIncomingLinks <em>Incoming Links</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference list '<em>Incoming Links</em>'.
   * @see com.metys.merlin.generation.gef.model.ENode#getIncomingLinks()
   * @see #getENode()
   * @generated
   */
  EReference getENode_IncomingLinks();

  /**
   * Returns the meta object for the containment reference list '{@link com.metys.merlin.generation.gef.model.ENode#getOutgoingLinks <em>Outgoing Links</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Outgoing Links</em>'.
   * @see com.metys.merlin.generation.gef.model.ENode#getOutgoingLinks()
   * @see #getENode()
   * @generated
   */
  EReference getENode_OutgoingLinks();

  /**
   * Returns the meta object for the containment reference list '{@link com.metys.merlin.generation.gef.model.ENode#getSubNodes <em>Sub Nodes</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Sub Nodes</em>'.
   * @see com.metys.merlin.generation.gef.model.ENode#getSubNodes()
   * @see #getENode()
   * @generated
   */
  EReference getENode_SubNodes();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.model.ENode#getInvalidMessage <em>Invalid Message</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Invalid Message</em>'.
   * @see com.metys.merlin.generation.gef.model.ENode#getInvalidMessage()
   * @see #getENode()
   * @generated
   */
  EAttribute getENode_InvalidMessage();

  /**
   * Returns the meta object for the reference '{@link com.metys.merlin.generation.gef.model.ENode#getDiagram <em>Diagram</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Diagram</em>'.
   * @see com.metys.merlin.generation.gef.model.ENode#getDiagram()
   * @see #getENode()
   * @generated
   */
  EReference getENode_Diagram();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.gef.model.ELink <em>ELink</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>ELink</em>'.
   * @see com.metys.merlin.generation.gef.model.ELink
   * @generated
   */
  EClass getELink();

  /**
   * Returns the meta object for the container reference '{@link com.metys.merlin.generation.gef.model.ELink#getSource <em>Source</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the container reference '<em>Source</em>'.
   * @see com.metys.merlin.generation.gef.model.ELink#getSource()
   * @see #getELink()
   * @generated
   */
  EReference getELink_Source();

  /**
   * Returns the meta object for the reference '{@link com.metys.merlin.generation.gef.model.ELink#getTarget <em>Target</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Target</em>'.
   * @see com.metys.merlin.generation.gef.model.ELink#getTarget()
   * @see #getELink()
   * @generated
   */
  EReference getELink_Target();

  /**
   * Returns the meta object for the attribute list '{@link com.metys.merlin.generation.gef.model.ELink#getBendpoints <em>Bendpoints</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute list '<em>Bendpoints</em>'.
   * @see com.metys.merlin.generation.gef.model.ELink#getBendpoints()
   * @see #getELink()
   * @generated
   */
  EAttribute getELink_Bendpoints();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.model.ELink#getInvalidMessage <em>Invalid Message</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Invalid Message</em>'.
   * @see com.metys.merlin.generation.gef.model.ELink#getInvalidMessage()
   * @see #getELink()
   * @generated
   */
  EAttribute getELink_InvalidMessage();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.gef.model.EReferenceLink <em>EReference Link</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>EReference Link</em>'.
   * @see com.metys.merlin.generation.gef.model.EReferenceLink
   * @generated
   */
  EClass getEReferenceLink();

  /**
   * Returns the meta object for the reference '{@link com.metys.merlin.generation.gef.model.EReferenceLink#getEReference <em>EReference</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>EReference</em>'.
   * @see com.metys.merlin.generation.gef.model.EReferenceLink#getEReference()
   * @see #getEReferenceLink()
   * @generated
   */
  EReference getEReferenceLink_EReference();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.gef.model.EObjectLink <em>EObject Link</em>}'.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @return the meta object for class '<em>EObject Link</em>'.
   * @see com.metys.merlin.generation.gef.model.EObjectLink
   * @generated
   */
	EClass getEObjectLink();

  /**
   * Returns the meta object for the reference '{@link com.metys.merlin.generation.gef.model.EObjectLink#getTransitionEObject <em>Transition EObject</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Transition EObject</em>'.
   * @see com.metys.merlin.generation.gef.model.EObjectLink#getTransitionEObject()
   * @see #getEObjectLink()
   * @generated
   */
  EReference getEObjectLink_TransitionEObject();

  /**
   * Returns the meta object for the reference '{@link com.metys.merlin.generation.gef.model.EObjectLink#getSourceReference <em>Source Reference</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Source Reference</em>'.
   * @see com.metys.merlin.generation.gef.model.EObjectLink#getSourceReference()
   * @see #getEObjectLink()
   * @generated
   */
  EReference getEObjectLink_SourceReference();

  /**
   * Returns the meta object for the reference '{@link com.metys.merlin.generation.gef.model.EObjectLink#getTargetReference <em>Target Reference</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Target Reference</em>'.
   * @see com.metys.merlin.generation.gef.model.EObjectLink#getTargetReference()
   * @see #getEObjectLink()
   * @generated
   */
  EReference getEObjectLink_TargetReference();

  /**
   * Returns the factory that creates the instances of the model.
   * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
   * @return the factory that creates the instances of the model.
   * @generated
   */
	ModelFactory getModelFactory();

} //ModelPackage
