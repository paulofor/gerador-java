/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package com.metys.merlin.generation.gef.genmodel.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import com.metys.merlin.generation.gef.genmodel.GenFigure;
import com.metys.merlin.generation.gef.genmodel.GenModelPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Gen Figure</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenFigureImpl#getFigureClass <em>Figure Class</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenFigureImpl#getLayoutClass <em>Layout Class</em>}</li>
 *   <li>{@link com.metys.merlin.generation.gef.genmodel.impl.GenFigureImpl#isAdditionalEditableLabel <em>Additional Editable Label</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class GenFigureImpl extends EObjectImpl implements GenFigure {
  /**
   * The default value of the '{@link #getFigureClass() <em>Figure Class</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFigureClass()
   * @generated
   * @ordered
   */
  protected static final String FIGURE_CLASS_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getFigureClass() <em>Figure Class</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFigureClass()
   * @generated
   * @ordered
   */
  protected String figureClass = FIGURE_CLASS_EDEFAULT;

  /**
   * The default value of the '{@link #getLayoutClass() <em>Layout Class</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLayoutClass()
   * @generated
   * @ordered
   */
  protected static final String LAYOUT_CLASS_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getLayoutClass() <em>Layout Class</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLayoutClass()
   * @generated
   * @ordered
   */
  protected String layoutClass = LAYOUT_CLASS_EDEFAULT;

  /**
   * The default value of the '{@link #isAdditionalEditableLabel() <em>Additional Editable Label</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isAdditionalEditableLabel()
   * @generated
   * @ordered
   */
  protected static final boolean ADDITIONAL_EDITABLE_LABEL_EDEFAULT = false;

  /**
   * The cached value of the '{@link #isAdditionalEditableLabel() <em>Additional Editable Label</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isAdditionalEditableLabel()
   * @generated
   * @ordered
   */
  protected boolean additionalEditableLabel = ADDITIONAL_EDITABLE_LABEL_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected GenFigureImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return GenModelPackage.eINSTANCE.getGenFigure();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getFigureClass() {
    return figureClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setFigureClass(String newFigureClass) {
    String oldFigureClass = figureClass;
    figureClass = newFigureClass;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_FIGURE__FIGURE_CLASS, oldFigureClass, figureClass));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getLayoutClass() {
    return layoutClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLayoutClass(String newLayoutClass) {
    String oldLayoutClass = layoutClass;
    layoutClass = newLayoutClass;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_FIGURE__LAYOUT_CLASS, oldLayoutClass, layoutClass));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isAdditionalEditableLabel() {
    return additionalEditableLabel;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setAdditionalEditableLabel(boolean newAdditionalEditableLabel) {
    boolean oldAdditionalEditableLabel = additionalEditableLabel;
    additionalEditableLabel = newAdditionalEditableLabel;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, GenModelPackage.GEN_FIGURE__ADDITIONAL_EDITABLE_LABEL, oldAdditionalEditableLabel, additionalEditableLabel));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_FIGURE__FIGURE_CLASS:
        return getFigureClass();
      case GenModelPackage.GEN_FIGURE__LAYOUT_CLASS:
        return getLayoutClass();
      case GenModelPackage.GEN_FIGURE__ADDITIONAL_EDITABLE_LABEL:
        return isAdditionalEditableLabel() ? Boolean.TRUE : Boolean.FALSE;
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_FIGURE__FIGURE_CLASS:
        setFigureClass((String)newValue);
        return;
      case GenModelPackage.GEN_FIGURE__LAYOUT_CLASS:
        setLayoutClass((String)newValue);
        return;
      case GenModelPackage.GEN_FIGURE__ADDITIONAL_EDITABLE_LABEL:
        setAdditionalEditableLabel(((Boolean)newValue).booleanValue());
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_FIGURE__FIGURE_CLASS:
        setFigureClass(FIGURE_CLASS_EDEFAULT);
        return;
      case GenModelPackage.GEN_FIGURE__LAYOUT_CLASS:
        setLayoutClass(LAYOUT_CLASS_EDEFAULT);
        return;
      case GenModelPackage.GEN_FIGURE__ADDITIONAL_EDITABLE_LABEL:
        setAdditionalEditableLabel(ADDITIONAL_EDITABLE_LABEL_EDEFAULT);
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
      case GenModelPackage.GEN_FIGURE__FIGURE_CLASS:
        return FIGURE_CLASS_EDEFAULT == null ? figureClass != null : !FIGURE_CLASS_EDEFAULT.equals(figureClass);
      case GenModelPackage.GEN_FIGURE__LAYOUT_CLASS:
        return LAYOUT_CLASS_EDEFAULT == null ? layoutClass != null : !LAYOUT_CLASS_EDEFAULT.equals(layoutClass);
      case GenModelPackage.GEN_FIGURE__ADDITIONAL_EDITABLE_LABEL:
        return additionalEditableLabel != ADDITIONAL_EDITABLE_LABEL_EDEFAULT;
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString() {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (figureClass: ");
    result.append(figureClass);
    result.append(", layoutClass: ");
    result.append(layoutClass);
    result.append(", additionalEditableLabel: ");
    result.append(additionalEditableLabel);
    result.append(')');
    return result.toString();
  }

} //GenFigureImpl
