/**
 * <copyright>
 * </copyright>
 *
 * $Id: GenModelPackageImpl.java,v 1.6 2005/07/08 23:58:37 jcheuoua Exp $
 */
package com.metys.merlin.generation.gef.genmodel.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.impl.EPackageImpl;
import org.eclipse.emf.ecore.impl.EcorePackageImpl;
import org.eclipse.emf.mapping.impl.MappingPackageImpl;

import com.metys.merlin.generation.gef.GefPackage;
import com.metys.merlin.generation.gef.genmodel.GenEditPart;
import com.metys.merlin.generation.gef.genmodel.GenEditPartFactory;
import com.metys.merlin.generation.gef.genmodel.GenEditor;
import com.metys.merlin.generation.gef.genmodel.GenFigure;
import com.metys.merlin.generation.gef.genmodel.GenGEFBase;
import com.metys.merlin.generation.gef.genmodel.GenGEFModel;
import com.metys.merlin.generation.gef.genmodel.GenLinkEditPart;
import com.metys.merlin.generation.gef.genmodel.GenModelFactory;
import com.metys.merlin.generation.gef.genmodel.GenModelPackage;
import com.metys.merlin.generation.gef.genmodel.GenNodeEditPart;
import com.metys.merlin.generation.gef.genmodel.GenPaletteComponentsFactory;
import com.metys.merlin.generation.gef.genmodel.GenPaletteConnectionsFactory;
import com.metys.merlin.generation.gef.genmodel.GenSubNodeReference;
import com.metys.merlin.generation.gef.genmodel.GenViewer;
import com.metys.merlin.generation.gef.impl.GefPackageImpl;
import com.metys.merlin.generation.gef.model.ModelPackage;
import com.metys.merlin.generation.gef.model.impl.ModelPackageImpl;
import com.metys.merlin.generation.templates.impl.JETTemplatePackageImpl;
import com.metys.merlin.generation.templates.jetmapping.JETMappingPackage;
import com.metys.merlin.generation.templates.jetmapping.impl.JETMappingPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class GenModelPackageImpl extends EPackageImpl implements GenModelPackage {
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass genGEFBaseEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass genGEFModelEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass genEditorEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass genViewerEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass genEditPartFactoryEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass genEditPartEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass genNodeEditPartEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass genSubNodeReferenceEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass genLinkEditPartEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass genPaletteComponentsFactoryEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass genPaletteConnectionsFactoryEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass genFigureEClass = null;

  /**
   * Creates an instance of the model <b>Package</b>, registered with
   * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
   * package URI value.
   * <p>Note: the correct way to create the package is via the static
   * factory method {@link #init init()}, which also performs
   * initialization of the package, or returns the registered package,
   * if one already exists.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.eclipse.emf.ecore.EPackage.Registry
   * @see com.metys.merlin.generation.gef.genmodel.GenModelPackage#eNS_URI
   * @see #init()
   * @generated
   */
  private GenModelPackageImpl() {
    super(eNS_URI, GenModelFactory.eINSTANCE);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static boolean isInited = false;

  /**
   * Creates, registers, and initializes the <b>Package</b> for this
   * model, and for any others upon which it depends.  Simple
   * dependencies are satisfied by calling this method on all
   * dependent packages before doing anything else.  This method drives
   * initialization for interdependent packages directly, in parallel
   * with this package, itself.
   * <p>Of this package and its interdependencies, all packages which
   * have not yet been registered by their URI values are first created
   * and registered.  The packages are then initialized in two steps:
   * meta-model objects for all of the packages are created before any
   * are initialized, since one package's meta-model objects may refer to
   * those of another.
   * <p>Invocation of this method will not affect any packages that have
   * already been initialized.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #eNS_URI
   * @see #createPackageContents()
   * @see #initializePackageContents()
   * @generated
   */
  public static GenModelPackage init() {
    if (isInited) return (GenModelPackage)EPackage.Registry.INSTANCE.getEPackage(GenModelPackage.eNS_URI);

    // Obtain or create and register package
    GenModelPackageImpl theGenModelPackage = (GenModelPackageImpl)(EPackage.Registry.INSTANCE.getEPackage(eNS_URI) instanceof GenModelPackageImpl ? EPackage.Registry.INSTANCE.getEPackage(eNS_URI) : new GenModelPackageImpl());

    isInited = true;

    // Initialize simple dependencies
    JETTemplatePackageImpl.init();
    EcorePackageImpl.init();
    org.eclipse.emf.codegen.ecore.genmodel.impl.GenModelPackageImpl.init();
    MappingPackageImpl.init();

    // Obtain or create and register interdependencies
    GefPackageImpl theGefPackage = (GefPackageImpl)(EPackage.Registry.INSTANCE.getEPackage(GefPackage.eNS_URI) instanceof GefPackageImpl ? EPackage.Registry.INSTANCE.getEPackage(GefPackage.eNS_URI) : GefPackage.eINSTANCE);
    ModelPackageImpl theModelPackage = (ModelPackageImpl)(EPackage.Registry.INSTANCE.getEPackage(ModelPackage.eNS_URI) instanceof ModelPackageImpl ? EPackage.Registry.INSTANCE.getEPackage(ModelPackage.eNS_URI) : ModelPackage.eINSTANCE);

    // Create package meta-data objects
    theGenModelPackage.createPackageContents();
    theGefPackage.createPackageContents();
    theModelPackage.createPackageContents();

    // Initialize created meta-data
    theGenModelPackage.initializePackageContents();
    theGefPackage.initializePackageContents();
    theModelPackage.initializePackageContents();

    // Mark meta-data to indicate it can't be changed
    theGenModelPackage.freeze();

    return theGenModelPackage;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getGenGEFBase() {
    return genGEFBaseEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGenGEFBase_Name() {
    return (EAttribute)genGEFBaseEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGenGEFBase_PackageName() {
    return (EAttribute)genGEFBaseEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getGenGEFModel() {
    return genGEFModelEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGenGEFModel_OutputDirectoryPath() {
    return (EAttribute)genGEFModelEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGenGEFModel_CopyrightText() {
    return (EAttribute)genGEFModelEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGenGEFModel_PluginID() {
    return (EAttribute)genGEFModelEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGenGEFModel_PluginClass() {
    return (EAttribute)genGEFModelEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenGEFModel_GenModel() {
    return (EReference)genGEFModelEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenGEFModel_GenEditPartFactories() {
    return (EReference)genGEFModelEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenGEFModel_GenEditors() {
    return (EReference)genGEFModelEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenGEFModel_GenViewers() {
    return (EReference)genGEFModelEClass.getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenGEFModel_GenEditParts() {
    return (EReference)genGEFModelEClass.getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGenGEFModel_TemplateDirectory() {
    return (EAttribute)genGEFModelEClass.getEStructuralFeatures().get(9);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getGenEditor() {
    return genEditorEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenEditor_GenEditPartFactory() {
    return (EReference)genEditorEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenEditor_GenPaletteComponentsFactories() {
    return (EReference)genEditorEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenEditor_GenPaletteConnectionsFactories() {
    return (EReference)genEditorEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenEditor_GenGEFModel() {
    return (EReference)genEditorEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getGenViewer() {
    return genViewerEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenViewer_GenEditPartFactory() {
    return (EReference)genViewerEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenViewer_GenGEFModel() {
    return (EReference)genViewerEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getGenEditPartFactory() {
    return genEditPartFactoryEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenEditPartFactory_GenEditParts() {
    return (EReference)genEditPartFactoryEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenEditPartFactory_GenGEFModel() {
    return (EReference)genEditPartFactoryEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getGenEditPart() {
    return genEditPartEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenEditPart_EcoreClass() {
    return (EReference)genEditPartEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenEditPart_GenGEFModel() {
    return (EReference)genEditPartEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getGenNodeEditPart() {
    return genNodeEditPartEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenNodeEditPart_GenFigure() {
    return (EReference)genNodeEditPartEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenNodeEditPart_SubNodeReferences() {
    return (EReference)genNodeEditPartEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGenNodeEditPart_ComponentEditPolicy() {
    return (EAttribute)genNodeEditPartEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGenNodeEditPart_ContainerEditPolicy() {
    return (EAttribute)genNodeEditPartEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGenNodeEditPart_GraphicalEditPolicy() {
    return (EAttribute)genNodeEditPartEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGenNodeEditPart_DirectEditPolicy() {
    return (EAttribute)genNodeEditPartEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getGenSubNodeReference() {
    return genSubNodeReferenceEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenSubNodeReference_Reference() {
    return (EReference)genSubNodeReferenceEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGenSubNodeReference_ParentLayoutClass() {
    return (EAttribute)genSubNodeReferenceEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getGenLinkEditPart() {
    return genLinkEditPartEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenLinkEditPart_SourceReference() {
    return (EReference)genLinkEditPartEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenLinkEditPart_TargetReference() {
    return (EReference)genLinkEditPartEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenLinkEditPart_GenFigure() {
    return (EReference)genLinkEditPartEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getGenPaletteComponentsFactory() {
    return genPaletteComponentsFactoryEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGenPaletteComponentsFactory_Name() {
    return (EAttribute)genPaletteComponentsFactoryEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenPaletteComponentsFactory_GenNodeParts() {
    return (EReference)genPaletteComponentsFactoryEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenPaletteComponentsFactory_GenEditor() {
    return (EReference)genPaletteComponentsFactoryEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getGenPaletteConnectionsFactory() {
    return genPaletteConnectionsFactoryEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGenPaletteConnectionsFactory_Name() {
    return (EAttribute)genPaletteConnectionsFactoryEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenPaletteConnectionsFactory_GenLinkParts() {
    return (EReference)genPaletteConnectionsFactoryEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getGenPaletteConnectionsFactory_GenEditor() {
    return (EReference)genPaletteConnectionsFactoryEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getGenFigure() {
    return genFigureEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGenFigure_FigureClass() {
    return (EAttribute)genFigureEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGenFigure_LayoutClass() {
    return (EAttribute)genFigureEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getGenFigure_AdditionalEditableLabel() {
    return (EAttribute)genFigureEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenModelFactory getGenModelFactory() {
    return (GenModelFactory)getEFactoryInstance();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private boolean isCreated = false;

  /**
   * Creates the meta-model objects for the package.  This method is
   * guarded to have no affect on any invocation but its first.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void createPackageContents() {
    if (isCreated) return;
    isCreated = true;

    // Create classes and their features
    genGEFBaseEClass = createEClass(GEN_GEF_BASE);
    createEAttribute(genGEFBaseEClass, GEN_GEF_BASE__NAME);
    createEAttribute(genGEFBaseEClass, GEN_GEF_BASE__PACKAGE_NAME);

    genGEFModelEClass = createEClass(GEN_GEF_MODEL);
    createEAttribute(genGEFModelEClass, GEN_GEF_MODEL__OUTPUT_DIRECTORY_PATH);
    createEAttribute(genGEFModelEClass, GEN_GEF_MODEL__COPYRIGHT_TEXT);
    createEAttribute(genGEFModelEClass, GEN_GEF_MODEL__PLUGIN_ID);
    createEAttribute(genGEFModelEClass, GEN_GEF_MODEL__PLUGIN_CLASS);
    createEReference(genGEFModelEClass, GEN_GEF_MODEL__GEN_MODEL);
    createEReference(genGEFModelEClass, GEN_GEF_MODEL__GEN_EDIT_PART_FACTORIES);
    createEReference(genGEFModelEClass, GEN_GEF_MODEL__GEN_EDITORS);
    createEReference(genGEFModelEClass, GEN_GEF_MODEL__GEN_VIEWERS);
    createEReference(genGEFModelEClass, GEN_GEF_MODEL__GEN_EDIT_PARTS);
    createEAttribute(genGEFModelEClass, GEN_GEF_MODEL__TEMPLATE_DIRECTORY);

    genEditorEClass = createEClass(GEN_EDITOR);
    createEReference(genEditorEClass, GEN_EDITOR__GEN_EDIT_PART_FACTORY);
    createEReference(genEditorEClass, GEN_EDITOR__GEN_PALETTE_COMPONENTS_FACTORIES);
    createEReference(genEditorEClass, GEN_EDITOR__GEN_PALETTE_CONNECTIONS_FACTORIES);
    createEReference(genEditorEClass, GEN_EDITOR__GEN_GEF_MODEL);

    genViewerEClass = createEClass(GEN_VIEWER);
    createEReference(genViewerEClass, GEN_VIEWER__GEN_EDIT_PART_FACTORY);
    createEReference(genViewerEClass, GEN_VIEWER__GEN_GEF_MODEL);

    genEditPartFactoryEClass = createEClass(GEN_EDIT_PART_FACTORY);
    createEReference(genEditPartFactoryEClass, GEN_EDIT_PART_FACTORY__GEN_EDIT_PARTS);
    createEReference(genEditPartFactoryEClass, GEN_EDIT_PART_FACTORY__GEN_GEF_MODEL);

    genEditPartEClass = createEClass(GEN_EDIT_PART);
    createEReference(genEditPartEClass, GEN_EDIT_PART__ECORE_CLASS);
    createEReference(genEditPartEClass, GEN_EDIT_PART__GEN_GEF_MODEL);

    genNodeEditPartEClass = createEClass(GEN_NODE_EDIT_PART);
    createEReference(genNodeEditPartEClass, GEN_NODE_EDIT_PART__GEN_FIGURE);
    createEReference(genNodeEditPartEClass, GEN_NODE_EDIT_PART__SUB_NODE_REFERENCES);
    createEAttribute(genNodeEditPartEClass, GEN_NODE_EDIT_PART__COMPONENT_EDIT_POLICY);
    createEAttribute(genNodeEditPartEClass, GEN_NODE_EDIT_PART__CONTAINER_EDIT_POLICY);
    createEAttribute(genNodeEditPartEClass, GEN_NODE_EDIT_PART__GRAPHICAL_EDIT_POLICY);
    createEAttribute(genNodeEditPartEClass, GEN_NODE_EDIT_PART__DIRECT_EDIT_POLICY);

    genSubNodeReferenceEClass = createEClass(GEN_SUB_NODE_REFERENCE);
    createEReference(genSubNodeReferenceEClass, GEN_SUB_NODE_REFERENCE__REFERENCE);
    createEAttribute(genSubNodeReferenceEClass, GEN_SUB_NODE_REFERENCE__PARENT_LAYOUT_CLASS);

    genLinkEditPartEClass = createEClass(GEN_LINK_EDIT_PART);
    createEReference(genLinkEditPartEClass, GEN_LINK_EDIT_PART__SOURCE_REFERENCE);
    createEReference(genLinkEditPartEClass, GEN_LINK_EDIT_PART__TARGET_REFERENCE);
    createEReference(genLinkEditPartEClass, GEN_LINK_EDIT_PART__GEN_FIGURE);

    genFigureEClass = createEClass(GEN_FIGURE);
    createEAttribute(genFigureEClass, GEN_FIGURE__FIGURE_CLASS);
    createEAttribute(genFigureEClass, GEN_FIGURE__LAYOUT_CLASS);
    createEAttribute(genFigureEClass, GEN_FIGURE__ADDITIONAL_EDITABLE_LABEL);

    genPaletteComponentsFactoryEClass = createEClass(GEN_PALETTE_COMPONENTS_FACTORY);
    createEAttribute(genPaletteComponentsFactoryEClass, GEN_PALETTE_COMPONENTS_FACTORY__NAME);
    createEReference(genPaletteComponentsFactoryEClass, GEN_PALETTE_COMPONENTS_FACTORY__GEN_NODE_PARTS);
    createEReference(genPaletteComponentsFactoryEClass, GEN_PALETTE_COMPONENTS_FACTORY__GEN_EDITOR);

    genPaletteConnectionsFactoryEClass = createEClass(GEN_PALETTE_CONNECTIONS_FACTORY);
    createEAttribute(genPaletteConnectionsFactoryEClass, GEN_PALETTE_CONNECTIONS_FACTORY__NAME);
    createEReference(genPaletteConnectionsFactoryEClass, GEN_PALETTE_CONNECTIONS_FACTORY__GEN_LINK_PARTS);
    createEReference(genPaletteConnectionsFactoryEClass, GEN_PALETTE_CONNECTIONS_FACTORY__GEN_EDITOR);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private boolean isInitialized = false;

  /**
   * Complete the initialization of the package and its meta-model.  This
   * method is guarded to have no affect on any invocation but its first.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void initializePackageContents() {
    if (isInitialized) return;
    isInitialized = true;

    // Initialize package
    setName(eNAME);
    setNsPrefix(eNS_PREFIX);
    setNsURI(eNS_URI);

    // Obtain other dependent packages
    org.eclipse.emf.codegen.ecore.genmodel.impl.GenModelPackageImpl theGenModelPackage_1 = (org.eclipse.emf.codegen.ecore.genmodel.impl.GenModelPackageImpl)EPackage.Registry.INSTANCE.getEPackage(org.eclipse.emf.codegen.ecore.genmodel.GenModelPackage.eNS_URI);
    JETMappingPackageImpl theJETMappingPackage = (JETMappingPackageImpl)EPackage.Registry.INSTANCE.getEPackage(JETMappingPackage.eNS_URI);
    GefPackageImpl theGefPackage = (GefPackageImpl)EPackage.Registry.INSTANCE.getEPackage(GefPackage.eNS_URI);

    // Add supertypes to classes
    genGEFModelEClass.getESuperTypes().add(this.getGenGEFBase());
    genEditorEClass.getESuperTypes().add(this.getGenGEFBase());
    genViewerEClass.getESuperTypes().add(this.getGenGEFBase());
    genEditPartFactoryEClass.getESuperTypes().add(this.getGenGEFBase());
    genEditPartEClass.getESuperTypes().add(this.getGenGEFBase());
    genNodeEditPartEClass.getESuperTypes().add(this.getGenEditPart());
    genLinkEditPartEClass.getESuperTypes().add(this.getGenEditPart());

    // Initialize classes and features; add operations and parameters
    initEClass(genGEFBaseEClass, GenGEFBase.class, "GenGEFBase", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getGenGEFBase_Name(), ecorePackage.getEString(), "name", null, 0, 1, GenGEFBase.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getGenGEFBase_PackageName(), ecorePackage.getEString(), "packageName", null, 0, 1, GenGEFBase.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(genGEFModelEClass, GenGEFModel.class, "GenGEFModel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getGenGEFModel_OutputDirectoryPath(), ecorePackage.getEString(), "outputDirectoryPath", null, 0, 1, GenGEFModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getGenGEFModel_CopyrightText(), ecorePackage.getEString(), "copyrightText", null, 0, 1, GenGEFModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getGenGEFModel_PluginID(), ecorePackage.getEString(), "pluginID", null, 0, 1, GenGEFModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getGenGEFModel_PluginClass(), ecorePackage.getEString(), "pluginClass", null, 0, 1, GenGEFModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getGenGEFModel_GenModel(), theGenModelPackage_1.getGenModel(), null, "genModel", null, 1, 1, GenGEFModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getGenGEFModel_GenEditPartFactories(), this.getGenEditPartFactory(), this.getGenEditPartFactory_GenGEFModel(), "genEditPartFactories", null, 0, -1, GenGEFModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getGenGEFModel_GenEditors(), this.getGenEditor(), this.getGenEditor_GenGEFModel(), "genEditors", null, 0, -1, GenGEFModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getGenGEFModel_GenViewers(), this.getGenViewer(), this.getGenViewer_GenGEFModel(), "genViewers", null, 0, -1, GenGEFModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getGenGEFModel_GenEditParts(), this.getGenEditPart(), this.getGenEditPart_GenGEFModel(), "genEditParts", null, 0, -1, GenGEFModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getGenGEFModel_TemplateDirectory(), ecorePackage.getEString(), "templateDirectory", null, 0, 1, GenGEFModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    EOperation op = addEOperation(genGEFModelEClass, null, "registerPartInAllEditors");
    addEParameter(op, this.getGenEditPart(), "editPart");

    op = addEOperation(genGEFModelEClass, null, "registerAllPartsInEditor");
    addEParameter(op, this.getGenEditor(), "editor");

    op = addEOperation(genGEFModelEClass, theJETMappingPackage.getJETTemplateMappingRoot(), "getTemplatesInstanceMapping");
    addEParameter(op, theGefPackage.getProgressMonitor(), "progressMonitor");

    initEClass(genEditorEClass, GenEditor.class, "GenEditor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getGenEditor_GenEditPartFactory(), this.getGenEditPartFactory(), null, "genEditPartFactory", null, 1, 1, GenEditor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getGenEditor_GenPaletteComponentsFactories(), this.getGenPaletteComponentsFactory(), this.getGenPaletteComponentsFactory_GenEditor(), "genPaletteComponentsFactories", null, 1, -1, GenEditor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getGenEditor_GenPaletteConnectionsFactories(), this.getGenPaletteConnectionsFactory(), this.getGenPaletteConnectionsFactory_GenEditor(), "genPaletteConnectionsFactories", null, 1, -1, GenEditor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getGenEditor_GenGEFModel(), this.getGenGEFModel(), this.getGenGEFModel_GenEditors(), "genGEFModel", null, 1, 1, GenEditor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(genViewerEClass, GenViewer.class, "GenViewer", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getGenViewer_GenEditPartFactory(), this.getGenEditPartFactory(), null, "genEditPartFactory", null, 1, 1, GenViewer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getGenViewer_GenGEFModel(), this.getGenGEFModel(), this.getGenGEFModel_GenViewers(), "genGEFModel", null, 1, 1, GenViewer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(genEditPartFactoryEClass, GenEditPartFactory.class, "GenEditPartFactory", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getGenEditPartFactory_GenEditParts(), this.getGenEditPart(), null, "genEditParts", null, 0, -1, GenEditPartFactory.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getGenEditPartFactory_GenGEFModel(), this.getGenGEFModel(), this.getGenGEFModel_GenEditPartFactories(), "genGEFModel", null, 1, 1, GenEditPartFactory.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(genEditPartEClass, GenEditPart.class, "GenEditPart", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getGenEditPart_EcoreClass(), ecorePackage.getEClass(), null, "ecoreClass", null, 1, 1, GenEditPart.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getGenEditPart_GenGEFModel(), this.getGenGEFModel(), this.getGenGEFModel_GenEditParts(), "genGEFModel", null, 1, 1, GenEditPart.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(genNodeEditPartEClass, GenNodeEditPart.class, "GenNodeEditPart", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getGenNodeEditPart_GenFigure(), this.getGenFigure(), null, "genFigure", null, 0, 1, GenNodeEditPart.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getGenNodeEditPart_SubNodeReferences(), this.getGenSubNodeReference(), null, "subNodeReferences", null, 0, -1, GenNodeEditPart.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getGenNodeEditPart_ComponentEditPolicy(), ecorePackage.getEBoolean(), "componentEditPolicy", "true", 0, 1, GenNodeEditPart.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getGenNodeEditPart_ContainerEditPolicy(), ecorePackage.getEBoolean(), "containerEditPolicy", "true", 0, 1, GenNodeEditPart.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getGenNodeEditPart_GraphicalEditPolicy(), ecorePackage.getEBoolean(), "graphicalEditPolicy", "true", 0, 1, GenNodeEditPart.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getGenNodeEditPart_DirectEditPolicy(), ecorePackage.getEBoolean(), "directEditPolicy", "true", 0, 1, GenNodeEditPart.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(genSubNodeReferenceEClass, GenSubNodeReference.class, "GenSubNodeReference", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getGenSubNodeReference_Reference(), ecorePackage.getEReference(), null, "reference", null, 1, 1, GenSubNodeReference.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getGenSubNodeReference_ParentLayoutClass(), ecorePackage.getEString(), "parentLayoutClass", null, 0, 1, GenSubNodeReference.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(genLinkEditPartEClass, GenLinkEditPart.class, "GenLinkEditPart", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getGenLinkEditPart_SourceReference(), ecorePackage.getEReference(), null, "sourceReference", null, 1, 1, GenLinkEditPart.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getGenLinkEditPart_TargetReference(), ecorePackage.getEReference(), null, "targetReference", null, 1, 1, GenLinkEditPart.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getGenLinkEditPart_GenFigure(), this.getGenFigure(), null, "genFigure", null, 0, 1, GenLinkEditPart.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(genFigureEClass, GenFigure.class, "GenFigure", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getGenFigure_FigureClass(), ecorePackage.getEString(), "figureClass", null, 0, 1, GenFigure.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getGenFigure_LayoutClass(), ecorePackage.getEString(), "layoutClass", null, 0, 1, GenFigure.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getGenFigure_AdditionalEditableLabel(), ecorePackage.getEBoolean(), "additionalEditableLabel", null, 0, 1, GenFigure.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(genPaletteComponentsFactoryEClass, GenPaletteComponentsFactory.class, "GenPaletteComponentsFactory", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getGenPaletteComponentsFactory_Name(), ecorePackage.getEString(), "name", null, 0, 1, GenPaletteComponentsFactory.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getGenPaletteComponentsFactory_GenNodeParts(), this.getGenNodeEditPart(), null, "genNodeParts", null, 0, -1, GenPaletteComponentsFactory.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getGenPaletteComponentsFactory_GenEditor(), this.getGenEditor(), this.getGenEditor_GenPaletteComponentsFactories(), "genEditor", null, 1, 1, GenPaletteComponentsFactory.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(genPaletteConnectionsFactoryEClass, GenPaletteConnectionsFactory.class, "GenPaletteConnectionsFactory", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getGenPaletteConnectionsFactory_Name(), ecorePackage.getEString(), "name", null, 0, 1, GenPaletteConnectionsFactory.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getGenPaletteConnectionsFactory_GenLinkParts(), this.getGenLinkEditPart(), null, "genLinkParts", null, 0, -1, GenPaletteConnectionsFactory.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getGenPaletteConnectionsFactory_GenEditor(), this.getGenEditor(), this.getGenEditor_GenPaletteConnectionsFactories(), "genEditor", null, 1, 1, GenPaletteConnectionsFactory.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
  }

} //GenModelPackageImpl
