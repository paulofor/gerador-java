/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.parts;

import java.util.List;

import org.eclipse.draw2d.ChopboxAnchor;
import org.eclipse.draw2d.ConnectionAnchor;
import org.eclipse.draw2d.ConnectionLayer;
import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.PositionConstants;
import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.draw2d.geometry.Point;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.edit.ui.provider.AdapterFactoryLabelProvider;
import org.eclipse.gef.ConnectionEditPart;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.GraphicalEditPart;
import org.eclipse.gef.LayerConstants;
import org.eclipse.gef.NodeEditPart;
import org.eclipse.gef.Request;
import org.eclipse.gef.RequestConstants;
import org.eclipse.gef.tools.DirectEditManager;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.PlatformUI;

import com.metys.merlin.generation.gef.figures.ENodeFigure;
import com.metys.merlin.generation.gef.model.ENode;
import com.metys.merlin.generation.gef.model.ModelPackage;
import com.metys.merlin.generation.gef.policies.ENodeComponentEditPolicy;
import com.metys.merlin.generation.gef.policies.ENodeDirectEditPolicy;
import com.metys.merlin.generation.gef.policies.ENodeGraphicalNodeEditPolicy;
import com.metys.merlin.generation.gef.policies.ENodeLayoutEditPolicy;

/**
 * @author jcheuoua
 * @version $Revision: 1.3 $
 */
public class ENodeEditPart extends GraphicalComponentEditPart implements NodeEditPart {

  protected DirectEditManager manager;
  protected AdapterFactoryLabelProvider labelProvider;

  /**
   * Constructor for ENodeEditPart.
   * @param adapterFactory AdapterFactory
   */
  public ENodeEditPart(AdapterFactory adapterFactory) {
    super(adapterFactory);
  }

  /**
   * Constructor for ENodeEditPart.
   * @param eObject EObject
   * @param adapterFactory AdapterFactory
   */
  public ENodeEditPart(EObject eObject, AdapterFactory adapterFactory) {
    this(adapterFactory);
    setModel(eObject);
  }

  /**
   * Method getLabelProvider.
   * @return AdapterFactoryLabelProvider
   */
  protected AdapterFactoryLabelProvider getLabelProvider() {
    if (labelProvider == null)
      labelProvider = new AdapterFactoryLabelProvider(adapterFactory);
    return labelProvider;
  }

  /**
   * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#createFigure()
   */
  protected IFigure createFigure() {
    Label l = new Label(getImage());
    l.setLabelAlignment(PositionConstants.CENTER);
    return new ENodeFigure(l);
  }
  
  /**
   * Method getContentPane.
   * @return IFigure
   * @see org.eclipse.gef.GraphicalEditPart#getContentPane()
   */
  public IFigure getContentPane() {
    return ((ENodeFigure) getFigure()).getContentPane();
  }
  
  public void refreshVisuals() {
    String name = getENode().getName();
    if (name == null || name.trim().length() == 0)
      name = getLabelProvider().getText(getENode().getEObject());
    Label l = (Label) ((ENodeFigure) getFigure()).getHeader();
    l.setText(name);

    Point loc = getENode().getLocation();
    Dimension size = new Dimension((int) getENode().getWidth(), (int) getENode().getHeight());
    Rectangle r = new Rectangle(loc, size);

    if (getParent() instanceof GraphicalEditPart)
      ((GraphicalEditPart) getParent()).setLayoutConstraint(this, getFigure(), r);
  }

  /**
   * @see org.eclipse.gef.EditPart#performRequest(org.eclipse.gef.Request)
   */
  public void performRequest(Request request) {
    if (request.getType() == RequestConstants.REQ_DIRECT_EDIT) {
      EditPolicy directEditPolicy = getEditPolicy(EditPolicy.DIRECT_EDIT_ROLE);
      if (directEditPolicy instanceof ENodeDirectEditPolicy)
        ((ENodeDirectEditPolicy)directEditPolicy).handleDirectEditRequest(request);      
    }
  }  

  /**
   * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#getModelSourceConnections()
   */
  protected List getModelSourceConnections() {
    return getENode().getOutgoingLinks();
  }

  /**
   * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#getModelTargetConnections()
   */
  protected List getModelTargetConnections() {
    return getENode().getIncomingLinks();
  }

  /**
   * Method getENode.
   * @return ENode
   */
  public ENode getENode() {
    return (ENode) getModel();
  }  
  
  /**
   * Method getConnectionLayer.
   * @return ConnectionLayer
   */
  public ConnectionLayer getConnectionLayer() {
    return (ConnectionLayer) getLayer(LayerConstants.CONNECTION_LAYER);
  }

  /**
   * Method handlePropertyChanged.
   * @param msg Notification
   */
  protected void handlePropertyChanged(Notification msg) {
    switch (msg.getFeatureID(ENode.class)) {
    case ModelPackage.ENODE__LOCATION:
    case ModelPackage.ENODE__WIDTH:
    case ModelPackage.ENODE__HEIGHT:
    case ModelPackage.ENODE__NAME:
      refreshVisuals();
      break;
    case ModelPackage.ENODE__OUTGOING_LINKS:
      refreshSourceConnections();
      break;
    case ModelPackage.ENODE__INCOMING_LINKS:
      refreshTargetConnections();
      break;
    case ModelPackage.ENODE__SUB_NODES:
      refreshChildren();
      break;
    }
  }

  /**
   * Method getModelChildren.
   * @return List
   */
  public List getModelChildren() {
    return getENode().getSubNodes();
  }

  /**
   * @return Image
   */
  protected Image getImage() {
    Image image = getLabelProvider().getImage(getENode().getEObject());
    if (image == null)
      image = PlatformUI.getWorkbench().getSharedImages().getImage(ISharedImages.IMG_OBJ_ELEMENT);
    return image;
  }

  /**
   * Method getSourceConnectionAnchor.
   * @param connection ConnectionEditPart
   * @return ConnectionAnchor
   * @see org.eclipse.gef.NodeEditPart#getSourceConnectionAnchor(ConnectionEditPart)
   */
  public ConnectionAnchor getSourceConnectionAnchor(ConnectionEditPart connection) {
    return new ChopboxAnchor(getFigure());
  }

  /**
   * Method getSourceConnectionAnchor.
   * @param request Request
   * @return ConnectionAnchor
   * @see org.eclipse.gef.NodeEditPart#getSourceConnectionAnchor(Request)
   */
  public ConnectionAnchor getSourceConnectionAnchor(Request request) {
    return new ChopboxAnchor(getFigure());
  }

  /**
   * Method getTargetConnectionAnchor.
   * @param connection ConnectionEditPart
   * @return ConnectionAnchor
   * @see org.eclipse.gef.NodeEditPart#getTargetConnectionAnchor(ConnectionEditPart)
   */
  public ConnectionAnchor getTargetConnectionAnchor(ConnectionEditPart connection) {
    return new ChopboxAnchor(getFigure());
  }

  /**
   * Method getTargetConnectionAnchor.
   * @param request Request
   * @return ConnectionAnchor
   * @see org.eclipse.gef.NodeEditPart#getTargetConnectionAnchor(Request)
   */
  public ConnectionAnchor getTargetConnectionAnchor(Request request) {
    return new ChopboxAnchor(getFigure());
  }
  
  /**
   * @see org.eclipse.gef.editparts.AbstractEditPart#createEditPolicies()
   */
  protected void createEditPolicies() {
    installEditPolicy(EditPolicy.LAYOUT_ROLE, new ENodeLayoutEditPolicy());
    installEditPolicy(EditPolicy.COMPONENT_ROLE, new ENodeComponentEditPolicy());
    installEditPolicy(EditPolicy.DIRECT_EDIT_ROLE, new ENodeDirectEditPolicy());
    installEditPolicy(EditPolicy.GRAPHICAL_NODE_ROLE, new ENodeGraphicalNodeEditPolicy());        
  }

  public void disableNotifications() {
    notificationsEnabled = false;
  }

  public void enableNotifications() {
    notificationsEnabled = true;
  }
}
