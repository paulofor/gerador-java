/**
 * <copyright>
 * </copyright>
 *
 * $Id: GenModelPackage.java,v 1.5 2005/07/08 23:51:28 jcheuoua Exp $
 */
package com.metys.merlin.generation.gef.genmodel;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see com.metys.merlin.generation.gef.genmodel.GenModelFactory
 * @model kind="package"
 * @generated
 */
public interface GenModelPackage extends EPackage{
  /**
   * The package name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNAME = "genmodel";

  /**
   * The package namespace URI.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_URI = "http://www.metys.com/merlin/generation/gef/genmodel.ecore";

  /**
   * The package namespace name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_PREFIX = "gef.genmodel";

  /**
   * The singleton instance of the package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  GenModelPackage eINSTANCE = com.metys.merlin.generation.gef.genmodel.impl.GenModelPackageImpl.init();

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.gef.genmodel.impl.GenGEFBaseImpl <em>Gen GEF Base</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenGEFBaseImpl
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenModelPackageImpl#getGenGEFBase()
   * @generated
   */
  int GEN_GEF_BASE = 0;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_GEF_BASE__NAME = 0;

  /**
   * The feature id for the '<em><b>Package Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_GEF_BASE__PACKAGE_NAME = 1;

  /**
   * The number of structural features of the the '<em>Gen GEF Base</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_GEF_BASE_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.gef.genmodel.impl.GenGEFModelImpl <em>Gen GEF Model</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenGEFModelImpl
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenModelPackageImpl#getGenGEFModel()
   * @generated
   */
  int GEN_GEF_MODEL = 1;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_GEF_MODEL__NAME = GEN_GEF_BASE__NAME;

  /**
   * The feature id for the '<em><b>Package Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_GEF_MODEL__PACKAGE_NAME = GEN_GEF_BASE__PACKAGE_NAME;

  /**
   * The feature id for the '<em><b>Output Directory Path</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_GEF_MODEL__OUTPUT_DIRECTORY_PATH = GEN_GEF_BASE_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Copyright Text</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_GEF_MODEL__COPYRIGHT_TEXT = GEN_GEF_BASE_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Plugin ID</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_GEF_MODEL__PLUGIN_ID = GEN_GEF_BASE_FEATURE_COUNT + 2;

  /**
   * The feature id for the '<em><b>Plugin Class</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_GEF_MODEL__PLUGIN_CLASS = GEN_GEF_BASE_FEATURE_COUNT + 3;

  /**
   * The feature id for the '<em><b>Gen Model</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_GEF_MODEL__GEN_MODEL = GEN_GEF_BASE_FEATURE_COUNT + 4;

  /**
   * The feature id for the '<em><b>Gen Edit Part Factories</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_GEF_MODEL__GEN_EDIT_PART_FACTORIES = GEN_GEF_BASE_FEATURE_COUNT + 5;

  /**
   * The feature id for the '<em><b>Gen Editors</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_GEF_MODEL__GEN_EDITORS = GEN_GEF_BASE_FEATURE_COUNT + 6;

  /**
   * The feature id for the '<em><b>Gen Viewers</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_GEF_MODEL__GEN_VIEWERS = GEN_GEF_BASE_FEATURE_COUNT + 7;

  /**
   * The feature id for the '<em><b>Gen Edit Parts</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_GEF_MODEL__GEN_EDIT_PARTS = GEN_GEF_BASE_FEATURE_COUNT + 8;

  /**
   * The feature id for the '<em><b>Template Directory</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_GEF_MODEL__TEMPLATE_DIRECTORY = GEN_GEF_BASE_FEATURE_COUNT + 9;

  /**
   * The number of structural features of the the '<em>Gen GEF Model</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_GEF_MODEL_FEATURE_COUNT = GEN_GEF_BASE_FEATURE_COUNT + 10;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.gef.genmodel.impl.GenEditorImpl <em>Gen Editor</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenEditorImpl
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenModelPackageImpl#getGenEditor()
   * @generated
   */
  int GEN_EDITOR = 2;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_EDITOR__NAME = GEN_GEF_BASE__NAME;

  /**
   * The feature id for the '<em><b>Package Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_EDITOR__PACKAGE_NAME = GEN_GEF_BASE__PACKAGE_NAME;

  /**
   * The feature id for the '<em><b>Gen Edit Part Factory</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_EDITOR__GEN_EDIT_PART_FACTORY = GEN_GEF_BASE_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Gen Palette Components Factories</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_EDITOR__GEN_PALETTE_COMPONENTS_FACTORIES = GEN_GEF_BASE_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Gen Palette Connections Factories</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_EDITOR__GEN_PALETTE_CONNECTIONS_FACTORIES = GEN_GEF_BASE_FEATURE_COUNT + 2;

  /**
   * The feature id for the '<em><b>Gen GEF Model</b></em>' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_EDITOR__GEN_GEF_MODEL = GEN_GEF_BASE_FEATURE_COUNT + 3;

  /**
   * The number of structural features of the the '<em>Gen Editor</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_EDITOR_FEATURE_COUNT = GEN_GEF_BASE_FEATURE_COUNT + 4;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.gef.genmodel.impl.GenViewerImpl <em>Gen Viewer</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenViewerImpl
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenModelPackageImpl#getGenViewer()
   * @generated
   */
  int GEN_VIEWER = 3;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_VIEWER__NAME = GEN_GEF_BASE__NAME;

  /**
   * The feature id for the '<em><b>Package Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_VIEWER__PACKAGE_NAME = GEN_GEF_BASE__PACKAGE_NAME;

  /**
   * The feature id for the '<em><b>Gen Edit Part Factory</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_VIEWER__GEN_EDIT_PART_FACTORY = GEN_GEF_BASE_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Gen GEF Model</b></em>' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_VIEWER__GEN_GEF_MODEL = GEN_GEF_BASE_FEATURE_COUNT + 1;

  /**
   * The number of structural features of the the '<em>Gen Viewer</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_VIEWER_FEATURE_COUNT = GEN_GEF_BASE_FEATURE_COUNT + 2;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.gef.genmodel.impl.GenEditPartFactoryImpl <em>Gen Edit Part Factory</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenEditPartFactoryImpl
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenModelPackageImpl#getGenEditPartFactory()
   * @generated
   */
  int GEN_EDIT_PART_FACTORY = 4;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_EDIT_PART_FACTORY__NAME = GEN_GEF_BASE__NAME;

  /**
   * The feature id for the '<em><b>Package Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_EDIT_PART_FACTORY__PACKAGE_NAME = GEN_GEF_BASE__PACKAGE_NAME;

  /**
   * The feature id for the '<em><b>Gen Edit Parts</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_EDIT_PART_FACTORY__GEN_EDIT_PARTS = GEN_GEF_BASE_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Gen GEF Model</b></em>' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_EDIT_PART_FACTORY__GEN_GEF_MODEL = GEN_GEF_BASE_FEATURE_COUNT + 1;

  /**
   * The number of structural features of the the '<em>Gen Edit Part Factory</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_EDIT_PART_FACTORY_FEATURE_COUNT = GEN_GEF_BASE_FEATURE_COUNT + 2;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.gef.genmodel.impl.GenEditPartImpl <em>Gen Edit Part</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenEditPartImpl
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenModelPackageImpl#getGenEditPart()
   * @generated
   */
  int GEN_EDIT_PART = 5;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_EDIT_PART__NAME = GEN_GEF_BASE__NAME;

  /**
   * The feature id for the '<em><b>Package Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_EDIT_PART__PACKAGE_NAME = GEN_GEF_BASE__PACKAGE_NAME;

  /**
   * The feature id for the '<em><b>Ecore Class</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_EDIT_PART__ECORE_CLASS = GEN_GEF_BASE_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Gen GEF Model</b></em>' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_EDIT_PART__GEN_GEF_MODEL = GEN_GEF_BASE_FEATURE_COUNT + 1;

  /**
   * The number of structural features of the the '<em>Gen Edit Part</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_EDIT_PART_FEATURE_COUNT = GEN_GEF_BASE_FEATURE_COUNT + 2;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.gef.genmodel.impl.GenNodeEditPartImpl <em>Gen Node Edit Part</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenNodeEditPartImpl
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenModelPackageImpl#getGenNodeEditPart()
   * @generated
   */
  int GEN_NODE_EDIT_PART = 6;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_NODE_EDIT_PART__NAME = GEN_EDIT_PART__NAME;

  /**
   * The feature id for the '<em><b>Package Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_NODE_EDIT_PART__PACKAGE_NAME = GEN_EDIT_PART__PACKAGE_NAME;

  /**
   * The feature id for the '<em><b>Ecore Class</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_NODE_EDIT_PART__ECORE_CLASS = GEN_EDIT_PART__ECORE_CLASS;

  /**
   * The feature id for the '<em><b>Gen GEF Model</b></em>' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_NODE_EDIT_PART__GEN_GEF_MODEL = GEN_EDIT_PART__GEN_GEF_MODEL;

  /**
   * The feature id for the '<em><b>Gen Figure</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_NODE_EDIT_PART__GEN_FIGURE = GEN_EDIT_PART_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Sub Node References</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_NODE_EDIT_PART__SUB_NODE_REFERENCES = GEN_EDIT_PART_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Component Edit Policy</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_NODE_EDIT_PART__COMPONENT_EDIT_POLICY = GEN_EDIT_PART_FEATURE_COUNT + 2;

  /**
   * The feature id for the '<em><b>Container Edit Policy</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_NODE_EDIT_PART__CONTAINER_EDIT_POLICY = GEN_EDIT_PART_FEATURE_COUNT + 3;

  /**
   * The feature id for the '<em><b>Graphical Edit Policy</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_NODE_EDIT_PART__GRAPHICAL_EDIT_POLICY = GEN_EDIT_PART_FEATURE_COUNT + 4;

  /**
   * The feature id for the '<em><b>Direct Edit Policy</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_NODE_EDIT_PART__DIRECT_EDIT_POLICY = GEN_EDIT_PART_FEATURE_COUNT + 5;

  /**
   * The number of structural features of the the '<em>Gen Node Edit Part</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_NODE_EDIT_PART_FEATURE_COUNT = GEN_EDIT_PART_FEATURE_COUNT + 6;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.gef.genmodel.impl.GenSubNodeReferenceImpl <em>Gen Sub Node Reference</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenSubNodeReferenceImpl
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenModelPackageImpl#getGenSubNodeReference()
   * @generated
   */
  int GEN_SUB_NODE_REFERENCE = 7;

  /**
   * The feature id for the '<em><b>Reference</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_SUB_NODE_REFERENCE__REFERENCE = 0;

  /**
   * The feature id for the '<em><b>Parent Layout Class</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_SUB_NODE_REFERENCE__PARENT_LAYOUT_CLASS = 1;

  /**
   * The number of structural features of the the '<em>Gen Sub Node Reference</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_SUB_NODE_REFERENCE_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.gef.genmodel.impl.GenLinkEditPartImpl <em>Gen Link Edit Part</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenLinkEditPartImpl
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenModelPackageImpl#getGenLinkEditPart()
   * @generated
   */
  int GEN_LINK_EDIT_PART = 8;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_LINK_EDIT_PART__NAME = GEN_EDIT_PART__NAME;

  /**
   * The feature id for the '<em><b>Package Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_LINK_EDIT_PART__PACKAGE_NAME = GEN_EDIT_PART__PACKAGE_NAME;

  /**
   * The feature id for the '<em><b>Ecore Class</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_LINK_EDIT_PART__ECORE_CLASS = GEN_EDIT_PART__ECORE_CLASS;

  /**
   * The feature id for the '<em><b>Gen GEF Model</b></em>' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_LINK_EDIT_PART__GEN_GEF_MODEL = GEN_EDIT_PART__GEN_GEF_MODEL;

  /**
   * The feature id for the '<em><b>Source Reference</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_LINK_EDIT_PART__SOURCE_REFERENCE = GEN_EDIT_PART_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Target Reference</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_LINK_EDIT_PART__TARGET_REFERENCE = GEN_EDIT_PART_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Gen Figure</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_LINK_EDIT_PART__GEN_FIGURE = GEN_EDIT_PART_FEATURE_COUNT + 2;

  /**
   * The number of structural features of the the '<em>Gen Link Edit Part</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_LINK_EDIT_PART_FEATURE_COUNT = GEN_EDIT_PART_FEATURE_COUNT + 3;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.gef.genmodel.impl.GenPaletteComponentsFactoryImpl <em>Gen Palette Components Factory</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenPaletteComponentsFactoryImpl
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenModelPackageImpl#getGenPaletteComponentsFactory()
   * @generated
   */
  int GEN_PALETTE_COMPONENTS_FACTORY = 10;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.gef.genmodel.impl.GenPaletteConnectionsFactoryImpl <em>Gen Palette Connections Factory</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenPaletteConnectionsFactoryImpl
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenModelPackageImpl#getGenPaletteConnectionsFactory()
   * @generated
   */
  int GEN_PALETTE_CONNECTIONS_FACTORY = 11;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.gef.genmodel.impl.GenFigureImpl <em>Gen Figure</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenFigureImpl
   * @see com.metys.merlin.generation.gef.genmodel.impl.GenModelPackageImpl#getGenFigure()
   * @generated
   */
  int GEN_FIGURE = 9;

  /**
   * The feature id for the '<em><b>Figure Class</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_FIGURE__FIGURE_CLASS = 0;

  /**
   * The feature id for the '<em><b>Layout Class</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_FIGURE__LAYOUT_CLASS = 1;

  /**
   * The feature id for the '<em><b>Additional Editable Label</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_FIGURE__ADDITIONAL_EDITABLE_LABEL = 2;

  /**
   * The number of structural features of the the '<em>Gen Figure</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_FIGURE_FEATURE_COUNT = 3;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_PALETTE_COMPONENTS_FACTORY__NAME = 0;

  /**
   * The feature id for the '<em><b>Gen Node Parts</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_PALETTE_COMPONENTS_FACTORY__GEN_NODE_PARTS = 1;

  /**
   * The feature id for the '<em><b>Gen Editor</b></em>' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_PALETTE_COMPONENTS_FACTORY__GEN_EDITOR = 2;

  /**
   * The number of structural features of the the '<em>Gen Palette Components Factory</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_PALETTE_COMPONENTS_FACTORY_FEATURE_COUNT = 3;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_PALETTE_CONNECTIONS_FACTORY__NAME = 0;

  /**
   * The feature id for the '<em><b>Gen Link Parts</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_PALETTE_CONNECTIONS_FACTORY__GEN_LINK_PARTS = 1;

  /**
   * The feature id for the '<em><b>Gen Editor</b></em>' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_PALETTE_CONNECTIONS_FACTORY__GEN_EDITOR = 2;

  /**
   * The number of structural features of the the '<em>Gen Palette Connections Factory</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int GEN_PALETTE_CONNECTIONS_FACTORY_FEATURE_COUNT = 3;

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.gef.genmodel.GenGEFBase <em>Gen GEF Base</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Gen GEF Base</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenGEFBase
   * @generated
   */
  EClass getGenGEFBase();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.genmodel.GenGEFBase#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenGEFBase#getName()
   * @see #getGenGEFBase()
   * @generated
   */
  EAttribute getGenGEFBase_Name();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.genmodel.GenGEFBase#getPackageName <em>Package Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Package Name</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenGEFBase#getPackageName()
   * @see #getGenGEFBase()
   * @generated
   */
  EAttribute getGenGEFBase_PackageName();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel <em>Gen GEF Model</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Gen GEF Model</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenGEFModel
   * @generated
   */
  EClass getGenGEFModel();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getOutputDirectoryPath <em>Output Directory Path</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Output Directory Path</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenGEFModel#getOutputDirectoryPath()
   * @see #getGenGEFModel()
   * @generated
   */
  EAttribute getGenGEFModel_OutputDirectoryPath();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getCopyrightText <em>Copyright Text</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Copyright Text</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenGEFModel#getCopyrightText()
   * @see #getGenGEFModel()
   * @generated
   */
  EAttribute getGenGEFModel_CopyrightText();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getPluginID <em>Plugin ID</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Plugin ID</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenGEFModel#getPluginID()
   * @see #getGenGEFModel()
   * @generated
   */
  EAttribute getGenGEFModel_PluginID();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getPluginClass <em>Plugin Class</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Plugin Class</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenGEFModel#getPluginClass()
   * @see #getGenGEFModel()
   * @generated
   */
  EAttribute getGenGEFModel_PluginClass();

  /**
   * Returns the meta object for the reference '{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getGenModel <em>Gen Model</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Gen Model</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenGEFModel#getGenModel()
   * @see #getGenGEFModel()
   * @generated
   */
  EReference getGenGEFModel_GenModel();

  /**
   * Returns the meta object for the containment reference list '{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getGenEditPartFactories <em>Gen Edit Part Factories</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Gen Edit Part Factories</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenGEFModel#getGenEditPartFactories()
   * @see #getGenGEFModel()
   * @generated
   */
  EReference getGenGEFModel_GenEditPartFactories();

  /**
   * Returns the meta object for the containment reference list '{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getGenEditors <em>Gen Editors</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Gen Editors</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenGEFModel#getGenEditors()
   * @see #getGenGEFModel()
   * @generated
   */
  EReference getGenGEFModel_GenEditors();

  /**
   * Returns the meta object for the containment reference list '{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getGenViewers <em>Gen Viewers</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Gen Viewers</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenGEFModel#getGenViewers()
   * @see #getGenGEFModel()
   * @generated
   */
  EReference getGenGEFModel_GenViewers();

  /**
   * Returns the meta object for the containment reference list '{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getGenEditParts <em>Gen Edit Parts</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Gen Edit Parts</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenGEFModel#getGenEditParts()
   * @see #getGenGEFModel()
   * @generated
   */
  EReference getGenGEFModel_GenEditParts();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.genmodel.GenGEFModel#getTemplateDirectory <em>Template Directory</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Template Directory</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenGEFModel#getTemplateDirectory()
   * @see #getGenGEFModel()
   * @generated
   */
  EAttribute getGenGEFModel_TemplateDirectory();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.gef.genmodel.GenEditor <em>Gen Editor</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Gen Editor</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenEditor
   * @generated
   */
  EClass getGenEditor();

  /**
   * Returns the meta object for the reference '{@link com.metys.merlin.generation.gef.genmodel.GenEditor#getGenEditPartFactory <em>Gen Edit Part Factory</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Gen Edit Part Factory</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenEditor#getGenEditPartFactory()
   * @see #getGenEditor()
   * @generated
   */
  EReference getGenEditor_GenEditPartFactory();

  /**
   * Returns the meta object for the containment reference list '{@link com.metys.merlin.generation.gef.genmodel.GenEditor#getGenPaletteComponentsFactories <em>Gen Palette Components Factories</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Gen Palette Components Factories</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenEditor#getGenPaletteComponentsFactories()
   * @see #getGenEditor()
   * @generated
   */
  EReference getGenEditor_GenPaletteComponentsFactories();

  /**
   * Returns the meta object for the containment reference list '{@link com.metys.merlin.generation.gef.genmodel.GenEditor#getGenPaletteConnectionsFactories <em>Gen Palette Connections Factories</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Gen Palette Connections Factories</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenEditor#getGenPaletteConnectionsFactories()
   * @see #getGenEditor()
   * @generated
   */
  EReference getGenEditor_GenPaletteConnectionsFactories();

  /**
   * Returns the meta object for the container reference '{@link com.metys.merlin.generation.gef.genmodel.GenEditor#getGenGEFModel <em>Gen GEF Model</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the container reference '<em>Gen GEF Model</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenEditor#getGenGEFModel()
   * @see #getGenEditor()
   * @generated
   */
  EReference getGenEditor_GenGEFModel();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.gef.genmodel.GenViewer <em>Gen Viewer</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Gen Viewer</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenViewer
   * @generated
   */
  EClass getGenViewer();

  /**
   * Returns the meta object for the reference '{@link com.metys.merlin.generation.gef.genmodel.GenViewer#getGenEditPartFactory <em>Gen Edit Part Factory</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Gen Edit Part Factory</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenViewer#getGenEditPartFactory()
   * @see #getGenViewer()
   * @generated
   */
  EReference getGenViewer_GenEditPartFactory();

  /**
   * Returns the meta object for the container reference '{@link com.metys.merlin.generation.gef.genmodel.GenViewer#getGenGEFModel <em>Gen GEF Model</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the container reference '<em>Gen GEF Model</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenViewer#getGenGEFModel()
   * @see #getGenViewer()
   * @generated
   */
  EReference getGenViewer_GenGEFModel();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.gef.genmodel.GenEditPartFactory <em>Gen Edit Part Factory</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Gen Edit Part Factory</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenEditPartFactory
   * @generated
   */
  EClass getGenEditPartFactory();

  /**
   * Returns the meta object for the reference list '{@link com.metys.merlin.generation.gef.genmodel.GenEditPartFactory#getGenEditParts <em>Gen Edit Parts</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference list '<em>Gen Edit Parts</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenEditPartFactory#getGenEditParts()
   * @see #getGenEditPartFactory()
   * @generated
   */
  EReference getGenEditPartFactory_GenEditParts();

  /**
   * Returns the meta object for the container reference '{@link com.metys.merlin.generation.gef.genmodel.GenEditPartFactory#getGenGEFModel <em>Gen GEF Model</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the container reference '<em>Gen GEF Model</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenEditPartFactory#getGenGEFModel()
   * @see #getGenEditPartFactory()
   * @generated
   */
  EReference getGenEditPartFactory_GenGEFModel();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.gef.genmodel.GenEditPart <em>Gen Edit Part</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Gen Edit Part</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenEditPart
   * @generated
   */
  EClass getGenEditPart();

  /**
   * Returns the meta object for the reference '{@link com.metys.merlin.generation.gef.genmodel.GenEditPart#getEcoreClass <em>Ecore Class</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Ecore Class</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenEditPart#getEcoreClass()
   * @see #getGenEditPart()
   * @generated
   */
  EReference getGenEditPart_EcoreClass();

  /**
   * Returns the meta object for the container reference '{@link com.metys.merlin.generation.gef.genmodel.GenEditPart#getGenGEFModel <em>Gen GEF Model</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the container reference '<em>Gen GEF Model</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenEditPart#getGenGEFModel()
   * @see #getGenEditPart()
   * @generated
   */
  EReference getGenEditPart_GenGEFModel();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.gef.genmodel.GenNodeEditPart <em>Gen Node Edit Part</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Gen Node Edit Part</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenNodeEditPart
   * @generated
   */
  EClass getGenNodeEditPart();

  /**
   * Returns the meta object for the containment reference '{@link com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#getGenFigure <em>Gen Figure</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Gen Figure</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#getGenFigure()
   * @see #getGenNodeEditPart()
   * @generated
   */
  EReference getGenNodeEditPart_GenFigure();

  /**
   * Returns the meta object for the containment reference list '{@link com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#getSubNodeReferences <em>Sub Node References</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Sub Node References</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#getSubNodeReferences()
   * @see #getGenNodeEditPart()
   * @generated
   */
  EReference getGenNodeEditPart_SubNodeReferences();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#isComponentEditPolicy <em>Component Edit Policy</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Component Edit Policy</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#isComponentEditPolicy()
   * @see #getGenNodeEditPart()
   * @generated
   */
  EAttribute getGenNodeEditPart_ComponentEditPolicy();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#isContainerEditPolicy <em>Container Edit Policy</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Container Edit Policy</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#isContainerEditPolicy()
   * @see #getGenNodeEditPart()
   * @generated
   */
  EAttribute getGenNodeEditPart_ContainerEditPolicy();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#isGraphicalEditPolicy <em>Graphical Edit Policy</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Graphical Edit Policy</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#isGraphicalEditPolicy()
   * @see #getGenNodeEditPart()
   * @generated
   */
  EAttribute getGenNodeEditPart_GraphicalEditPolicy();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#isDirectEditPolicy <em>Direct Edit Policy</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Direct Edit Policy</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenNodeEditPart#isDirectEditPolicy()
   * @see #getGenNodeEditPart()
   * @generated
   */
  EAttribute getGenNodeEditPart_DirectEditPolicy();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.gef.genmodel.GenSubNodeReference <em>Gen Sub Node Reference</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Gen Sub Node Reference</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenSubNodeReference
   * @generated
   */
  EClass getGenSubNodeReference();

  /**
   * Returns the meta object for the reference '{@link com.metys.merlin.generation.gef.genmodel.GenSubNodeReference#getReference <em>Reference</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Reference</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenSubNodeReference#getReference()
   * @see #getGenSubNodeReference()
   * @generated
   */
  EReference getGenSubNodeReference_Reference();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.genmodel.GenSubNodeReference#getParentLayoutClass <em>Parent Layout Class</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Parent Layout Class</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenSubNodeReference#getParentLayoutClass()
   * @see #getGenSubNodeReference()
   * @generated
   */
  EAttribute getGenSubNodeReference_ParentLayoutClass();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.gef.genmodel.GenLinkEditPart <em>Gen Link Edit Part</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Gen Link Edit Part</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenLinkEditPart
   * @generated
   */
  EClass getGenLinkEditPart();

  /**
   * Returns the meta object for the reference '{@link com.metys.merlin.generation.gef.genmodel.GenLinkEditPart#getSourceReference <em>Source Reference</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Source Reference</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenLinkEditPart#getSourceReference()
   * @see #getGenLinkEditPart()
   * @generated
   */
  EReference getGenLinkEditPart_SourceReference();

  /**
   * Returns the meta object for the reference '{@link com.metys.merlin.generation.gef.genmodel.GenLinkEditPart#getTargetReference <em>Target Reference</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Target Reference</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenLinkEditPart#getTargetReference()
   * @see #getGenLinkEditPart()
   * @generated
   */
  EReference getGenLinkEditPart_TargetReference();

  /**
   * Returns the meta object for the containment reference '{@link com.metys.merlin.generation.gef.genmodel.GenLinkEditPart#getGenFigure <em>Gen Figure</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Gen Figure</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenLinkEditPart#getGenFigure()
   * @see #getGenLinkEditPart()
   * @generated
   */
  EReference getGenLinkEditPart_GenFigure();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.gef.genmodel.GenPaletteComponentsFactory <em>Gen Palette Components Factory</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Gen Palette Components Factory</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenPaletteComponentsFactory
   * @generated
   */
  EClass getGenPaletteComponentsFactory();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.genmodel.GenPaletteComponentsFactory#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenPaletteComponentsFactory#getName()
   * @see #getGenPaletteComponentsFactory()
   * @generated
   */
  EAttribute getGenPaletteComponentsFactory_Name();

  /**
   * Returns the meta object for the reference list '{@link com.metys.merlin.generation.gef.genmodel.GenPaletteComponentsFactory#getGenNodeParts <em>Gen Node Parts</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference list '<em>Gen Node Parts</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenPaletteComponentsFactory#getGenNodeParts()
   * @see #getGenPaletteComponentsFactory()
   * @generated
   */
  EReference getGenPaletteComponentsFactory_GenNodeParts();

  /**
   * Returns the meta object for the container reference '{@link com.metys.merlin.generation.gef.genmodel.GenPaletteComponentsFactory#getGenEditor <em>Gen Editor</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the container reference '<em>Gen Editor</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenPaletteComponentsFactory#getGenEditor()
   * @see #getGenPaletteComponentsFactory()
   * @generated
   */
  EReference getGenPaletteComponentsFactory_GenEditor();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.gef.genmodel.GenPaletteConnectionsFactory <em>Gen Palette Connections Factory</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Gen Palette Connections Factory</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenPaletteConnectionsFactory
   * @generated
   */
  EClass getGenPaletteConnectionsFactory();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.genmodel.GenPaletteConnectionsFactory#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenPaletteConnectionsFactory#getName()
   * @see #getGenPaletteConnectionsFactory()
   * @generated
   */
  EAttribute getGenPaletteConnectionsFactory_Name();

  /**
   * Returns the meta object for the reference list '{@link com.metys.merlin.generation.gef.genmodel.GenPaletteConnectionsFactory#getGenLinkParts <em>Gen Link Parts</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference list '<em>Gen Link Parts</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenPaletteConnectionsFactory#getGenLinkParts()
   * @see #getGenPaletteConnectionsFactory()
   * @generated
   */
  EReference getGenPaletteConnectionsFactory_GenLinkParts();

  /**
   * Returns the meta object for the container reference '{@link com.metys.merlin.generation.gef.genmodel.GenPaletteConnectionsFactory#getGenEditor <em>Gen Editor</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the container reference '<em>Gen Editor</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenPaletteConnectionsFactory#getGenEditor()
   * @see #getGenPaletteConnectionsFactory()
   * @generated
   */
  EReference getGenPaletteConnectionsFactory_GenEditor();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.gef.genmodel.GenFigure <em>Gen Figure</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Gen Figure</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenFigure
   * @generated
   */
  EClass getGenFigure();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.genmodel.GenFigure#getFigureClass <em>Figure Class</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Figure Class</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenFigure#getFigureClass()
   * @see #getGenFigure()
   * @generated
   */
  EAttribute getGenFigure_FigureClass();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.genmodel.GenFigure#getLayoutClass <em>Layout Class</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Layout Class</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenFigure#getLayoutClass()
   * @see #getGenFigure()
   * @generated
   */
  EAttribute getGenFigure_LayoutClass();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.gef.genmodel.GenFigure#isAdditionalEditableLabel <em>Additional Editable Label</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Additional Editable Label</em>'.
   * @see com.metys.merlin.generation.gef.genmodel.GenFigure#isAdditionalEditableLabel()
   * @see #getGenFigure()
   * @generated
   */
  EAttribute getGenFigure_AdditionalEditableLabel();

  /**
   * Returns the factory that creates the instances of the model.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the factory that creates the instances of the model.
   * @generated
   */
  GenModelFactory getGenModelFactory();

} //GenModelPackage
