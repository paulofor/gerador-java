/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.jetmapping;

import org.eclipse.emf.codegen.ecore.genmodel.GenModelPackage;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.mapping.MappingPackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see com.metys.merlin.generation.templates.jetmapping.JETMappingFactory
 * @generated
 */
public interface JETMappingPackage extends EPackage{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "(c) 2005 Jo�l Cheuoua & Contributors";

	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "jetmapping";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.metys.com/merlin/generation/templates/jetmapping.ecore";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "templates.jetmapping";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	JETMappingPackage eINSTANCE = com.metys.merlin.generation.templates.jetmapping.impl.JETMappingPackageImpl.init();

	/**
	 * The meta object id for the '{@link com.metys.merlin.generation.templates.jetmapping.impl.JETTemplateMappingRootImpl <em>JET Template Mapping Root</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.metys.merlin.generation.templates.jetmapping.impl.JETTemplateMappingRootImpl
	 * @see com.metys.merlin.generation.templates.jetmapping.impl.JETMappingPackageImpl#getJETTemplateMappingRoot()
	 * @generated
	 */
	int JET_TEMPLATE_MAPPING_ROOT = 0;

	/**
	 * The feature id for the '<em><b>Helper</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JET_TEMPLATE_MAPPING_ROOT__HELPER = MappingPackage.MAPPING_ROOT__HELPER;

	/**
	 * The feature id for the '<em><b>Nested</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JET_TEMPLATE_MAPPING_ROOT__NESTED = MappingPackage.MAPPING_ROOT__NESTED;

	/**
	 * The feature id for the '<em><b>Nested In</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JET_TEMPLATE_MAPPING_ROOT__NESTED_IN = MappingPackage.MAPPING_ROOT__NESTED_IN;

	/**
	 * The feature id for the '<em><b>Inputs</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JET_TEMPLATE_MAPPING_ROOT__INPUTS = MappingPackage.MAPPING_ROOT__INPUTS;

	/**
	 * The feature id for the '<em><b>Outputs</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JET_TEMPLATE_MAPPING_ROOT__OUTPUTS = MappingPackage.MAPPING_ROOT__OUTPUTS;

	/**
	 * The feature id for the '<em><b>Type Mapping</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JET_TEMPLATE_MAPPING_ROOT__TYPE_MAPPING = MappingPackage.MAPPING_ROOT__TYPE_MAPPING;

	/**
	 * The feature id for the '<em><b>Output Read Only</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JET_TEMPLATE_MAPPING_ROOT__OUTPUT_READ_ONLY = MappingPackage.MAPPING_ROOT__OUTPUT_READ_ONLY;

	/**
	 * The feature id for the '<em><b>Top To Bottom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JET_TEMPLATE_MAPPING_ROOT__TOP_TO_BOTTOM = MappingPackage.MAPPING_ROOT__TOP_TO_BOTTOM;

	/**
	 * The feature id for the '<em><b>Command Stack</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JET_TEMPLATE_MAPPING_ROOT__COMMAND_STACK = MappingPackage.MAPPING_ROOT__COMMAND_STACK;

	/**
	 * The number of structural features of the the '<em>JET Template Mapping Root</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JET_TEMPLATE_MAPPING_ROOT_FEATURE_COUNT = MappingPackage.MAPPING_ROOT_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link com.metys.merlin.generation.templates.jetmapping.impl.JETTemplateMappingImpl <em>JET Template Mapping</em>}' class.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see com.metys.merlin.generation.templates.jetmapping.impl.JETTemplateMappingImpl
	 * @see com.metys.merlin.generation.templates.jetmapping.impl.JETMappingPackageImpl#getJETTemplateMapping()
	 * @generated
	 */
  int JET_TEMPLATE_MAPPING = 1;

	/**
	 * The feature id for the '<em><b>Helper</b></em>' containment reference.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JET_TEMPLATE_MAPPING__HELPER = MappingPackage.MAPPING__HELPER;

	/**
	 * The feature id for the '<em><b>Nested</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JET_TEMPLATE_MAPPING__NESTED = MappingPackage.MAPPING__NESTED;

	/**
	 * The feature id for the '<em><b>Nested In</b></em>' container reference.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JET_TEMPLATE_MAPPING__NESTED_IN = MappingPackage.MAPPING__NESTED_IN;

	/**
	 * The feature id for the '<em><b>Inputs</b></em>' reference list.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JET_TEMPLATE_MAPPING__INPUTS = MappingPackage.MAPPING__INPUTS;

	/**
	 * The feature id for the '<em><b>Outputs</b></em>' reference list.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JET_TEMPLATE_MAPPING__OUTPUTS = MappingPackage.MAPPING__OUTPUTS;

	/**
	 * The feature id for the '<em><b>Type Mapping</b></em>' reference.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JET_TEMPLATE_MAPPING__TYPE_MAPPING = MappingPackage.MAPPING__TYPE_MAPPING;

	/**
	 * The number of structural features of the the '<em>JET Template Mapping</em>' class.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JET_TEMPLATE_MAPPING_FEATURE_COUNT = MappingPackage.MAPPING_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link com.metys.merlin.generation.templates.jetmapping.impl.JETMappingGeneratorImpl <em>Generator</em>}' class.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see com.metys.merlin.generation.templates.jetmapping.impl.JETMappingGeneratorImpl
	 * @see com.metys.merlin.generation.templates.jetmapping.impl.JETMappingPackageImpl#getJETMappingGenerator()
	 * @generated
	 */
  int JET_MAPPING_GENERATOR = 2;

	/**
	 * The feature id for the '<em><b>Mapping Root</b></em>' reference.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JET_MAPPING_GENERATOR__MAPPING_ROOT = GenModelPackage.GEN_BASE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Current Generated Object</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JET_MAPPING_GENERATOR__CURRENT_GENERATED_OBJECT = GenModelPackage.GEN_BASE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Class Loader</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JET_MAPPING_GENERATOR__CLASS_LOADER = GenModelPackage.GEN_BASE_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the the '<em>Generator</em>' class.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JET_MAPPING_GENERATOR_FEATURE_COUNT = GenModelPackage.GEN_BASE_FEATURE_COUNT + 3;


	/**
	 * Returns the meta object for class '{@link com.metys.merlin.generation.templates.jetmapping.JETTemplateMappingRoot <em>JET Template Mapping Root</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>JET Template Mapping Root</em>'.
	 * @see com.metys.merlin.generation.templates.jetmapping.JETTemplateMappingRoot
	 * @generated
	 */
	EClass getJETTemplateMappingRoot();

	/**
	 * Returns the meta object for class '{@link com.metys.merlin.generation.templates.jetmapping.JETTemplateMapping <em>JET Template Mapping</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for class '<em>JET Template Mapping</em>'.
	 * @see com.metys.merlin.generation.templates.jetmapping.JETTemplateMapping
	 * @generated
	 */
  EClass getJETTemplateMapping();

	/**
	 * Returns the meta object for class '{@link com.metys.merlin.generation.templates.jetmapping.JETMappingGenerator <em>Generator</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Generator</em>'.
	 * @see com.metys.merlin.generation.templates.jetmapping.JETMappingGenerator
	 * @generated
	 */
  EClass getJETMappingGenerator();

	/**
	 * Returns the meta object for the reference '{@link com.metys.merlin.generation.templates.jetmapping.JETMappingGenerator#getMappingRoot <em>Mapping Root</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Mapping Root</em>'.
	 * @see com.metys.merlin.generation.templates.jetmapping.JETMappingGenerator#getMappingRoot()
	 * @see #getJETMappingGenerator()
	 * @generated
	 */
  EReference getJETMappingGenerator_MappingRoot();

	/**
	 * Returns the meta object for the attribute '{@link com.metys.merlin.generation.templates.jetmapping.JETMappingGenerator#getCurrentGeneratedObject <em>Current Generated Object</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Current Generated Object</em>'.
	 * @see com.metys.merlin.generation.templates.jetmapping.JETMappingGenerator#getCurrentGeneratedObject()
	 * @see #getJETMappingGenerator()
	 * @generated
	 */
  EAttribute getJETMappingGenerator_CurrentGeneratedObject();

	/**
	 * Returns the meta object for the attribute '{@link com.metys.merlin.generation.templates.jetmapping.JETMappingGenerator#getClassLoader <em>Class Loader</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Class Loader</em>'.
	 * @see com.metys.merlin.generation.templates.jetmapping.JETMappingGenerator#getClassLoader()
	 * @see #getJETMappingGenerator()
	 * @generated
	 */
  EAttribute getJETMappingGenerator_ClassLoader();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	JETMappingFactory getJETMappingFactory();

} //JETMappingPackage
