/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.impl;

import java.util.StringTokenizer;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentWithInverseEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.util.InternalEList;

import com.metys.merlin.generation.templates.JETTemplate;
import com.metys.merlin.generation.templates.JETTemplateAnnotation;
import com.metys.merlin.generation.templates.JETTemplateContainer;
import com.metys.merlin.generation.templates.JETTemplatePackage;

import java.util.Collection;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>JET Template</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.templates.impl.JETTemplateImpl#getTemplateFilePath <em>Template File Path</em>}</li>
 *   <li>{@link com.metys.merlin.generation.templates.impl.JETTemplateImpl#getOutputDirectoryPath <em>Output Directory Path</em>}</li>
 *   <li>{@link com.metys.merlin.generation.templates.impl.JETTemplateImpl#getPluginVariables <em>Plugin Variables</em>}</li>
 *   <li>{@link com.metys.merlin.generation.templates.impl.JETTemplateImpl#getTemplateContainer <em>Template Container</em>}</li>
 *   <li>{@link com.metys.merlin.generation.templates.impl.JETTemplateImpl#getAnnotations <em>Annotations</em>}</li>
 *   <li>{@link com.metys.merlin.generation.templates.impl.JETTemplateImpl#getAdditionalGeneratorArguments <em>Additional Generator Arguments</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public abstract class JETTemplateImpl extends EObjectImpl implements JETTemplate {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "(c) 2005 Jo�l Cheuoua & Contributors";

	/**
	 * The default value of the '{@link #getTemplateFilePath() <em>Template File Path</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see #getTemplateFilePath()
	 * @generated
	 * @ordered
	 */
  protected static final String TEMPLATE_FILE_PATH_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTemplateFilePath() <em>Template File Path</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see #getTemplateFilePath()
	 * @generated
	 * @ordered
	 */
  protected String templateFilePath = TEMPLATE_FILE_PATH_EDEFAULT;

	/**
	 * The default value of the '{@link #getOutputDirectoryPath() <em>Output Directory Path</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see #getOutputDirectoryPath()
	 * @generated
	 * @ordered
	 */
  protected static final String OUTPUT_DIRECTORY_PATH_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOutputDirectoryPath() <em>Output Directory Path</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see #getOutputDirectoryPath()
	 * @generated
	 * @ordered
	 */
  protected String outputDirectoryPath = OUTPUT_DIRECTORY_PATH_EDEFAULT;

	/**
	 * The default value of the '{@link #getPluginVariables() <em>Plugin Variables</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPluginVariables()
	 * @generated
	 * @ordered
	 */
	protected static final String PLUGIN_VARIABLES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPluginVariables() <em>Plugin Variables</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPluginVariables()
	 * @generated
	 * @ordered
	 */
	protected String pluginVariables = PLUGIN_VARIABLES_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAnnotations() <em>Annotations</em>}' containment reference list.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see #getAnnotations()
	 * @generated
	 * @ordered
	 */
  protected EList annotations = null;

	/**
	 * The cached value of the '{@link #getAdditionalGeneratorArguments() <em>Additional Generator Arguments</em>}' reference list.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see #getAdditionalGeneratorArguments()
	 * @generated
	 * @ordered
	 */
  protected EList additionalGeneratorArguments = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected JETTemplateImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return JETTemplatePackage.eINSTANCE.getJETTemplate();
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public String getTemplateFilePath() {
		return templateFilePath;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public void setTemplateFilePath(String newTemplateFilePath) {
		String oldTemplateFilePath = templateFilePath;
		templateFilePath = newTemplateFilePath;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, JETTemplatePackage.JET_TEMPLATE__TEMPLATE_FILE_PATH, oldTemplateFilePath, templateFilePath));
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public String getOutputDirectoryPath() {
		return outputDirectoryPath;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public void setOutputDirectoryPath(String newOutputDirectoryPath) {
		String oldOutputDirectoryPath = outputDirectoryPath;
		outputDirectoryPath = newOutputDirectoryPath;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, JETTemplatePackage.JET_TEMPLATE__OUTPUT_DIRECTORY_PATH, oldOutputDirectoryPath, outputDirectoryPath));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPluginVariables() {
		return pluginVariables;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public void setPluginVariables(String newPluginVariables) {
		String oldPluginVariables = pluginVariables;
		pluginVariables = newPluginVariables;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, JETTemplatePackage.JET_TEMPLATE__PLUGIN_VARIABLES, oldPluginVariables, pluginVariables));
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public JETTemplateContainer getTemplateContainer() {
		if (eContainerFeatureID != JETTemplatePackage.JET_TEMPLATE__TEMPLATE_CONTAINER) return null;
		return (JETTemplateContainer)eContainer;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public void setTemplateContainer(JETTemplateContainer newTemplateContainer) {
		if (newTemplateContainer != eContainer || (eContainerFeatureID != JETTemplatePackage.JET_TEMPLATE__TEMPLATE_CONTAINER && newTemplateContainer != null)) {
			if (EcoreUtil.isAncestor(this, newTemplateContainer))
				throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eContainer != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (newTemplateContainer != null)
				msgs = ((InternalEObject)newTemplateContainer).eInverseAdd(this, JETTemplatePackage.JET_TEMPLATE_CONTAINER__JET_TEMPLATES, JETTemplateContainer.class, msgs);
			msgs = eBasicSetContainer((InternalEObject)newTemplateContainer, JETTemplatePackage.JET_TEMPLATE__TEMPLATE_CONTAINER, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, JETTemplatePackage.JET_TEMPLATE__TEMPLATE_CONTAINER, newTemplateContainer, newTemplateContainer));
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EList getAnnotations() {
		if (annotations == null) {
			annotations = new EObjectContainmentWithInverseEList(JETTemplateAnnotation.class, this, JETTemplatePackage.JET_TEMPLATE__ANNOTATIONS, JETTemplatePackage.JET_TEMPLATE_ANNOTATION__TEMPLATE);
		}
		return annotations;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EList getAdditionalGeneratorArguments() {
		if (additionalGeneratorArguments == null) {
			additionalGeneratorArguments = new EObjectResolvingEList(EObject.class, this, JETTemplatePackage.JET_TEMPLATE__ADDITIONAL_GENERATOR_ARGUMENTS);
		}
		return additionalGeneratorArguments;
	}

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public EList getPluginVariablesList() {
    EList list = new BasicEList();
    String variables = getPluginVariables();
    if (variables == null)
      return list;
    for (StringTokenizer tokenizer = new StringTokenizer(variables, ","); tokenizer.hasMoreTokens();) {//$NON-NLS-1$
      list.add(tokenizer.nextToken().trim());
    }
    return list;
  }

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case JETTemplatePackage.JET_TEMPLATE__TEMPLATE_CONTAINER:
					if (eContainer != null)
						msgs = eBasicRemoveFromContainer(msgs);
					return eBasicSetContainer(otherEnd, JETTemplatePackage.JET_TEMPLATE__TEMPLATE_CONTAINER, msgs);
				case JETTemplatePackage.JET_TEMPLATE__ANNOTATIONS:
					return ((InternalEList)getAnnotations()).basicAdd(otherEnd, msgs);
				default:
					return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
			}
		}
		if (eContainer != null)
			msgs = eBasicRemoveFromContainer(msgs);
		return eBasicSetContainer(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case JETTemplatePackage.JET_TEMPLATE__TEMPLATE_CONTAINER:
					return eBasicSetContainer(null, JETTemplatePackage.JET_TEMPLATE__TEMPLATE_CONTAINER, msgs);
				case JETTemplatePackage.JET_TEMPLATE__ANNOTATIONS:
					return ((InternalEList)getAnnotations()).basicRemove(otherEnd, msgs);
				default:
					return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
			}
		}
		return eBasicSetContainer(null, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
		if (eContainerFeatureID >= 0) {
			switch (eContainerFeatureID) {
				case JETTemplatePackage.JET_TEMPLATE__TEMPLATE_CONTAINER:
					return eContainer.eInverseRemove(this, JETTemplatePackage.JET_TEMPLATE_CONTAINER__JET_TEMPLATES, JETTemplateContainer.class, msgs);
				default:
					return eDynamicBasicRemoveFromContainer(msgs);
			}
		}
		return eContainer.eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(EStructuralFeature eFeature, boolean resolve) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case JETTemplatePackage.JET_TEMPLATE__TEMPLATE_FILE_PATH:
				return getTemplateFilePath();
			case JETTemplatePackage.JET_TEMPLATE__OUTPUT_DIRECTORY_PATH:
				return getOutputDirectoryPath();
			case JETTemplatePackage.JET_TEMPLATE__PLUGIN_VARIABLES:
				return getPluginVariables();
			case JETTemplatePackage.JET_TEMPLATE__TEMPLATE_CONTAINER:
				return getTemplateContainer();
			case JETTemplatePackage.JET_TEMPLATE__ANNOTATIONS:
				return getAnnotations();
			case JETTemplatePackage.JET_TEMPLATE__ADDITIONAL_GENERATOR_ARGUMENTS:
				return getAdditionalGeneratorArguments();
		}
		return eDynamicGet(eFeature, resolve);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(EStructuralFeature eFeature, Object newValue) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case JETTemplatePackage.JET_TEMPLATE__TEMPLATE_FILE_PATH:
				setTemplateFilePath((String)newValue);
				return;
			case JETTemplatePackage.JET_TEMPLATE__OUTPUT_DIRECTORY_PATH:
				setOutputDirectoryPath((String)newValue);
				return;
			case JETTemplatePackage.JET_TEMPLATE__PLUGIN_VARIABLES:
				setPluginVariables((String)newValue);
				return;
			case JETTemplatePackage.JET_TEMPLATE__TEMPLATE_CONTAINER:
				setTemplateContainer((JETTemplateContainer)newValue);
				return;
			case JETTemplatePackage.JET_TEMPLATE__ANNOTATIONS:
				getAnnotations().clear();
				getAnnotations().addAll((Collection)newValue);
				return;
			case JETTemplatePackage.JET_TEMPLATE__ADDITIONAL_GENERATOR_ARGUMENTS:
				getAdditionalGeneratorArguments().clear();
				getAdditionalGeneratorArguments().addAll((Collection)newValue);
				return;
		}
		eDynamicSet(eFeature, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case JETTemplatePackage.JET_TEMPLATE__TEMPLATE_FILE_PATH:
				setTemplateFilePath(TEMPLATE_FILE_PATH_EDEFAULT);
				return;
			case JETTemplatePackage.JET_TEMPLATE__OUTPUT_DIRECTORY_PATH:
				setOutputDirectoryPath(OUTPUT_DIRECTORY_PATH_EDEFAULT);
				return;
			case JETTemplatePackage.JET_TEMPLATE__PLUGIN_VARIABLES:
				setPluginVariables(PLUGIN_VARIABLES_EDEFAULT);
				return;
			case JETTemplatePackage.JET_TEMPLATE__TEMPLATE_CONTAINER:
				setTemplateContainer((JETTemplateContainer)null);
				return;
			case JETTemplatePackage.JET_TEMPLATE__ANNOTATIONS:
				getAnnotations().clear();
				return;
			case JETTemplatePackage.JET_TEMPLATE__ADDITIONAL_GENERATOR_ARGUMENTS:
				getAdditionalGeneratorArguments().clear();
				return;
		}
		eDynamicUnset(eFeature);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case JETTemplatePackage.JET_TEMPLATE__TEMPLATE_FILE_PATH:
				return TEMPLATE_FILE_PATH_EDEFAULT == null ? templateFilePath != null : !TEMPLATE_FILE_PATH_EDEFAULT.equals(templateFilePath);
			case JETTemplatePackage.JET_TEMPLATE__OUTPUT_DIRECTORY_PATH:
				return OUTPUT_DIRECTORY_PATH_EDEFAULT == null ? outputDirectoryPath != null : !OUTPUT_DIRECTORY_PATH_EDEFAULT.equals(outputDirectoryPath);
			case JETTemplatePackage.JET_TEMPLATE__PLUGIN_VARIABLES:
				return PLUGIN_VARIABLES_EDEFAULT == null ? pluginVariables != null : !PLUGIN_VARIABLES_EDEFAULT.equals(pluginVariables);
			case JETTemplatePackage.JET_TEMPLATE__TEMPLATE_CONTAINER:
				return getTemplateContainer() != null;
			case JETTemplatePackage.JET_TEMPLATE__ANNOTATIONS:
				return annotations != null && !annotations.isEmpty();
			case JETTemplatePackage.JET_TEMPLATE__ADDITIONAL_GENERATOR_ARGUMENTS:
				return additionalGeneratorArguments != null && !additionalGeneratorArguments.isEmpty();
		}
		return eDynamicIsSet(eFeature);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (templateFilePath: ");
		result.append(templateFilePath);
		result.append(", outputDirectoryPath: ");
		result.append(outputDirectoryPath);
		result.append(", pluginVariables: ");
		result.append(pluginVariables);
		result.append(')');
		return result.toString();
	}

} //JETTemplateImpl
