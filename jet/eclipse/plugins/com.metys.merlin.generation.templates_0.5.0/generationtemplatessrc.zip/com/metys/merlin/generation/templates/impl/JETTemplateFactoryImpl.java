/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.impl;

import com.metys.merlin.generation.templates.*;

import java.util.List;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.impl.EFactoryImpl;
import com.metys.merlin.generation.templates.GIFTemplate;
import com.metys.merlin.generation.templates.JETTemplateContainer;
import com.metys.merlin.generation.templates.JETTemplateFactory;
import com.metys.merlin.generation.templates.JETTemplatePackage;
import com.metys.merlin.generation.templates.JavaJETTemplate;
import com.metys.merlin.generation.templates.TextJETTemplate;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class JETTemplateFactoryImpl extends EFactoryImpl implements JETTemplateFactory {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "(c) 2005 Jo�l Cheuoua & Contributors";

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public JETTemplateFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case JETTemplatePackage.JET_TEMPLATE_CONTAINER: return createJETTemplateContainer();
			case JETTemplatePackage.JAVA_JET_TEMPLATE: return createJavaJETTemplate();
			case JETTemplatePackage.TEXT_JET_TEMPLATE: return createTextJETTemplate();
			case JETTemplatePackage.GIF_TEMPLATE: return createGIFTemplate();
			case JETTemplatePackage.JET_TEMPLATE_ANNOTATION: return createJETTemplateAnnotation();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case JETTemplatePackage.CLASS_LOADER:
				return createClassLoaderFromString(eDataType, initialValue);
			case JETTemplatePackage.IPROGRESS_MONITOR:
				return createIProgressMonitorFromString(eDataType, initialValue);
			case JETTemplatePackage.LIST:
				return createListFromString(eDataType, initialValue);
			case JETTemplatePackage.PATH:
				return createPathFromString(eDataType, initialValue);
			case JETTemplatePackage.RESOURCE:
				return createResourceFromString(eDataType, initialValue);
			case JETTemplatePackage.STRING_ARRAY:
				return createStringArrayFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case JETTemplatePackage.CLASS_LOADER:
				return convertClassLoaderToString(eDataType, instanceValue);
			case JETTemplatePackage.IPROGRESS_MONITOR:
				return convertIProgressMonitorToString(eDataType, instanceValue);
			case JETTemplatePackage.LIST:
				return convertListToString(eDataType, instanceValue);
			case JETTemplatePackage.PATH:
				return convertPathToString(eDataType, instanceValue);
			case JETTemplatePackage.RESOURCE:
				return convertResourceToString(eDataType, instanceValue);
			case JETTemplatePackage.STRING_ARRAY:
				return convertStringArrayToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public JETTemplateContainer createJETTemplateContainer() {
		JETTemplateContainerImpl jetTemplateContainer = new JETTemplateContainerImpl();
		return jetTemplateContainer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public JavaJETTemplate createJavaJETTemplate() {
		JavaJETTemplateImpl javaJETTemplate = new JavaJETTemplateImpl();
		return javaJETTemplate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TextJETTemplate createTextJETTemplate() {
		TextJETTemplateImpl textJETTemplate = new TextJETTemplateImpl();
		return textJETTemplate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GIFTemplate createGIFTemplate() {
		GIFTemplateImpl gifTemplate = new GIFTemplateImpl();
		return gifTemplate;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public JETTemplateAnnotation createJETTemplateAnnotation() {
		JETTemplateAnnotationImpl jetTemplateAnnotation = new JETTemplateAnnotationImpl();
		return jetTemplateAnnotation;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public ClassLoader createClassLoaderFromString(EDataType eDataType, String initialValue) {
		return (ClassLoader)super.createFromString(eDataType, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public String convertClassLoaderToString(EDataType eDataType, Object instanceValue) {
		return super.convertToString(eDataType, instanceValue);
	}

	/**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public IResource createResourceFromString(EDataType eDataType, String initialValue)
  {
		IResource resource = ResourcesPlugin.getWorkspace().getRoot().findMember(new Path(initialValue));
    if (resource == null)
      return ResourcesPlugin.getWorkspace().getRoot().getProject(initialValue);
    return resource;    
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public String convertResourceToString(EDataType eDataType, Object instanceValue)
  {
  	return ((IResource) instanceValue).getFullPath().toString();    
  }
	
	/**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public IPath createPathFromString(EDataType eDataType, String initialValue)
  {
  	if (initialValue == null)
  		return new Path("");
		return new Path(initialValue);    
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public String convertPathToString(EDataType eDataType, Object instanceValue)
  {
  	if (instanceValue == null)
  		return "";
  	return ((IPath) instanceValue).toString();    
  }

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public IProgressMonitor createIProgressMonitorFromString(EDataType eDataType, String initialValue) {
		return (IProgressMonitor)super.createFromString(eDataType, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public String convertIProgressMonitorToString(EDataType eDataType, Object instanceValue) {
		return super.convertToString(eDataType, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public String[] createStringArrayFromString(EDataType eDataType, String initialValue) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public String convertStringArrayToString(EDataType eDataType, Object instanceValue) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public List createListFromString(EDataType eDataType, String initialValue) {
		return (List)super.createFromString(eDataType, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public String convertListToString(EDataType eDataType, Object instanceValue) {
		return super.convertToString(eDataType, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public JETTemplatePackage getJETTemplatePackage() {
		return (JETTemplatePackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	public static JETTemplatePackage getPackage() {
		return JETTemplatePackage.eINSTANCE;
	}

} //JETTemplatesFactoryImpl
