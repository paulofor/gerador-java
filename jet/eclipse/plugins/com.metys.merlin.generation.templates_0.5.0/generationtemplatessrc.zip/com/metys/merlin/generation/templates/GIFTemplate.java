/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>GIF Template</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.templates.GIFTemplate#getOutputFileName <em>Output File Name</em>}</li>
 *   <li>{@link com.metys.merlin.generation.templates.GIFTemplate#getFileSuffix <em>File Suffix</em>}</li>
 *   <li>{@link com.metys.merlin.generation.templates.GIFTemplate#getFilePrefix <em>File Prefix</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.metys.merlin.generation.templates.JETTemplatePackage#getGIFTemplate()
 * @model
 * @generated
 */
public interface GIFTemplate extends JETTemplate{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "(c) 2005 Jo�l Cheuoua & Contributors";

	/**
	 * Returns the value of the '<em><b>Output File Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Output File Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
	 * @return the value of the '<em>Output File Name</em>' attribute.
	 * @see #setOutputFileName(String)
	 * @see com.metys.merlin.generation.templates.JETTemplatePackage#getGIFTemplate_OutputFileName()
	 * @model
	 * @generated
	 */
  String getOutputFileName();

	/**
	 * Sets the value of the '{@link com.metys.merlin.generation.templates.GIFTemplate#getOutputFileName <em>Output File Name</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Output File Name</em>' attribute.
	 * @see #getOutputFileName()
	 * @generated
	 */
  void setOutputFileName(String value);

	/**
	 * Returns the value of the '<em><b>File Suffix</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>File Suffix</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
	 * @return the value of the '<em>File Suffix</em>' attribute.
	 * @see #setFileSuffix(String)
	 * @see com.metys.merlin.generation.templates.JETTemplatePackage#getGIFTemplate_FileSuffix()
	 * @model
	 * @generated
	 */
  String getFileSuffix();

	/**
	 * Sets the value of the '{@link com.metys.merlin.generation.templates.GIFTemplate#getFileSuffix <em>File Suffix</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @param value the new value of the '<em>File Suffix</em>' attribute.
	 * @see #getFileSuffix()
	 * @generated
	 */
  void setFileSuffix(String value);

	/**
	 * Returns the value of the '<em><b>File Prefix</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>File Prefix</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
	 * @return the value of the '<em>File Prefix</em>' attribute.
	 * @see #setFilePrefix(String)
	 * @see com.metys.merlin.generation.templates.JETTemplatePackage#getGIFTemplate_FilePrefix()
	 * @model
	 * @generated
	 */
  String getFilePrefix();

	/**
	 * Sets the value of the '{@link com.metys.merlin.generation.templates.GIFTemplate#getFilePrefix <em>File Prefix</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @param value the new value of the '<em>File Prefix</em>' attribute.
	 * @see #getFilePrefix()
	 * @generated
	 */
  void setFilePrefix(String value);

} // GIFTemplate
