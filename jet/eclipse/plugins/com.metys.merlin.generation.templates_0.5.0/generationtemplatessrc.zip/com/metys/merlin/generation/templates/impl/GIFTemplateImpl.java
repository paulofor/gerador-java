/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.InternalEList;

import com.metys.merlin.generation.templates.GIFTemplate;
import com.metys.merlin.generation.templates.JETTemplateContainer;
import com.metys.merlin.generation.templates.JETTemplatePackage;

import java.util.Collection;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>GIF Template</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.templates.impl.GIFTemplateImpl#getOutputFileName <em>Output File Name</em>}</li>
 *   <li>{@link com.metys.merlin.generation.templates.impl.GIFTemplateImpl#getFileSuffix <em>File Suffix</em>}</li>
 *   <li>{@link com.metys.merlin.generation.templates.impl.GIFTemplateImpl#getFilePrefix <em>File Prefix</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class GIFTemplateImpl extends JETTemplateImpl implements GIFTemplate {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "(c) 2005 Jo�l Cheuoua & Contributors";

	/**
	 * The default value of the '{@link #getOutputFileName() <em>Output File Name</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see #getOutputFileName()
	 * @generated
	 * @ordered
	 */
  protected static final String OUTPUT_FILE_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOutputFileName() <em>Output File Name</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see #getOutputFileName()
	 * @generated
	 * @ordered
	 */
  protected String outputFileName = OUTPUT_FILE_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getFileSuffix() <em>File Suffix</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see #getFileSuffix()
	 * @generated
	 * @ordered
	 */
  protected static final String FILE_SUFFIX_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFileSuffix() <em>File Suffix</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see #getFileSuffix()
	 * @generated
	 * @ordered
	 */
  protected String fileSuffix = FILE_SUFFIX_EDEFAULT;

	/**
	 * The default value of the '{@link #getFilePrefix() <em>File Prefix</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see #getFilePrefix()
	 * @generated
	 * @ordered
	 */
  protected static final String FILE_PREFIX_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFilePrefix() <em>File Prefix</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see #getFilePrefix()
	 * @generated
	 * @ordered
	 */
  protected String filePrefix = FILE_PREFIX_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GIFTemplateImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return JETTemplatePackage.eINSTANCE.getGIFTemplate();
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public String getOutputFileName() {
		return outputFileName;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public void setOutputFileName(String newOutputFileName) {
		String oldOutputFileName = outputFileName;
		outputFileName = newOutputFileName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, JETTemplatePackage.GIF_TEMPLATE__OUTPUT_FILE_NAME, oldOutputFileName, outputFileName));
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public String getFileSuffix() {
		return fileSuffix;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public void setFileSuffix(String newFileSuffix) {
		String oldFileSuffix = fileSuffix;
		fileSuffix = newFileSuffix;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, JETTemplatePackage.GIF_TEMPLATE__FILE_SUFFIX, oldFileSuffix, fileSuffix));
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public String getFilePrefix() {
		return filePrefix;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public void setFilePrefix(String newFilePrefix) {
		String oldFilePrefix = filePrefix;
		filePrefix = newFilePrefix;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, JETTemplatePackage.GIF_TEMPLATE__FILE_PREFIX, oldFilePrefix, filePrefix));
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case JETTemplatePackage.GIF_TEMPLATE__TEMPLATE_CONTAINER:
					if (eContainer != null)
						msgs = eBasicRemoveFromContainer(msgs);
					return eBasicSetContainer(otherEnd, JETTemplatePackage.GIF_TEMPLATE__TEMPLATE_CONTAINER, msgs);
				case JETTemplatePackage.GIF_TEMPLATE__ANNOTATIONS:
					return ((InternalEList)getAnnotations()).basicAdd(otherEnd, msgs);
				default:
					return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
			}
		}
		if (eContainer != null)
			msgs = eBasicRemoveFromContainer(msgs);
		return eBasicSetContainer(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case JETTemplatePackage.GIF_TEMPLATE__TEMPLATE_CONTAINER:
					return eBasicSetContainer(null, JETTemplatePackage.GIF_TEMPLATE__TEMPLATE_CONTAINER, msgs);
				case JETTemplatePackage.GIF_TEMPLATE__ANNOTATIONS:
					return ((InternalEList)getAnnotations()).basicRemove(otherEnd, msgs);
				default:
					return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
			}
		}
		return eBasicSetContainer(null, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
		if (eContainerFeatureID >= 0) {
			switch (eContainerFeatureID) {
				case JETTemplatePackage.GIF_TEMPLATE__TEMPLATE_CONTAINER:
					return eContainer.eInverseRemove(this, JETTemplatePackage.JET_TEMPLATE_CONTAINER__JET_TEMPLATES, JETTemplateContainer.class, msgs);
				default:
					return eDynamicBasicRemoveFromContainer(msgs);
			}
		}
		return eContainer.eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(EStructuralFeature eFeature, boolean resolve) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case JETTemplatePackage.GIF_TEMPLATE__TEMPLATE_FILE_PATH:
				return getTemplateFilePath();
			case JETTemplatePackage.GIF_TEMPLATE__OUTPUT_DIRECTORY_PATH:
				return getOutputDirectoryPath();
			case JETTemplatePackage.GIF_TEMPLATE__PLUGIN_VARIABLES:
				return getPluginVariables();
			case JETTemplatePackage.GIF_TEMPLATE__TEMPLATE_CONTAINER:
				return getTemplateContainer();
			case JETTemplatePackage.GIF_TEMPLATE__ANNOTATIONS:
				return getAnnotations();
			case JETTemplatePackage.GIF_TEMPLATE__ADDITIONAL_GENERATOR_ARGUMENTS:
				return getAdditionalGeneratorArguments();
			case JETTemplatePackage.GIF_TEMPLATE__OUTPUT_FILE_NAME:
				return getOutputFileName();
			case JETTemplatePackage.GIF_TEMPLATE__FILE_SUFFIX:
				return getFileSuffix();
			case JETTemplatePackage.GIF_TEMPLATE__FILE_PREFIX:
				return getFilePrefix();
		}
		return eDynamicGet(eFeature, resolve);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(EStructuralFeature eFeature, Object newValue) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case JETTemplatePackage.GIF_TEMPLATE__TEMPLATE_FILE_PATH:
				setTemplateFilePath((String)newValue);
				return;
			case JETTemplatePackage.GIF_TEMPLATE__OUTPUT_DIRECTORY_PATH:
				setOutputDirectoryPath((String)newValue);
				return;
			case JETTemplatePackage.GIF_TEMPLATE__PLUGIN_VARIABLES:
				setPluginVariables((String)newValue);
				return;
			case JETTemplatePackage.GIF_TEMPLATE__TEMPLATE_CONTAINER:
				setTemplateContainer((JETTemplateContainer)newValue);
				return;
			case JETTemplatePackage.GIF_TEMPLATE__ANNOTATIONS:
				getAnnotations().clear();
				getAnnotations().addAll((Collection)newValue);
				return;
			case JETTemplatePackage.GIF_TEMPLATE__ADDITIONAL_GENERATOR_ARGUMENTS:
				getAdditionalGeneratorArguments().clear();
				getAdditionalGeneratorArguments().addAll((Collection)newValue);
				return;
			case JETTemplatePackage.GIF_TEMPLATE__OUTPUT_FILE_NAME:
				setOutputFileName((String)newValue);
				return;
			case JETTemplatePackage.GIF_TEMPLATE__FILE_SUFFIX:
				setFileSuffix((String)newValue);
				return;
			case JETTemplatePackage.GIF_TEMPLATE__FILE_PREFIX:
				setFilePrefix((String)newValue);
				return;
		}
		eDynamicSet(eFeature, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case JETTemplatePackage.GIF_TEMPLATE__TEMPLATE_FILE_PATH:
				setTemplateFilePath(TEMPLATE_FILE_PATH_EDEFAULT);
				return;
			case JETTemplatePackage.GIF_TEMPLATE__OUTPUT_DIRECTORY_PATH:
				setOutputDirectoryPath(OUTPUT_DIRECTORY_PATH_EDEFAULT);
				return;
			case JETTemplatePackage.GIF_TEMPLATE__PLUGIN_VARIABLES:
				setPluginVariables(PLUGIN_VARIABLES_EDEFAULT);
				return;
			case JETTemplatePackage.GIF_TEMPLATE__TEMPLATE_CONTAINER:
				setTemplateContainer((JETTemplateContainer)null);
				return;
			case JETTemplatePackage.GIF_TEMPLATE__ANNOTATIONS:
				getAnnotations().clear();
				return;
			case JETTemplatePackage.GIF_TEMPLATE__ADDITIONAL_GENERATOR_ARGUMENTS:
				getAdditionalGeneratorArguments().clear();
				return;
			case JETTemplatePackage.GIF_TEMPLATE__OUTPUT_FILE_NAME:
				setOutputFileName(OUTPUT_FILE_NAME_EDEFAULT);
				return;
			case JETTemplatePackage.GIF_TEMPLATE__FILE_SUFFIX:
				setFileSuffix(FILE_SUFFIX_EDEFAULT);
				return;
			case JETTemplatePackage.GIF_TEMPLATE__FILE_PREFIX:
				setFilePrefix(FILE_PREFIX_EDEFAULT);
				return;
		}
		eDynamicUnset(eFeature);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case JETTemplatePackage.GIF_TEMPLATE__TEMPLATE_FILE_PATH:
				return TEMPLATE_FILE_PATH_EDEFAULT == null ? templateFilePath != null : !TEMPLATE_FILE_PATH_EDEFAULT.equals(templateFilePath);
			case JETTemplatePackage.GIF_TEMPLATE__OUTPUT_DIRECTORY_PATH:
				return OUTPUT_DIRECTORY_PATH_EDEFAULT == null ? outputDirectoryPath != null : !OUTPUT_DIRECTORY_PATH_EDEFAULT.equals(outputDirectoryPath);
			case JETTemplatePackage.GIF_TEMPLATE__PLUGIN_VARIABLES:
				return PLUGIN_VARIABLES_EDEFAULT == null ? pluginVariables != null : !PLUGIN_VARIABLES_EDEFAULT.equals(pluginVariables);
			case JETTemplatePackage.GIF_TEMPLATE__TEMPLATE_CONTAINER:
				return getTemplateContainer() != null;
			case JETTemplatePackage.GIF_TEMPLATE__ANNOTATIONS:
				return annotations != null && !annotations.isEmpty();
			case JETTemplatePackage.GIF_TEMPLATE__ADDITIONAL_GENERATOR_ARGUMENTS:
				return additionalGeneratorArguments != null && !additionalGeneratorArguments.isEmpty();
			case JETTemplatePackage.GIF_TEMPLATE__OUTPUT_FILE_NAME:
				return OUTPUT_FILE_NAME_EDEFAULT == null ? outputFileName != null : !OUTPUT_FILE_NAME_EDEFAULT.equals(outputFileName);
			case JETTemplatePackage.GIF_TEMPLATE__FILE_SUFFIX:
				return FILE_SUFFIX_EDEFAULT == null ? fileSuffix != null : !FILE_SUFFIX_EDEFAULT.equals(fileSuffix);
			case JETTemplatePackage.GIF_TEMPLATE__FILE_PREFIX:
				return FILE_PREFIX_EDEFAULT == null ? filePrefix != null : !FILE_PREFIX_EDEFAULT.equals(filePrefix);
		}
		return eDynamicIsSet(eFeature);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (outputFileName: ");
		result.append(outputFileName);
		result.append(", fileSuffix: ");
		result.append(fileSuffix);
		result.append(", filePrefix: ");
		result.append(filePrefix);
		result.append(')');
		return result.toString();
	}

} //GIFTemplateImpl
