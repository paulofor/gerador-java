/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.jetmapping;

import com.metys.merlin.generation.templates.JETTemplate;
import com.metys.merlin.generation.templates.JETTemplateContainer;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.codegen.ecore.genmodel.GenBase;
import org.eclipse.emf.codegen.jet.JETEmitter;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Generator</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.templates.jetmapping.JETMappingGenerator#getMappingRoot <em>Mapping Root</em>}</li>
 *   <li>{@link com.metys.merlin.generation.templates.jetmapping.JETMappingGenerator#getCurrentGeneratedObject <em>Current Generated Object</em>}</li>
 *   <li>{@link com.metys.merlin.generation.templates.jetmapping.JETMappingGenerator#getClassLoader <em>Class Loader</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.metys.merlin.generation.templates.jetmapping.JETMappingPackage#getJETMappingGenerator()
 * @model
 * @generated
 */
public interface JETMappingGenerator extends GenBase{
	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  String copyright = "(c) 2005 Jo�l Cheuoua & Contributors";

	/**
	 * Returns the value of the '<em><b>Mapping Root</b></em>' reference.
	 * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Mapping Root</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
	 * @return the value of the '<em>Mapping Root</em>' reference.
	 * @see #setMappingRoot(JETTemplateMappingRoot)
	 * @see com.metys.merlin.generation.templates.jetmapping.JETMappingPackage#getJETMappingGenerator_MappingRoot()
	 * @model required="true"
	 * @generated
	 */
  JETTemplateMappingRoot getMappingRoot();

	/**
	 * Sets the value of the '{@link com.metys.merlin.generation.templates.jetmapping.JETMappingGenerator#getMappingRoot <em>Mapping Root</em>}' reference.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Mapping Root</em>' reference.
	 * @see #getMappingRoot()
	 * @generated
	 */
  void setMappingRoot(JETTemplateMappingRoot value);

	/**
	 * Returns the value of the '<em><b>Current Generated Object</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Current Generated Object</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
	 * @return the value of the '<em>Current Generated Object</em>' attribute.
	 * @see #setCurrentGeneratedObject(Object)
	 * @see com.metys.merlin.generation.templates.jetmapping.JETMappingPackage#getJETMappingGenerator_CurrentGeneratedObject()
	 * @model
	 * @generated
	 */
  Object getCurrentGeneratedObject();

	/**
	 * Sets the value of the '{@link com.metys.merlin.generation.templates.jetmapping.JETMappingGenerator#getCurrentGeneratedObject <em>Current Generated Object</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Current Generated Object</em>' attribute.
	 * @see #getCurrentGeneratedObject()
	 * @generated
	 */
  void setCurrentGeneratedObject(Object value);

	/**
	 * Returns the value of the '<em><b>Class Loader</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Class Loader</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
	 * @return the value of the '<em>Class Loader</em>' attribute.
	 * @see #setClassLoader(ClassLoader)
	 * @see com.metys.merlin.generation.templates.jetmapping.JETMappingPackage#getJETMappingGenerator_ClassLoader()
	 * @model dataType="com.metys.merlin.generation.templates.ClassLoader"
	 * @generated
	 */
  ClassLoader getClassLoader();

	/**
	 * Sets the value of the '{@link com.metys.merlin.generation.templates.jetmapping.JETMappingGenerator#getClassLoader <em>Class Loader</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Class Loader</em>' attribute.
	 * @see #getClassLoader()
	 * @generated
	 */
  void setClassLoader(ClassLoader value);

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @model parameters="com.metys.merlin.generation.templates.JETEmitter org.eclipse.emf.ecore.EString com.metys.merlin.generation.templates.ClassLoader"
	 * @generated
	 */
  void setMethod(JETEmitter jetEmitter, String className, ClassLoader cl);

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
  boolean canGenerate(Object object);

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @model parameters="org.eclipse.emf.ecore.EJavaObject com.metys.merlin.generation.templates.IProgressMonitor"
	 * @generated
	 */
  void generate(Object object, IProgressMonitor progressMonitor);

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @model parameters="org.eclipse.emf.ecore.EJavaObject com.metys.merlin.generation.templates.JETTemplate com.metys.merlin.generation.templates.IProgressMonitor"
	 * @generated
	 */
  void generate(Object object, JETTemplate jettemplate, IProgressMonitor progressMonitor);

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @model parameters="org.eclipse.emf.ecore.EJavaObject org.eclipse.emf.ecore.EString org.eclipse.emf.ecore.EString org.eclipse.emf.ecore.EString com.metys.merlin.generation.templates.IProgressMonitor"
	 * @generated
	 */
  String generateText(Object generatedObject, String jetFilePath, String compiledJETFilesDir, String previousGenerated, IProgressMonitor progressMonitor);

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @model parameters="org.eclipse.emf.ecore.EJavaObject org.eclipse.emf.ecore.EString org.eclipse.emf.ecore.EString org.eclipse.emf.ecore.EString com.metys.merlin.generation.templates.IProgressMonitor"
	 * @generated
	 */
  String generateJava(Object generatedObject, String jetFilePath, String compiledJETFilesDir, String previousGenerated, IProgressMonitor progressMonitor);

  void resetClassLoader(Object generatedObject, IResource resource, JETTemplateContainer templateContainer);

} // JETMappingGenerator
