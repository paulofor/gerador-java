/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see com.metys.merlin.generation.templates.JETTemplateFactory
 * @generated
 */
public interface JETTemplatePackage extends EPackage{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String copyright = "(c) 2005 Jo�l Cheuoua & Contributors";

	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "templates";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.metys.com/merlin/generation/templates.ecore";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "templates";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	JETTemplatePackage eINSTANCE = com.metys.merlin.generation.templates.impl.JETTemplatePackageImpl.init();

	/**
	 * The meta object id for the '{@link com.metys.merlin.generation.templates.impl.JETTemplateContainerImpl <em>Container</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.metys.merlin.generation.templates.impl.JETTemplateContainerImpl
	 * @see com.metys.merlin.generation.templates.impl.JETTemplatePackageImpl#getJETTemplateContainer()
	 * @generated
	 */
	int JET_TEMPLATE_CONTAINER = 0;

	/**
	 * The feature id for the '<em><b>Java JET Source</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JET_TEMPLATE_CONTAINER__JAVA_JET_SOURCE = 0;

	/**
	 * The feature id for the '<em><b>Jet Templates</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JET_TEMPLATE_CONTAINER__JET_TEMPLATES = 1;

	/**
	 * The number of structural features of the the '<em>Container</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JET_TEMPLATE_CONTAINER_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link com.metys.merlin.generation.templates.impl.JETTemplateImpl <em>JET Template</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.metys.merlin.generation.templates.impl.JETTemplateImpl
	 * @see com.metys.merlin.generation.templates.impl.JETTemplatePackageImpl#getJETTemplate()
	 * @generated
	 */
	int JET_TEMPLATE = 1;

	/**
	 * The feature id for the '<em><b>Template File Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JET_TEMPLATE__TEMPLATE_FILE_PATH = 0;

	/**
	 * The feature id for the '<em><b>Output Directory Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JET_TEMPLATE__OUTPUT_DIRECTORY_PATH = 1;

	/**
	 * The feature id for the '<em><b>Plugin Variables</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JET_TEMPLATE__PLUGIN_VARIABLES = 2;

	/**
	 * The feature id for the '<em><b>Template Container</b></em>' container reference.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JET_TEMPLATE__TEMPLATE_CONTAINER = 3;

	/**
	 * The feature id for the '<em><b>Annotations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JET_TEMPLATE__ANNOTATIONS = 4;

	/**
	 * The feature id for the '<em><b>Additional Generator Arguments</b></em>' reference list.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JET_TEMPLATE__ADDITIONAL_GENERATOR_ARGUMENTS = 5;

	/**
	 * The number of structural features of the the '<em>JET Template</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JET_TEMPLATE_FEATURE_COUNT = 6;

	/**
	 * The meta object id for the '{@link com.metys.merlin.generation.templates.impl.JavaJETTemplateImpl <em>Java JET Template</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.metys.merlin.generation.templates.impl.JavaJETTemplateImpl
	 * @see com.metys.merlin.generation.templates.impl.JETTemplatePackageImpl#getJavaJETTemplate()
	 * @generated
	 */
	int JAVA_JET_TEMPLATE = 2;

	/**
	 * The feature id for the '<em><b>Template File Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JAVA_JET_TEMPLATE__TEMPLATE_FILE_PATH = JET_TEMPLATE__TEMPLATE_FILE_PATH;

	/**
	 * The feature id for the '<em><b>Output Directory Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JAVA_JET_TEMPLATE__OUTPUT_DIRECTORY_PATH = JET_TEMPLATE__OUTPUT_DIRECTORY_PATH;

	/**
	 * The feature id for the '<em><b>Plugin Variables</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_JET_TEMPLATE__PLUGIN_VARIABLES = JET_TEMPLATE__PLUGIN_VARIABLES;

	/**
	 * The feature id for the '<em><b>Template Container</b></em>' container reference.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JAVA_JET_TEMPLATE__TEMPLATE_CONTAINER = JET_TEMPLATE__TEMPLATE_CONTAINER;

	/**
	 * The feature id for the '<em><b>Annotations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JAVA_JET_TEMPLATE__ANNOTATIONS = JET_TEMPLATE__ANNOTATIONS;

	/**
	 * The feature id for the '<em><b>Additional Generator Arguments</b></em>' reference list.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JAVA_JET_TEMPLATE__ADDITIONAL_GENERATOR_ARGUMENTS = JET_TEMPLATE__ADDITIONAL_GENERATOR_ARGUMENTS;

	/**
	 * The number of structural features of the the '<em>Java JET Template</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JAVA_JET_TEMPLATE_FEATURE_COUNT = JET_TEMPLATE_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link com.metys.merlin.generation.templates.impl.TextJETTemplateImpl <em>Text JET Template</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.metys.merlin.generation.templates.impl.TextJETTemplateImpl
	 * @see com.metys.merlin.generation.templates.impl.JETTemplatePackageImpl#getTextJETTemplate()
	 * @generated
	 */
	int TEXT_JET_TEMPLATE = 3;

	/**
	 * The feature id for the '<em><b>Template File Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int TEXT_JET_TEMPLATE__TEMPLATE_FILE_PATH = JET_TEMPLATE__TEMPLATE_FILE_PATH;

	/**
	 * The feature id for the '<em><b>Output Directory Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int TEXT_JET_TEMPLATE__OUTPUT_DIRECTORY_PATH = JET_TEMPLATE__OUTPUT_DIRECTORY_PATH;

	/**
	 * The feature id for the '<em><b>Plugin Variables</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_JET_TEMPLATE__PLUGIN_VARIABLES = JET_TEMPLATE__PLUGIN_VARIABLES;

	/**
	 * The feature id for the '<em><b>Template Container</b></em>' container reference.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int TEXT_JET_TEMPLATE__TEMPLATE_CONTAINER = JET_TEMPLATE__TEMPLATE_CONTAINER;

	/**
	 * The feature id for the '<em><b>Annotations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int TEXT_JET_TEMPLATE__ANNOTATIONS = JET_TEMPLATE__ANNOTATIONS;

	/**
	 * The feature id for the '<em><b>Additional Generator Arguments</b></em>' reference list.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int TEXT_JET_TEMPLATE__ADDITIONAL_GENERATOR_ARGUMENTS = JET_TEMPLATE__ADDITIONAL_GENERATOR_ARGUMENTS;

	/**
	 * The feature id for the '<em><b>Output File Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int TEXT_JET_TEMPLATE__OUTPUT_FILE_NAME = JET_TEMPLATE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>File Prefix</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int TEXT_JET_TEMPLATE__FILE_PREFIX = JET_TEMPLATE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>File Suffix</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int TEXT_JET_TEMPLATE__FILE_SUFFIX = JET_TEMPLATE_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the the '<em>Text JET Template</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEXT_JET_TEMPLATE_FEATURE_COUNT = JET_TEMPLATE_FEATURE_COUNT + 3;

	/**
	 * The meta object id for the '{@link com.metys.merlin.generation.templates.impl.GIFTemplateImpl <em>GIF Template</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.metys.merlin.generation.templates.impl.GIFTemplateImpl
	 * @see com.metys.merlin.generation.templates.impl.JETTemplatePackageImpl#getGIFTemplate()
	 * @generated
	 */
	int GIF_TEMPLATE = 4;

	/**
	 * The feature id for the '<em><b>Template File Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int GIF_TEMPLATE__TEMPLATE_FILE_PATH = JET_TEMPLATE__TEMPLATE_FILE_PATH;

	/**
	 * The feature id for the '<em><b>Output Directory Path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GIF_TEMPLATE__OUTPUT_DIRECTORY_PATH = JET_TEMPLATE__OUTPUT_DIRECTORY_PATH;

	/**
	 * The feature id for the '<em><b>Plugin Variables</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GIF_TEMPLATE__PLUGIN_VARIABLES = JET_TEMPLATE__PLUGIN_VARIABLES;

	/**
	 * The feature id for the '<em><b>Template Container</b></em>' container reference.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int GIF_TEMPLATE__TEMPLATE_CONTAINER = JET_TEMPLATE__TEMPLATE_CONTAINER;

	/**
	 * The feature id for the '<em><b>Annotations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int GIF_TEMPLATE__ANNOTATIONS = JET_TEMPLATE__ANNOTATIONS;

	/**
	 * The feature id for the '<em><b>Additional Generator Arguments</b></em>' reference list.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int GIF_TEMPLATE__ADDITIONAL_GENERATOR_ARGUMENTS = JET_TEMPLATE__ADDITIONAL_GENERATOR_ARGUMENTS;

	/**
	 * The feature id for the '<em><b>Output File Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int GIF_TEMPLATE__OUTPUT_FILE_NAME = JET_TEMPLATE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>File Suffix</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int GIF_TEMPLATE__FILE_SUFFIX = JET_TEMPLATE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>File Prefix</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int GIF_TEMPLATE__FILE_PREFIX = JET_TEMPLATE_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the the '<em>GIF Template</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GIF_TEMPLATE_FEATURE_COUNT = JET_TEMPLATE_FEATURE_COUNT + 3;

	/**
	 * The meta object id for the '{@link com.metys.merlin.generation.templates.impl.JETTemplateAnnotationImpl <em>Annotation</em>}' class.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see com.metys.merlin.generation.templates.impl.JETTemplateAnnotationImpl
	 * @see com.metys.merlin.generation.templates.impl.JETTemplatePackageImpl#getJETTemplateAnnotation()
	 * @generated
	 */
  int JET_TEMPLATE_ANNOTATION = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JET_TEMPLATE_ANNOTATION__NAME = 0;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JET_TEMPLATE_ANNOTATION__VALUE = 1;

	/**
	 * The feature id for the '<em><b>Template</b></em>' container reference.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JET_TEMPLATE_ANNOTATION__TEMPLATE = 2;

	/**
	 * The number of structural features of the the '<em>Annotation</em>' class.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int JET_TEMPLATE_ANNOTATION_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '<em>Class Loader</em>' data type.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see java.lang.ClassLoader
	 * @see com.metys.merlin.generation.templates.impl.JETTemplatePackageImpl#getClassLoader()
	 * @generated
	 */
  int CLASS_LOADER = 6;

	/**
	 * The meta object id for the '<em>Resource</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.core.resources.IResource
	 * @see com.metys.merlin.generation.templates.impl.JETTemplatePackageImpl#getResource()
	 * @generated
	 */
	int RESOURCE = 12;

	/**
	 * The meta object id for the '<em>Path</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.core.runtime.IPath
	 * @see com.metys.merlin.generation.templates.impl.JETTemplatePackageImpl#getPath()
	 * @generated
	 */
	int PATH = 11;


	/**
	 * The meta object id for the '<em>Java Project</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.jdt.core.IJavaProject
	 * @see com.metys.merlin.generation.templates.impl.JETTemplatePackageImpl#getJavaProject()
	 * @generated
	 */
	int JAVA_PROJECT = 8;


	/**
	 * The meta object id for the '<em>IProgress Monitor</em>' data type.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see org.eclipse.core.runtime.IProgressMonitor
	 * @see com.metys.merlin.generation.templates.impl.JETTemplatePackageImpl#getIProgressMonitor()
	 * @generated
	 */
  int IPROGRESS_MONITOR = 7;

	/**
	 * The meta object id for the '<em>JET Emitter</em>' data type.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see org.eclipse.emf.codegen.jet.JETEmitter
	 * @see com.metys.merlin.generation.templates.impl.JETTemplatePackageImpl#getJETEmitter()
	 * @generated
	 */
  int JET_EMITTER = 9;

	/**
	 * The meta object id for the '<em>String Array</em>' data type.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see com.metys.merlin.generation.templates.impl.JETTemplatePackageImpl#getStringArray()
	 * @generated
	 */
  int STRING_ARRAY = 13;

	/**
	 * The meta object id for the '<em>List</em>' data type.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see java.util.List
	 * @see com.metys.merlin.generation.templates.impl.JETTemplatePackageImpl#getList()
	 * @generated
	 */
  int LIST = 10;


	/**
	 * Returns the meta object for class '{@link com.metys.merlin.generation.templates.JETTemplateContainer <em>Container</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Container</em>'.
	 * @see com.metys.merlin.generation.templates.JETTemplateContainer
	 * @generated
	 */
	EClass getJETTemplateContainer();

	/**
	 * Returns the meta object for the attribute '{@link com.metys.merlin.generation.templates.JETTemplateContainer#getJavaJETSource <em>Java JET Source</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Java JET Source</em>'.
	 * @see com.metys.merlin.generation.templates.JETTemplateContainer#getJavaJETSource()
	 * @see #getJETTemplateContainer()
	 * @generated
	 */
  EAttribute getJETTemplateContainer_JavaJETSource();

	/**
	 * Returns the meta object for the containment reference list '{@link com.metys.merlin.generation.templates.JETTemplateContainer#getJetTemplates <em>Jet Templates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Jet Templates</em>'.
	 * @see com.metys.merlin.generation.templates.JETTemplateContainer#getJetTemplates()
	 * @see #getJETTemplateContainer()
	 * @generated
	 */
	EReference getJETTemplateContainer_JetTemplates();

	/**
	 * Returns the meta object for class '{@link com.metys.merlin.generation.templates.JETTemplate <em>JET Template</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>JET Template</em>'.
	 * @see com.metys.merlin.generation.templates.JETTemplate
	 * @generated
	 */
	EClass getJETTemplate();

	/**
	 * Returns the meta object for the attribute '{@link com.metys.merlin.generation.templates.JETTemplate#getTemplateFilePath <em>Template File Path</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Template File Path</em>'.
	 * @see com.metys.merlin.generation.templates.JETTemplate#getTemplateFilePath()
	 * @see #getJETTemplate()
	 * @generated
	 */
  EAttribute getJETTemplate_TemplateFilePath();

	/**
	 * Returns the meta object for the attribute '{@link com.metys.merlin.generation.templates.JETTemplate#getOutputDirectoryPath <em>Output Directory Path</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Output Directory Path</em>'.
	 * @see com.metys.merlin.generation.templates.JETTemplate#getOutputDirectoryPath()
	 * @see #getJETTemplate()
	 * @generated
	 */
  EAttribute getJETTemplate_OutputDirectoryPath();

	/**
	 * Returns the meta object for the attribute '{@link com.metys.merlin.generation.templates.JETTemplate#getPluginVariables <em>Plugin Variables</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Plugin Variables</em>'.
	 * @see com.metys.merlin.generation.templates.JETTemplate#getPluginVariables()
	 * @see #getJETTemplate()
	 * @generated
	 */
	EAttribute getJETTemplate_PluginVariables();

	/**
	 * Returns the meta object for the container reference '{@link com.metys.merlin.generation.templates.JETTemplate#getTemplateContainer <em>Template Container</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for the container reference '<em>Template Container</em>'.
	 * @see com.metys.merlin.generation.templates.JETTemplate#getTemplateContainer()
	 * @see #getJETTemplate()
	 * @generated
	 */
  EReference getJETTemplate_TemplateContainer();

	/**
	 * Returns the meta object for the containment reference list '{@link com.metys.merlin.generation.templates.JETTemplate#getAnnotations <em>Annotations</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Annotations</em>'.
	 * @see com.metys.merlin.generation.templates.JETTemplate#getAnnotations()
	 * @see #getJETTemplate()
	 * @generated
	 */
  EReference getJETTemplate_Annotations();

	/**
	 * Returns the meta object for the reference list '{@link com.metys.merlin.generation.templates.JETTemplate#getAdditionalGeneratorArguments <em>Additional Generator Arguments</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Additional Generator Arguments</em>'.
	 * @see com.metys.merlin.generation.templates.JETTemplate#getAdditionalGeneratorArguments()
	 * @see #getJETTemplate()
	 * @generated
	 */
  EReference getJETTemplate_AdditionalGeneratorArguments();

	/**
	 * Returns the meta object for class '{@link com.metys.merlin.generation.templates.JavaJETTemplate <em>Java JET Template</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Java JET Template</em>'.
	 * @see com.metys.merlin.generation.templates.JavaJETTemplate
	 * @generated
	 */
	EClass getJavaJETTemplate();

	/**
	 * Returns the meta object for class '{@link com.metys.merlin.generation.templates.TextJETTemplate <em>Text JET Template</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Text JET Template</em>'.
	 * @see com.metys.merlin.generation.templates.TextJETTemplate
	 * @generated
	 */
	EClass getTextJETTemplate();

	/**
	 * Returns the meta object for the attribute '{@link com.metys.merlin.generation.templates.TextJETTemplate#getOutputFileName <em>Output File Name</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Output File Name</em>'.
	 * @see com.metys.merlin.generation.templates.TextJETTemplate#getOutputFileName()
	 * @see #getTextJETTemplate()
	 * @generated
	 */
  EAttribute getTextJETTemplate_OutputFileName();

	/**
	 * Returns the meta object for the attribute '{@link com.metys.merlin.generation.templates.TextJETTemplate#getFilePrefix <em>File Prefix</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>File Prefix</em>'.
	 * @see com.metys.merlin.generation.templates.TextJETTemplate#getFilePrefix()
	 * @see #getTextJETTemplate()
	 * @generated
	 */
  EAttribute getTextJETTemplate_FilePrefix();

	/**
	 * Returns the meta object for the attribute '{@link com.metys.merlin.generation.templates.TextJETTemplate#getFileSuffix <em>File Suffix</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>File Suffix</em>'.
	 * @see com.metys.merlin.generation.templates.TextJETTemplate#getFileSuffix()
	 * @see #getTextJETTemplate()
	 * @generated
	 */
  EAttribute getTextJETTemplate_FileSuffix();

	/**
	 * Returns the meta object for class '{@link com.metys.merlin.generation.templates.GIFTemplate <em>GIF Template</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>GIF Template</em>'.
	 * @see com.metys.merlin.generation.templates.GIFTemplate
	 * @generated
	 */
	EClass getGIFTemplate();

	/**
	 * Returns the meta object for the attribute '{@link com.metys.merlin.generation.templates.GIFTemplate#getOutputFileName <em>Output File Name</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Output File Name</em>'.
	 * @see com.metys.merlin.generation.templates.GIFTemplate#getOutputFileName()
	 * @see #getGIFTemplate()
	 * @generated
	 */
  EAttribute getGIFTemplate_OutputFileName();

	/**
	 * Returns the meta object for the attribute '{@link com.metys.merlin.generation.templates.GIFTemplate#getFileSuffix <em>File Suffix</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>File Suffix</em>'.
	 * @see com.metys.merlin.generation.templates.GIFTemplate#getFileSuffix()
	 * @see #getGIFTemplate()
	 * @generated
	 */
  EAttribute getGIFTemplate_FileSuffix();

	/**
	 * Returns the meta object for the attribute '{@link com.metys.merlin.generation.templates.GIFTemplate#getFilePrefix <em>File Prefix</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>File Prefix</em>'.
	 * @see com.metys.merlin.generation.templates.GIFTemplate#getFilePrefix()
	 * @see #getGIFTemplate()
	 * @generated
	 */
  EAttribute getGIFTemplate_FilePrefix();

	/**
	 * Returns the meta object for class '{@link com.metys.merlin.generation.templates.JETTemplateAnnotation <em>Annotation</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Annotation</em>'.
	 * @see com.metys.merlin.generation.templates.JETTemplateAnnotation
	 * @generated
	 */
  EClass getJETTemplateAnnotation();

	/**
	 * Returns the meta object for the attribute '{@link com.metys.merlin.generation.templates.JETTemplateAnnotation#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see com.metys.merlin.generation.templates.JETTemplateAnnotation#getName()
	 * @see #getJETTemplateAnnotation()
	 * @generated
	 */
  EAttribute getJETTemplateAnnotation_Name();

	/**
	 * Returns the meta object for the attribute '{@link com.metys.merlin.generation.templates.JETTemplateAnnotation#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see com.metys.merlin.generation.templates.JETTemplateAnnotation#getValue()
	 * @see #getJETTemplateAnnotation()
	 * @generated
	 */
  EAttribute getJETTemplateAnnotation_Value();

	/**
	 * Returns the meta object for the container reference '{@link com.metys.merlin.generation.templates.JETTemplateAnnotation#getTemplate <em>Template</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for the container reference '<em>Template</em>'.
	 * @see com.metys.merlin.generation.templates.JETTemplateAnnotation#getTemplate()
	 * @see #getJETTemplateAnnotation()
	 * @generated
	 */
  EReference getJETTemplateAnnotation_Template();

	/**
	 * Returns the meta object for data type '{@link java.lang.ClassLoader <em>Class Loader</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Class Loader</em>'.
	 * @see java.lang.ClassLoader
	 * @model instanceClass="java.lang.ClassLoader"
	 * @generated
	 */
  EDataType getClassLoader();

	/**
	 * Returns the meta object for data type '{@link org.eclipse.core.resources.IResource <em>Resource</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Resource</em>'.
	 * @see org.eclipse.core.resources.IResource
	 * @model instanceClass="org.eclipse.core.resources.IResource"
	 * @generated
	 */
	EDataType getResource();

	/**
	 * Returns the meta object for data type '{@link org.eclipse.core.runtime.IPath <em>Path</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Path</em>'.
	 * @see org.eclipse.core.runtime.IPath
	 * @model instanceClass="org.eclipse.core.runtime.IPath"
	 * @generated
	 */
	EDataType getPath();

	/**
	 * Returns the meta object for data type '{@link org.eclipse.jdt.core.IJavaProject <em>Java Project</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Java Project</em>'.
	 * @see org.eclipse.jdt.core.IJavaProject
	 * @model instanceClass="org.eclipse.jdt.core.IJavaProject" serializable="false"
	 * @generated
	 */
	EDataType getJavaProject();

	/**
	 * Returns the meta object for data type '{@link org.eclipse.core.runtime.IProgressMonitor <em>IProgress Monitor</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>IProgress Monitor</em>'.
	 * @see org.eclipse.core.runtime.IProgressMonitor
	 * @model instanceClass="org.eclipse.core.runtime.IProgressMonitor"
	 * @generated
	 */
  EDataType getIProgressMonitor();

	/**
	 * Returns the meta object for data type '{@link org.eclipse.emf.codegen.jet.JETEmitter <em>JET Emitter</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>JET Emitter</em>'.
	 * @see org.eclipse.emf.codegen.jet.JETEmitter
	 * @model instanceClass="org.eclipse.emf.codegen.jet.JETEmitter" serializable="false"
	 * @generated
	 */
  EDataType getJETEmitter();

	/**
	 * Returns the meta object for data type '<em>String Array</em>'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>String Array</em>'.
	 * @model instanceClass="java.lang.String[]"
	 * @generated
	 */
  EDataType getStringArray();

	/**
	 * Returns the meta object for data type '{@link java.util.List <em>List</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>List</em>'.
	 * @see java.util.List
	 * @model instanceClass="java.util.List"
	 * @generated
	 */
  EDataType getList();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	JETTemplateFactory getJETTemplateFactory();

} //JETTemplatePackage
