/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates;

import org.eclipse.core.runtime.IPath;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.jdt.core.IJavaProject;
import org.osgi.framework.Bundle;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Container</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.templates.JETTemplateContainer#getJavaJETSource <em>Java JET Source</em>}</li>
 *   <li>{@link com.metys.merlin.generation.templates.JETTemplateContainer#getJetTemplates <em>Jet Templates</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.metys.merlin.generation.templates.JETTemplatePackage#getJETTemplateContainer()
 * @model
 * @generated
 */
public interface JETTemplateContainer extends EObject{
	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  String copyright = "(c) 2005 Jo�l Cheuoua & Contributors";

	/**
	 * Returns the value of the '<em><b>Java JET Source</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Java JET Source</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
	 * @return the value of the '<em>Java JET Source</em>' attribute.
	 * @see #setJavaJETSource(String)
	 * @see com.metys.merlin.generation.templates.JETTemplatePackage#getJETTemplateContainer_JavaJETSource()
	 * @model required="true"
	 * @generated
	 */
  String getJavaJETSource();

	/**
	 * Sets the value of the '{@link com.metys.merlin.generation.templates.JETTemplateContainer#getJavaJETSource <em>Java JET Source</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Java JET Source</em>' attribute.
	 * @see #getJavaJETSource()
	 * @generated
	 */
  void setJavaJETSource(String value);

	/**
	 * Returns the value of the '<em><b>Jet Templates</b></em>' containment reference list.
	 * The list contents are of type {@link com.metys.merlin.generation.templates.JETTemplate}.
	 * It is bidirectional and its opposite is '{@link com.metys.merlin.generation.templates.JETTemplate#getTemplateContainer <em>Template Container</em>}'.
	 * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Jet Templates</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
	 * @return the value of the '<em>Jet Templates</em>' containment reference list.
	 * @see com.metys.merlin.generation.templates.JETTemplatePackage#getJETTemplateContainer_JetTemplates()
	 * @see com.metys.merlin.generation.templates.JETTemplate#getTemplateContainer
	 * @model type="com.metys.merlin.generation.templates.JETTemplate" opposite="templateContainer" containment="true"
	 * @generated
	 */
  EList getJetTemplates();

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @model dataType="com.metys.merlin.generation.templates.Path" parameters=""
	 * @generated
	 */
  IPath getContainerPath();

  Bundle getBundle();
  IJavaProject getJavaProject();
} // JETTemplateContainer
