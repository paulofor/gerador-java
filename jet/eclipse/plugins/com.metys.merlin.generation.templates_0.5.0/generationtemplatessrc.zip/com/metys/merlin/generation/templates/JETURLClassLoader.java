/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.net.URLStreamHandlerFactory;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

import org.osgi.framework.Bundle;

/**
 * @author Jo�l
 * 
 * TODO To change the template for this generated type comment go to Window - Preferences - Java - Code Style - Code
 * Templates
 */
public class JETURLClassLoader extends URLClassLoader {
  private List delegateLoaders = new ArrayList();

  public static class SimpleFileFilter implements FilenameFilter {
    private String[] extensions;

    public SimpleFileFilter(String ext) {
      this(new String[] { ext });
    }

    public SimpleFileFilter(String[] exts) {
      extensions = new String[exts.length];
      for (int i = 0; i < exts.length; i++) {
        extensions[i] = exts[i].toLowerCase();
      }
    }

    /** filenamefilter interface method */
    public boolean accept(File dir, String _name) {
      String name = _name.toLowerCase();
      for (int i = 0; i < extensions.length; i++) {
        if (name.endsWith(extensions[i]))
          return true;
      }
      return false;
    }

    /**
     * this method checks to see if an asterisk is embedded in the filename, if it is, it does an "ls" or "dir" of the
     * parent directory returning a list of files that match eg. /usr/home/mjennings/*.jar would expand out to all of
     * the files with a .jar extension in the /usr/home/mjennings directory
     */
    public static String[] fileOrFiles(File f) {
      if (f == null)
        return null;
      String fname = f.getName();
      String[] files;
      if (fname.length() > 0 && fname.charAt(0) == '*') {
        String parentName = f.getParent();
        if (parentName == null)
          return null;
        File parent = new File(parentName);
        String filter = fname.substring(1, fname.length());
        files = parent.list(new SimpleFileFilter(filter));
        return files;
      } else {
        files = new String[1];
        files[0] = f.getPath();// was:fname;
        return files;
      }
    }
  }

  public JETURLClassLoader(File[] files) {
    this(new URL[0]);
    setFiles(files);
  }

  public JETURLClassLoader(File[] files, ClassLoader parent) {
    this(new URL[0], parent);
    setFiles(files);
  }

  public JETURLClassLoader(URL[] urls) {
    super(urls);
  }

  public JETURLClassLoader(URL[] urls, ClassLoader parent) {
    super(urls, parent);
  }

  public JETURLClassLoader(URL[] urls, ClassLoader parent, URLStreamHandlerFactory factory) {
    super(urls, parent, factory);
  }

  public void addClassLoaderDelegate(ClassLoader delegate) {
    if (delegateLoaders == null)
      delegateLoaders = new ArrayList();
    delegateLoaders.add(delegate);
  }

  public Collection getDelegateLoaders() {
    return delegateLoaders;
  }

  /**
   * Sets for the specified files to this class loader
   * @param files The files from which to load classes and resources
   */
  public synchronized void setFiles(File[] files) {
    if (files != null) {
      for (int i = 0; i < files.length; i++) {
        File file = files[i];
        String[] filenames;
        filenames = SimpleFileFilter.fileOrFiles(file);
        if (filenames != null) {
          for (int j = 0; j < filenames.length; j++) {
            file = new File(filenames[j]);
            if (file.canRead() && (file.isDirectory() || isZipOrJarArchive(file))) {
              // Transforms the file into an url
              try {
                String path = file.getAbsolutePath();
                file = new File(path);
                addURL(file.toURL());
              } catch (MalformedURLException e) {
              }
            }
          }
        }
      }
    }
  }

  /**
   * Returns an array of files that has been set to this class loader
   */
  public File[] getFiles() {
    URL[] urls = getURLs();
    File[] result = new File[urls.length];
    for (int i = 0; i < urls.length; i++) {
      result[i] = new File(urls[i].getFile());
    }
    return result;
  }

  /**
   * Tests if a file is a ZIP or JAR archive.
   * @param file the file to be tested.
   * @return <code>true</code> if the file is a ZIP/JAR archive, <code>false</code> otherwise.
   */
  private boolean isZipOrJarArchive(File file) {
    boolean isArchive = true;
    ZipFile zipFile = null;
    try {
      zipFile = new ZipFile(file);
    } catch (ZipException zipCurrupted) {
      isArchive = false;
    } catch (IOException anyIOError) {
      isArchive = false;
    } finally {
      if (zipFile != null) {
        try {
          zipFile.close();
        } catch (IOException e) {
        }
      }
    }
    return isArchive;
  }

  /*
   * (non-Javadoc)
   * @see java.lang.ClassLoader#loadClass(java.lang.String)
   */
  public Class loadClass(String name) throws ClassNotFoundException {
    Class c = null;
    // First, look in the delegates if any
    if (delegateLoaders != null && !delegateLoaders.isEmpty()) {
      for (Iterator it = delegateLoaders.iterator(); it.hasNext();) {
        Object delegateLoader = it.next();
        if (delegateLoader instanceof ClassLoader) {
          ClassLoader delegate = (ClassLoader) delegateLoader;
          try {
            c = delegate.loadClass(name);
            return c;
          } catch (ClassNotFoundException subex) {
            // Continue to the next delegate
          }
        }
        if (delegateLoader instanceof Bundle) {
          Bundle delegate = (Bundle) delegateLoader;
          c = delegate.loadClass(name);
          if (c != null)
            return c;
        }
      }
    }
    return super.loadClass(name);
  }

  /**
   * Convert a JAR URL into the orginal URL of the JAR File. Do nothing if this is not a JAR URL.
   * @param url
   * @return
   */
  private URL convertJarURL(URL url) {
    String protocol = url.getProtocol();
    if (!"jar".equals(protocol))
      return url;
    String fileURL = url.getFile();
    int index = fileURL.indexOf("!/");
    if (index > 0)
      fileURL = fileURL.substring(0, index);
    try {
      if (fileURL.startsWith("file:"))
        return new URL("file", null, fileURL.substring(5));
      else
        return new URL(fileURL);
    } catch (MalformedURLException e) {
      // should never happen
      e.printStackTrace();
    }
    return null;
  }
}
