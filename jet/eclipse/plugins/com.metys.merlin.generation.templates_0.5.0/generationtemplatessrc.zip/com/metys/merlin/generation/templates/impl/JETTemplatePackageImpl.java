/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.impl;

import java.util.List;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.codegen.ecore.genmodel.impl.GenModelPackageImpl;
import org.eclipse.emf.codegen.jet.JETEmitter;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.impl.EPackageImpl;
import org.eclipse.emf.ecore.impl.EcorePackageImpl;

import org.eclipse.emf.mapping.impl.MappingPackageImpl;
import org.eclipse.jdt.core.IJavaProject;
import com.metys.merlin.generation.templates.GIFTemplate;
import com.metys.merlin.generation.templates.JETTemplate;
import com.metys.merlin.generation.templates.JETTemplateAnnotation;
import com.metys.merlin.generation.templates.JETTemplateContainer;
import com.metys.merlin.generation.templates.JETTemplateFactory;
import com.metys.merlin.generation.templates.JETTemplatePackage;
import com.metys.merlin.generation.templates.JavaJETTemplate;
import com.metys.merlin.generation.templates.TextJETTemplate;
import com.metys.merlin.generation.templates.jetmapping.JETMappingPackage;
import com.metys.merlin.generation.templates.jetmapping.impl.JETMappingPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class JETTemplatePackageImpl extends EPackageImpl implements JETTemplatePackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "(c) 2005 Jo�l Cheuoua & Contributors";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass jetTemplateContainerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass jetTemplateEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass javaJETTemplateEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass textJETTemplateEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass gifTemplateEClass = null;

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  private EClass jetTemplateAnnotationEClass = null;

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  private EDataType classLoaderEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType resourceEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType pathEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType javaProjectEDataType = null;

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  private EDataType iProgressMonitorEDataType = null;

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  private EDataType jetEmitterEDataType = null;

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  private EDataType stringArrayEDataType = null;

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  private EDataType listEDataType = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see com.metys.merlin.generation.templates.JETTemplatePackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private JETTemplatePackageImpl() {
		super(eNS_URI, JETTemplateFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this
	 * model, and for any others upon which it depends.  Simple
	 * dependencies are satisfied by calling this method on all
	 * dependent packages before doing anything else.  This method drives
	 * initialization for interdependent packages directly, in parallel
	 * with this package, itself.
	 * <p>Of this package and its interdependencies, all packages which
	 * have not yet been registered by their URI values are first created
	 * and registered.  The packages are then initialized in two steps:
	 * meta-model objects for all of the packages are created before any
	 * are initialized, since one package's meta-model objects may refer to
	 * those of another.
	 * <p>Invocation of this method will not affect any packages that have
	 * already been initialized.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static JETTemplatePackage init() {
		if (isInited) return (JETTemplatePackage)EPackage.Registry.INSTANCE.getEPackage(JETTemplatePackage.eNS_URI);

		// Obtain or create and register package
		JETTemplatePackageImpl theJETTemplatePackage = (JETTemplatePackageImpl)(EPackage.Registry.INSTANCE.getEPackage(eNS_URI) instanceof JETTemplatePackageImpl ? EPackage.Registry.INSTANCE.getEPackage(eNS_URI) : new JETTemplatePackageImpl());

		isInited = true;

		// Initialize simple dependencies
		MappingPackageImpl.init();
		EcorePackageImpl.init();
		GenModelPackageImpl.init();

		// Obtain or create and register interdependencies
		JETMappingPackageImpl theJETMappingPackage = (JETMappingPackageImpl)(EPackage.Registry.INSTANCE.getEPackage(JETMappingPackage.eNS_URI) instanceof JETMappingPackageImpl ? EPackage.Registry.INSTANCE.getEPackage(JETMappingPackage.eNS_URI) : JETMappingPackage.eINSTANCE);

		// Create package meta-data objects
		theJETTemplatePackage.createPackageContents();
		theJETMappingPackage.createPackageContents();

		// Initialize created meta-data
		theJETTemplatePackage.initializePackageContents();
		theJETMappingPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theJETTemplatePackage.freeze();

		return theJETTemplatePackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getJETTemplateContainer() {
		return jetTemplateContainerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EAttribute getJETTemplateContainer_JavaJETSource() {
		return (EAttribute)jetTemplateContainerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getJETTemplateContainer_JetTemplates() {
		return (EReference)jetTemplateContainerEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getJETTemplate() {
		return jetTemplateEClass;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EAttribute getJETTemplate_TemplateFilePath() {
		return (EAttribute)jetTemplateEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EAttribute getJETTemplate_OutputDirectoryPath() {
		return (EAttribute)jetTemplateEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getJETTemplate_PluginVariables() {
		return (EAttribute)jetTemplateEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EReference getJETTemplate_TemplateContainer() {
		return (EReference)jetTemplateEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EReference getJETTemplate_Annotations() {
		return (EReference)jetTemplateEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EReference getJETTemplate_AdditionalGeneratorArguments() {
		return (EReference)jetTemplateEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getJavaJETTemplate() {
		return javaJETTemplateEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTextJETTemplate() {
		return textJETTemplateEClass;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EAttribute getTextJETTemplate_OutputFileName() {
		return (EAttribute)textJETTemplateEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EAttribute getTextJETTemplate_FilePrefix() {
		return (EAttribute)textJETTemplateEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EAttribute getTextJETTemplate_FileSuffix() {
		return (EAttribute)textJETTemplateEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getGIFTemplate() {
		return gifTemplateEClass;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EAttribute getGIFTemplate_OutputFileName() {
		return (EAttribute)gifTemplateEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EAttribute getGIFTemplate_FileSuffix() {
		return (EAttribute)gifTemplateEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EAttribute getGIFTemplate_FilePrefix() {
		return (EAttribute)gifTemplateEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EClass getJETTemplateAnnotation() {
		return jetTemplateAnnotationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EAttribute getJETTemplateAnnotation_Name() {
		return (EAttribute)jetTemplateAnnotationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EAttribute getJETTemplateAnnotation_Value() {
		return (EAttribute)jetTemplateAnnotationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EReference getJETTemplateAnnotation_Template() {
		return (EReference)jetTemplateAnnotationEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EDataType getClassLoader() {
		return classLoaderEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getResource() {
		return resourceEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getPath() {
		return pathEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getJavaProject() {
		return javaProjectEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EDataType getIProgressMonitor() {
		return iProgressMonitorEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EDataType getJETEmitter() {
		return jetEmitterEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EDataType getStringArray() {
		return stringArrayEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public EDataType getList() {
		return listEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public JETTemplateFactory getJETTemplateFactory() {
		return (JETTemplateFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		jetTemplateContainerEClass = createEClass(JET_TEMPLATE_CONTAINER);
		createEAttribute(jetTemplateContainerEClass, JET_TEMPLATE_CONTAINER__JAVA_JET_SOURCE);
		createEReference(jetTemplateContainerEClass, JET_TEMPLATE_CONTAINER__JET_TEMPLATES);

		jetTemplateEClass = createEClass(JET_TEMPLATE);
		createEAttribute(jetTemplateEClass, JET_TEMPLATE__TEMPLATE_FILE_PATH);
		createEAttribute(jetTemplateEClass, JET_TEMPLATE__OUTPUT_DIRECTORY_PATH);
		createEAttribute(jetTemplateEClass, JET_TEMPLATE__PLUGIN_VARIABLES);
		createEReference(jetTemplateEClass, JET_TEMPLATE__TEMPLATE_CONTAINER);
		createEReference(jetTemplateEClass, JET_TEMPLATE__ANNOTATIONS);
		createEReference(jetTemplateEClass, JET_TEMPLATE__ADDITIONAL_GENERATOR_ARGUMENTS);

		javaJETTemplateEClass = createEClass(JAVA_JET_TEMPLATE);

		textJETTemplateEClass = createEClass(TEXT_JET_TEMPLATE);
		createEAttribute(textJETTemplateEClass, TEXT_JET_TEMPLATE__OUTPUT_FILE_NAME);
		createEAttribute(textJETTemplateEClass, TEXT_JET_TEMPLATE__FILE_PREFIX);
		createEAttribute(textJETTemplateEClass, TEXT_JET_TEMPLATE__FILE_SUFFIX);

		gifTemplateEClass = createEClass(GIF_TEMPLATE);
		createEAttribute(gifTemplateEClass, GIF_TEMPLATE__OUTPUT_FILE_NAME);
		createEAttribute(gifTemplateEClass, GIF_TEMPLATE__FILE_SUFFIX);
		createEAttribute(gifTemplateEClass, GIF_TEMPLATE__FILE_PREFIX);

		jetTemplateAnnotationEClass = createEClass(JET_TEMPLATE_ANNOTATION);
		createEAttribute(jetTemplateAnnotationEClass, JET_TEMPLATE_ANNOTATION__NAME);
		createEAttribute(jetTemplateAnnotationEClass, JET_TEMPLATE_ANNOTATION__VALUE);
		createEReference(jetTemplateAnnotationEClass, JET_TEMPLATE_ANNOTATION__TEMPLATE);

		// Create data types
		classLoaderEDataType = createEDataType(CLASS_LOADER);
		iProgressMonitorEDataType = createEDataType(IPROGRESS_MONITOR);
		javaProjectEDataType = createEDataType(JAVA_PROJECT);
		jetEmitterEDataType = createEDataType(JET_EMITTER);
		listEDataType = createEDataType(LIST);
		pathEDataType = createEDataType(PATH);
		resourceEDataType = createEDataType(RESOURCE);
		stringArrayEDataType = createEDataType(STRING_ARRAY);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		JETMappingPackageImpl theJETMappingPackage = (JETMappingPackageImpl)EPackage.Registry.INSTANCE.getEPackage(JETMappingPackage.eNS_URI);

		// Add subpackages
		getESubpackages().add(theJETMappingPackage);

		// Add supertypes to classes
		javaJETTemplateEClass.getESuperTypes().add(this.getJETTemplate());
		textJETTemplateEClass.getESuperTypes().add(this.getJETTemplate());
		gifTemplateEClass.getESuperTypes().add(this.getJETTemplate());

		// Initialize classes and features; add operations and parameters
		initEClass(jetTemplateContainerEClass, JETTemplateContainer.class, "JETTemplateContainer", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getJETTemplateContainer_JavaJETSource(), ecorePackage.getEString(), "javaJETSource", null, 1, 1, JETTemplateContainer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJETTemplateContainer_JetTemplates(), this.getJETTemplate(), this.getJETTemplate_TemplateContainer(), "jetTemplates", null, 0, -1, JETTemplateContainer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		addEOperation(jetTemplateContainerEClass, this.getPath(), "getContainerPath");

		initEClass(jetTemplateEClass, JETTemplate.class, "JETTemplate", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getJETTemplate_TemplateFilePath(), ecorePackage.getEString(), "templateFilePath", null, 0, 1, JETTemplate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getJETTemplate_OutputDirectoryPath(), ecorePackage.getEString(), "outputDirectoryPath", null, 0, 1, JETTemplate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getJETTemplate_PluginVariables(), ecorePackage.getEString(), "pluginVariables", null, 0, 1, JETTemplate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJETTemplate_TemplateContainer(), this.getJETTemplateContainer(), this.getJETTemplateContainer_JetTemplates(), "templateContainer", null, 1, 1, JETTemplate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJETTemplate_Annotations(), this.getJETTemplateAnnotation(), this.getJETTemplateAnnotation_Template(), "annotations", null, 0, -1, JETTemplate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJETTemplate_AdditionalGeneratorArguments(), ecorePackage.getEObject(), null, "additionalGeneratorArguments", null, 0, -1, JETTemplate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		addEOperation(jetTemplateEClass, ecorePackage.getEEList(), "getPluginVariablesList");

		initEClass(javaJETTemplateEClass, JavaJETTemplate.class, "JavaJETTemplate", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(textJETTemplateEClass, TextJETTemplate.class, "TextJETTemplate", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTextJETTemplate_OutputFileName(), ecorePackage.getEString(), "outputFileName", null, 0, 1, TextJETTemplate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTextJETTemplate_FilePrefix(), ecorePackage.getEString(), "filePrefix", null, 0, 1, TextJETTemplate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTextJETTemplate_FileSuffix(), ecorePackage.getEString(), "fileSuffix", null, 0, 1, TextJETTemplate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(gifTemplateEClass, GIFTemplate.class, "GIFTemplate", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getGIFTemplate_OutputFileName(), ecorePackage.getEString(), "outputFileName", null, 0, 1, GIFTemplate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getGIFTemplate_FileSuffix(), ecorePackage.getEString(), "fileSuffix", null, 0, 1, GIFTemplate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getGIFTemplate_FilePrefix(), ecorePackage.getEString(), "filePrefix", null, 0, 1, GIFTemplate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(jetTemplateAnnotationEClass, JETTemplateAnnotation.class, "JETTemplateAnnotation", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getJETTemplateAnnotation_Name(), ecorePackage.getEString(), "name", null, 0, 1, JETTemplateAnnotation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getJETTemplateAnnotation_Value(), ecorePackage.getEString(), "value", null, 0, 1, JETTemplateAnnotation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJETTemplateAnnotation_Template(), this.getJETTemplate(), this.getJETTemplate_Annotations(), "template", null, 0, 1, JETTemplateAnnotation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize data types
		initEDataType(classLoaderEDataType, ClassLoader.class, "ClassLoader", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(iProgressMonitorEDataType, IProgressMonitor.class, "IProgressMonitor", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(javaProjectEDataType, IJavaProject.class, "JavaProject", !IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(jetEmitterEDataType, JETEmitter.class, "JETEmitter", !IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(listEDataType, List.class, "List", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(pathEDataType, IPath.class, "Path", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(resourceEDataType, IResource.class, "Resource", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(stringArrayEDataType, String[].class, "StringArray", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);

		// Create resource
		createResource(eNS_URI);
	}

} //JETTemplatePackageImpl
