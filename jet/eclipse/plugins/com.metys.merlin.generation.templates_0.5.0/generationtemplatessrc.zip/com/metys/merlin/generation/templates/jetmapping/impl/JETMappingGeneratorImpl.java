/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.jetmapping.impl;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.lang.reflect.Method;
import java.net.URL;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourceAttributes;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.SubProgressMonitor;
import org.eclipse.emf.codegen.ecore.CodeGenEcorePlugin;
import org.eclipse.emf.codegen.ecore.Generator;
import org.eclipse.emf.codegen.ecore.genmodel.GenBase;
import org.eclipse.emf.codegen.ecore.genmodel.GenClass;
import org.eclipse.emf.codegen.ecore.genmodel.GenModel;
import org.eclipse.emf.codegen.ecore.genmodel.GenPackage;
import org.eclipse.emf.codegen.ecore.genmodel.impl.GenBaseImpl;
import org.eclipse.emf.codegen.jet.JETCompiler;
import org.eclipse.emf.codegen.jet.JETEmitter;
import org.eclipse.emf.codegen.jet.JETException;
import org.eclipse.emf.codegen.jmerge.JMerger;
import org.eclipse.emf.codegen.jmerge.PropertyMerger;
import org.eclipse.emf.codegen.util.ImportManager;
import org.eclipse.emf.common.command.BasicCommandStack;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.common.util.UniqueEList;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EModelElement;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.mapping.Mapping;
import org.eclipse.emf.mapping.MappingRoot;
import org.eclipse.emf.mapping.domain.AdapterFactoryMappingDomain;
import org.eclipse.jdt.core.IClasspathEntry;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.osgi.framework.Bundle;

import com.metys.merlin.generation.templates.GIFTemplate;
import com.metys.merlin.generation.templates.JETTemplate;
import com.metys.merlin.generation.templates.JETTemplateContainer;
import com.metys.merlin.generation.templates.JETTemplatesPlugin;
import com.metys.merlin.generation.templates.JETURLClassLoader;
import com.metys.merlin.generation.templates.JavaClassLoaderFactory;
import com.metys.merlin.generation.templates.JavaJETTemplate;
import com.metys.merlin.generation.templates.TextJETTemplate;
import com.metys.merlin.generation.templates.jetmapping.JETMappingGenerator;
import com.metys.merlin.generation.templates.jetmapping.JETMappingPackage;
import com.metys.merlin.generation.templates.jetmapping.JETTemplateMapping;
import com.metys.merlin.generation.templates.jetmapping.JETTemplateMappingRoot;
import com.metys.merlin.generation.templates.jetmapping.util.JETMappingAdapterFactory;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Generator</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.templates.jetmapping.impl.JETMappingGeneratorImpl#getMappingRoot <em>Mapping Root</em>}</li>
 *   <li>{@link com.metys.merlin.generation.templates.jetmapping.impl.JETMappingGeneratorImpl#getCurrentGeneratedObject <em>Current Generated Object</em>}</li>
 *   <li>{@link com.metys.merlin.generation.templates.jetmapping.impl.JETMappingGeneratorImpl#getClassLoader <em>Class Loader</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class JETMappingGeneratorImpl extends GenBaseImpl implements JETMappingGenerator {
	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public static final String copyright = "(c) 2005 Jo�l Cheuoua & Contributors";

	/**
	 * The cached value of the '{@link #getMappingRoot() <em>Mapping Root</em>}' reference.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see #getMappingRoot()
	 * @generated
	 * @ordered
	 */
  protected JETTemplateMappingRoot mappingRoot = null;

	/**
	 * The default value of the '{@link #getCurrentGeneratedObject() <em>Current Generated Object</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see #getCurrentGeneratedObject()
	 * @generated
	 * @ordered
	 */
  protected static final Object CURRENT_GENERATED_OBJECT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCurrentGeneratedObject() <em>Current Generated Object</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see #getCurrentGeneratedObject()
	 * @generated
	 * @ordered
	 */
  protected Object currentGeneratedObject = CURRENT_GENERATED_OBJECT_EDEFAULT;

	/**
	 * The default value of the '{@link #getClassLoader() <em>Class Loader</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see #getClassLoader()
	 * @generated
	 * @ordered
	 */
  protected static final ClassLoader CLASS_LOADER_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getClassLoader() <em>Class Loader</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see #getClassLoader()
	 * @generated
	 * @ordered
	 */
  protected ClassLoader classLoader= CLASS_LOADER_EDEFAULT;
  
  private GenModel genModel = null;

  private JETTemplate currentJETTemplate;

  private boolean generatingJava;
  
	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  protected JETMappingGeneratorImpl() {
		super();
	}

  public GenModel getGenModel() {
    if (genModel == null)
      genModel = JETTemplatesPlugin.getJetMappingGenModel();
    return genModel;
  }

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  protected EClass eStaticClass() {
		return JETMappingPackage.eINSTANCE.getJETMappingGenerator();
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public JETTemplateMappingRoot getMappingRoot() {
		if (mappingRoot != null && mappingRoot.eIsProxy()) {
			JETTemplateMappingRoot oldMappingRoot = mappingRoot;
			mappingRoot = (JETTemplateMappingRoot)eResolveProxy((InternalEObject)mappingRoot);
			if (mappingRoot != oldMappingRoot) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, JETMappingPackage.JET_MAPPING_GENERATOR__MAPPING_ROOT, oldMappingRoot, mappingRoot));
			}
		}
		return mappingRoot;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public JETTemplateMappingRoot basicGetMappingRoot() {
		return mappingRoot;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public void setMappingRoot(JETTemplateMappingRoot newMappingRoot) {
		JETTemplateMappingRoot oldMappingRoot = mappingRoot;
		mappingRoot = newMappingRoot;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, JETMappingPackage.JET_MAPPING_GENERATOR__MAPPING_ROOT, oldMappingRoot, mappingRoot));
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public Object getCurrentGeneratedObject() {
		return currentGeneratedObject;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public void setCurrentGeneratedObject(Object newCurrentGeneratedObject) {
		Object oldCurrentGeneratedObject = currentGeneratedObject;
		currentGeneratedObject = newCurrentGeneratedObject;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, JETMappingPackage.JET_MAPPING_GENERATOR__CURRENT_GENERATED_OBJECT, oldCurrentGeneratedObject, currentGeneratedObject));
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public ClassLoader getClassLoader() {
		return classLoader;
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public void setClassLoader(ClassLoader newClassLoader) {
		ClassLoader oldClassLoader = classLoader;
		classLoader = newClassLoader;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, JETMappingPackage.JET_MAPPING_GENERATOR__CLASS_LOADER, oldClassLoader, classLoader));
	}

  public boolean isFeatureMapType(EAttribute attr) {
    String instanceClassName = attr.getEType().getInstanceClassName();
    return "org.eclipse.emf.ecore.util.FeatureMap.Entry".equals(instanceClassName)
        || "org.eclipse.emf.ecore.util.FeatureMap$Entry".equals(instanceClassName);
  }
  
  public boolean isStringType(EAttribute attr) {
    String instanceClassName = attr.getEType().getInstanceClassName();
    return "java.lang.String".equals(instanceClassName);
  }

  public EAttribute getLabelFeature(EClass clazz) {
    EAttribute labelFeature = null;
    for (Iterator iter = clazz.getEAllAttributes().iterator(); iter.hasNext();) {
      EAttribute feature = (EAttribute) iter.next();
      if (!feature.isMany() &&
          isStringType(feature) &&
          !isFeatureMapType(feature) && 
          !feature.isTransient()) {
        String featureName = feature.getName();
        if (featureName != null) {
          if (featureName.equalsIgnoreCase("name")) {
            labelFeature = feature;
          } else if (featureName.equalsIgnoreCase("id")) {
            if (labelFeature == null || !labelFeature.getName().toLowerCase().endsWith("name")) {
              labelFeature = feature;
            }
          } else if (featureName.toLowerCase().endsWith("name")) {
            if (labelFeature == null || !labelFeature.getName().toLowerCase().endsWith("name")
                && !labelFeature.getName().equalsIgnoreCase("id")) {
              labelFeature = feature;
            }
          } else if (featureName.toLowerCase().indexOf("name") != -1) {
            if (labelFeature == null || labelFeature.getName().toLowerCase().indexOf("name") == -1
                && !labelFeature.getName().equalsIgnoreCase("id")) {
              labelFeature = feature;
            }
          } else if (labelFeature == null) {
            labelFeature = feature;
          }
        }
      }      
    }

    return labelFeature;
  }

  private String guessObjectName(Object object) {
    if (object == null)
      return "";
    if (object instanceof EObject) {
      EObject eObject = (EObject) object;
      EClass clazz = eObject.eClass();
      EAttribute labelFeature = getLabelFeature(clazz);
      if (labelFeature != null)
        return (String) eObject.eGet(labelFeature);
      return EcoreUtil.getIdentification(eObject);
    }
    return object.toString();
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.metys.merlin.generation.genpattern.impl.GenerationPatternImpl#loadClass(java.lang.String)
   */
  protected Class loadEmitterClass(String className, ClassLoader cl) throws ClassNotFoundException {
    Class clazz = null;
    try {
      clazz = Class.forName(className, true, cl);
    } catch (Throwable t) {
      clazz = Class.forName(className);
    }
    return clazz;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public void setMethod(JETEmitter jetEmitter, String className, ClassLoader cl) {
    try {
      Class emitterClass = loadEmitterClass(className, cl);
      Method emitterMethod = emitterClass.getDeclaredMethod("generate", new Class[] { Object.class });
      jetEmitter.setMethod(emitterMethod);
    } catch (Exception exception) {
      // It's okay for there not be a precompiled template, so fail
      // quietly.
      // GenpatternPlugin.INSTANCE.log(exception);
    }
  }

  private void initialize(MappingRoot mappingRoot) {
    if (mappingRoot.getTypeMappingRoot() != null) {
      initialize(mappingRoot.getTypeMappingRoot());
    }
    mappingRoot.setTopToBottom(true);
    if (mappingRoot.getDomain() == null)
      mappingRoot.setDomain(new DefaultMappingDomain());      
    for (Iterator it = mappingRoot.eAllContents(); it.hasNext();) {
      Object obj = it.next();
      if (obj instanceof Mapping) {
        Mapping mapping = (Mapping) obj;
        mappingRoot.register(mapping);          
      }
    }
  }
  
  private class DefaultMappingDomain extends AdapterFactoryMappingDomain {
    public DefaultMappingDomain() {
      super(new JETMappingAdapterFactory(), new AdapterFactoryImpl(), new AdapterFactoryImpl(), new BasicCommandStack());
    }
  }
  
  private Collection getMappingTemplates(Object object) {
    MappingRoot root = getMappingRoot();
    ArrayList result = new ArrayList();
    Collection mappings = root.getMappings(object);
    for (Iterator j = mappings.iterator(); j.hasNext();) {
      Mapping mapping = (Mapping) j.next();
      if (mapping.getInputs().contains(object))
        result.addAll(mapping.getOutputs());
      else if (mapping.getOutputs().contains(object))
        result.addAll(mapping.getInputs());      
    }
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public boolean canGenerate(Object object) {
    if (!getMappingTemplates(object).isEmpty())
      return true;
    if (object instanceof EObject) {
      EObject eObject = (EObject) object;
      for (Iterator children = eObject.eContents().iterator(); children.hasNext();) {
        if (canGenerate((EObject)children.next()))
          return true;
      }
    }
    return false;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public void generate(Object object, IProgressMonitor progressMonitor) {
    initialize(getMappingRoot());
    Collection objectsToGenerate = new ArrayList();
    objectsToGenerate.add(object);
    if (object instanceof GenBase)
      genModel = ((GenBase) object).getGenModel();
    ImportManager importManager = new ImportManager("");
    setImportManager(importManager);
    if (object instanceof EObject) {
      EObject eObject = (EObject) object;
      for (Iterator children = eObject.eAllContents();children.hasNext();) {
        objectsToGenerate.add(children.next());
      }
    }
    progressMonitor.beginTask("", objectsToGenerate.size());
    for (Iterator it = objectsToGenerate.iterator(); it.hasNext();) {
      EObject objToGenerate = (EObject) it.next();
      Collection jetTemplates = getMappingTemplates(objToGenerate);      
      if (jetTemplates != null) {
        Iterator templatesIt = jetTemplates.iterator();
        while (templatesIt.hasNext()) {
          Object next = templatesIt.next();
          if (!(next instanceof JETTemplate))
            continue;
          JETTemplate jetTemplate = (JETTemplate) next;
          generate(objToGenerate, jetTemplate, new SubProgressMonitor(progressMonitor, 1));
        }
      }
    }    
    progressMonitor.done();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public void generate(Object object, JETTemplate jettemplate, IProgressMonitor progressMonitor) {
    IPath templateFilePath = Path.fromPortableString(jettemplate.getTemplateFilePath());
    IPath containerPath = jettemplate.getTemplateContainer() == null ? null : jettemplate.getTemplateContainer().getContainerPath();
    if (templateFilePath.getDevice() != null)
      containerPath = null;
    
    IPath resourcePath = containerPath == null ? templateFilePath : containerPath.append(templateFilePath);
    
    IResource resource = null;
    String location = null;
    File file = new File(resourcePath.toString());
    if (file.exists()) {
      location = resourcePath.toString();
    } else {
      resource = ResourcesPlugin.getWorkspace().getRoot().findMember(resourcePath);
      if (resource == null || !resource.exists())
        resource = ResourcesPlugin.getWorkspace().getRoot().findMember(templateFilePath);
      if (resource == null || !resource.exists()) {
        JETTemplatesPlugin.getPlugin().logInError(new Error("Resource " + resourcePath + " not found"), " The Template File Path " + templateFilePath + " has not been not found");
        return;        
      }
      location = resource.getLocation().toString();
    }
    currentJETTemplate = jettemplate;
    if (jettemplate instanceof GIFTemplate) {
      processGIFTemplate(object, jettemplate, resource, location, progressMonitor);
    } else if (jettemplate instanceof JavaJETTemplate) {
      processJavaTemplate(object, jettemplate, resource, location, progressMonitor);
    } else if (jettemplate instanceof TextJETTemplate) {
      processTextTemplate(object, jettemplate, resource, location, progressMonitor);
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public String generateText(Object generatedObject, String jetFilePath, String compiledJETFilesDir, String previousGenerated, IProgressMonitor progressMonitor) {
    try {
      // Parse the JET Template
      JETCompiler jetCompiler = new JETCompiler(jetFilePath, "UTF-8");
      jetCompiler.parse();
      
      // Create the adequate classLoader
      ClassLoader cl = getClassLoader();
      if (compiledJETFilesDir != null) {
        URL[] urls = new URL[1]; 
        urls[0] = new URL("file", null, compiledJETFilesDir);
        cl = new JETURLClassLoader(urls, generatedObject.getClass().getClassLoader());
        ((JETURLClassLoader)classLoader).getDelegateLoaders().add(getClass().getClassLoader());
      }
      JETEmitter jetEmitter = new JETEmitter(jetFilePath, cl);
      setMethod(jetEmitter, jetCompiler.getSkeleton().getPackageName() + "." + jetCompiler.getSkeleton().getClassName(), cl);
      return getGeneratedTextString(progressMonitor, jetEmitter, generatedObject, false, previousGenerated);
    } catch (JETException e) {
      JETTemplatesPlugin.INSTANCE.log(e);
    } catch (IOException e) {
      JETTemplatesPlugin.INSTANCE.log(e);
    }
    return null;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public String generateJava(Object generatedObject, String jetFilePath, String compiledJETFilesDir, String previousGenerated, IProgressMonitor progressMonitor) {
    try {
      // Parse the JET Template
      JETCompiler jetCompiler = new JETCompiler(jetFilePath, "UTF-8");
      jetCompiler.parse();
      
      // Create the adequate classLoader
      ClassLoader cl = getClassLoader();
      if (compiledJETFilesDir != null) {
        URL[] urls = new URL[1]; 
        urls[0] = new URL("file", null, compiledJETFilesDir);
        cl = new JETURLClassLoader(urls, generatedObject.getClass().getClassLoader());
        ((JETURLClassLoader)classLoader).getDelegateLoaders().add(getClass().getClassLoader());
      }
      
      JETEmitter jetEmitter = new JETEmitter(jetFilePath, cl);
      setMethod(jetEmitter, jetCompiler.getSkeleton().getPackageName() + "." + jetCompiler.getSkeleton().getClassName(), cl);
      
      if (generatedObject instanceof GenBase)
        genModel = ((GenBase) generatedObject).getGenModel();
      // Create an dummy import manager for this compilation unit
      ImportManager importManager = new ImportManager("");
      setImportManager(importManager);
      
      return getGeneratedJavaString(progressMonitor, jetEmitter, generatedObject, false, previousGenerated);
    } catch (JETException e) {
      JETTemplatesPlugin.INSTANCE.log(e);
    } catch (IOException e) {
      JETTemplatesPlugin.INSTANCE.log(e);
    }
    return null;
  }
  
  /**
   * @param genBase
   * @param jetTemplate
   * @param resource
   */
  private void processJavaTemplate(Object object, JETTemplate jetTemplate, IResource resource,
      String jetTemplateLocation, IProgressMonitor progressMonitor) {
    JETCompiler jetCompiler = null;
    try {
      jetCompiler = new JETCompiler(jetTemplateLocation, "UTF-8");
      jetCompiler.parse();
    } catch (JETException e) {
      JETTemplatesPlugin.INSTANCE.log(e);
      return;
    }
    JETTemplateContainer jetContainer = (JETTemplateContainer) jetTemplate.eContainer();
    resetClassLoader(object, resource, jetContainer);
    JETEmitter jetEmitter = new JETEmitter(jetTemplateLocation, classLoader);
    setMethod(jetEmitter, 
        jetCompiler.getSkeleton().getPackageName() + "." + jetCompiler.getSkeleton().getClassName(), 
        classLoader);
    String packageName = null;
    String className = null;
    String generated = null;
    try {
      Object argument = null;
      if (getMappingRoot() != null) {
    	argument = new ArrayList();
    	((List)argument).add(object);
        Collection mappings = getMappingRoot().getMappings(object);
        for (Iterator mappingsIt = mappings.iterator();mappingsIt.hasNext();) {
          Object mappingObj = mappingsIt.next();
          if (!(mappingObj instanceof JETTemplateMapping))
            continue;
          if (!jetTemplate.getAdditionalGeneratorArguments().isEmpty()) {          
            ((ArrayList)argument).addAll(jetTemplate.getAdditionalGeneratorArguments());        
          }
        }
      }
      if (argument == null || ((List)argument).size() == 1) {
        argument = object;        
      }
      generated = jetEmitter.generate(new NullProgressMonitor(), new Object[] { argument });
      BufferedReader reader = new BufferedReader(new StringReader(generated));
      // Compute the java package & class name
      String line;
      while ((line = reader.readLine()) != null) {
        String packageDeclaration = "package";
        if (line.indexOf(packageDeclaration) != -1 && packageName == null) {
          int startPackageIndex = line.indexOf(packageDeclaration) + packageDeclaration.length();
          int endPackageIndex = line.indexOf(';', startPackageIndex);
          if (endPackageIndex != -1)
            packageName = line.substring(startPackageIndex, endPackageIndex).trim();
        }
        String[] publicClassDeclarations = new String[] { "public class", "public final class",
            "public abstract class", "abstract public class", "final public class", " class ", "public interface",
            " interface " };
        for (int i = 0; i < publicClassDeclarations.length; i++) {
          String publicClassDeclaration = (String) publicClassDeclarations[i];
          if (line.indexOf(publicClassDeclaration) != -1 && className == null) {
            int startClassIndex = line.indexOf(publicClassDeclaration) + publicClassDeclaration.length();
            String restOfLine = line.substring(startClassIndex);
            while (restOfLine.startsWith(" "))
              restOfLine = restOfLine.substring(1);
            int endClassIndex = restOfLine.indexOf(' ');
            if (endClassIndex != -1)
              className = restOfLine.substring(0, endClassIndex).trim();
            else {
              className = restOfLine;
            }
            break;
          }
        }        
        if (packageName != null && className != null)
          break;
      }
    } catch (JETException e) {
      JETTemplatesPlugin.INSTANCE.log(e);
    } catch (IOException e) {
      JETTemplatesPlugin.INSTANCE.log(e);
    }
    if (className == null) {
      JETTemplatesPlugin.INSTANCE.log(new Error("Error : Cannot compute the java class name for the template : " + jetTemplate.getTemplateFilePath() + ". Java Source Visited : " + jetContainer.getJavaJETSource()));
      return;
    }
        
    produceJava(object, progressMonitor, jetTemplate.getPluginVariablesList(), jetTemplate
        .getOutputDirectoryPath().toString(), packageName == null ? "" : packageName, className, jetEmitter);
  }

  /**
   * @param object
   * @param resource
   * @param jetContainer
   */
  public void resetClassLoader(Object object, IResource resource, JETTemplateContainer jetContainer) {
    if (jetContainer == null)
      return;
    Bundle jetBundle = jetContainer.getBundle();
    IJavaProject javaProject = jetContainer.getJavaProject();
    if (javaProject == null &&  
        jetBundle == null && 
        resource != null)
      javaProject = JavaCore.create(resource.getProject());
    if (javaProject != null && javaProject.exists()) {
      ClassLoader objectClassLoader = object.getClass().getClassLoader();
      classLoader = JavaClassLoaderFactory.getClassLoader(javaProject, objectClassLoader);
    }
    else {
      if (jetBundle != null) {
        ClassLoader objectClassLoader = object.getClass().getClassLoader();
        classLoader = new JETURLClassLoader(new URL[0], objectClassLoader);
        ((JETURLClassLoader)classLoader).getDelegateLoaders().add(jetBundle);
      } else if (classLoader == null)
        classLoader = getClass().getClassLoader();
    }
    if (classLoader instanceof JETURLClassLoader) {
      ClassLoader currentClassLoader = getClass().getClassLoader();
      ((JETURLClassLoader)classLoader).addClassLoaderDelegate(currentClassLoader);
    }
  }
  
  /**
   * @param genBase
   * @return
   */
  private String qualifiedContainerName(Object object, char separator) {
    if (object instanceof EObject) {
      EObject eObject = (EObject) object;
      EObject parent = eObject.eContainer();
      if (parent != null) {
        String name = guessObjectName(parent);
        if (name != null && parent.eContainer() instanceof GenBase)
          return qualifiedContainerName(parent, separator) + separator + name;
        return name == null ? "" : name;
      }
    }
    return "";
  }

  /**
   * @param genBase
   * @param jetTemplate
   * @param resource
   */
  private void processTextTemplate(Object object, JETTemplate jetTemplate, IResource resource,
      String jetTemplateLocation, IProgressMonitor progressMonitor) {
    JETCompiler jetCompiler = null;
    try {
      jetCompiler = new JETCompiler(jetTemplateLocation, "UTF-8");
      jetCompiler.parse();
    } catch (JETException e) {
      JETTemplatesPlugin.INSTANCE.log(e);
      return;
    }
    TextJETTemplate textTemplate = (TextJETTemplate) jetTemplate;
    JETTemplateContainer jetContainer = (JETTemplateContainer) jetTemplate.eContainer();
    resetClassLoader(object, resource, jetContainer);
    JETEmitter jetEmitter = new JETEmitter(jetTemplateLocation, classLoader);
    setMethod(jetEmitter, 
        jetCompiler.getSkeleton().getPackageName() + "." + jetCompiler.getSkeleton().getClassName(),
        classLoader);

    String outputFilePath = jetTemplate.getOutputDirectoryPath() + "/" + textTemplate.getOutputFileName();
    if (textTemplate.getOutputFileName() == null) {
      String filePrefix = textTemplate.getFilePrefix() == null ? "" : textTemplate.getFilePrefix();
      String fileSuffix = textTemplate.getFileSuffix() == null ? "" : textTemplate.getFileSuffix();
      String additionalDirPath = qualifiedContainerName(object, '/');
      if (additionalDirPath.length() > 0)
        additionalDirPath = "/" + additionalDirPath;
      String baseFileame = filePrefix + guessObjectName(object) + fileSuffix;
      outputFilePath = jetTemplate.getOutputDirectoryPath() + additionalDirPath + "/" + baseFileame;
    }

    produceText(object, progressMonitor, jetTemplate.getPluginVariablesList(), outputFilePath, jetEmitter);
  }

  /**
   * @param genBase
   * @param jetTemplate
   * @param resource
   */
  private void processGIFTemplate(Object object, JETTemplate jetTemplate, IResource resource,
      String jetTemplateLocation, IProgressMonitor progressMonitor) {
    GIFTemplate gifTemplate = (GIFTemplate) jetTemplate;
    GIFEmitter gifEmitter = new GIFEmitter(jetTemplateLocation);
    String outputDirectory = gifTemplate.getOutputDirectoryPath().toString();
    String gifName = gifTemplate.getOutputFileName();
    String gifPrefix = gifTemplate.getFilePrefix() == null ? "" : gifTemplate.getFilePrefix();
    String gifSuffix = gifTemplate.getFileSuffix() == null ? "" : gifTemplate.getFileSuffix();
    String genBaseName = guessObjectName(object);
    if (object instanceof GenClass) {
      genBaseName = ((GenClass) object).getInterfaceName();
    } else if (object instanceof GenPackage) {
      genBaseName = ((GenPackage) object).getPrefix();
    } else if (object instanceof GenModel) {
      genBaseName = ((GenModel) object).getModelName();
    }
    if (gifName == null) {
      gifName = gifPrefix + genBaseName + gifSuffix;
    }
    if (gifName == null)
      gifName = gifPrefix + genBaseName + gifSuffix;
    if (!gifName.endsWith(".gif"))
      gifName += ".gif";
    produceGIF(object, progressMonitor, gifTemplate.getPluginVariablesList(), outputDirectory + "/"
        + gifName, genBaseName, gifEmitter);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  private void produceText(Object object, IProgressMonitor progressMonitor, List pluginVariables, String outputFilePath, JETEmitter jetEmitter) {
    setCurrentGeneratedObject(object);
    generate(progressMonitor, -1, pluginVariables, outputFilePath, jetEmitter);
    setCurrentGeneratedObject(null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  private void produceJava(Object object, IProgressMonitor progressMonitor, List pluginVariables, String targetDirectory, String packageName, String className, JETEmitter jetEmitter) {
    setCurrentGeneratedObject(object);
    generate(progressMonitor, -1, pluginVariables, targetDirectory, packageName, className, jetEmitter);
    setCurrentGeneratedObject(null);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  private void produceGIF(Object object, IProgressMonitor progressMonitor, List pluginVariables, String outputFilePath, String name, Object gifEmitter) {
    setCurrentGeneratedObject(object);
    generate(progressMonitor, -1, pluginVariables, outputFilePath, (GIFEmitter) gifEmitter, name);
    setCurrentGeneratedObject(null);
  }  

  /*
   * (non-Javadoc)
   * 
   * @see org.eclipse.emf.codegen.ecore.genmodel.impl.GenBaseImpl#findOrCreateContainer(org.eclipse.core.runtime.IProgressMonitor,
   *      int, java.util.List, org.eclipse.core.runtime.IPath, boolean)
   */
  protected IContainer findOrCreateContainer(IProgressMonitor progressMonitor, int style, List pluginVariables, IPath outputPath, boolean forceStyle) {
    IContainer container = null;
    try {
      progressMonitor.beginTask("", outputPath.segmentCount() + 3);
      progressMonitor.subTask(JETTemplatesPlugin.INSTANCE.getString("_UI_OpeningFolder_message",
          new Object[] { outputPath }));
      if (outputPath.isAbsolute()) {
        IWorkspace workspace = ResourcesPlugin.getWorkspace();
        IProject project = workspace.getRoot().getProject(outputPath.segment(0));

        IPath projectLocation = null;
        List referencedProjects = new UniqueEList();
        if (project.exists()) {
          referencedProjects.addAll(Arrays.asList(project.getDescription().getReferencedProjects()));
          projectLocation = project.getDescription().getLocation();          
        } else if (getCurrentGeneratedObject() instanceof EObject) {
            EObject eObject = (EObject) getCurrentGeneratedObject();
            URI currentGeneratedObjectURI = eObject.eResource().getURI();
            if (currentGeneratedObjectURI.toString().startsWith("platform:/resource/")) {
              IProject currentGeneratedInputProject = workspace.getRoot().getProject(currentGeneratedObjectURI.segments()[1]);
              projectLocation = currentGeneratedInputProject.getDescription().getLocation();            
            }          
            if (projectLocation != null)
              projectLocation = projectLocation.removeLastSegments(1).append(outputPath.segment(0));          
        }
        
        IPath outputFirstSegmentPath = new Path("/" + outputPath.segment(0));
        String srcPackageDir = outputPath.segment(1);
        if (srcPackageDir == null && generatingJava) 
          srcPackageDir = "src";
        IPath path = srcPackageDir == null ? outputFirstSegmentPath : outputFirstSegmentPath.append(srcPackageDir);
        Generator.createEMFProject(path, projectLocation, referencedProjects,
            new SubProgressMonitor(progressMonitor, 1), style, pluginVariables);
        
        if (generatingJava) {
          IJavaProject javaProject = JavaCore.create(project);
          IContainer sourceContainer = project;
          if (path.segmentCount() > 1) {
            sourceContainer = project.getFolder(path.removeFirstSegments(1).makeAbsolute());
            if (!sourceContainer.exists()) {
              ((IFolder)sourceContainer).create(false, true, new SubProgressMonitor(progressMonitor, 1));
            }
          }
          List classpathEntries = new UniqueEList();
          classpathEntries.addAll(Arrays.asList(javaProject.getRawClasspath()));
          boolean sourcePathComputed = false;
          for (Iterator i = classpathEntries.iterator(); i.hasNext(); )   {
            IClasspathEntry classpathEntry = (IClasspathEntry)i.next();
            if (classpathEntry.getPath().isPrefixOf(path) && classpathEntry.getEntryKind() == IClasspathEntry.CPE_SOURCE) {
              i.remove();
            }
            if (classpathEntry.getPath().equals(path) && classpathEntry.getEntryKind() == IClasspathEntry.CPE_SOURCE) {
              sourcePathComputed = true;
            }
          }
          if (!sourcePathComputed) {
            IClasspathEntry sourceClasspathEntry = JavaCore.newSourceEntry(path);
            classpathEntries.add(0, sourceClasspathEntry);
            javaProject.setRawClasspath((IClasspathEntry [])classpathEntries.toArray(new IClasspathEntry [classpathEntries.size()]),
                new SubProgressMonitor(progressMonitor, 1));
          }
        }
        container = project;
        
        for (int i = 1, length = outputPath.segmentCount(); i < length; ++i) {
          IFolder folder = container.getFolder(new Path(outputPath.segment(i)));
          if (!folder.exists()) {
            try {
              folder.create(false, true, new SubProgressMonitor(progressMonitor, 1));
            } catch (CoreException e) {
              JETTemplatesPlugin.getPlugin().logInError(e, null);
            }
          }
          container = folder;
        }
      }
      return container;
    } catch (CoreException e) {
      return container;
    } finally {
      progressMonitor.done();
    }
  }

  protected void generate(IProgressMonitor progressMonitor, int style, List pluginVariables, String targetDirectory, String packageName, String className, JETEmitter jetEmitter) {
    try {
      if (!targetDirectory.startsWith("/"))
        targetDirectory = "/" + targetDirectory;
      IPath targetDirectoryPath = new Path(targetDirectory + "/" );
      IPath outputPath = targetDirectoryPath.append(packageName.replace('.', '/'));
      progressMonitor.beginTask("", 5);
      generatingJava = true;
      IContainer container = findOrCreateContainer(new SubProgressMonitor(progressMonitor, 1), style, pluginVariables, outputPath, false);
      generatingJava = false;
      if (container != null) {
        // Create an import manager for this compilation unit
        ImportManager importManager = new ImportManager(packageName);
        importManager.addMasterImport(packageName, className);
        setImportManager(importManager);
        
        Object argument = null;
        if (currentGeneratedObject instanceof EObject) {
          argument = new ArrayList();
          ((ArrayList)argument).add(currentGeneratedObject);
          Collection mappings = getMappingRoot().getMappings(currentGeneratedObject);
          for (Iterator mappingsIt = mappings.iterator();mappingsIt.hasNext();) {
            Object mappingObj = mappingsIt.next();
            if (!(mappingObj instanceof JETTemplateMapping))
              continue;
            JETTemplate jetTemplate = currentJETTemplate;
            if (!jetTemplate.getAdditionalGeneratorArguments().isEmpty()) {          
              ((ArrayList)argument).addAll(jetTemplate.getAdditionalGeneratorArguments());        
            }
          }
        }
        if (argument == null || ((List)argument).size() == 1) {
          argument = currentGeneratedObject;          
        }
        String emitterResult = jetEmitter.generate(new SubProgressMonitor(progressMonitor, 1), new Object[] { argument });
        progressMonitor.worked(1);

        boolean changed = true;
        IFile targetFile = container.getFile(new Path(className + ".java"));
        progressMonitor.subTask(CodeGenEcorePlugin.INSTANCE.getString("_UI_Generating_message",
            new Object[] { targetFile.getFullPath() }));
        JMerger jMerger = new JMerger();
        jMerger.setControlModel(getGenModel().getJControlModel());
        jMerger.setSourceCompilationUnit(jMerger.createCompilationUnitForContents(emitterResult));
        String newContents = null;
        if (targetFile.exists()) {
          progressMonitor.subTask(CodeGenEcorePlugin.INSTANCE.getString("_UI_ExaminingOld_message",
              new Object[] { targetFile.getFullPath() }));
          jMerger.setTargetCompilationUnit(jMerger.createCompilationUnitForInputStream(targetFile.getContents(true)));
          String oldContents = jMerger.getTargetCompilationUnitContents();

          progressMonitor.subTask(CodeGenEcorePlugin.INSTANCE.getString("_UI_PreparingNew_message",
              new Object[] { targetFile.getFullPath() }));
          jMerger.merge();
          progressMonitor.worked(1);

          newContents = jMerger.getTargetCompilationUnitContents();
          changed = !oldContents.equals(newContents);
          if (changed) {
            if (targetFile.isReadOnly()
                && targetFile.getWorkspace().validateEdit(new IFile[] { targetFile },
                    new SubProgressMonitor(progressMonitor, 1)).isOK()) {
              jMerger.setTargetCompilationUnit(jMerger
                  .createCompilationUnitForInputStream(targetFile.getContents(true)));
              jMerger.remerge();
              newContents = jMerger.getTargetCompilationUnitContents();
            }
          }
        } else {
          changed = true;
          progressMonitor.subTask(CodeGenEcorePlugin.INSTANCE.getString("_UI_PreparingNew_message",
              new Object[] { targetFile.getFullPath() }));
          jMerger.merge();
          progressMonitor.worked(1);
          newContents = jMerger.getTargetCompilationUnitContents();
        }

        if (changed) {
          String encoding = null;
          try {
            encoding = targetFile.getCharset();
          } catch (CoreException ce) {
            // use no encoding
          }
          byte[] bytes = encoding == null ? newContents.getBytes() : newContents.getBytes(encoding);

          InputStream contents = new ByteArrayInputStream(bytes);

          String redirection = getGenModel().getRedirection();
          boolean redirect = redirection != null && redirection.indexOf("{0}") != -1;

          // Use an alternate if we can't write to this one.
          //
          if (redirect) {
            String baseName = MessageFormat.format(redirection, new Object[] { className + ".java" });
            targetFile = container.getFile(new Path(baseName));
            progressMonitor.subTask(CodeGenEcorePlugin.INSTANCE.getString("_UI_UsingAlternate_message",
                new Object[] { targetFile.getFullPath() }));
          }

          if (targetFile.isReadOnly()) {
            if (getGenModel().isForceOverwrite()) {
              ResourceAttributes attrs = new ResourceAttributes();
              attrs.setReadOnly(false);
              targetFile.setResourceAttributes(attrs);
            } else {
              targetFile = container.getFile(new Path("." + className + ".java.new"));
              progressMonitor.subTask(CodeGenEcorePlugin.INSTANCE.getString("_UI_UsingDefaultAlternate_message",
                  new Object[] { targetFile.getFullPath() }));
            }
          }

          if (targetFile.exists()) {
            targetFile.setContents(contents, true, true, new SubProgressMonitor(progressMonitor, 1));
          } else {
            targetFile.create(contents, true, new SubProgressMonitor(progressMonitor, 1));
          }
        }
      } else {
        Error error = new Error("Cannot create container with path : " + targetDirectory );
        JETTemplatesPlugin.getPlugin().logInError(error, "Failed to create container path for code generation");
        throw error;
      }
    } catch (JETException exception) {
      CodeGenEcorePlugin.INSTANCE.log(exception);
    } catch (Exception exception) {
      CodeGenEcorePlugin.INSTANCE.log(exception);
    }

    // Clear the import manager by setting a new one
    ImportManager importManager = new ImportManager(packageName);
    importManager.addMasterImport(packageName, className);
    setImportManager(importManager);

    progressMonitor.done();
  }

  protected void generate(IProgressMonitor progressMonitor, int style, List pluginVariables, String outputFilePath,
      JETEmitter jetEmitter) {
    try {
      IPath outputPath = new Path(outputFilePath.substring(0, outputFilePath.lastIndexOf("/")));      
      progressMonitor.beginTask("", 6);
      progressMonitor.subTask(CodeGenEcorePlugin.INSTANCE.getString("_UI_GeneratingFile_message",
          new Object[] { outputFilePath }));
      IContainer container = findOrCreateContainer(new SubProgressMonitor(progressMonitor, 1), style, pluginVariables,
          outputPath, false);
      if (container != null) {
        IFile targetFile = container.getFile(new Path(outputFilePath.substring(outputFilePath.lastIndexOf("/") + 1)));
        if (targetFile.exists()
            && (outputFilePath.endsWith("/build.properties") || !outputFilePath.endsWith(".properties"))) {
          return;
        }

        boolean changed = false;
        boolean isUnicodeEscapeEncoded = outputFilePath.endsWith(".properties");
        
        Object argument = null;
        if (currentGeneratedObject instanceof EObject) {
          argument = new ArrayList();
          ((ArrayList)argument).add(currentGeneratedObject);
          Collection mappings = getMappingRoot().getMappings(currentGeneratedObject);
          for (Iterator mappingsIt = mappings.iterator();mappingsIt.hasNext();) {
            Object mappingObj = mappingsIt.next();
            if (!(mappingObj instanceof JETTemplateMapping))
              continue;
            JETTemplate jetTemplate = currentJETTemplate;
            if (!jetTemplate.getAdditionalGeneratorArguments().isEmpty()) {          
              ((ArrayList)argument).addAll(jetTemplate.getAdditionalGeneratorArguments());        
            }
          }
        }	
        if (argument == null || ((List)argument).size() == 1) {
          argument = currentGeneratedObject;          
        }
        
        String emitterResult = jetEmitter.generate(new SubProgressMonitor(progressMonitor, 1),
            new Object[] { argument });
        if (isUnicodeEscapeEncoded) {
          emitterResult = unicodeEscapeEncode(emitterResult);
        }

        progressMonitor.worked(1);
        InputStream contents = new ByteArrayInputStream(emitterResult.toString().getBytes(
            isUnicodeEscapeEncoded ? "ISO-8859-1" : "UTF-8"));
        if (targetFile.exists()) {
          // Don't overwrite exising file
          PropertyMerger propertyMerger = new PropertyMerger();
          propertyMerger.setSourceProperties(emitterResult);
          progressMonitor.subTask(CodeGenEcorePlugin.INSTANCE.getString("_UI_ExaminingOld_message",
              new Object[] { targetFile.getFullPath() }));
          String oldProperties = propertyMerger.createPropertiesForInputStream(targetFile.getContents(true));
          propertyMerger.setTargetProperties(oldProperties);
          progressMonitor.subTask(CodeGenEcorePlugin.INSTANCE.getString("_UI_PreparingNew_message",
              new Object[] { targetFile.getFullPath() }));
          propertyMerger.merge();
          progressMonitor.worked(1);

          String mergedResult = propertyMerger.getTargetProperties();
          changed = !mergedResult.equals(oldProperties);
          if (changed) {
            if (targetFile.isReadOnly()
                && targetFile.getWorkspace().validateEdit(new IFile[] { targetFile },
                    new SubProgressMonitor(progressMonitor, 1)).isOK()) {
              propertyMerger.setTargetProperties(propertyMerger.createPropertiesForInputStream(targetFile
                  .getContents(true)));
              propertyMerger.merge();
              mergedResult = propertyMerger.getTargetProperties();
            }

            contents = new ByteArrayInputStream(mergedResult.getBytes(isUnicodeEscapeEncoded ? "ISO-8859-1" : "UTF-8"));
          }
        } else {
          changed = true;
        }

        if (changed) {
          String redirection = getGenModel().getRedirection();
          boolean redirect = redirection != null && redirection.indexOf("{0}") != -1;

          // Use an alternate if we can't write to this one.
          //
          if (redirect) {
            String baseName = MessageFormat.format(redirection, new Object[] { targetFile.getName() });
            targetFile = container.getFile(new Path(baseName));
            progressMonitor.subTask(CodeGenEcorePlugin.INSTANCE.getString("_UI_UsingAlternate_message",
                new Object[] { targetFile.getFullPath() }));
          }

          if (targetFile.isReadOnly()) {
            if (getGenModel().isForceOverwrite()) {
              ResourceAttributes attrs = new ResourceAttributes();
              attrs.setReadOnly(false);
              targetFile.setResourceAttributes(attrs);
            } else {
              targetFile = container.getFile(new Path("." + targetFile.getName() + ".new"));
              progressMonitor.subTask(CodeGenEcorePlugin.INSTANCE.getString("_UI_UsingDefaultAlternate_message",
                  new Object[] { targetFile.getFullPath() }));
            }
          }

          if (targetFile.exists()) {
            targetFile.setContents(contents, true, true, new SubProgressMonitor(progressMonitor, 1));
          } else {
            targetFile.create(contents, true, new SubProgressMonitor(progressMonitor, 1));
            // Force the addition of the PDE requiredPlugin path entry if the file generated is a plugin.xml
            IJavaProject javaProject = JavaCore.create(targetFile.getProject());
            if (javaProject.exists() && 
                targetFile.getParent() == targetFile.getProject() &&
                "plugin.xml".equals(targetFile.getName())) {
              IClasspathEntry[] oldEntries = javaProject.getRawClasspath();
              IClasspathEntry[] newEntries = new IClasspathEntry[oldEntries.length + 1];
              System.arraycopy(oldEntries, 0, newEntries, 0, oldEntries.length);
              newEntries[oldEntries.length] = JavaCore.newContainerEntry(new Path("org.eclipse.pde.core.requiredPlugins"));
              javaProject.setRawClasspath(newEntries, new SubProgressMonitor(progressMonitor, 1));
            }
          }
        }
      } else {
        Error error = new Error("Cannot create container with path : " + outputPath );
        JETTemplatesPlugin.getPlugin().logInError(error, "Failed to create container path for code generation");
        throw error;        
      }
    } catch (Exception exception) {
      CodeGenEcorePlugin.INSTANCE.log(exception);
    } finally {
      progressMonitor.done();
    }
  }
  
  protected String getGeneratedTextString(IProgressMonitor progressMonitor, JETEmitter jetEmitter, Object argument, boolean additionalGenModelArg, String previousGeneratedString) {
    try {
      progressMonitor.beginTask("", 3);
      progressMonitor.subTask("Generating Output");
      
      Object args = argument;
      if (additionalGenModelArg) {
        args = new ArrayList();
        ((ArrayList)args).add(argument);
        ((ArrayList)args).add(getGenModel());        
      }
      
      String emitterResult = jetEmitter.generate(new SubProgressMonitor(progressMonitor, 1),
          new Object[] { args });
      emitterResult = unicodeEscapeEncode(emitterResult);
      
      progressMonitor.worked(1);
      
      if (previousGeneratedString != null) {
        // Don't overwrite exising file
        PropertyMerger propertyMerger = new PropertyMerger();
        propertyMerger.setSourceProperties(emitterResult);
        progressMonitor.subTask(CodeGenEcorePlugin.INSTANCE.getString("_UI_ExaminingOld_message"));
        String oldProperties = previousGeneratedString;
        propertyMerger.setTargetProperties(oldProperties);
        progressMonitor.subTask(CodeGenEcorePlugin.INSTANCE.getString("_UI_PreparingNew_message"));
        propertyMerger.merge();
        progressMonitor.worked(1);

        String mergedResult = propertyMerger.getTargetProperties();
        return mergedResult;
      }
      return emitterResult;
    } catch (Exception exception) {
      JETTemplatesPlugin.INSTANCE.log(exception);
      return "";
    } finally {
      progressMonitor.done();
    }
  }
  
  protected String getGeneratedJavaString(IProgressMonitor progressMonitor, JETEmitter jetEmitter, Object argument, boolean additionalGenModelArg, String previousGeneratedString) {
    try {
      progressMonitor.beginTask("", 3);
      progressMonitor.subTask("Generating Output");
      
      Object args = argument;
      if (additionalGenModelArg) {
        args = new ArrayList();
        ((ArrayList)args).add(argument);
        ((ArrayList)args).add(getGenModel());        
      }
      
      String emitterResult = jetEmitter.generate(new SubProgressMonitor(progressMonitor, 1),
          new Object[] { args });
      emitterResult = unicodeEscapeEncode(emitterResult);
      
      JMerger jMerger = new JMerger();
      jMerger.setControlModel(getGenModel().getJControlModel());
      jMerger.setSourceCompilationUnit(jMerger.createCompilationUnitForContents(emitterResult));
      String newContents = null;
      if (previousGeneratedString != null) {
        progressMonitor.subTask(CodeGenEcorePlugin.INSTANCE.getString("_UI_ExaminingOld_message"));
        jMerger.setTargetCompilationUnit(jMerger.createCompilationUnitForInputStream(new ByteArrayInputStream(previousGeneratedString.getBytes())));
        String oldContents = jMerger.getTargetCompilationUnitContents();

        progressMonitor.subTask(CodeGenEcorePlugin.INSTANCE.getString("_UI_PreparingNew_message"));
        jMerger.merge();
        progressMonitor.worked(1);

        newContents = jMerger.getTargetCompilationUnitContents();        
      } else {
        progressMonitor.subTask(CodeGenEcorePlugin.INSTANCE.getString("_UI_PreparingNew_message"));
        jMerger.merge();
        progressMonitor.worked(1);
        newContents = jMerger.getTargetCompilationUnitContents();
      }
      
      return newContents;
    } catch (Exception exception) {
      JETTemplatesPlugin.INSTANCE.log(exception);
      return "";
    } finally {
      progressMonitor.done();
    }
  }

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case JETMappingPackage.JET_MAPPING_GENERATOR__MAPPING_ROOT:
				if (resolve) return getMappingRoot();
				return basicGetMappingRoot();
			case JETMappingPackage.JET_MAPPING_GENERATOR__CURRENT_GENERATED_OBJECT:
				return getCurrentGeneratedObject();
			case JETMappingPackage.JET_MAPPING_GENERATOR__CLASS_LOADER:
				return getClassLoader();
		}
		return eDynamicGet(eFeature, resolve);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case JETMappingPackage.JET_MAPPING_GENERATOR__MAPPING_ROOT:
				setMappingRoot((JETTemplateMappingRoot)newValue);
				return;
			case JETMappingPackage.JET_MAPPING_GENERATOR__CURRENT_GENERATED_OBJECT:
				setCurrentGeneratedObject((Object)newValue);
				return;
			case JETMappingPackage.JET_MAPPING_GENERATOR__CLASS_LOADER:
				setClassLoader((ClassLoader)newValue);
				return;
		}
		eDynamicSet(eFeature, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public void eUnset(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case JETMappingPackage.JET_MAPPING_GENERATOR__MAPPING_ROOT:
				setMappingRoot((JETTemplateMappingRoot)null);
				return;
			case JETMappingPackage.JET_MAPPING_GENERATOR__CURRENT_GENERATED_OBJECT:
				setCurrentGeneratedObject(CURRENT_GENERATED_OBJECT_EDEFAULT);
				return;
			case JETMappingPackage.JET_MAPPING_GENERATOR__CLASS_LOADER:
				setClassLoader(CLASS_LOADER_EDEFAULT);
				return;
		}
		eDynamicUnset(eFeature);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public boolean eIsSet(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case JETMappingPackage.JET_MAPPING_GENERATOR__MAPPING_ROOT:
				return mappingRoot != null;
			case JETMappingPackage.JET_MAPPING_GENERATOR__CURRENT_GENERATED_OBJECT:
				return CURRENT_GENERATED_OBJECT_EDEFAULT == null ? currentGeneratedObject != null : !CURRENT_GENERATED_OBJECT_EDEFAULT.equals(currentGeneratedObject);
			case JETMappingPackage.JET_MAPPING_GENERATOR__CLASS_LOADER:
				return CLASS_LOADER_EDEFAULT == null ? classLoader != null : !CLASS_LOADER_EDEFAULT.equals(classLoader);
		}
		return eDynamicIsSet(eFeature);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (currentGeneratedObject: ");
		result.append(currentGeneratedObject);
		result.append(", classLoader: ");
		result.append(classLoader);
		result.append(')');
		return result.toString();
	}

  /* (non-Javadoc)
   * @see org.eclipse.emf.codegen.ecore.genmodel.impl.GenBaseImpl#getName()
   */
  public String getName() {
    return "JETMappingGenerator";
  }

  /* (non-Javadoc)
   * @see org.eclipse.emf.codegen.ecore.genmodel.impl.GenBaseImpl#getEcoreModelElement()
   */
  public EModelElement getEcoreModelElement() {
    return null;
  }

  /* (non-Javadoc)
   * @see org.eclipse.emf.codegen.ecore.genmodel.GenBase#reconcile()
   */
  public boolean reconcile() {
    return false;
  }

} //JETMappingGeneratorImpl
