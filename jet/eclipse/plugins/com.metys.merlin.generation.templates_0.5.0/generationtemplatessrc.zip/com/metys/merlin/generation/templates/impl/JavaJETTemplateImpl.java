/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.impl;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.util.InternalEList;

import com.metys.merlin.generation.templates.JETTemplateContainer;
import com.metys.merlin.generation.templates.JETTemplatePackage;
import com.metys.merlin.generation.templates.JavaJETTemplate;

import java.util.Collection;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Java JET Template</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class JavaJETTemplateImpl extends JETTemplateImpl implements JavaJETTemplate {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String copyright = "(c) 2005 Jo�l Cheuoua & Contributors";

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected JavaJETTemplateImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return JETTemplatePackage.eINSTANCE.getJavaJETTemplate();
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case JETTemplatePackage.JAVA_JET_TEMPLATE__TEMPLATE_CONTAINER:
					if (eContainer != null)
						msgs = eBasicRemoveFromContainer(msgs);
					return eBasicSetContainer(otherEnd, JETTemplatePackage.JAVA_JET_TEMPLATE__TEMPLATE_CONTAINER, msgs);
				case JETTemplatePackage.JAVA_JET_TEMPLATE__ANNOTATIONS:
					return ((InternalEList)getAnnotations()).basicAdd(otherEnd, msgs);
				default:
					return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
			}
		}
		if (eContainer != null)
			msgs = eBasicRemoveFromContainer(msgs);
		return eBasicSetContainer(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
		if (featureID >= 0) {
			switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
				case JETTemplatePackage.JAVA_JET_TEMPLATE__TEMPLATE_CONTAINER:
					return eBasicSetContainer(null, JETTemplatePackage.JAVA_JET_TEMPLATE__TEMPLATE_CONTAINER, msgs);
				case JETTemplatePackage.JAVA_JET_TEMPLATE__ANNOTATIONS:
					return ((InternalEList)getAnnotations()).basicRemove(otherEnd, msgs);
				default:
					return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
			}
		}
		return eBasicSetContainer(null, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
		if (eContainerFeatureID >= 0) {
			switch (eContainerFeatureID) {
				case JETTemplatePackage.JAVA_JET_TEMPLATE__TEMPLATE_CONTAINER:
					return eContainer.eInverseRemove(this, JETTemplatePackage.JET_TEMPLATE_CONTAINER__JET_TEMPLATES, JETTemplateContainer.class, msgs);
				default:
					return eDynamicBasicRemoveFromContainer(msgs);
			}
		}
		return eContainer.eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(EStructuralFeature eFeature, boolean resolve) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case JETTemplatePackage.JAVA_JET_TEMPLATE__TEMPLATE_FILE_PATH:
				return getTemplateFilePath();
			case JETTemplatePackage.JAVA_JET_TEMPLATE__OUTPUT_DIRECTORY_PATH:
				return getOutputDirectoryPath();
			case JETTemplatePackage.JAVA_JET_TEMPLATE__PLUGIN_VARIABLES:
				return getPluginVariables();
			case JETTemplatePackage.JAVA_JET_TEMPLATE__TEMPLATE_CONTAINER:
				return getTemplateContainer();
			case JETTemplatePackage.JAVA_JET_TEMPLATE__ANNOTATIONS:
				return getAnnotations();
			case JETTemplatePackage.JAVA_JET_TEMPLATE__ADDITIONAL_GENERATOR_ARGUMENTS:
				return getAdditionalGeneratorArguments();
		}
		return eDynamicGet(eFeature, resolve);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(EStructuralFeature eFeature, Object newValue) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case JETTemplatePackage.JAVA_JET_TEMPLATE__TEMPLATE_FILE_PATH:
				setTemplateFilePath((String)newValue);
				return;
			case JETTemplatePackage.JAVA_JET_TEMPLATE__OUTPUT_DIRECTORY_PATH:
				setOutputDirectoryPath((String)newValue);
				return;
			case JETTemplatePackage.JAVA_JET_TEMPLATE__PLUGIN_VARIABLES:
				setPluginVariables((String)newValue);
				return;
			case JETTemplatePackage.JAVA_JET_TEMPLATE__TEMPLATE_CONTAINER:
				setTemplateContainer((JETTemplateContainer)newValue);
				return;
			case JETTemplatePackage.JAVA_JET_TEMPLATE__ANNOTATIONS:
				getAnnotations().clear();
				getAnnotations().addAll((Collection)newValue);
				return;
			case JETTemplatePackage.JAVA_JET_TEMPLATE__ADDITIONAL_GENERATOR_ARGUMENTS:
				getAdditionalGeneratorArguments().clear();
				getAdditionalGeneratorArguments().addAll((Collection)newValue);
				return;
		}
		eDynamicSet(eFeature, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case JETTemplatePackage.JAVA_JET_TEMPLATE__TEMPLATE_FILE_PATH:
				setTemplateFilePath(TEMPLATE_FILE_PATH_EDEFAULT);
				return;
			case JETTemplatePackage.JAVA_JET_TEMPLATE__OUTPUT_DIRECTORY_PATH:
				setOutputDirectoryPath(OUTPUT_DIRECTORY_PATH_EDEFAULT);
				return;
			case JETTemplatePackage.JAVA_JET_TEMPLATE__PLUGIN_VARIABLES:
				setPluginVariables(PLUGIN_VARIABLES_EDEFAULT);
				return;
			case JETTemplatePackage.JAVA_JET_TEMPLATE__TEMPLATE_CONTAINER:
				setTemplateContainer((JETTemplateContainer)null);
				return;
			case JETTemplatePackage.JAVA_JET_TEMPLATE__ANNOTATIONS:
				getAnnotations().clear();
				return;
			case JETTemplatePackage.JAVA_JET_TEMPLATE__ADDITIONAL_GENERATOR_ARGUMENTS:
				getAdditionalGeneratorArguments().clear();
				return;
		}
		eDynamicUnset(eFeature);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(EStructuralFeature eFeature) {
		switch (eDerivedStructuralFeatureID(eFeature)) {
			case JETTemplatePackage.JAVA_JET_TEMPLATE__TEMPLATE_FILE_PATH:
				return TEMPLATE_FILE_PATH_EDEFAULT == null ? templateFilePath != null : !TEMPLATE_FILE_PATH_EDEFAULT.equals(templateFilePath);
			case JETTemplatePackage.JAVA_JET_TEMPLATE__OUTPUT_DIRECTORY_PATH:
				return OUTPUT_DIRECTORY_PATH_EDEFAULT == null ? outputDirectoryPath != null : !OUTPUT_DIRECTORY_PATH_EDEFAULT.equals(outputDirectoryPath);
			case JETTemplatePackage.JAVA_JET_TEMPLATE__PLUGIN_VARIABLES:
				return PLUGIN_VARIABLES_EDEFAULT == null ? pluginVariables != null : !PLUGIN_VARIABLES_EDEFAULT.equals(pluginVariables);
			case JETTemplatePackage.JAVA_JET_TEMPLATE__TEMPLATE_CONTAINER:
				return getTemplateContainer() != null;
			case JETTemplatePackage.JAVA_JET_TEMPLATE__ANNOTATIONS:
				return annotations != null && !annotations.isEmpty();
			case JETTemplatePackage.JAVA_JET_TEMPLATE__ADDITIONAL_GENERATOR_ARGUMENTS:
				return additionalGeneratorArguments != null && !additionalGeneratorArguments.isEmpty();
		}
		return eDynamicIsSet(eFeature);
	}

} //JavaJETTemplateImpl
