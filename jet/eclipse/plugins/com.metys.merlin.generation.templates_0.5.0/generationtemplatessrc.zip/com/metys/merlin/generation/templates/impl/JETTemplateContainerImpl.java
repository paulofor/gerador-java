/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.templates.impl;

import java.io.IOException;
import java.net.URL;
import java.util.Collection;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentWithInverseEList;
import org.eclipse.emf.ecore.util.InternalEList;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.osgi.framework.Bundle;
import com.metys.merlin.generation.templates.JETTemplate;
import com.metys.merlin.generation.templates.JETTemplateContainer;
import com.metys.merlin.generation.templates.JETTemplatePackage;
import com.metys.merlin.generation.templates.JETTemplatesPlugin;

/**
 * <!-- begin-user-doc --> An implementation of the model object '<em><b>Container</b></em>'. <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 * <li>{@link com.metys.merlin.generation.templates.impl.JETTemplateContainerImpl#getJavaJETSource <em>Java JET Source</em>}</li>
 * <li>{@link com.metys.merlin.generation.templates.impl.JETTemplateContainerImpl#getJetTemplates <em>Jet Templates</em>}</li>
 * </ul>
 * </p>
 * 
 * @generated
 */
public class JETTemplateContainerImpl extends EObjectImpl implements JETTemplateContainer {
  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  public static final String copyright = "(c) 2005 Jo�l Cheuoua & Contributors";

  /**
   * The default value of the '{@link #getJavaJETSource() <em>Java JET Source</em>}' attribute. <!-- begin-user-doc
   * --> <!-- end-user-doc -->
   * 
   * @see #getJavaJETSource()
   * @generated
   * @ordered
   */
  protected static final String JAVA_JET_SOURCE_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getJavaJETSource() <em>Java JET Source</em>}' attribute. <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * 
   * @see #getJavaJETSource()
   * @generated
   * @ordered
   */
  protected String javaJETSource = JAVA_JET_SOURCE_EDEFAULT;

  /**
   * The cached value of the '{@link #getJetTemplates() <em>Jet Templates</em>}' containment reference list. <!--
   * begin-user-doc --> <!-- end-user-doc -->
   * 
   * @see #getJetTemplates()
   * @generated
   * @ordered
   */
  protected EList jetTemplates = null;

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  protected JETTemplateContainerImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  protected EClass eStaticClass() {
    return JETTemplatePackage.eINSTANCE.getJETTemplateContainer();
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  public String getJavaJETSource() {
    return javaJETSource;
  }

  /**
   * <!-- begin-user-doc --> 
   * <!-- end-user-doc -->
   * @generated
   */
  public void setJavaJETSource(String newJavaJETSource) {
    String oldJavaJETSource = javaJETSource;
    javaJETSource = newJavaJETSource;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, JETTemplatePackage.JET_TEMPLATE_CONTAINER__JAVA_JET_SOURCE,
          oldJavaJETSource, javaJETSource));
  }

  /**
   * <!-- begin-user-doc --> 
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getJetTemplates() {
    if (jetTemplates == null) {
      jetTemplates = new EObjectContainmentWithInverseEList(JETTemplate.class, this,
          JETTemplatePackage.JET_TEMPLATE_CONTAINER__JET_TEMPLATES, JETTemplatePackage.JET_TEMPLATE__TEMPLATE_CONTAINER);
    }
    return jetTemplates;
  }

  public Bundle getBundle() {
    if (getJavaJETSource() == null)
      return null;
    IPath javaSourcePath = new Path(getJavaJETSource());
    String projectString = javaSourcePath.segment(0);
    return Platform.getBundle(projectString);
  }

  public IJavaProject getJavaProject() {
    if (getJavaJETSource() == null || getJavaJETSource().trim().length() == 0)
      return null;
    IPath javaSourcePath = new Path(getJavaJETSource());
    String projectString = javaSourcePath.segment(0);
    IProject project = ResourcesPlugin.getWorkspace().getRoot().getProject(projectString);
    IJavaProject javaProject = JavaCore.create(project);
    if (javaProject.exists())
      return javaProject;
    return null;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public IPath getContainerPath() {
    if (getJavaJETSource() == null)
      return new Path("");
    IPath javaSourcePath = new Path(getJavaJETSource());
    IPath folderPath = javaSourcePath.removeFirstSegments(1);
    IJavaProject javaJETProject = getJavaProject();
    if (javaJETProject != null) {
      return javaJETProject.getProject().getFullPath().append(folderPath);
    }
    Bundle bundle = getBundle();
    if (bundle != null) {
      try {
        URL nativeURL = Platform.resolve(bundle.getEntry("/"));
        String rootDir = nativeURL.getFile();
        return new Path(rootDir).append(folderPath);
      } catch (IOException e) {
        JETTemplatesPlugin.getPlugin().logInError(e, "Cannot resolve bundle entry " + bundle.getSymbolicName());
        return null;
      }
    }
    return null;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
      case JETTemplatePackage.JET_TEMPLATE_CONTAINER__JET_TEMPLATES:
        return ((InternalEList) getJetTemplates()).basicAdd(otherEnd, msgs);
      default:
        return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass,
      NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
      case JETTemplatePackage.JET_TEMPLATE_CONTAINER__JET_TEMPLATES:
        return ((InternalEList) getJetTemplates()).basicRemove(otherEnd, msgs);
      default:
        return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case JETTemplatePackage.JET_TEMPLATE_CONTAINER__JAVA_JET_SOURCE:
      return getJavaJETSource();
    case JETTemplatePackage.JET_TEMPLATE_CONTAINER__JET_TEMPLATES:
      return getJetTemplates();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case JETTemplatePackage.JET_TEMPLATE_CONTAINER__JAVA_JET_SOURCE:
      setJavaJETSource((String) newValue);
      return;
    case JETTemplatePackage.JET_TEMPLATE_CONTAINER__JET_TEMPLATES:
      getJetTemplates().clear();
      getJetTemplates().addAll((Collection) newValue);
      return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case JETTemplatePackage.JET_TEMPLATE_CONTAINER__JAVA_JET_SOURCE:
      setJavaJETSource(JAVA_JET_SOURCE_EDEFAULT);
      return;
    case JETTemplatePackage.JET_TEMPLATE_CONTAINER__JET_TEMPLATES:
      getJetTemplates().clear();
      return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case JETTemplatePackage.JET_TEMPLATE_CONTAINER__JAVA_JET_SOURCE:
      return JAVA_JET_SOURCE_EDEFAULT == null ? javaJETSource != null : !JAVA_JET_SOURCE_EDEFAULT.equals(javaJETSource);
    case JETTemplatePackage.JET_TEMPLATE_CONTAINER__JET_TEMPLATES:
      return jetTemplates != null && !jetTemplates.isEmpty();
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc --> <!-- end-user-doc -->
   * 
   * @generated
   */
  public String toString() {
    if (eIsProxy())
      return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (javaJETSource: ");
    result.append(javaJETSource);
    result.append(')');
    return result.toString();
  }

} // JETTemplateContainerImpl
