/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.mappingmodel.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Iterator;

import org.eclipse.emf.common.command.BasicCommandStack;
import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.mapping.Mapping;
import org.eclipse.emf.mapping.MappingRoot;
import org.eclipse.emf.mapping.domain.AdapterFactoryMappingDomain;

import com.metys.merlin.generation.mappingmodel.mapping.Transformer;
import com.metys.merlin.generation.mappingmodel.mapping.TypeMapping;
import com.metys.merlin.generation.mappingmodel.mapping.TypeMappingRoot;
import com.metys.merlin.generation.mappingmodel.mapping.util.MappingAdapterFactory;
import com.metys.merlin.generation.mappingmodel.rules.EvaluationMode;
import com.metys.merlin.generation.mappingmodel.rules.MappingRule;
import com.metys.merlin.generation.mappingmodel.rules.MappingRuleCondition;
import com.metys.merlin.generation.mappingmodel.rules.RulesFactory;


/**
 * @author Jo�l
 */
public class MappingModelUtil {
  
  public static Hashtable mappingCache = new Hashtable();
  
  public static Collection allInputs(Mapping root) {
    ArrayList result = new ArrayList();
    result.addAll(root.getInputs());
    for (Iterator iter = root.getNested().iterator(); iter.hasNext();) {
      Mapping nested = (Mapping) iter.next();
      result.addAll(allInputs(nested));
    }
    return result;
  }
  
  public static Collection allOutputs(Mapping root) {
    ArrayList result = new ArrayList();
    result.addAll(root.getOutputs());
    for (Iterator iter = root.getNested().iterator(); iter.hasNext();) {
      Mapping nested = (Mapping) iter.next();
      result.addAll(allOutputs(nested));
    }
    return result;
  }
  
  public static Mapping addMapping(Object source, Object newTarget, MappingRoot root) {
    Mapping mapping = root.createMapping(Collections.singleton(source), Collections.singleton(newTarget));
    root.getNested().add(mapping);
    root.register(mapping);
    return mapping;
  }
  
  public static void removeMappings(Object object, MappingRoot root) {
    Collection mappings = root.getMappings(object);
    ArrayList copy = new ArrayList(mappings);
    for (Iterator j = copy.iterator(); j.hasNext();) {
      Mapping mapping = (Mapping) j.next();
      if (mapping.getInputs().contains(object)) {
        mapping.getInputs().remove(object);
        if (mapping.getInputs().isEmpty())
          EcoreUtil.remove(mapping);
      }
      if (mapping.getOutputs().contains(object)) {
        mapping.getOutputs().remove(object);
        if (mapping.getOutputs().isEmpty())
          EcoreUtil.remove(mapping);
      }      
    }    
  }
  
  public static void removeMappings(Object source, Object target, MappingRoot root) {
    Collection mappings = root.getMappings(source);
    ArrayList copy = new ArrayList(mappings);
    for (Iterator j = copy.iterator(); j.hasNext();) {
      Mapping mapping = (Mapping) j.next();
      if (mapping.getInputs().contains(source) && 
          mapping.getOutputs().contains(target)) {
        mapping.getInputs().remove(source);
        mapping.getOutputs().remove(target);
        
      }
      if (mapping.getInputs().contains(target) && 
          mapping.getOutputs().contains(source)) {
        mapping.getInputs().remove(target);
        mapping.getOutputs().remove(source);        
      }
      if (mapping.getInputs().isEmpty() &&
          mapping.getOutputs().isEmpty())
        EcoreUtil.remove(mapping);
    }    
  }
  
  public static void replaceMappings(Object prevObject, Object newObject, MappingRoot root) {
    Collection mappings = root.getMappings(prevObject);
    ArrayList copy = new ArrayList(mappings);
    for (Iterator j = copy.iterator(); j.hasNext();) {
      Mapping mapping = (Mapping) j.next();
      if (mapping.getInputs().contains(prevObject)) {
        mapping.getInputs().remove(prevObject);
        mapping.getInputs().add(newObject);
      }
      else if (mapping.getOutputs().contains(prevObject)) {
        mapping.getOutputs().remove(prevObject);
        mapping.getOutputs().add(newObject);
      }
    }    
  }
  
  public static Collection collectMappedObjectsForTypeMapping(Object object, MappingRoot root, Mapping typeMapping) {
    ArrayList result = new ArrayList();
    Collection mappings = root.getMappings(object);
    for (Iterator j = mappings.iterator(); j.hasNext();) {
      Mapping mapping = (Mapping) j.next();
      if (mapping.getTypeMapping() == typeMapping) {
        if (mapping.getInputs().contains(object))
          result.addAll(mapping.getOutputs());
        else if (mapping.getOutputs().contains(object))
          result.addAll(mapping.getInputs());      
      }
    }
    return result;
  }
  
  public static Collection collectMappedObjects(Object object, MappingRoot root) {
    ArrayList result = new ArrayList();
    Collection mappings = root.getMappings(object);
    for (Iterator j = mappings.iterator(); j.hasNext();) {
      Mapping mapping = (Mapping) j.next();
      if (mapping.getInputs().contains(object))
        result.addAll(mapping.getOutputs());
      else if (mapping.getOutputs().contains(object))
        result.addAll(mapping.getInputs());      
    }
    return result;
  }

  public static String qualifiedName(EObject eObject) {
    return qualifiedName(eObject, '.');
  }
  
  public static String qualifiedName(EObject eObject, char separator) {
    String objectName = null;
    EClass eClass = eObject.eClass();
    EStructuralFeature nameAttribute = eClass.getEStructuralFeature("name");
    if (nameAttribute instanceof EAttribute &&
        !nameAttribute.isMany() &&
        "java.lang.String".equals(((EAttribute)nameAttribute).getEAttributeType().getInstanceClassName())) {
      objectName = (String) eObject.eGet(nameAttribute);
    } else {
      return EcoreUtil.getID(eObject);
    }
    if (eObject.eContainer() == null)
      return objectName;
    return qualifiedName(eObject.eContainer(), separator) + separator + objectName;
  }  

  public static void clear(MappingRoot mappingRoot) {
    mappingRoot.getNested().clear();
    mappingRoot.getMappedObjects().clear();
    mappingRoot.getInputs().clear();
    mappingRoot.getOutputs().clear();
    initialize(mappingRoot);
  }
  
  public static void initializeMappingRules(TypeMapping typeMapping) {
    if (typeMapping.getHelper() == null) {
      MappingRule mappingRule = RulesFactory.eINSTANCE.createMappingRule();
      typeMapping.setHelper(mappingRule);
      mappingRule.getMappingRuleActions().addAll(typeMapping.getMappingRuleActions());
      mappingRule.getMappingRuleConditions().addAll(typeMapping.getMappingRuleConditions());
    }    
    for (Iterator iter = typeMapping.getNested().iterator(); iter.hasNext();) {
      TypeMapping subMapping = (TypeMapping) iter.next();
      initializeMappingRules(subMapping);
    }
  }
  public static void initializeMappingRules(TypeMappingRoot typeMappingRoot) {
    for (Iterator iter = typeMappingRoot.getNested().iterator(); iter.hasNext();) {
      TypeMapping typeMapping = (TypeMapping) iter.next();
      initializeMappingRules(typeMapping);
    }
  }
  
  public static void initialize(MappingRoot mappingRoot) {
    if (mappingCache.containsKey(mappingRoot))
      return;
    if (mappingRoot.getTypeMappingRoot() != null) {
      initialize(mappingRoot.getTypeMappingRoot());
    }    
    mappingRoot.setTopToBottom(true);
    if (mappingRoot.getDomain() == null)
      mappingRoot.setDomain(new DefaultMappingDomain());
    for (Iterator it = mappingRoot.eAllContents(); it.hasNext();) {
      Object obj = it.next();
      if (obj instanceof Mapping) {
        Mapping mapping = (Mapping) obj;
        mappingRoot.register(mapping);          
      }
    }
    if (mappingRoot instanceof TypeMappingRoot)
      initializeMappingRules((TypeMappingRoot) mappingRoot);
    mappingCache.put(mappingRoot, new Hashtable());
  }
  
  public static class DefaultMappingDomain extends AdapterFactoryMappingDomain {
    public DefaultMappingDomain() {
      super(new MappingAdapterFactory(), new AdapterFactoryImpl(), new AdapterFactoryImpl(), new BasicCommandStack());
    }
  }

  public static MappingRule getMappingRule(Mapping mapping) {
    if (mapping.getEffectiveHelper() instanceof MappingRule)
      return (MappingRule) mapping.getEffectiveHelper();
    return null;    
  }

  public static boolean canApplyMapping(Mapping mapping, EObject sourceObject, EObject targetObject, Transformer mapper, MappingRoot mappingRoot) {
    MappingRule mappingRule = getMappingRule(mapping);
    if (mappingRule == null)
      return true; // no rules == freedom :)
    Collection mappingConditions = mappingRule.getMappingRuleConditions();
    EvaluationMode mode = mappingRule.getConstraints();
    for (Iterator it = mappingConditions.iterator(); it.hasNext();) {
      MappingRuleCondition ruleCondition = (MappingRuleCondition) it.next();
      if (EvaluationMode.ALL_CONDITIONS_TRUE_LITERAL.equals(mode)
          && !ruleCondition.evaluate(sourceObject, targetObject, mapper, mappingRoot))
        return false;
      if (EvaluationMode.ALL_CONDITIONS_FALSE_LITERAL.equals(mode)
          && ruleCondition.evaluate(sourceObject, targetObject, mapper, mappingRoot))
        return false;
      if (EvaluationMode.ONE_CONDITION_TRUE_LITERAL.equals(mode)
          && ruleCondition.evaluate(sourceObject, targetObject, mapper, mappingRoot))
        return true;
    }
    if (EvaluationMode.ONE_CONDITION_TRUE_LITERAL.equals(mode) && !mappingConditions.isEmpty())
      return false;
    return true;
  }

  public static EObject getFirstInput(Mapping root) {
    if (root.getInputs().isEmpty()) {
      for (Iterator iter = root.getNested().iterator(); iter.hasNext();) {
        Mapping nested = (Mapping) iter.next();
        EObject nestedFirstInput = getFirstInput(nested);
        if (nestedFirstInput != null)
          return nestedFirstInput; 
      }
      return null;
    }
    return (EObject) root.getInputs().get(0);
  }
  
  public static EObject getFirstOutput(Mapping root) {
    if (root.getOutputs().isEmpty()) {
      for (Iterator iter = root.getNested().iterator(); iter.hasNext();) {
        Mapping nested = (Mapping) iter.next();
        EObject nestedFirstInput = getFirstOutput(nested);
        if (nestedFirstInput != null)
          return nestedFirstInput; 
      }
      return null;
    }
    return (EObject) root.getOutputs().get(0);
  }  
  
}
