/**
 * <copyright>
 * </copyright>
 *
 * $Id: Transformer.java,v 1.1 2005/07/07 21:33:31 jcheuoua Exp $
 */
package com.metys.merlin.generation.mappingmodel.mapping;

import java.util.Collection;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.change.ChangeDescription;

import org.eclipse.emf.ecore.resource.Resource;

import org.eclipse.emf.mapping.MappingRoot;

import org.eclipse.emf.mapping.ecore2ecore.Ecore2EcoreMappingRoot;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Transformer</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getTypeMappingRoot <em>Type Mapping Root</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getMappingRoot <em>Mapping Root</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getTargetContext <em>Target Context</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getSourceContext <em>Source Context</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getMappingReports <em>Mapping Reports</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getChangeDescription <em>Change Description</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getMappedInstancesFactory <em>Mapped Instances Factory</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getReferenceChangeHandler <em>Reference Change Handler</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getAttributeChangeHandler <em>Attribute Change Handler</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getMappedInstanceHandler <em>Mapped Instance Handler</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getTransformer()
 * @model
 * @generated
 */
public interface Transformer extends EObject {
  /**
   * Returns the value of the '<em><b>Type Mapping Root</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Type Mapping Root</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Type Mapping Root</em>' reference.
   * @see #setTypeMappingRoot(Ecore2EcoreMappingRoot)
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getTransformer_TypeMappingRoot()
   * @model required="true"
   * @generated
   */
  Ecore2EcoreMappingRoot getTypeMappingRoot();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getTypeMappingRoot <em>Type Mapping Root</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Type Mapping Root</em>' reference.
   * @see #getTypeMappingRoot()
   * @generated
   */
  void setTypeMappingRoot(Ecore2EcoreMappingRoot value);

  /**
   * Returns the value of the '<em><b>Mapping Reports</b></em>' containment reference list.
   * The list contents are of type {@link com.metys.merlin.generation.mappingmodel.mapping.MappingReport}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Mapping Reports</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Mapping Reports</em>' containment reference list.
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getTransformer_MappingReports()
   * @model type="com.metys.merlin.generation.mappingmodel.mapping.MappingReport" containment="true"
   * @generated
   */
  EList getMappingReports();

  /**
   * Returns the value of the '<em><b>Mapped Instances Factory</b></em>' containment reference.
   * It is bidirectional and its opposite is '{@link com.metys.merlin.generation.mappingmodel.mapping.MappedInstancesFactory#getTransformer <em>Transformer</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Mapped Instances Factory</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Mapped Instances Factory</em>' containment reference.
   * @see #setMappedInstancesFactory(MappedInstancesFactory)
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getTransformer_MappedInstancesFactory()
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappedInstancesFactory#getTransformer
   * @model opposite="transformer" containment="true"
   * @generated
   */
  MappedInstancesFactory getMappedInstancesFactory();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getMappedInstancesFactory <em>Mapped Instances Factory</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Mapped Instances Factory</em>' containment reference.
   * @see #getMappedInstancesFactory()
   * @generated
   */
  void setMappedInstancesFactory(MappedInstancesFactory value);

  /**
   * Returns the value of the '<em><b>Reference Change Handler</b></em>' containment reference.
   * It is bidirectional and its opposite is '{@link com.metys.merlin.generation.mappingmodel.mapping.ReferenceChangeHandler#getTransformer <em>Transformer</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Reference Change Handler</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Reference Change Handler</em>' containment reference.
   * @see #setReferenceChangeHandler(ReferenceChangeHandler)
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getTransformer_ReferenceChangeHandler()
   * @see com.metys.merlin.generation.mappingmodel.mapping.ReferenceChangeHandler#getTransformer
   * @model opposite="transformer" containment="true"
   * @generated
   */
  ReferenceChangeHandler getReferenceChangeHandler();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getReferenceChangeHandler <em>Reference Change Handler</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Reference Change Handler</em>' containment reference.
   * @see #getReferenceChangeHandler()
   * @generated
   */
  void setReferenceChangeHandler(ReferenceChangeHandler value);

  /**
   * Returns the value of the '<em><b>Attribute Change Handler</b></em>' containment reference.
   * It is bidirectional and its opposite is '{@link com.metys.merlin.generation.mappingmodel.mapping.AttributeChangeHandler#getTransformer <em>Transformer</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Attribute Change Handler</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Attribute Change Handler</em>' containment reference.
   * @see #setAttributeChangeHandler(AttributeChangeHandler)
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getTransformer_AttributeChangeHandler()
   * @see com.metys.merlin.generation.mappingmodel.mapping.AttributeChangeHandler#getTransformer
   * @model opposite="transformer" containment="true"
   * @generated
   */
  AttributeChangeHandler getAttributeChangeHandler();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getAttributeChangeHandler <em>Attribute Change Handler</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Attribute Change Handler</em>' containment reference.
   * @see #getAttributeChangeHandler()
   * @generated
   */
  void setAttributeChangeHandler(AttributeChangeHandler value);

  /**
   * Returns the value of the '<em><b>Mapped Instance Handler</b></em>' containment reference.
   * It is bidirectional and its opposite is '{@link com.metys.merlin.generation.mappingmodel.mapping.MappedInstanceHandler#getTransformer <em>Transformer</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Mapped Instance Handler</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Mapped Instance Handler</em>' containment reference.
   * @see #setMappedInstanceHandler(MappedInstanceHandler)
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getTransformer_MappedInstanceHandler()
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappedInstanceHandler#getTransformer
   * @model opposite="transformer" containment="true"
   * @generated
   */
  MappedInstanceHandler getMappedInstanceHandler();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getMappedInstanceHandler <em>Mapped Instance Handler</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Mapped Instance Handler</em>' containment reference.
   * @see #getMappedInstanceHandler()
   * @generated
   */
  void setMappedInstanceHandler(MappedInstanceHandler value);

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model dataType="com.metys.merlin.generation.mappingmodel.Collection" sourcesDataType="com.metys.merlin.generation.mappingmodel.Collection" targetsDataType="com.metys.merlin.generation.mappingmodel.Collection" progressDataType="com.metys.merlin.generation.mappingmodel.ProgressMonitor"
   * @generated
   */
  Collection transform(Collection sources, Collection targets, IProgressMonitor progress);

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model dataType="com.metys.merlin.generation.mappingmodel.Collection" sourceDataType="com.metys.merlin.generation.mappingmodel.Resource" targetDataType="com.metys.merlin.generation.mappingmodel.Resource" progressDataType="com.metys.merlin.generation.mappingmodel.ProgressMonitor"
   * @generated
   */
  Collection transform(Resource source, Resource target, IProgressMonitor progress);

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model dataType="com.metys.merlin.generation.mappingmodel.Collection" progressDataType="com.metys.merlin.generation.mappingmodel.ProgressMonitor"
   * @generated
   */
  Collection transform(MappingRoot inputMappingRoot, IProgressMonitor progress);

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model
   * @generated
   */
  void process(EObject source);

  /**
   * Returns the value of the '<em><b>Mapping Root</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Mapping Root</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Mapping Root</em>' reference.
   * @see #setMappingRoot(MappingRoot)
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getTransformer_MappingRoot()
   * @model required="true"
   * @generated
   */
  MappingRoot getMappingRoot();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getMappingRoot <em>Mapping Root</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Mapping Root</em>' reference.
   * @see #getMappingRoot()
   * @generated
   */
  void setMappingRoot(MappingRoot value);

  /**
   * Returns the value of the '<em><b>Change Description</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Change Description</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Change Description</em>' reference.
   * @see #setChangeDescription(ChangeDescription)
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getTransformer_ChangeDescription()
   * @model
   * @generated
   */
  ChangeDescription getChangeDescription();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getChangeDescription <em>Change Description</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Change Description</em>' reference.
   * @see #getChangeDescription()
   * @generated
   */
  void setChangeDescription(ChangeDescription value);

  /**
   * Returns the value of the '<em><b>Target Context</b></em>' attribute list.
   * The list contents are of type {@link org.eclipse.emf.ecore.resource.Resource}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Target Context</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Target Context</em>' attribute list.
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getTransformer_TargetContext()
   * @model type="org.eclipse.emf.ecore.resource.Resource" dataType="com.metys.merlin.generation.mappingmodel.Resource"
   * @generated
   */
  EList getTargetContext();

  /**
   * Returns the value of the '<em><b>Source Context</b></em>' attribute list.
   * The list contents are of type {@link org.eclipse.emf.ecore.resource.Resource}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Source Context</em>' attribute list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Source Context</em>' attribute list.
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getTransformer_SourceContext()
   * @model type="org.eclipse.emf.ecore.resource.Resource" dataType="com.metys.merlin.generation.mappingmodel.Resource"
   * @generated
   */
  EList getSourceContext();

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model
   * @generated
   */
  EObject getFirstMappedInstance(EObject sourceObject, boolean create);

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model
   * @generated
   */
  EObject getFirstMappedInstance(EObject sourceObject, Class mappedJavaClass, boolean create);

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model dataType="com.metys.merlin.generation.mappingmodel.Collection"
   * @generated
   */
  Collection getMappedInstances(EObject sourceObject, boolean create);

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model dataType="com.metys.merlin.generation.mappingmodel.Collection"
   * @generated
   */
  Collection getMappedInstances(EObject sourceObject, Class mappedJavaClass, boolean create);

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model
   * @generated
   */
  boolean isProcessed(EObject eObject);

} // Transformer
