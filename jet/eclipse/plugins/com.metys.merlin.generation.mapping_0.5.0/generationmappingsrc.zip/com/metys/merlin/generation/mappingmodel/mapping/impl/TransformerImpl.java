/**
 * <copyright>
 * </copyright>
 *
 * $Id: TransformerImpl.java,v 1.2 2005/07/10 23:36:13 jcheuoua Exp $
 */
package com.metys.merlin.generation.mappingmodel.mapping.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.change.ChangeDescription;
import org.eclipse.emf.ecore.change.ChangeFactory;
import org.eclipse.emf.ecore.change.util.ChangeRecorder;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;
import org.eclipse.emf.mapping.Mapping;
import org.eclipse.emf.mapping.MappingRoot;
import org.eclipse.emf.mapping.ecore2ecore.Ecore2EcoreMappingRoot;

import com.metys.merlin.generation.mappingmodel.MappingModelPlugin;
import com.metys.merlin.generation.mappingmodel.mapping.AttributeChangeHandler;
import com.metys.merlin.generation.mappingmodel.mapping.MappedInstanceHandler;
import com.metys.merlin.generation.mappingmodel.mapping.MappedInstancesFactory;
import com.metys.merlin.generation.mappingmodel.mapping.MappingFactory;
import com.metys.merlin.generation.mappingmodel.mapping.MappingPackage;
import com.metys.merlin.generation.mappingmodel.mapping.MappingReport;
import com.metys.merlin.generation.mappingmodel.mapping.ReferenceChangeHandler;
import com.metys.merlin.generation.mappingmodel.mapping.Transformer;
import com.metys.merlin.generation.mappingmodel.rules.MappingRule;
import com.metys.merlin.generation.mappingmodel.rules.MappingRuleAction;
import com.metys.merlin.generation.mappingmodel.rules.PolicyKind;
import com.metys.merlin.generation.mappingmodel.util.MappingModelUtil;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Transformer</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.TransformerImpl#getTypeMappingRoot <em>Type Mapping Root</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.TransformerImpl#getMappingRoot <em>Mapping Root</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.TransformerImpl#getTargetContext <em>Target Context</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.TransformerImpl#getSourceContext <em>Source Context</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.TransformerImpl#getMappingReports <em>Mapping Reports</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.TransformerImpl#getChangeDescription <em>Change Description</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.TransformerImpl#getMappedInstancesFactory <em>Mapped Instances Factory</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.TransformerImpl#getReferenceChangeHandler <em>Reference Change Handler</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.TransformerImpl#getAttributeChangeHandler <em>Attribute Change Handler</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.TransformerImpl#getMappedInstanceHandler <em>Mapped Instance Handler</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class TransformerImpl extends EObjectImpl implements Transformer {
  /**
   * The cached value of the '{@link #getTypeMappingRoot() <em>Type Mapping Root</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTypeMappingRoot()
   * @generated
   * @ordered
   */
  protected Ecore2EcoreMappingRoot typeMappingRoot = null;

  /**
   * The cached value of the '{@link #getMappingRoot() <em>Mapping Root</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMappingRoot()
   * @generated
   * @ordered
   */
  protected MappingRoot mappingRoot = null;

  /**
   * The cached value of the '{@link #getTargetContext() <em>Target Context</em>}' attribute list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTargetContext()
   * @generated
   * @ordered
   */
  protected EList targetContext = null;

  /**
   * The cached value of the '{@link #getSourceContext() <em>Source Context</em>}' attribute list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getSourceContext()
   * @generated
   * @ordered
   */
  protected EList sourceContext = null;

  /**
   * The cached value of the '{@link #getMappingReports() <em>Mapping Reports</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMappingReports()
   * @generated
   * @ordered
   */
  protected EList mappingReports = null;

  /**
   * The cached value of the '{@link #getChangeDescription() <em>Change Description</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getChangeDescription()
   * @generated
   * @ordered
   */
  protected ChangeDescription changeDescription = null;

  /**
   * The cached value of the '{@link #getMappedInstancesFactory() <em>Mapped Instances Factory</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMappedInstancesFactory()
   * @generated
   * @ordered
   */
  protected MappedInstancesFactory mappedInstancesFactory = null;

  /**
   * The cached value of the '{@link #getReferenceChangeHandler() <em>Reference Change Handler</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getReferenceChangeHandler()
   * @generated
   * @ordered
   */
  protected ReferenceChangeHandler referenceChangeHandler = null;

  /**
   * The cached value of the '{@link #getAttributeChangeHandler() <em>Attribute Change Handler</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAttributeChangeHandler()
   * @generated
   * @ordered
   */
  protected AttributeChangeHandler attributeChangeHandler = null;

  /**
   * The cached value of the '{@link #getMappedInstanceHandler() <em>Mapped Instance Handler</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMappedInstanceHandler()
   * @generated
   * @ordered
   */
  protected MappedInstanceHandler mappedInstanceHandler = null;

  private ChangeRecorder changeRecorder;

  private HashSet processedSources = new HashSet();

  public long previousTime = 0L;

  public long currentTime = 0L;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  protected TransformerImpl() {
    super();
    setMappedInstancesFactory(MappingFactory.eINSTANCE.createMappedInstancesFactory());
    setMappedInstanceHandler(MappingFactory.eINSTANCE.createMappedInstanceHandler());
    setAttributeChangeHandler(MappingFactory.eINSTANCE.createAttributeChangeHandler());
    setReferenceChangeHandler(MappingFactory.eINSTANCE.createReferenceChangeHandler());
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return MappingPackage.eINSTANCE.getTransformer();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Ecore2EcoreMappingRoot getTypeMappingRoot() {
    if (typeMappingRoot != null && typeMappingRoot.eIsProxy()) {
      Ecore2EcoreMappingRoot oldTypeMappingRoot = typeMappingRoot;
      typeMappingRoot = (Ecore2EcoreMappingRoot) eResolveProxy((InternalEObject) typeMappingRoot);
      if (typeMappingRoot != oldTypeMappingRoot) {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, MappingPackage.TRANSFORMER__TYPE_MAPPING_ROOT,
              oldTypeMappingRoot, typeMappingRoot));
      }
    }
    return typeMappingRoot;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Ecore2EcoreMappingRoot basicGetTypeMappingRoot() {
    return typeMappingRoot;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTypeMappingRoot(Ecore2EcoreMappingRoot newTypeMappingRoot) {
    Ecore2EcoreMappingRoot oldTypeMappingRoot = typeMappingRoot;
    typeMappingRoot = newTypeMappingRoot;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, MappingPackage.TRANSFORMER__TYPE_MAPPING_ROOT,
          oldTypeMappingRoot, typeMappingRoot));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getMappingReports() {
    if (mappingReports == null) {
      mappingReports = new EObjectContainmentEList(MappingReport.class, this,
          MappingPackage.TRANSFORMER__MAPPING_REPORTS);
    }
    return mappingReports;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MappedInstancesFactory getMappedInstancesFactory() {
    return mappedInstancesFactory;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetMappedInstancesFactory(MappedInstancesFactory newMappedInstancesFactory,
      NotificationChain msgs) {
    MappedInstancesFactory oldMappedInstancesFactory = mappedInstancesFactory;
    mappedInstancesFactory = newMappedInstancesFactory;
    if (eNotificationRequired()) {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
          MappingPackage.TRANSFORMER__MAPPED_INSTANCES_FACTORY, oldMappedInstancesFactory, newMappedInstancesFactory);
      if (msgs == null)
        msgs = notification;
      else
        msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMappedInstancesFactory(MappedInstancesFactory newMappedInstancesFactory) {
    if (newMappedInstancesFactory != mappedInstancesFactory) {
      NotificationChain msgs = null;
      if (mappedInstancesFactory != null)
        msgs = ((InternalEObject) mappedInstancesFactory).eInverseRemove(this,
            MappingPackage.MAPPED_INSTANCES_FACTORY__TRANSFORMER, MappedInstancesFactory.class, msgs);
      if (newMappedInstancesFactory != null)
        msgs = ((InternalEObject) newMappedInstancesFactory).eInverseAdd(this,
            MappingPackage.MAPPED_INSTANCES_FACTORY__TRANSFORMER, MappedInstancesFactory.class, msgs);
      msgs = basicSetMappedInstancesFactory(newMappedInstancesFactory, msgs);
      if (msgs != null)
        msgs.dispatch();
    } else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, MappingPackage.TRANSFORMER__MAPPED_INSTANCES_FACTORY,
          newMappedInstancesFactory, newMappedInstancesFactory));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ReferenceChangeHandler getReferenceChangeHandler() {
    return referenceChangeHandler;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetReferenceChangeHandler(ReferenceChangeHandler newReferenceChangeHandler,
      NotificationChain msgs) {
    ReferenceChangeHandler oldReferenceChangeHandler = referenceChangeHandler;
    referenceChangeHandler = newReferenceChangeHandler;
    if (eNotificationRequired()) {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
          MappingPackage.TRANSFORMER__REFERENCE_CHANGE_HANDLER, oldReferenceChangeHandler, newReferenceChangeHandler);
      if (msgs == null)
        msgs = notification;
      else
        msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setReferenceChangeHandler(ReferenceChangeHandler newReferenceChangeHandler) {
    if (newReferenceChangeHandler != referenceChangeHandler) {
      NotificationChain msgs = null;
      if (referenceChangeHandler != null)
        msgs = ((InternalEObject) referenceChangeHandler).eInverseRemove(this,
            MappingPackage.REFERENCE_CHANGE_HANDLER__TRANSFORMER, ReferenceChangeHandler.class, msgs);
      if (newReferenceChangeHandler != null)
        msgs = ((InternalEObject) newReferenceChangeHandler).eInverseAdd(this,
            MappingPackage.REFERENCE_CHANGE_HANDLER__TRANSFORMER, ReferenceChangeHandler.class, msgs);
      msgs = basicSetReferenceChangeHandler(newReferenceChangeHandler, msgs);
      if (msgs != null)
        msgs.dispatch();
    } else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, MappingPackage.TRANSFORMER__REFERENCE_CHANGE_HANDLER,
          newReferenceChangeHandler, newReferenceChangeHandler));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public AttributeChangeHandler getAttributeChangeHandler() {
    return attributeChangeHandler;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetAttributeChangeHandler(AttributeChangeHandler newAttributeChangeHandler,
      NotificationChain msgs) {
    AttributeChangeHandler oldAttributeChangeHandler = attributeChangeHandler;
    attributeChangeHandler = newAttributeChangeHandler;
    if (eNotificationRequired()) {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
          MappingPackage.TRANSFORMER__ATTRIBUTE_CHANGE_HANDLER, oldAttributeChangeHandler, newAttributeChangeHandler);
      if (msgs == null)
        msgs = notification;
      else
        msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setAttributeChangeHandler(AttributeChangeHandler newAttributeChangeHandler) {
    if (newAttributeChangeHandler != attributeChangeHandler) {
      NotificationChain msgs = null;
      if (attributeChangeHandler != null)
        msgs = ((InternalEObject) attributeChangeHandler).eInverseRemove(this,
            MappingPackage.ATTRIBUTE_CHANGE_HANDLER__TRANSFORMER, AttributeChangeHandler.class, msgs);
      if (newAttributeChangeHandler != null)
        msgs = ((InternalEObject) newAttributeChangeHandler).eInverseAdd(this,
            MappingPackage.ATTRIBUTE_CHANGE_HANDLER__TRANSFORMER, AttributeChangeHandler.class, msgs);
      msgs = basicSetAttributeChangeHandler(newAttributeChangeHandler, msgs);
      if (msgs != null)
        msgs.dispatch();
    } else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, MappingPackage.TRANSFORMER__ATTRIBUTE_CHANGE_HANDLER,
          newAttributeChangeHandler, newAttributeChangeHandler));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MappedInstanceHandler getMappedInstanceHandler() {
    return mappedInstanceHandler;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetMappedInstanceHandler(MappedInstanceHandler newMappedInstanceHandler,
      NotificationChain msgs) {
    MappedInstanceHandler oldMappedInstanceHandler = mappedInstanceHandler;
    mappedInstanceHandler = newMappedInstanceHandler;
    if (eNotificationRequired()) {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
          MappingPackage.TRANSFORMER__MAPPED_INSTANCE_HANDLER, oldMappedInstanceHandler, newMappedInstanceHandler);
      if (msgs == null)
        msgs = notification;
      else
        msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMappedInstanceHandler(MappedInstanceHandler newMappedInstanceHandler) {
    if (newMappedInstanceHandler != mappedInstanceHandler) {
      NotificationChain msgs = null;
      if (mappedInstanceHandler != null)
        msgs = ((InternalEObject) mappedInstanceHandler).eInverseRemove(this,
            MappingPackage.MAPPED_INSTANCE_HANDLER__TRANSFORMER, MappedInstanceHandler.class, msgs);
      if (newMappedInstanceHandler != null)
        msgs = ((InternalEObject) newMappedInstanceHandler).eInverseAdd(this,
            MappingPackage.MAPPED_INSTANCE_HANDLER__TRANSFORMER, MappedInstanceHandler.class, msgs);
      msgs = basicSetMappedInstanceHandler(newMappedInstanceHandler, msgs);
      if (msgs != null)
        msgs.dispatch();
    } else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, MappingPackage.TRANSFORMER__MAPPED_INSTANCE_HANDLER,
          newMappedInstanceHandler, newMappedInstanceHandler));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MappingRoot getMappingRoot() {
    if (mappingRoot != null && mappingRoot.eIsProxy()) {
      MappingRoot oldMappingRoot = mappingRoot;
      mappingRoot = (MappingRoot) eResolveProxy((InternalEObject) mappingRoot);
      if (mappingRoot != oldMappingRoot) {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, MappingPackage.TRANSFORMER__MAPPING_ROOT,
              oldMappingRoot, mappingRoot));
      }
    }
    return mappingRoot;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MappingRoot basicGetMappingRoot() {
    return mappingRoot;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMappingRoot(MappingRoot newMappingRoot) {
    MappingRoot oldMappingRoot = mappingRoot;
    mappingRoot = newMappingRoot;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, MappingPackage.TRANSFORMER__MAPPING_ROOT, oldMappingRoot,
          mappingRoot));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ChangeDescription getChangeDescription() {
    if (changeDescription != null && changeDescription.eIsProxy()) {
      ChangeDescription oldChangeDescription = changeDescription;
      changeDescription = (ChangeDescription) eResolveProxy((InternalEObject) changeDescription);
      if (changeDescription != oldChangeDescription) {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE, MappingPackage.TRANSFORMER__CHANGE_DESCRIPTION,
              oldChangeDescription, changeDescription));
      }
    }
    return changeDescription;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ChangeDescription basicGetChangeDescription() {
    return changeDescription;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setChangeDescription(ChangeDescription newChangeDescription) {
    ChangeDescription oldChangeDescription = changeDescription;
    changeDescription = newChangeDescription;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, MappingPackage.TRANSFORMER__CHANGE_DESCRIPTION,
          oldChangeDescription, changeDescription));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getTargetContext() {
    if (targetContext == null) {
      targetContext = new EDataTypeUniqueEList(Resource.class, this, MappingPackage.TRANSFORMER__TARGET_CONTEXT);
    }
    return targetContext;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getSourceContext() {
    if (sourceContext == null) {
      sourceContext = new EDataTypeUniqueEList(Resource.class, this, MappingPackage.TRANSFORMER__SOURCE_CONTEXT);
    }
    return sourceContext;
  }

  /**
   * 
   */
  private void endTransformation() {
    setChangeDescription(changeRecorder.endRecording());
    processedSources.clear();
  }

  /**
   * 
   */
  private void beginTransformation() {
    if (getMappingRoot() == null)
      setMappingRoot(org.eclipse.emf.mapping.MappingFactory.eINSTANCE.createMappingRoot());
    if (getMappingRoot().getTypeMappingRoot() == null && getTypeMappingRoot() != null)
      getMappingRoot().setTypeMapping(getTypeMappingRoot());
    MappingModelUtil.initialize(getMappingRoot());
    MappingModelPlugin.initBSHInterpreter(getClass().getClassLoader(), getSourceContext(), getTargetContext());
    changeRecorder = new ChangeRecorder();
    Collection recordables = new ArrayList();
    setChangeDescription(ChangeFactory.eINSTANCE.createChangeDescription());
    for (Iterator iter = getTargetContext().iterator(); iter.hasNext();) {
      Resource targetResource = (Resource) iter.next();
      recordables.add(targetResource);
      for (Iterator iterator = targetResource.getAllContents(); iterator.hasNext();) {
        EObject element = (EObject) iterator.next();
        recordables.add(element);
      }
    }
    changeRecorder.beginRecording(getChangeDescription(), recordables);
    processedSources.clear();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public Collection transform(Collection sources, Collection targets, IProgressMonitor progress) {
    //  First ensure the mappings are correctely registered
    // and that the mapping domain is provided (prevents a EMF bug)    
    if (sources != null && !getSourceContext().containsAll(sources))
      getSourceContext().addAll(sources);
    if (targets != null && !getTargetContext().containsAll(targets))
      getTargetContext().addAll(targets);

    beginTransformation();
    if (progress != null)
      progress.beginTask("Generating mapped output ...", getSourceContext().size());
    for (Iterator iter = getSourceContext().iterator(); iter.hasNext();) {
      Resource sourceResource = (Resource) iter.next();
      for (Iterator it = sourceResource.getContents().iterator(); it.hasNext();) {
        process((EObject) it.next());
      }
      if (progress != null)
        progress.worked(1);
    }
    endTransformation();

    if (progress != null)
      progress.done();
    return MappingModelUtil.allOutputs(getMappingRoot());
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public Collection transform(Resource source, Resource target, IProgressMonitor progress) {
    //  First ensure the mappings are correctely registered
    // and that the mapping domain is provided (prevents a EMF bug)    
    if (source != null && !getSourceContext().contains(source))
      getSourceContext().add(source);
    if (target != null && !getTargetContext().contains(target))
      getTargetContext().add(target);

    beginTransformation();
    if (progress != null)
      progress.beginTask("Generating mapped output ...", source.getContents().size());
    for (Iterator it = source.getContents().iterator(); it.hasNext();) {
      process((EObject) it.next());
      if (progress != null)
        progress.worked(1);
    }
    endTransformation();
    if (progress != null)
      progress.done();
    return MappingModelUtil.allOutputs(getMappingRoot());
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public Collection transform(MappingRoot inputMappingRoot, IProgressMonitor progress) {
    // First ensure the mappings are correctely registered
    // and that the mapping domain is provided (prevents a EMF bug)    
    setMappingRoot(inputMappingRoot);
    if (inputMappingRoot.getTypeMappingRoot() instanceof Ecore2EcoreMappingRoot)
      setTypeMappingRoot((Ecore2EcoreMappingRoot)inputMappingRoot.getTypeMappingRoot());
    Collection initialSources = MappingModelUtil.allInputs(getMappingRoot());
    for (Iterator iter = initialSources.iterator(); iter.hasNext();) {
      EObject source = (EObject) iter.next();
      Resource sourceResource = source.eResource();
      if (sourceResource != null && !getSourceContext().contains(sourceResource))
        getSourceContext().add(sourceResource);
    }
    Collection initialOutputs = MappingModelUtil.allOutputs(getMappingRoot());
    for (Iterator iter = initialOutputs.iterator(); iter.hasNext();) {
      EObject output = (EObject) iter.next();
      Resource targetResource = output.eResource();
      if (targetResource != null && !getTargetContext().contains(targetResource))
        getTargetContext().add(targetResource);
    }
    beginTransformation();
    if (progress != null)
      progress.beginTask("Generating mapped output ...", initialSources.size());
    for (Iterator iter = getSourceContext().iterator(); iter.hasNext();) {
      Resource sourceResource = (Resource) iter.next();
      for (Iterator it = sourceResource.getContents().iterator(); it.hasNext();) {
        process((EObject) it.next());
      }
      if (progress != null)
        progress.worked(1);
    }
    endTransformation();
    if (progress != null)
      progress.done();
    return MappingModelUtil.allOutputs(getMappingRoot());
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public EObject getFirstMappedInstance(EObject sourceObject, boolean create) {
    Collection mappedInstances = getMappedInstances(sourceObject, create);
    if (mappedInstances.isEmpty())
      return null;
    Object obj = mappedInstances.iterator().next();
    if (obj instanceof EObject)
      return (EObject) obj;
    return null;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public EObject getFirstMappedInstance(EObject sourceObject, Class mappedJavaClass, boolean create) {
    Collection mappedInstances = getMappedInstances(sourceObject, mappedJavaClass, create);
    if (mappedInstances.isEmpty())
      return null;
    Object obj = mappedInstances.iterator().next();
    if (obj instanceof EObject)
      return (EObject) obj;
    return null;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public Collection getMappedInstances(EObject sourceObject, boolean create) {
    if (create)
      process(sourceObject);
    Collection result = MappingModelUtil.collectMappedObjects(sourceObject, getMappingRoot());
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public Collection getMappedInstances(EObject sourceObject, Class mappedJavaClass, boolean create) {
    if (create)
      process(sourceObject);
    Collection mappedInstances = MappingModelUtil.collectMappedObjects(sourceObject, getMappingRoot());
    Collection result = new ArrayList();
    Iterator it = mappedInstances.iterator();
    while (it.hasNext()) {
      Object obj = it.next();
      if (mappedJavaClass.isInstance(obj))
        result.add(obj);
    }
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public boolean isProcessed(EObject eObject) {
    return processedSources.contains(eObject);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public void process(EObject source) {
    if (isProcessed(source))
      return;
    processedSources.add(source);
    EClass sourceClass = source.eClass();
    Collection mappings = getMappingRoot().getTypeMappingRoot().getMappings(sourceClass);
    if (!mappings.isEmpty()) {
      for (Iterator mappingsIt = mappings.iterator(); mappingsIt.hasNext();) {
        Mapping mapping = (Mapping) mappingsIt.next();
        if (MappingModelUtil.canApplyMapping(mapping, source, null, this, getMappingRoot()))
          applyMapping(mapping, source, getMappingRoot());
      }
    }
    // Create mapped instances for contained object if they're not mapped
    for (Iterator iter = source.eContents().iterator(); iter.hasNext();) {
      EObject subObjectSource = (EObject) iter.next();
      process(subObjectSource);
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
      case MappingPackage.TRANSFORMER__MAPPED_INSTANCES_FACTORY:
        if (mappedInstancesFactory != null)
          msgs = ((InternalEObject) mappedInstancesFactory).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
              - MappingPackage.TRANSFORMER__MAPPED_INSTANCES_FACTORY, null, msgs);
        return basicSetMappedInstancesFactory((MappedInstancesFactory) otherEnd, msgs);
      case MappingPackage.TRANSFORMER__REFERENCE_CHANGE_HANDLER:
        if (referenceChangeHandler != null)
          msgs = ((InternalEObject) referenceChangeHandler).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
              - MappingPackage.TRANSFORMER__REFERENCE_CHANGE_HANDLER, null, msgs);
        return basicSetReferenceChangeHandler((ReferenceChangeHandler) otherEnd, msgs);
      case MappingPackage.TRANSFORMER__ATTRIBUTE_CHANGE_HANDLER:
        if (attributeChangeHandler != null)
          msgs = ((InternalEObject) attributeChangeHandler).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
              - MappingPackage.TRANSFORMER__ATTRIBUTE_CHANGE_HANDLER, null, msgs);
        return basicSetAttributeChangeHandler((AttributeChangeHandler) otherEnd, msgs);
      case MappingPackage.TRANSFORMER__MAPPED_INSTANCE_HANDLER:
        if (mappedInstanceHandler != null)
          msgs = ((InternalEObject) mappedInstanceHandler).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
              - MappingPackage.TRANSFORMER__MAPPED_INSTANCE_HANDLER, null, msgs);
        return basicSetMappedInstanceHandler((MappedInstanceHandler) otherEnd, msgs);
      default:
        return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  private void applyMapping(Mapping typeMapping, EObject source, MappingRoot root) {
    // Collect previous targets for this source
    Collection previousSourceTargets = MappingModelUtil.collectMappedObjectsForTypeMapping(source, root, typeMapping);
    // Create & register the mapped instances for this source object
    Collection sourceTargets = getMappedInstancesFactory().createMappedInstances(typeMapping, source, root);

    // Add all new targets to the recordings
    for (Iterator iter = sourceTargets.iterator(); iter.hasNext();) {
      EObject target = (EObject) iter.next();
      if (target.eContainer() != null)
        continue;
      boolean contained = false;
      for (Iterator targetResources = getTargetContext().iterator(); targetResources.hasNext();) {
        Resource targetResource = (Resource) targetResources.next();
        if (targetResource.getContents().contains(target)) {
          contained = true;
          break;
        }
      }
      if (!contained)
        getChangeDescription().getObjectsToAttach().add(target);      
    }
    
    // Proceed on mapped instances
    for (Iterator targetsIt = sourceTargets.iterator(); targetsIt.hasNext();) {
      EObject target = (EObject) targetsIt.next();
      getMappedInstanceHandler().handleMappedInstance(source, target, root);
    }

    MappingRule mappingRule = MappingModelUtil.getMappingRule(typeMapping);
    if (mappingRule.getPolicy() == PolicyKind.ENFORCE_LITERAL) {
      // Remove all previousTarget that are not included on the new mapped objects, 
      // and whose type is contained in the type mapping's outputs  
      for (Iterator iter = previousSourceTargets.iterator(); iter.hasNext();) {
        EObject previousTarget = (EObject) iter.next();
        if (!sourceTargets.contains(previousTarget)) {
          MappingModelUtil.removeMappings(source, previousTarget, getMappingRoot());
          //EcoreUtil.remove(previousTarget);
          //getChangeDescription().getObjectsToDetach().add(previousTarget);
        }
      }
    }
    if (mappingRule != null) {
      for (Iterator targetsIt = sourceTargets.iterator(); targetsIt.hasNext();) {
        EObject target = (EObject) targetsIt.next();
        // Perform the custom actions
        for (Iterator it = mappingRule.getMappingRuleActions().iterator(); it.hasNext();) {
          MappingRuleAction ruleAction = (MappingRuleAction) it.next();
          ruleAction.apply(source, target, this, root);
        }
      }
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass,
      NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
      case MappingPackage.TRANSFORMER__MAPPING_REPORTS:
        return ((InternalEList) getMappingReports()).basicRemove(otherEnd, msgs);
      case MappingPackage.TRANSFORMER__MAPPED_INSTANCES_FACTORY:
        return basicSetMappedInstancesFactory(null, msgs);
      case MappingPackage.TRANSFORMER__REFERENCE_CHANGE_HANDLER:
        return basicSetReferenceChangeHandler(null, msgs);
      case MappingPackage.TRANSFORMER__ATTRIBUTE_CHANGE_HANDLER:
        return basicSetAttributeChangeHandler(null, msgs);
      case MappingPackage.TRANSFORMER__MAPPED_INSTANCE_HANDLER:
        return basicSetMappedInstanceHandler(null, msgs);
      default:
        return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.TRANSFORMER__TYPE_MAPPING_ROOT:
      if (resolve)
        return getTypeMappingRoot();
      return basicGetTypeMappingRoot();
    case MappingPackage.TRANSFORMER__MAPPING_ROOT:
      if (resolve)
        return getMappingRoot();
      return basicGetMappingRoot();
    case MappingPackage.TRANSFORMER__TARGET_CONTEXT:
      return getTargetContext();
    case MappingPackage.TRANSFORMER__SOURCE_CONTEXT:
      return getSourceContext();
    case MappingPackage.TRANSFORMER__MAPPING_REPORTS:
      return getMappingReports();
    case MappingPackage.TRANSFORMER__CHANGE_DESCRIPTION:
      if (resolve)
        return getChangeDescription();
      return basicGetChangeDescription();
    case MappingPackage.TRANSFORMER__MAPPED_INSTANCES_FACTORY:
      return getMappedInstancesFactory();
    case MappingPackage.TRANSFORMER__REFERENCE_CHANGE_HANDLER:
      return getReferenceChangeHandler();
    case MappingPackage.TRANSFORMER__ATTRIBUTE_CHANGE_HANDLER:
      return getAttributeChangeHandler();
    case MappingPackage.TRANSFORMER__MAPPED_INSTANCE_HANDLER:
      return getMappedInstanceHandler();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.TRANSFORMER__TYPE_MAPPING_ROOT:
      setTypeMappingRoot((Ecore2EcoreMappingRoot) newValue);
      return;
    case MappingPackage.TRANSFORMER__MAPPING_ROOT:
      setMappingRoot((MappingRoot) newValue);
      return;
    case MappingPackage.TRANSFORMER__TARGET_CONTEXT:
      getTargetContext().clear();
      getTargetContext().addAll((Collection) newValue);
      return;
    case MappingPackage.TRANSFORMER__SOURCE_CONTEXT:
      getSourceContext().clear();
      getSourceContext().addAll((Collection) newValue);
      return;
    case MappingPackage.TRANSFORMER__MAPPING_REPORTS:
      getMappingReports().clear();
      getMappingReports().addAll((Collection) newValue);
      return;
    case MappingPackage.TRANSFORMER__CHANGE_DESCRIPTION:
      setChangeDescription((ChangeDescription) newValue);
      return;
    case MappingPackage.TRANSFORMER__MAPPED_INSTANCES_FACTORY:
      setMappedInstancesFactory((MappedInstancesFactory) newValue);
      return;
    case MappingPackage.TRANSFORMER__REFERENCE_CHANGE_HANDLER:
      setReferenceChangeHandler((ReferenceChangeHandler) newValue);
      return;
    case MappingPackage.TRANSFORMER__ATTRIBUTE_CHANGE_HANDLER:
      setAttributeChangeHandler((AttributeChangeHandler) newValue);
      return;
    case MappingPackage.TRANSFORMER__MAPPED_INSTANCE_HANDLER:
      setMappedInstanceHandler((MappedInstanceHandler) newValue);
      return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.TRANSFORMER__TYPE_MAPPING_ROOT:
      setTypeMappingRoot((Ecore2EcoreMappingRoot) null);
      return;
    case MappingPackage.TRANSFORMER__MAPPING_ROOT:
      setMappingRoot((MappingRoot) null);
      return;
    case MappingPackage.TRANSFORMER__TARGET_CONTEXT:
      getTargetContext().clear();
      return;
    case MappingPackage.TRANSFORMER__SOURCE_CONTEXT:
      getSourceContext().clear();
      return;
    case MappingPackage.TRANSFORMER__MAPPING_REPORTS:
      getMappingReports().clear();
      return;
    case MappingPackage.TRANSFORMER__CHANGE_DESCRIPTION:
      setChangeDescription((ChangeDescription) null);
      return;
    case MappingPackage.TRANSFORMER__MAPPED_INSTANCES_FACTORY:
      setMappedInstancesFactory((MappedInstancesFactory) null);
      return;
    case MappingPackage.TRANSFORMER__REFERENCE_CHANGE_HANDLER:
      setReferenceChangeHandler((ReferenceChangeHandler) null);
      return;
    case MappingPackage.TRANSFORMER__ATTRIBUTE_CHANGE_HANDLER:
      setAttributeChangeHandler((AttributeChangeHandler) null);
      return;
    case MappingPackage.TRANSFORMER__MAPPED_INSTANCE_HANDLER:
      setMappedInstanceHandler((MappedInstanceHandler) null);
      return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.TRANSFORMER__TYPE_MAPPING_ROOT:
      return typeMappingRoot != null;
    case MappingPackage.TRANSFORMER__MAPPING_ROOT:
      return mappingRoot != null;
    case MappingPackage.TRANSFORMER__TARGET_CONTEXT:
      return targetContext != null && !targetContext.isEmpty();
    case MappingPackage.TRANSFORMER__SOURCE_CONTEXT:
      return sourceContext != null && !sourceContext.isEmpty();
    case MappingPackage.TRANSFORMER__MAPPING_REPORTS:
      return mappingReports != null && !mappingReports.isEmpty();
    case MappingPackage.TRANSFORMER__CHANGE_DESCRIPTION:
      return changeDescription != null;
    case MappingPackage.TRANSFORMER__MAPPED_INSTANCES_FACTORY:
      return mappedInstancesFactory != null;
    case MappingPackage.TRANSFORMER__REFERENCE_CHANGE_HANDLER:
      return referenceChangeHandler != null;
    case MappingPackage.TRANSFORMER__ATTRIBUTE_CHANGE_HANDLER:
      return attributeChangeHandler != null;
    case MappingPackage.TRANSFORMER__MAPPED_INSTANCE_HANDLER:
      return mappedInstanceHandler != null;
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString() {
    if (eIsProxy())
      return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (targetContext: ");
    result.append(targetContext);
    result.append(", sourceContext: ");
    result.append(sourceContext);
    result.append(')');
    return result.toString();
  }

} //TransformerImpl
