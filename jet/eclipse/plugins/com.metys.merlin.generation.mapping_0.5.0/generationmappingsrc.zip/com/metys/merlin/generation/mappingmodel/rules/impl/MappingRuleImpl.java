/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.mappingmodel.rules.impl;

import java.util.Collection;
import java.util.Iterator;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;
import org.eclipse.emf.mapping.Mapping;
import org.eclipse.emf.mapping.MappingHelper;
import org.eclipse.emf.mapping.MappingPackage;
import org.eclipse.emf.mapping.MappingRoot;
import org.eclipse.emf.mapping.impl.MappingHelperImpl;

import com.metys.merlin.generation.mappingmodel.mapping.Transformer;
import com.metys.merlin.generation.mappingmodel.rules.EvaluationMode;
import com.metys.merlin.generation.mappingmodel.rules.MappingRule;
import com.metys.merlin.generation.mappingmodel.rules.MappingRuleAction;
import com.metys.merlin.generation.mappingmodel.rules.MappingRuleCondition;
import com.metys.merlin.generation.mappingmodel.rules.PolicyKind;
import com.metys.merlin.generation.mappingmodel.rules.RulesPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Rule</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.rules.impl.MappingRuleImpl#getName <em>Name</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.rules.impl.MappingRuleImpl#getTargetMatchingConditions <em>Target Matching Conditions</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.rules.impl.MappingRuleImpl#getMappingRuleConditions <em>Mapping Rule Conditions</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.rules.impl.MappingRuleImpl#getMappingRuleActions <em>Mapping Rule Actions</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.rules.impl.MappingRuleImpl#getConstraints <em>Constraints</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.rules.impl.MappingRuleImpl#getPolicy <em>Policy</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class MappingRuleImpl extends MappingHelperImpl implements MappingRule {
  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * The cached value of the '{@link #getTargetMatchingConditions() <em>Target Matching Conditions</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTargetMatchingConditions()
   * @generated
   * @ordered
   */
  protected EList targetMatchingConditions = null;

  /**
   * The cached value of the '{@link #getMappingRuleConditions() <em>Mapping Rule Conditions</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMappingRuleConditions()
   * @generated
   * @ordered
   */
  protected EList mappingRuleConditions = null;

  /**
   * The cached value of the '{@link #getMappingRuleActions() <em>Mapping Rule Actions</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMappingRuleActions()
   * @generated
   * @ordered
   */
  protected EList mappingRuleActions = null;

  /**
   * The default value of the '{@link #getConstraints() <em>Constraints</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getConstraints()
   * @generated
   * @ordered
   */
  protected static final EvaluationMode CONSTRAINTS_EDEFAULT = EvaluationMode.ALL_CONDITIONS_TRUE_LITERAL;

  /**
   * The cached value of the '{@link #getConstraints() <em>Constraints</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getConstraints()
   * @generated
   * @ordered
   */
  protected EvaluationMode constraints = CONSTRAINTS_EDEFAULT;

  /**
   * The default value of the '{@link #getPolicy() <em>Policy</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPolicy()
   * @generated
   * @ordered
   */
  protected static final PolicyKind POLICY_EDEFAULT = PolicyKind.ENFORCE_LITERAL;

  /**
   * The cached value of the '{@link #getPolicy() <em>Policy</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPolicy()
   * @generated
   * @ordered
   */
  protected PolicyKind policy = POLICY_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected MappingRuleImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return RulesPackage.eINSTANCE.getMappingRule();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName() {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(String newName) {
    String oldName = name;
    name = newName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, RulesPackage.MAPPING_RULE__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EvaluationMode getConstraints() {
    return constraints;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setConstraints(EvaluationMode newConstraints) {
    EvaluationMode oldConstraints = constraints;
    constraints = newConstraints == null ? CONSTRAINTS_EDEFAULT : newConstraints;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, RulesPackage.MAPPING_RULE__CONSTRAINTS, oldConstraints,
          constraints));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public PolicyKind getPolicy() {
    return policy;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPolicy(PolicyKind newPolicy) {
    PolicyKind oldPolicy = policy;
    policy = newPolicy == null ? POLICY_EDEFAULT : newPolicy;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, RulesPackage.MAPPING_RULE__POLICY, oldPolicy, policy));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getTargetMatchingConditions() {
    if (targetMatchingConditions == null) {
      targetMatchingConditions = new EObjectContainmentEList(MappingRuleCondition.class, this,
          RulesPackage.MAPPING_RULE__TARGET_MATCHING_CONDITIONS);
    }
    return targetMatchingConditions;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public void fireRule(EObject source, EObject target, Transformer mapper, MappingRoot instancesMappingRoot) {
    for (Iterator it = getMappingRuleActions().iterator(); it.hasNext();) {
      MappingRuleAction ruleAction = (MappingRuleAction) it.next();
      ruleAction.apply(source, target, mapper, instancesMappingRoot);
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public boolean canFireRule(EObject source, EObject target, Transformer mapper, MappingRoot instancesMappingRoot) {
    for (Iterator it = getMappingRuleConditions().iterator(); it.hasNext();) {
      MappingRuleCondition ruleCondition = (MappingRuleCondition) it.next();
      if (EvaluationMode.ALL_CONDITIONS_TRUE_LITERAL.equals(getConstraints())
          && !ruleCondition.evaluate(source, target, mapper, instancesMappingRoot))
        return false;
      if (EvaluationMode.ALL_CONDITIONS_FALSE_LITERAL.equals(getConstraints())
          && ruleCondition.evaluate(source, target, mapper, instancesMappingRoot))
        return false;
      if (EvaluationMode.ONE_CONDITION_TRUE_LITERAL.equals(getConstraints())
          && ruleCondition.evaluate(source, target, mapper, instancesMappingRoot))
        return true;
    }
    if (EvaluationMode.ONE_CONDITION_TRUE_LITERAL.equals(getConstraints()) && !getMappingRuleConditions().isEmpty())
      return false;
    return true;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
      case RulesPackage.MAPPING_RULE__MAPPER:
        if (eContainer != null)
          msgs = eBasicRemoveFromContainer(msgs);
        return eBasicSetContainer(otherEnd, RulesPackage.MAPPING_RULE__MAPPER, msgs);
      case RulesPackage.MAPPING_RULE__NESTED_IN:
        if (eContainer != null)
          msgs = eBasicRemoveFromContainer(msgs);
        return eBasicSetContainer(otherEnd, RulesPackage.MAPPING_RULE__NESTED_IN, msgs);
      case RulesPackage.MAPPING_RULE__NESTED:
        return ((InternalEList) getNested()).basicAdd(otherEnd, msgs);
      default:
        return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getMappingRuleConditions() {
    if (mappingRuleConditions == null) {
      mappingRuleConditions = new EObjectContainmentEList(MappingRuleCondition.class, this,
          RulesPackage.MAPPING_RULE__MAPPING_RULE_CONDITIONS);
    }
    return mappingRuleConditions;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getMappingRuleActions() {
    if (mappingRuleActions == null) {
      mappingRuleActions = new EObjectContainmentEList(MappingRuleAction.class, this,
          RulesPackage.MAPPING_RULE__MAPPING_RULE_ACTIONS);
    }
    return mappingRuleActions;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass,
      NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
      case RulesPackage.MAPPING_RULE__MAPPER:
        return eBasicSetContainer(null, RulesPackage.MAPPING_RULE__MAPPER, msgs);
      case RulesPackage.MAPPING_RULE__NESTED_IN:
        return eBasicSetContainer(null, RulesPackage.MAPPING_RULE__NESTED_IN, msgs);
      case RulesPackage.MAPPING_RULE__NESTED:
        return ((InternalEList) getNested()).basicRemove(otherEnd, msgs);
      case RulesPackage.MAPPING_RULE__TARGET_MATCHING_CONDITIONS:
        return ((InternalEList) getTargetMatchingConditions()).basicRemove(otherEnd, msgs);
      case RulesPackage.MAPPING_RULE__MAPPING_RULE_CONDITIONS:
        return ((InternalEList) getMappingRuleConditions()).basicRemove(otherEnd, msgs);
      case RulesPackage.MAPPING_RULE__MAPPING_RULE_ACTIONS:
        return ((InternalEList) getMappingRuleActions()).basicRemove(otherEnd, msgs);
      default:
        return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
    if (eContainerFeatureID >= 0) {
      switch (eContainerFeatureID) {
      case RulesPackage.MAPPING_RULE__MAPPER:
        return eContainer.eInverseRemove(this, MappingPackage.MAPPING__HELPER, Mapping.class, msgs);
      case RulesPackage.MAPPING_RULE__NESTED_IN:
        return eContainer.eInverseRemove(this, MappingPackage.MAPPING_HELPER__NESTED, MappingHelper.class, msgs);
      default:
        return eDynamicBasicRemoveFromContainer(msgs);
      }
    }
    return eContainer.eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case RulesPackage.MAPPING_RULE__MAPPER:
      return getMapper();
    case RulesPackage.MAPPING_RULE__HELPED_OBJECT:
      if (resolve)
        return getHelpedObject();
      return basicGetHelpedObject();
    case RulesPackage.MAPPING_RULE__NESTED_IN:
      return getNestedIn();
    case RulesPackage.MAPPING_RULE__NESTED:
      return getNested();
    case RulesPackage.MAPPING_RULE__NAME:
      return getName();
    case RulesPackage.MAPPING_RULE__TARGET_MATCHING_CONDITIONS:
      return getTargetMatchingConditions();
    case RulesPackage.MAPPING_RULE__MAPPING_RULE_CONDITIONS:
      return getMappingRuleConditions();
    case RulesPackage.MAPPING_RULE__MAPPING_RULE_ACTIONS:
      return getMappingRuleActions();
    case RulesPackage.MAPPING_RULE__CONSTRAINTS:
      return getConstraints();
    case RulesPackage.MAPPING_RULE__POLICY:
      return getPolicy();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case RulesPackage.MAPPING_RULE__MAPPER:
      setMapper((Mapping) newValue);
      return;
    case RulesPackage.MAPPING_RULE__HELPED_OBJECT:
      setHelpedObject((EObject) newValue);
      return;
    case RulesPackage.MAPPING_RULE__NESTED_IN:
      setNestedIn((MappingHelper) newValue);
      return;
    case RulesPackage.MAPPING_RULE__NESTED:
      getNested().clear();
      getNested().addAll((Collection) newValue);
      return;
    case RulesPackage.MAPPING_RULE__NAME:
      setName((String) newValue);
      return;
    case RulesPackage.MAPPING_RULE__TARGET_MATCHING_CONDITIONS:
      getTargetMatchingConditions().clear();
      getTargetMatchingConditions().addAll((Collection) newValue);
      return;
    case RulesPackage.MAPPING_RULE__MAPPING_RULE_CONDITIONS:
      getMappingRuleConditions().clear();
      getMappingRuleConditions().addAll((Collection) newValue);
      return;
    case RulesPackage.MAPPING_RULE__MAPPING_RULE_ACTIONS:
      getMappingRuleActions().clear();
      getMappingRuleActions().addAll((Collection) newValue);
      return;
    case RulesPackage.MAPPING_RULE__CONSTRAINTS:
      setConstraints((EvaluationMode) newValue);
      return;
    case RulesPackage.MAPPING_RULE__POLICY:
      setPolicy((PolicyKind) newValue);
      return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case RulesPackage.MAPPING_RULE__MAPPER:
      setMapper((Mapping) null);
      return;
    case RulesPackage.MAPPING_RULE__HELPED_OBJECT:
      setHelpedObject((EObject) null);
      return;
    case RulesPackage.MAPPING_RULE__NESTED_IN:
      setNestedIn((MappingHelper) null);
      return;
    case RulesPackage.MAPPING_RULE__NESTED:
      getNested().clear();
      return;
    case RulesPackage.MAPPING_RULE__NAME:
      setName(NAME_EDEFAULT);
      return;
    case RulesPackage.MAPPING_RULE__TARGET_MATCHING_CONDITIONS:
      getTargetMatchingConditions().clear();
      return;
    case RulesPackage.MAPPING_RULE__MAPPING_RULE_CONDITIONS:
      getMappingRuleConditions().clear();
      return;
    case RulesPackage.MAPPING_RULE__MAPPING_RULE_ACTIONS:
      getMappingRuleActions().clear();
      return;
    case RulesPackage.MAPPING_RULE__CONSTRAINTS:
      setConstraints(CONSTRAINTS_EDEFAULT);
      return;
    case RulesPackage.MAPPING_RULE__POLICY:
      setPolicy(POLICY_EDEFAULT);
      return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case RulesPackage.MAPPING_RULE__MAPPER:
      return getMapper() != null;
    case RulesPackage.MAPPING_RULE__HELPED_OBJECT:
      return helpedObject != null;
    case RulesPackage.MAPPING_RULE__NESTED_IN:
      return getNestedIn() != null;
    case RulesPackage.MAPPING_RULE__NESTED:
      return nested != null && !nested.isEmpty();
    case RulesPackage.MAPPING_RULE__NAME:
      return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
    case RulesPackage.MAPPING_RULE__TARGET_MATCHING_CONDITIONS:
      return targetMatchingConditions != null && !targetMatchingConditions.isEmpty();
    case RulesPackage.MAPPING_RULE__MAPPING_RULE_CONDITIONS:
      return mappingRuleConditions != null && !mappingRuleConditions.isEmpty();
    case RulesPackage.MAPPING_RULE__MAPPING_RULE_ACTIONS:
      return mappingRuleActions != null && !mappingRuleActions.isEmpty();
    case RulesPackage.MAPPING_RULE__CONSTRAINTS:
      return constraints != CONSTRAINTS_EDEFAULT;
    case RulesPackage.MAPPING_RULE__POLICY:
      return policy != POLICY_EDEFAULT;
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString() {
    if (eIsProxy())
      return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (name: ");
    result.append(name);
    result.append(", constraints: ");
    result.append(constraints);
    result.append(", policy: ");
    result.append(policy);
    result.append(')');
    return result.toString();
  }

} //MappingRuleImpl
