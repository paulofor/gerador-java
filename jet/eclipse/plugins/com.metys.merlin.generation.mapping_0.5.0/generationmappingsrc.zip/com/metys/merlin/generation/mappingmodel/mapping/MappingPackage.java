/**
 * <copyright>
 * </copyright>
 *
 * $Id: MappingPackage.java,v 1.3 2005/07/07 21:33:31 jcheuoua Exp $
 */
package com.metys.merlin.generation.mappingmodel.mapping;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.mapping.ecore2ecore.Ecore2EcorePackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see com.metys.merlin.generation.mappingmodel.mapping.MappingFactory
 * @model kind="package"
 * @generated
 */
public interface MappingPackage extends EPackage {
  /**
   * The package name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNAME = "mapping";

  /**
   * The package namespace URI.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_URI = "http://www.metys.com/merlin/generation/mappingmodel/mapping.ecore";

  /**
   * The package namespace name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_PREFIX = "mappingmodel.mapping";

  /**
   * The singleton instance of the package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  MappingPackage eINSTANCE = com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl.init();

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.mappingmodel.mapping.impl.TypeMappingRootImpl <em>Type Mapping Root</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.TypeMappingRootImpl
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl#getTypeMappingRoot()
   * @generated
   */
  int TYPE_MAPPING_ROOT = 0;

  /**
   * The feature id for the '<em><b>Helper</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TYPE_MAPPING_ROOT__HELPER = Ecore2EcorePackage.ECORE2_ECORE_MAPPING_ROOT__HELPER;

  /**
   * The feature id for the '<em><b>Nested</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TYPE_MAPPING_ROOT__NESTED = Ecore2EcorePackage.ECORE2_ECORE_MAPPING_ROOT__NESTED;

  /**
   * The feature id for the '<em><b>Nested In</b></em>' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TYPE_MAPPING_ROOT__NESTED_IN = Ecore2EcorePackage.ECORE2_ECORE_MAPPING_ROOT__NESTED_IN;

  /**
   * The feature id for the '<em><b>Inputs</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TYPE_MAPPING_ROOT__INPUTS = Ecore2EcorePackage.ECORE2_ECORE_MAPPING_ROOT__INPUTS;

  /**
   * The feature id for the '<em><b>Outputs</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TYPE_MAPPING_ROOT__OUTPUTS = Ecore2EcorePackage.ECORE2_ECORE_MAPPING_ROOT__OUTPUTS;

  /**
   * The feature id for the '<em><b>Type Mapping</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TYPE_MAPPING_ROOT__TYPE_MAPPING = Ecore2EcorePackage.ECORE2_ECORE_MAPPING_ROOT__TYPE_MAPPING;

  /**
   * The feature id for the '<em><b>Output Read Only</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TYPE_MAPPING_ROOT__OUTPUT_READ_ONLY = Ecore2EcorePackage.ECORE2_ECORE_MAPPING_ROOT__OUTPUT_READ_ONLY;

  /**
   * The feature id for the '<em><b>Top To Bottom</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TYPE_MAPPING_ROOT__TOP_TO_BOTTOM = Ecore2EcorePackage.ECORE2_ECORE_MAPPING_ROOT__TOP_TO_BOTTOM;

  /**
   * The feature id for the '<em><b>Command Stack</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TYPE_MAPPING_ROOT__COMMAND_STACK = Ecore2EcorePackage.ECORE2_ECORE_MAPPING_ROOT__COMMAND_STACK;

  /**
   * The number of structural features of the the '<em>Type Mapping Root</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TYPE_MAPPING_ROOT_FEATURE_COUNT = Ecore2EcorePackage.ECORE2_ECORE_MAPPING_ROOT_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.mappingmodel.mapping.impl.TypeMappingImpl <em>Type Mapping</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.TypeMappingImpl
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl#getTypeMapping()
   * @generated
   */
  int TYPE_MAPPING = 1;

  /**
   * The feature id for the '<em><b>Helper</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TYPE_MAPPING__HELPER = org.eclipse.emf.mapping.MappingPackage.MAPPING__HELPER;

  /**
   * The feature id for the '<em><b>Nested</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TYPE_MAPPING__NESTED = org.eclipse.emf.mapping.MappingPackage.MAPPING__NESTED;

  /**
   * The feature id for the '<em><b>Nested In</b></em>' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TYPE_MAPPING__NESTED_IN = org.eclipse.emf.mapping.MappingPackage.MAPPING__NESTED_IN;

  /**
   * The feature id for the '<em><b>Inputs</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TYPE_MAPPING__INPUTS = org.eclipse.emf.mapping.MappingPackage.MAPPING__INPUTS;

  /**
   * The feature id for the '<em><b>Outputs</b></em>' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TYPE_MAPPING__OUTPUTS = org.eclipse.emf.mapping.MappingPackage.MAPPING__OUTPUTS;

  /**
   * The feature id for the '<em><b>Type Mapping</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TYPE_MAPPING__TYPE_MAPPING = org.eclipse.emf.mapping.MappingPackage.MAPPING__TYPE_MAPPING;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TYPE_MAPPING__NAME = org.eclipse.emf.mapping.MappingPackage.MAPPING_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Mapping Rules</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TYPE_MAPPING__MAPPING_RULES = org.eclipse.emf.mapping.MappingPackage.MAPPING_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Mapping Rule Conditions</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TYPE_MAPPING__MAPPING_RULE_CONDITIONS = org.eclipse.emf.mapping.MappingPackage.MAPPING_FEATURE_COUNT + 2;

  /**
   * The feature id for the '<em><b>Mapping Rule Actions</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TYPE_MAPPING__MAPPING_RULE_ACTIONS = org.eclipse.emf.mapping.MappingPackage.MAPPING_FEATURE_COUNT + 3;

  /**
   * The feature id for the '<em><b>Constraints</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TYPE_MAPPING__CONSTRAINTS = org.eclipse.emf.mapping.MappingPackage.MAPPING_FEATURE_COUNT + 4;

  /**
   * The number of structural features of the the '<em>Type Mapping</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TYPE_MAPPING_FEATURE_COUNT = org.eclipse.emf.mapping.MappingPackage.MAPPING_FEATURE_COUNT + 5;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.mappingmodel.mapping.impl.TransformerImpl <em>Transformer</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.TransformerImpl
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl#getTransformer()
   * @generated
   */
  int TRANSFORMER = 2;

  /**
   * The feature id for the '<em><b>Type Mapping Root</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TRANSFORMER__TYPE_MAPPING_ROOT = 0;

  /**
   * The feature id for the '<em><b>Mapping Root</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TRANSFORMER__MAPPING_ROOT = 1;

  /**
   * The feature id for the '<em><b>Target Context</b></em>' attribute list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TRANSFORMER__TARGET_CONTEXT = 2;

  /**
   * The feature id for the '<em><b>Source Context</b></em>' attribute list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TRANSFORMER__SOURCE_CONTEXT = 3;

  /**
   * The feature id for the '<em><b>Mapping Reports</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TRANSFORMER__MAPPING_REPORTS = 4;

  /**
   * The feature id for the '<em><b>Change Description</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TRANSFORMER__CHANGE_DESCRIPTION = 5;

  /**
   * The feature id for the '<em><b>Mapped Instances Factory</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TRANSFORMER__MAPPED_INSTANCES_FACTORY = 6;

  /**
   * The feature id for the '<em><b>Reference Change Handler</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TRANSFORMER__REFERENCE_CHANGE_HANDLER = 7;

  /**
   * The feature id for the '<em><b>Attribute Change Handler</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TRANSFORMER__ATTRIBUTE_CHANGE_HANDLER = 8;

  /**
   * The feature id for the '<em><b>Mapped Instance Handler</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TRANSFORMER__MAPPED_INSTANCE_HANDLER = 9;

  /**
   * The number of structural features of the the '<em>Transformer</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TRANSFORMER_FEATURE_COUNT = 10;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.mappingmodel.mapping.impl.MappingIdentifierImpl <em>Identifier</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.MappingIdentifierImpl
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl#getMappingIdentifier()
   * @generated
   */
  int MAPPING_IDENTIFIER = 3;

  /**
   * The feature id for the '<em><b>Mapper</b></em>' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_IDENTIFIER__MAPPER = org.eclipse.emf.mapping.MappingPackage.MAPPING_HELPER__MAPPER;

  /**
   * The feature id for the '<em><b>Helped Object</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_IDENTIFIER__HELPED_OBJECT = org.eclipse.emf.mapping.MappingPackage.MAPPING_HELPER__HELPED_OBJECT;

  /**
   * The feature id for the '<em><b>Nested In</b></em>' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_IDENTIFIER__NESTED_IN = org.eclipse.emf.mapping.MappingPackage.MAPPING_HELPER__NESTED_IN;

  /**
   * The feature id for the '<em><b>Nested</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_IDENTIFIER__NESTED = org.eclipse.emf.mapping.MappingPackage.MAPPING_HELPER__NESTED;

  /**
   * The feature id for the '<em><b>Id</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_IDENTIFIER__ID = org.eclipse.emf.mapping.MappingPackage.MAPPING_HELPER_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Mapping Kind</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_IDENTIFIER__MAPPING_KIND = org.eclipse.emf.mapping.MappingPackage.MAPPING_HELPER_FEATURE_COUNT + 1;

  /**
   * The number of structural features of the the '<em>Identifier</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_IDENTIFIER_FEATURE_COUNT = org.eclipse.emf.mapping.MappingPackage.MAPPING_HELPER_FEATURE_COUNT + 2;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.mappingmodel.mapping.impl.MappedInstancesFactoryImpl <em>Mapped Instances Factory</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.MappedInstancesFactoryImpl
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl#getMappedInstancesFactory()
   * @generated
   */
  int MAPPED_INSTANCES_FACTORY = 4;

  /**
   * The feature id for the '<em><b>Transformer</b></em>' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPED_INSTANCES_FACTORY__TRANSFORMER = 0;

  /**
   * The number of structural features of the the '<em>Mapped Instances Factory</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPED_INSTANCES_FACTORY_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.mappingmodel.mapping.impl.MappedInstanceHandlerImpl <em>Mapped Instance Handler</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.MappedInstanceHandlerImpl
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl#getMappedInstanceHandler()
   * @generated
   */
  int MAPPED_INSTANCE_HANDLER = 5;

  /**
   * The feature id for the '<em><b>Transformer</b></em>' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPED_INSTANCE_HANDLER__TRANSFORMER = 0;

  /**
   * The number of structural features of the the '<em>Mapped Instance Handler</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPED_INSTANCE_HANDLER_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.mappingmodel.mapping.impl.AttributeChangeHandlerImpl <em>Attribute Change Handler</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.AttributeChangeHandlerImpl
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl#getAttributeChangeHandler()
   * @generated
   */
  int ATTRIBUTE_CHANGE_HANDLER = 6;

  /**
   * The feature id for the '<em><b>Transformer</b></em>' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ATTRIBUTE_CHANGE_HANDLER__TRANSFORMER = 0;

  /**
   * The number of structural features of the the '<em>Attribute Change Handler</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ATTRIBUTE_CHANGE_HANDLER_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.mappingmodel.mapping.impl.ReferenceChangeHandlerImpl <em>Reference Change Handler</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.ReferenceChangeHandlerImpl
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl#getReferenceChangeHandler()
   * @generated
   */
  int REFERENCE_CHANGE_HANDLER = 7;

  /**
   * The feature id for the '<em><b>Transformer</b></em>' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int REFERENCE_CHANGE_HANDLER__TRANSFORMER = 0;

  /**
   * The number of structural features of the the '<em>Reference Change Handler</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int REFERENCE_CHANGE_HANDLER_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.mappingmodel.mapping.impl.MappingReportImpl <em>Report</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.MappingReportImpl
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl#getMappingReport()
   * @generated
   */
  int MAPPING_REPORT = 8;

  /**
   * The feature id for the '<em><b>Severity</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_REPORT__SEVERITY = 0;

  /**
   * The feature id for the '<em><b>Message</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_REPORT__MESSAGE = 1;

  /**
   * The number of structural features of the the '<em>Report</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_REPORT_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.mappingmodel.mapping.impl.EObjectDiffNodeImpl <em>EObject Diff Node</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.EObjectDiffNodeImpl
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl#getEObjectDiffNode()
   * @generated
   */
  int EOBJECT_DIFF_NODE = 9;

  /**
   * The feature id for the '<em><b>Sub Diff Nodes</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EOBJECT_DIFF_NODE__SUB_DIFF_NODES = 0;

  /**
   * The feature id for the '<em><b>Change Description</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EOBJECT_DIFF_NODE__CHANGE_DESCRIPTION = 1;

  /**
   * The number of structural features of the the '<em>EObject Diff Node</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EOBJECT_DIFF_NODE_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.mappingmodel.mapping.impl.ReconcilingDiffTreeImpl <em>Reconciling Diff Tree</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.ReconcilingDiffTreeImpl
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl#getReconcilingDiffTree()
   * @generated
   */
  int RECONCILING_DIFF_TREE = 10;

  /**
   * The feature id for the '<em><b>Roots</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int RECONCILING_DIFF_TREE__ROOTS = 0;

  /**
   * The number of structural features of the the '<em>Reconciling Diff Tree</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int RECONCILING_DIFF_TREE_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.mappingmodel.mapping.SeverityKind <em>Severity Kind</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.mappingmodel.mapping.SeverityKind
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl#getSeverityKind()
   * @generated
   */
  int SEVERITY_KIND = 11;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.mappingmodel.mapping.MappingKind <em>Kind</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingKind
   * @see com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl#getMappingKind()
   * @generated
   */
  int MAPPING_KIND = 12;

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.mappingmodel.mapping.TypeMappingRoot <em>Type Mapping Root</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Type Mapping Root</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.TypeMappingRoot
   * @generated
   */
  EClass getTypeMappingRoot();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.mappingmodel.mapping.TypeMapping <em>Type Mapping</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Type Mapping</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.TypeMapping
   * @generated
   */
  EClass getTypeMapping();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.mappingmodel.mapping.TypeMapping#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.TypeMapping#getName()
   * @see #getTypeMapping()
   * @generated
   */
  EAttribute getTypeMapping_Name();

  /**
   * Returns the meta object for the containment reference list '{@link com.metys.merlin.generation.mappingmodel.mapping.TypeMapping#getMappingRules <em>Mapping Rules</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Mapping Rules</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.TypeMapping#getMappingRules()
   * @see #getTypeMapping()
   * @generated
   */
  EReference getTypeMapping_MappingRules();

  /**
   * Returns the meta object for the containment reference list '{@link com.metys.merlin.generation.mappingmodel.mapping.TypeMapping#getMappingRuleConditions <em>Mapping Rule Conditions</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Mapping Rule Conditions</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.TypeMapping#getMappingRuleConditions()
   * @see #getTypeMapping()
   * @generated
   */
  EReference getTypeMapping_MappingRuleConditions();

  /**
   * Returns the meta object for the containment reference list '{@link com.metys.merlin.generation.mappingmodel.mapping.TypeMapping#getMappingRuleActions <em>Mapping Rule Actions</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Mapping Rule Actions</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.TypeMapping#getMappingRuleActions()
   * @see #getTypeMapping()
   * @generated
   */
  EReference getTypeMapping_MappingRuleActions();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.mappingmodel.mapping.TypeMapping#getConstraints <em>Constraints</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Constraints</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.TypeMapping#getConstraints()
   * @see #getTypeMapping()
   * @generated
   */
  EAttribute getTypeMapping_Constraints();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer <em>Transformer</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Transformer</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.Transformer
   * @generated
   */
  EClass getTransformer();

  /**
   * Returns the meta object for the reference '{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getTypeMappingRoot <em>Type Mapping Root</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Type Mapping Root</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.Transformer#getTypeMappingRoot()
   * @see #getTransformer()
   * @generated
   */
  EReference getTransformer_TypeMappingRoot();

  /**
   * Returns the meta object for the containment reference list '{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getMappingReports <em>Mapping Reports</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Mapping Reports</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.Transformer#getMappingReports()
   * @see #getTransformer()
   * @generated
   */
  EReference getTransformer_MappingReports();

  /**
   * Returns the meta object for the containment reference '{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getMappedInstancesFactory <em>Mapped Instances Factory</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Mapped Instances Factory</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.Transformer#getMappedInstancesFactory()
   * @see #getTransformer()
   * @generated
   */
  EReference getTransformer_MappedInstancesFactory();

  /**
   * Returns the meta object for the containment reference '{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getReferenceChangeHandler <em>Reference Change Handler</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Reference Change Handler</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.Transformer#getReferenceChangeHandler()
   * @see #getTransformer()
   * @generated
   */
  EReference getTransformer_ReferenceChangeHandler();

  /**
   * Returns the meta object for the containment reference '{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getAttributeChangeHandler <em>Attribute Change Handler</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Attribute Change Handler</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.Transformer#getAttributeChangeHandler()
   * @see #getTransformer()
   * @generated
   */
  EReference getTransformer_AttributeChangeHandler();

  /**
   * Returns the meta object for the containment reference '{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getMappedInstanceHandler <em>Mapped Instance Handler</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Mapped Instance Handler</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.Transformer#getMappedInstanceHandler()
   * @see #getTransformer()
   * @generated
   */
  EReference getTransformer_MappedInstanceHandler();

  /**
   * Returns the meta object for the reference '{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getMappingRoot <em>Mapping Root</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Mapping Root</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.Transformer#getMappingRoot()
   * @see #getTransformer()
   * @generated
   */
  EReference getTransformer_MappingRoot();

  /**
   * Returns the meta object for the reference '{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getChangeDescription <em>Change Description</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Change Description</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.Transformer#getChangeDescription()
   * @see #getTransformer()
   * @generated
   */
  EReference getTransformer_ChangeDescription();

  /**
   * Returns the meta object for the attribute list '{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getTargetContext <em>Target Context</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute list '<em>Target Context</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.Transformer#getTargetContext()
   * @see #getTransformer()
   * @generated
   */
  EAttribute getTransformer_TargetContext();

  /**
   * Returns the meta object for the attribute list '{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getSourceContext <em>Source Context</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute list '<em>Source Context</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.Transformer#getSourceContext()
   * @see #getTransformer()
   * @generated
   */
  EAttribute getTransformer_SourceContext();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.mappingmodel.mapping.MappingIdentifier <em>Identifier</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Identifier</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingIdentifier
   * @generated
   */
  EClass getMappingIdentifier();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.mappingmodel.mapping.MappingIdentifier#getId <em>Id</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Id</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingIdentifier#getId()
   * @see #getMappingIdentifier()
   * @generated
   */
  EAttribute getMappingIdentifier_Id();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.mappingmodel.mapping.MappingIdentifier#getMappingKind <em>Mapping Kind</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Mapping Kind</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingIdentifier#getMappingKind()
   * @see #getMappingIdentifier()
   * @generated
   */
  EAttribute getMappingIdentifier_MappingKind();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.mappingmodel.mapping.MappedInstancesFactory <em>Mapped Instances Factory</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Mapped Instances Factory</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappedInstancesFactory
   * @generated
   */
  EClass getMappedInstancesFactory();

  /**
   * Returns the meta object for the container reference '{@link com.metys.merlin.generation.mappingmodel.mapping.MappedInstancesFactory#getTransformer <em>Transformer</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the container reference '<em>Transformer</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappedInstancesFactory#getTransformer()
   * @see #getMappedInstancesFactory()
   * @generated
   */
  EReference getMappedInstancesFactory_Transformer();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.mappingmodel.mapping.MappedInstanceHandler <em>Mapped Instance Handler</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Mapped Instance Handler</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappedInstanceHandler
   * @generated
   */
  EClass getMappedInstanceHandler();

  /**
   * Returns the meta object for the container reference '{@link com.metys.merlin.generation.mappingmodel.mapping.MappedInstanceHandler#getTransformer <em>Transformer</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the container reference '<em>Transformer</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappedInstanceHandler#getTransformer()
   * @see #getMappedInstanceHandler()
   * @generated
   */
  EReference getMappedInstanceHandler_Transformer();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.mappingmodel.mapping.AttributeChangeHandler <em>Attribute Change Handler</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Attribute Change Handler</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.AttributeChangeHandler
   * @generated
   */
  EClass getAttributeChangeHandler();

  /**
   * Returns the meta object for the container reference '{@link com.metys.merlin.generation.mappingmodel.mapping.AttributeChangeHandler#getTransformer <em>Transformer</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the container reference '<em>Transformer</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.AttributeChangeHandler#getTransformer()
   * @see #getAttributeChangeHandler()
   * @generated
   */
  EReference getAttributeChangeHandler_Transformer();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.mappingmodel.mapping.ReferenceChangeHandler <em>Reference Change Handler</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Reference Change Handler</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.ReferenceChangeHandler
   * @generated
   */
  EClass getReferenceChangeHandler();

  /**
   * Returns the meta object for the container reference '{@link com.metys.merlin.generation.mappingmodel.mapping.ReferenceChangeHandler#getTransformer <em>Transformer</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the container reference '<em>Transformer</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.ReferenceChangeHandler#getTransformer()
   * @see #getReferenceChangeHandler()
   * @generated
   */
  EReference getReferenceChangeHandler_Transformer();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.mappingmodel.mapping.MappingReport <em>Report</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Report</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingReport
   * @generated
   */
  EClass getMappingReport();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.mappingmodel.mapping.MappingReport#getSeverity <em>Severity</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Severity</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingReport#getSeverity()
   * @see #getMappingReport()
   * @generated
   */
  EAttribute getMappingReport_Severity();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.mappingmodel.mapping.MappingReport#getMessage <em>Message</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Message</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingReport#getMessage()
   * @see #getMappingReport()
   * @generated
   */
  EAttribute getMappingReport_Message();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.mappingmodel.mapping.EObjectDiffNode <em>EObject Diff Node</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>EObject Diff Node</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.EObjectDiffNode
   * @generated
   */
  EClass getEObjectDiffNode();

  /**
   * Returns the meta object for the containment reference list '{@link com.metys.merlin.generation.mappingmodel.mapping.EObjectDiffNode#getSubDiffNodes <em>Sub Diff Nodes</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Sub Diff Nodes</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.EObjectDiffNode#getSubDiffNodes()
   * @see #getEObjectDiffNode()
   * @generated
   */
  EReference getEObjectDiffNode_SubDiffNodes();

  /**
   * Returns the meta object for the reference '{@link com.metys.merlin.generation.mappingmodel.mapping.EObjectDiffNode#getChangeDescription <em>Change Description</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Change Description</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.EObjectDiffNode#getChangeDescription()
   * @see #getEObjectDiffNode()
   * @generated
   */
  EReference getEObjectDiffNode_ChangeDescription();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.mappingmodel.mapping.ReconcilingDiffTree <em>Reconciling Diff Tree</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Reconciling Diff Tree</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.ReconcilingDiffTree
   * @generated
   */
  EClass getReconcilingDiffTree();

  /**
   * Returns the meta object for the containment reference list '{@link com.metys.merlin.generation.mappingmodel.mapping.ReconcilingDiffTree#getRoots <em>Roots</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Roots</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.ReconcilingDiffTree#getRoots()
   * @see #getReconcilingDiffTree()
   * @generated
   */
  EReference getReconcilingDiffTree_Roots();

  /**
   * Returns the meta object for enum '{@link com.metys.merlin.generation.mappingmodel.mapping.SeverityKind <em>Severity Kind</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>Severity Kind</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.SeverityKind
   * @generated
   */
  EEnum getSeverityKind();

  /**
   * Returns the meta object for enum '{@link com.metys.merlin.generation.mappingmodel.mapping.MappingKind <em>Kind</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>Kind</em>'.
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingKind
   * @generated
   */
  EEnum getMappingKind();

  /**
   * Returns the factory that creates the instances of the model.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the factory that creates the instances of the model.
   * @generated
   */
  MappingFactory getMappingFactory();

} //MappingPackage
