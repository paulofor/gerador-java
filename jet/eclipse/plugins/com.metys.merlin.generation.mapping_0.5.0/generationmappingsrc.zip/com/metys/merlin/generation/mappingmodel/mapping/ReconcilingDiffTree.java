/**
 * <copyright>
 * </copyright>
 *
 * $Id: ReconcilingDiffTree.java,v 1.1 2005/07/07 21:33:31 jcheuoua Exp $
 */
package com.metys.merlin.generation.mappingmodel.mapping;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Reconciling Diff Tree</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.ReconcilingDiffTree#getRoots <em>Roots</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getReconcilingDiffTree()
 * @model
 * @generated
 */
public interface ReconcilingDiffTree extends EObject {
  /**
   * Returns the value of the '<em><b>Roots</b></em>' containment reference list.
   * The list contents are of type {@link com.metys.merlin.generation.mappingmodel.mapping.EObjectDiffNode}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Roots</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Roots</em>' containment reference list.
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getReconcilingDiffTree_Roots()
   * @model type="com.metys.merlin.generation.mappingmodel.mapping.EObjectDiffNode" containment="true"
   * @generated
   */
  EList getRoots();

} // ReconcilingDiffTree
