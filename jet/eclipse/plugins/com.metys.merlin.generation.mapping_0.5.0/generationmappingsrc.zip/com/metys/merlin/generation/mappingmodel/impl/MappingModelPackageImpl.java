/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.mappingmodel.impl;

import java.io.File;
import java.util.Collection;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.change.impl.ChangePackageImpl;

import org.eclipse.emf.ecore.impl.EPackageImpl;
import org.eclipse.emf.ecore.impl.EcorePackageImpl;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;

import org.eclipse.emf.mapping.ecore2ecore.impl.Ecore2EcorePackageImpl;
import org.eclipse.emf.mapping.impl.MappingPackageImpl;

import com.metys.merlin.generation.mappingmodel.MappingModelFactory;
import com.metys.merlin.generation.mappingmodel.MappingModelPackage;
import com.metys.merlin.generation.mappingmodel.mapping.MappingPackage;
import com.metys.merlin.generation.mappingmodel.rules.RulesPackage;
import com.metys.merlin.generation.mappingmodel.rules.impl.RulesPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class MappingModelPackageImpl extends EPackageImpl implements MappingModelPackage {
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EDataType fileEDataType = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EDataType collectionEDataType = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EDataType progressMonitorEDataType = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EDataType resourceEDataType = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EDataType resourceSetEDataType = null;

  /**
   * Creates an instance of the model <b>Package</b>, registered with
   * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
   * package URI value.
   * <p>Note: the correct way to create the package is via the static
   * factory method {@link #init init()}, which also performs
   * initialization of the package, or returns the registered package,
   * if one already exists.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.eclipse.emf.ecore.EPackage.Registry
   * @see com.metys.merlin.generation.mappingmodel.MappingModelPackage#eNS_URI
   * @see #init()
   * @generated
   */
  private MappingModelPackageImpl() {
    super(eNS_URI, MappingModelFactory.eINSTANCE);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static boolean isInited = false;

  /**
   * Creates, registers, and initializes the <b>Package</b> for this
   * model, and for any others upon which it depends.  Simple
   * dependencies are satisfied by calling this method on all
   * dependent packages before doing anything else.  This method drives
   * initialization for interdependent packages directly, in parallel
   * with this package, itself.
   * <p>Of this package and its interdependencies, all packages which
   * have not yet been registered by their URI values are first created
   * and registered.  The packages are then initialized in two steps:
   * meta-model objects for all of the packages are created before any
   * are initialized, since one package's meta-model objects may refer to
   * those of another.
   * <p>Invocation of this method will not affect any packages that have
   * already been initialized.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #eNS_URI
   * @see #createPackageContents()
   * @see #initializePackageContents()
   * @generated
   */
  public static MappingModelPackage init() {
    if (isInited)
      return (MappingModelPackage) EPackage.Registry.INSTANCE.getEPackage(MappingModelPackage.eNS_URI);

    // Obtain or create and register package
    MappingModelPackageImpl theMappingModelPackage = (MappingModelPackageImpl) (EPackage.Registry.INSTANCE
        .getEPackage(eNS_URI) instanceof MappingModelPackageImpl ? EPackage.Registry.INSTANCE.getEPackage(eNS_URI)
        : new MappingModelPackageImpl());

    isInited = true;

    // Initialize simple dependencies
    EcorePackageImpl.init();
    Ecore2EcorePackageImpl.init();
    MappingPackageImpl.init();
    ChangePackageImpl.init();

    // Obtain or create and register interdependencies
    RulesPackageImpl theRulesPackage = (RulesPackageImpl) (EPackage.Registry.INSTANCE.getEPackage(RulesPackage.eNS_URI) instanceof RulesPackageImpl ? EPackage.Registry.INSTANCE
        .getEPackage(RulesPackage.eNS_URI)
        : RulesPackage.eINSTANCE);
    com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl theMappingPackage_1 = (com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl) (EPackage.Registry.INSTANCE
        .getEPackage(MappingPackage.eNS_URI) instanceof com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl ? EPackage.Registry.INSTANCE
        .getEPackage(MappingPackage.eNS_URI)
        : MappingPackage.eINSTANCE);

    // Create package meta-data objects
    theMappingModelPackage.createPackageContents();
    theRulesPackage.createPackageContents();
    theMappingPackage_1.createPackageContents();

    // Initialize created meta-data
    theMappingModelPackage.initializePackageContents();
    theRulesPackage.initializePackageContents();
    theMappingPackage_1.initializePackageContents();

    // Mark meta-data to indicate it can't be changed
    theMappingModelPackage.freeze();

    return theMappingModelPackage;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EDataType getFile() {
    return fileEDataType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EDataType getCollection() {
    return collectionEDataType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EDataType getProgressMonitor() {
    return progressMonitorEDataType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EDataType getResource() {
    return resourceEDataType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EDataType getResourceSet() {
    return resourceSetEDataType;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MappingModelFactory getMappingModelFactory() {
    return (MappingModelFactory) getEFactoryInstance();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private boolean isCreated = false;

  /**
   * Creates the meta-model objects for the package.  This method is
   * guarded to have no affect on any invocation but its first.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void createPackageContents() {
    if (isCreated)
      return;
    isCreated = true;

    // Create data types
    fileEDataType = createEDataType(FILE);
    collectionEDataType = createEDataType(COLLECTION);
    progressMonitorEDataType = createEDataType(PROGRESS_MONITOR);
    resourceEDataType = createEDataType(RESOURCE);
    resourceSetEDataType = createEDataType(RESOURCE_SET);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private boolean isInitialized = false;

  /**
   * Complete the initialization of the package and its meta-model.  This
   * method is guarded to have no affect on any invocation but its first.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void initializePackageContents() {
    if (isInitialized)
      return;
    isInitialized = true;

    // Initialize package
    setName(eNAME);
    setNsPrefix(eNS_PREFIX);
    setNsURI(eNS_URI);

    // Obtain other dependent packages
    RulesPackageImpl theRulesPackage = (RulesPackageImpl) EPackage.Registry.INSTANCE.getEPackage(RulesPackage.eNS_URI);
    com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl theMappingPackage_1 = (com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl) EPackage.Registry.INSTANCE
        .getEPackage(MappingPackage.eNS_URI);

    // Add subpackages
    getESubpackages().add(theRulesPackage);
    getESubpackages().add(theMappingPackage_1);

    // Initialize data types
    initEDataType(fileEDataType, File.class, "File", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
    initEDataType(collectionEDataType, Collection.class, "Collection", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
    initEDataType(progressMonitorEDataType, IProgressMonitor.class, "ProgressMonitor", !IS_SERIALIZABLE,
        !IS_GENERATED_INSTANCE_CLASS);
    initEDataType(resourceEDataType, Resource.class, "Resource", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
    initEDataType(resourceSetEDataType, ResourceSet.class, "ResourceSet", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);

    // Create resource
    createResource(eNS_URI);
  }

} //MappingModelPackageImpl
