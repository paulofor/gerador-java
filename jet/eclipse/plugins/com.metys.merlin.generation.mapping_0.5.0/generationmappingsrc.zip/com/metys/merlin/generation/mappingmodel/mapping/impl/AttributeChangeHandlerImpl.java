/**
 * <copyright>
 * </copyright>
 *
 * $Id: AttributeChangeHandlerImpl.java,v 1.2 2005/07/10 23:36:13 jcheuoua Exp $
 */
package com.metys.merlin.generation.mappingmodel.mapping.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.mapping.Mapping;
import org.eclipse.emf.mapping.MappingRoot;

import com.metys.merlin.generation.mappingmodel.mapping.AttributeChangeHandler;
import com.metys.merlin.generation.mappingmodel.mapping.Transformer;
import com.metys.merlin.generation.mappingmodel.mapping.MappingPackage;
import com.metys.merlin.generation.mappingmodel.rules.MappingRule;
import com.metys.merlin.generation.mappingmodel.rules.MappingRuleAction;
import com.metys.merlin.generation.mappingmodel.util.MappingModelUtil;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Attribute Change Handler</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.AttributeChangeHandlerImpl#getTransformer <em>Transformer</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class AttributeChangeHandlerImpl extends EObjectImpl implements AttributeChangeHandler {
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected AttributeChangeHandlerImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return MappingPackage.eINSTANCE.getAttributeChangeHandler();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Transformer getTransformer() {
    if (eContainerFeatureID != MappingPackage.ATTRIBUTE_CHANGE_HANDLER__TRANSFORMER)
      return null;
    return (Transformer) eContainer;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTransformer(Transformer newTransformer) {
    if (newTransformer != eContainer
        || (eContainerFeatureID != MappingPackage.ATTRIBUTE_CHANGE_HANDLER__TRANSFORMER && newTransformer != null)) {
      if (EcoreUtil.isAncestor(this, newTransformer))
        throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
      NotificationChain msgs = null;
      if (eContainer != null)
        msgs = eBasicRemoveFromContainer(msgs);
      if (newTransformer != null)
        msgs = ((InternalEObject) newTransformer).eInverseAdd(this,
            MappingPackage.TRANSFORMER__ATTRIBUTE_CHANGE_HANDLER, Transformer.class, msgs);
      msgs = eBasicSetContainer((InternalEObject) newTransformer, MappingPackage.ATTRIBUTE_CHANGE_HANDLER__TRANSFORMER,
          msgs);
      if (msgs != null)
        msgs.dispatch();
    } else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, MappingPackage.ATTRIBUTE_CHANGE_HANDLER__TRANSFORMER,
          newTransformer, newTransformer));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public void handleAttributes(EObject sourceObject, EObject targetObject, MappingRoot mappingRoot,
      EStructuralFeature sourceFeature) {
    EAttribute sourceAttribute = (EAttribute) sourceFeature;
    MappingRoot typeMappingRoot = mappingRoot.getTypeMappingRoot();
    Collection mappings = typeMappingRoot.getMappings(sourceAttribute);
    for (Iterator it = mappings.iterator(); it.hasNext();) {
      Mapping mapping = (Mapping) it.next();
      if (MappingModelUtil.canApplyMapping(mapping, sourceObject, targetObject, getTransformer(), mappingRoot))
        applyMapping(mapping, sourceObject, targetObject, sourceAttribute, mappingRoot);
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
      case MappingPackage.ATTRIBUTE_CHANGE_HANDLER__TRANSFORMER:
        if (eContainer != null)
          msgs = eBasicRemoveFromContainer(msgs);
        return eBasicSetContainer(otherEnd, MappingPackage.ATTRIBUTE_CHANGE_HANDLER__TRANSFORMER, msgs);
      default:
        return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass,
      NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
      case MappingPackage.ATTRIBUTE_CHANGE_HANDLER__TRANSFORMER:
        return eBasicSetContainer(null, MappingPackage.ATTRIBUTE_CHANGE_HANDLER__TRANSFORMER, msgs);
      default:
        return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
    if (eContainerFeatureID >= 0) {
      switch (eContainerFeatureID) {
      case MappingPackage.ATTRIBUTE_CHANGE_HANDLER__TRANSFORMER:
        return eContainer.eInverseRemove(this, MappingPackage.TRANSFORMER__ATTRIBUTE_CHANGE_HANDLER, Transformer.class,
            msgs);
      default:
        return eDynamicBasicRemoveFromContainer(msgs);
      }
    }
    return eContainer.eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.ATTRIBUTE_CHANGE_HANDLER__TRANSFORMER:
      return getTransformer();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.ATTRIBUTE_CHANGE_HANDLER__TRANSFORMER:
      setTransformer((Transformer) newValue);
      return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.ATTRIBUTE_CHANGE_HANDLER__TRANSFORMER:
      setTransformer((Transformer) null);
      return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.ATTRIBUTE_CHANGE_HANDLER__TRANSFORMER:
      return getTransformer() != null;
    }
    return eDynamicIsSet(eFeature);
  }

  private void applyMapping(Mapping mapping, EObject sourceObject, EObject targetObject, EAttribute sourceAttribute,
      MappingRoot mappingRoot) {
    Object value = sourceObject.eGet(sourceAttribute);
    // Collect the value(s)
    List sourceValueList = new ArrayList();
    if (sourceAttribute.isMany()) {
      sourceValueList.addAll((Collection) value);
    } else if (value != null){
      sourceValueList.add(value);
    }
    // Don't process sourceObject if sourceAttribute is unset and the value is null or empty
    if (!sourceObject.eIsSet(sourceAttribute) && sourceValueList.isEmpty())
      return;
    EClass targetClass = targetObject.eClass();
    EDataType sourceAttributeType = sourceAttribute.getEAttributeType();
    // Proceed on feature mappings
    for (Iterator iter = mapping.getOutputs().iterator(); iter.hasNext();) {
      Object featureOutput = (Object) iter.next();
      if (featureOutput instanceof EAttribute) {
        EAttribute targetAttribute = (EAttribute) featureOutput;
        EDataType targetAttributeType = targetAttribute.getEAttributeType();
        if (!targetAttribute.isChangeable() ||
            !targetAttribute.getEContainingClass().isSuperTypeOf(targetClass))
          continue;
        Object initialTargetValue = targetObject.eGet(targetAttribute);
        // If the source value is null, or empty unset the corresponding value in the target and continue
        if (sourceValueList.isEmpty()) {
          if (targetAttribute.isMany()) {
            Collection targetValues = (Collection) initialTargetValue;
            if (!targetValues.isEmpty())
              targetValues.clear();
          } else {
            if (initialTargetValue != null)
              targetObject.eSet(targetAttribute, null);
          }
          continue;
        }
        List initialTargetValueList = new ArrayList();
        if (targetAttribute.isMany()) {
          initialTargetValueList.addAll((Collection) initialTargetValue);
        } else if (initialTargetValue != null) {
          initialTargetValueList.add(initialTargetValue);
        }
        
        // Create the mapped value(s)
        List targetValueList = new ArrayList();
        for (Iterator valueIt = sourceValueList.iterator(); valueIt.hasNext();) {
          Object val = valueIt.next();
          Object targetValue = null;
          // Serialize the value then deserialize it to create the mapped value.
          try {            
            String stringVal = val instanceof String ? (String) val : EcoreUtil.convertToString(sourceAttributeType, val);            
            targetValue = targetAttributeType.getInstanceClass() == String.class ? stringVal : EcoreUtil.createFromString(targetAttributeType, stringVal);
          } catch (Exception ex) {
            if (targetAttributeType.getInstanceClass() != null &&
                sourceAttributeType.getInstanceClass() != null &&
                targetAttributeType.getInstanceClass().isAssignableFrom(sourceAttributeType.getInstanceClass()))
              targetValue = val;
          }
          if (targetValue != null)
            targetValueList.add(targetValue);
        }
        // if targetValueList && initialTargetValueList are equals, continue
        if (targetValueList.equals(initialTargetValueList))
          continue;
        // If no mappedValue has been computed, just continue
        if (targetValueList.isEmpty())
          continue;
        // Assign the value to the mappedInstance
        if (targetAttribute.isMany()) {
          Collection targetValues = (Collection) initialTargetValue;
          targetValues.clear();
          targetValues.addAll(targetValueList);
        } else {
          targetObject.eSet(targetAttribute, targetValueList.get(0));
        }
      }
    }

    //  Fire custom actions for feature mappings if relevant
    MappingRule mappingRule = MappingModelUtil.getMappingRule(mapping);
    if (mappingRule != null && targetObject != null) {
      // Perform the custom actions
      for (Iterator it = mappingRule.getMappingRuleActions().iterator(); it.hasNext();) {
        MappingRuleAction ruleAction = (MappingRuleAction) it.next();
        ruleAction.apply(sourceObject, targetObject, getTransformer(), mappingRoot);
      }
    }
  }

} //AttributeChangeHandlerImpl
