/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.mappingmodel.mapping.impl;

import com.metys.merlin.generation.mappingmodel.mapping.*;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.impl.EFactoryImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class MappingFactoryImpl extends EFactoryImpl implements MappingFactory {
  /**
   * Creates an instance of the factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MappingFactoryImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EObject create(EClass eClass) {
    switch (eClass.getClassifierID()) {
    case MappingPackage.TYPE_MAPPING_ROOT:
      return createTypeMappingRoot();
    case MappingPackage.TYPE_MAPPING:
      return createTypeMapping();
    case MappingPackage.TRANSFORMER:
      return createTransformer();
    case MappingPackage.MAPPING_IDENTIFIER:
      return createMappingIdentifier();
    case MappingPackage.MAPPED_INSTANCES_FACTORY:
      return createMappedInstancesFactory();
    case MappingPackage.MAPPED_INSTANCE_HANDLER:
      return createMappedInstanceHandler();
    case MappingPackage.ATTRIBUTE_CHANGE_HANDLER:
      return createAttributeChangeHandler();
    case MappingPackage.REFERENCE_CHANGE_HANDLER:
      return createReferenceChangeHandler();
    case MappingPackage.MAPPING_REPORT:
      return createMappingReport();
    case MappingPackage.EOBJECT_DIFF_NODE:
      return createEObjectDiffNode();
    case MappingPackage.RECONCILING_DIFF_TREE:
      return createReconcilingDiffTree();
    default:
      throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object createFromString(EDataType eDataType, String initialValue) {
    switch (eDataType.getClassifierID()) {
    case MappingPackage.SEVERITY_KIND: {
      SeverityKind result = SeverityKind.get(initialValue);
      if (result == null)
        throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '"
            + eDataType.getName() + "'");
      return result;
    }
    case MappingPackage.MAPPING_KIND: {
      MappingKind result = MappingKind.get(initialValue);
      if (result == null)
        throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '"
            + eDataType.getName() + "'");
      return result;
    }
    default:
      throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String convertToString(EDataType eDataType, Object instanceValue) {
    switch (eDataType.getClassifierID()) {
    case MappingPackage.SEVERITY_KIND:
      return instanceValue == null ? null : instanceValue.toString();
    case MappingPackage.MAPPING_KIND:
      return instanceValue == null ? null : instanceValue.toString();
    default:
      throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TypeMapping createTypeMapping() {
    TypeMappingImpl typeMapping = new TypeMappingImpl();
    return typeMapping;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Transformer createTransformer() {
    TransformerImpl transformer = new TransformerImpl();
    return transformer;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MappingIdentifier createMappingIdentifier() {
    MappingIdentifierImpl mappingIdentifier = new MappingIdentifierImpl();
    return mappingIdentifier;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MappedInstancesFactory createMappedInstancesFactory() {
    MappedInstancesFactoryImpl mappedInstancesFactory = new MappedInstancesFactoryImpl();
    return mappedInstancesFactory;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MappedInstanceHandler createMappedInstanceHandler() {
    MappedInstanceHandlerImpl mappedInstanceHandler = new MappedInstanceHandlerImpl();
    return mappedInstanceHandler;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public AttributeChangeHandler createAttributeChangeHandler() {
    AttributeChangeHandlerImpl attributeChangeHandler = new AttributeChangeHandlerImpl();
    return attributeChangeHandler;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ReferenceChangeHandler createReferenceChangeHandler() {
    ReferenceChangeHandlerImpl referenceChangeHandler = new ReferenceChangeHandlerImpl();
    return referenceChangeHandler;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MappingReport createMappingReport() {
    MappingReportImpl mappingReport = new MappingReportImpl();
    return mappingReport;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EObjectDiffNode createEObjectDiffNode() {
    EObjectDiffNodeImpl eObjectDiffNode = new EObjectDiffNodeImpl();
    return eObjectDiffNode;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ReconcilingDiffTree createReconcilingDiffTree() {
    ReconcilingDiffTreeImpl reconcilingDiffTree = new ReconcilingDiffTreeImpl();
    return reconcilingDiffTree;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TypeMappingRoot createTypeMappingRoot() {
    TypeMappingRootImpl typeMappingRoot = new TypeMappingRootImpl();
    return typeMappingRoot;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MappingPackage getMappingPackage() {
    return (MappingPackage) getEPackage();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @deprecated
   * @generated
   */
  public static MappingPackage getPackage() {
    return MappingPackage.eINSTANCE;
  }

} //MappingFactoryImpl
