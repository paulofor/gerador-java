/**
 * <copyright>
 * </copyright>
 *
 * $Id: MappedInstancesFactoryImpl.java,v 1.1 2005/07/07 21:33:31 jcheuoua Exp $
 */
package com.metys.merlin.generation.mappingmodel.mapping.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.mapping.Mapping;
import org.eclipse.emf.mapping.MappingRoot;

import com.metys.merlin.generation.mappingmodel.mapping.MappedInstancesFactory;
import com.metys.merlin.generation.mappingmodel.mapping.MappingPackage;
import com.metys.merlin.generation.mappingmodel.mapping.Transformer;
import com.metys.merlin.generation.mappingmodel.rules.MappingRule;
import com.metys.merlin.generation.mappingmodel.rules.MappingRuleCondition;
import com.metys.merlin.generation.mappingmodel.rules.PolicyKind;
import com.metys.merlin.generation.mappingmodel.util.MappingModelUtil;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Mapped Instances Factory</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.MappedInstancesFactoryImpl#getTransformer <em>Transformer</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class MappedInstancesFactoryImpl extends EObjectImpl implements MappedInstancesFactory {
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected MappedInstancesFactoryImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return MappingPackage.eINSTANCE.getMappedInstancesFactory();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Transformer getTransformer() {
    if (eContainerFeatureID != MappingPackage.MAPPED_INSTANCES_FACTORY__TRANSFORMER)
      return null;
    return (Transformer) eContainer;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTransformer(Transformer newTransformer) {
    if (newTransformer != eContainer
        || (eContainerFeatureID != MappingPackage.MAPPED_INSTANCES_FACTORY__TRANSFORMER && newTransformer != null)) {
      if (EcoreUtil.isAncestor(this, newTransformer))
        throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
      NotificationChain msgs = null;
      if (eContainer != null)
        msgs = eBasicRemoveFromContainer(msgs);
      if (newTransformer != null)
        msgs = ((InternalEObject) newTransformer).eInverseAdd(this,
            MappingPackage.TRANSFORMER__MAPPED_INSTANCES_FACTORY, Transformer.class, msgs);
      msgs = eBasicSetContainer((InternalEObject) newTransformer, MappingPackage.MAPPED_INSTANCES_FACTORY__TRANSFORMER,
          msgs);
      if (msgs != null)
        msgs.dispatch();
    } else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, MappingPackage.MAPPED_INSTANCES_FACTORY__TRANSFORMER,
          newTransformer, newTransformer));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public Collection createMappedInstances(Mapping typeMapping, EObject sourceObject, MappingRoot mappingRoot) {
    MappingRule mappingRule = MappingModelUtil.getMappingRule(typeMapping);
    ArrayList results = new ArrayList();
    for (Iterator iter = typeMapping.getOutputs().iterator(); iter.hasNext();) {
      Object typeOutput = (Object) iter.next();
      if (typeOutput instanceof EClass) {
        EClass targetClass = (EClass) typeOutput;
        if (targetClass.isAbstract())
          continue;
        boolean mappedInstanceExists = false;
        boolean mappingExists = false;
        for (Iterator resources = getTransformer().getTargetContext().iterator(); resources.hasNext();) {
          Resource targetResource = (Resource) resources.next();
          for (Iterator iterator = targetResource.getAllContents(); iterator.hasNext();) {
            EObject targetObject = (EObject) iterator.next();
            if (!targetClass.isInstance(targetObject))
              continue;
            Collection targetMappings = mappingRoot.getMappings(targetObject);
            for (Iterator mappings = targetMappings.iterator(); mappings.hasNext();) {
              Mapping mapping = (Mapping) mappings.next();
              if (mapping.getTypeMapping() == typeMapping && mapping.getInputs().contains(sourceObject)) {
                mappedInstanceExists = true;
                mappingExists = true;
                break;
              }
            }
            if (!mappedInstanceExists) {
              mappedInstanceExists = !mappingRule.getTargetMatchingConditions().isEmpty();
              for (Iterator conditions = mappingRule.getTargetMatchingConditions().iterator(); conditions.hasNext();) {
                MappingRuleCondition targetMatchingCondition = (MappingRuleCondition) conditions.next();
                if (!targetMatchingCondition.evaluate(sourceObject, targetObject, getTransformer(), mappingRoot)) {
                  mappedInstanceExists = false;
                  break;
                }
              }
            }
            if (mappedInstanceExists) {
              EObject existingTargetObject = targetObject;
              // If this target is already mapped to the source
              // Just add it to the list and continue
              if (!mappingExists) {
                Mapping mapping = MappingModelUtil.addMapping(sourceObject, targetObject, mappingRoot);
                mapping.setTypeMapping(typeMapping);
              }
              results.add(existingTargetObject);
              break;
            }
          }
          if (mappedInstanceExists)
            break;
        }
        if (mappedInstanceExists || mappingRule.getPolicy() == PolicyKind.CHECK_ONLY_LITERAL)
          continue;
        EObject targetObject = EcoreUtil.create(targetClass);
        Mapping mapping = MappingModelUtil.addMapping(sourceObject, targetObject, mappingRoot);
        mapping.setTypeMapping(typeMapping);
        results.add(targetObject);
      }
    }
    return results;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
      case MappingPackage.MAPPED_INSTANCES_FACTORY__TRANSFORMER:
        if (eContainer != null)
          msgs = eBasicRemoveFromContainer(msgs);
        return eBasicSetContainer(otherEnd, MappingPackage.MAPPED_INSTANCES_FACTORY__TRANSFORMER, msgs);
      default:
        return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass,
      NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
      case MappingPackage.MAPPED_INSTANCES_FACTORY__TRANSFORMER:
        return eBasicSetContainer(null, MappingPackage.MAPPED_INSTANCES_FACTORY__TRANSFORMER, msgs);
      default:
        return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
    if (eContainerFeatureID >= 0) {
      switch (eContainerFeatureID) {
      case MappingPackage.MAPPED_INSTANCES_FACTORY__TRANSFORMER:
        return eContainer.eInverseRemove(this, MappingPackage.TRANSFORMER__MAPPED_INSTANCES_FACTORY, Transformer.class,
            msgs);
      default:
        return eDynamicBasicRemoveFromContainer(msgs);
      }
    }
    return eContainer.eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.MAPPED_INSTANCES_FACTORY__TRANSFORMER:
      return getTransformer();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.MAPPED_INSTANCES_FACTORY__TRANSFORMER:
      setTransformer((Transformer) newValue);
      return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.MAPPED_INSTANCES_FACTORY__TRANSFORMER:
      setTransformer((Transformer) null);
      return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.MAPPED_INSTANCES_FACTORY__TRANSFORMER:
      return getTransformer() != null;
    }
    return eDynamicIsSet(eFeature);
  }

} //MappedInstancesFactoryImpl
