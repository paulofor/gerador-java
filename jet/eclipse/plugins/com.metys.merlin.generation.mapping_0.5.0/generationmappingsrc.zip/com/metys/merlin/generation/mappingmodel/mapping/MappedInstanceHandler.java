/**
 * <copyright>
 * </copyright>
 *
 * $Id: MappedInstanceHandler.java,v 1.1 2005/07/07 21:33:31 jcheuoua Exp $
 */
package com.metys.merlin.generation.mappingmodel.mapping;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.mapping.MappingRoot;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mapped Instance Handler</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.MappedInstanceHandler#getTransformer <em>Transformer</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getMappedInstanceHandler()
 * @model
 * @generated
 */
public interface MappedInstanceHandler extends EObject {
  /**
   * Returns the value of the '<em><b>Transformer</b></em>' container reference.
   * It is bidirectional and its opposite is '{@link com.metys.merlin.generation.mappingmodel.mapping.Transformer#getMappedInstanceHandler <em>Mapped Instance Handler</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Transformer</em>' container reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Transformer</em>' container reference.
   * @see #setTransformer(Transformer)
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getMappedInstanceHandler_Transformer()
   * @see com.metys.merlin.generation.mappingmodel.mapping.Transformer#getMappedInstanceHandler
   * @model opposite="mappedInstanceHandler"
   * @generated
   */
  Transformer getTransformer();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.mappingmodel.mapping.MappedInstanceHandler#getTransformer <em>Transformer</em>}' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Transformer</em>' container reference.
   * @see #getTransformer()
   * @generated
   */
  void setTransformer(Transformer value);

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model
   * @generated
   */
  void handleMappedInstance(EObject sourceObject, EObject targetObject, MappingRoot mappingRoot);

} // MappedInstanceHandler
