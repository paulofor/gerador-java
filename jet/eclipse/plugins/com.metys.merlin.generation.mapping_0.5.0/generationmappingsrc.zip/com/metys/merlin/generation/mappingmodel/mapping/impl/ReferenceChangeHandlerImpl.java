/**
 * <copyright>
 * </copyright>
 *
 * $Id: ReferenceChangeHandlerImpl.java,v 1.1 2005/07/07 21:33:31 jcheuoua Exp $
 */
package com.metys.merlin.generation.mappingmodel.mapping.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.mapping.Mapping;
import org.eclipse.emf.mapping.MappingRoot;

import com.metys.merlin.generation.mappingmodel.mapping.Transformer;
import com.metys.merlin.generation.mappingmodel.mapping.MappingPackage;
import com.metys.merlin.generation.mappingmodel.mapping.ReferenceChangeHandler;
import com.metys.merlin.generation.mappingmodel.rules.MappingRule;
import com.metys.merlin.generation.mappingmodel.rules.MappingRuleAction;
import com.metys.merlin.generation.mappingmodel.util.MappingModelUtil;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Reference Change Handler</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.ReferenceChangeHandlerImpl#getTransformer <em>Transformer</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ReferenceChangeHandlerImpl extends EObjectImpl implements ReferenceChangeHandler {
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ReferenceChangeHandlerImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return MappingPackage.eINSTANCE.getReferenceChangeHandler();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Transformer getTransformer() {
    if (eContainerFeatureID != MappingPackage.REFERENCE_CHANGE_HANDLER__TRANSFORMER)
      return null;
    return (Transformer) eContainer;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTransformer(Transformer newTransformer) {
    if (newTransformer != eContainer
        || (eContainerFeatureID != MappingPackage.REFERENCE_CHANGE_HANDLER__TRANSFORMER && newTransformer != null)) {
      if (EcoreUtil.isAncestor(this, newTransformer))
        throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
      NotificationChain msgs = null;
      if (eContainer != null)
        msgs = eBasicRemoveFromContainer(msgs);
      if (newTransformer != null)
        msgs = ((InternalEObject) newTransformer).eInverseAdd(this,
            MappingPackage.TRANSFORMER__REFERENCE_CHANGE_HANDLER, Transformer.class, msgs);
      msgs = eBasicSetContainer((InternalEObject) newTransformer, MappingPackage.REFERENCE_CHANGE_HANDLER__TRANSFORMER,
          msgs);
      if (msgs != null)
        msgs.dispatch();
    } else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, MappingPackage.REFERENCE_CHANGE_HANDLER__TRANSFORMER,
          newTransformer, newTransformer));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public void handleReferences(EObject sourceObject, EObject targetObject, MappingRoot mappingRoot,
      EStructuralFeature sourceFeature) {
    EReference sourceReference = (EReference) sourceFeature;
    MappingRoot typeMappingRoot = mappingRoot.getTypeMappingRoot();
    Collection mappings = typeMappingRoot.getMappings(sourceReference);
    for (Iterator it = mappings.iterator(); it.hasNext();) {
      Mapping mapping = (Mapping) it.next();
      if (MappingModelUtil.canApplyMapping(mapping, sourceObject, targetObject, getTransformer(), mappingRoot))
        applyMapping(mapping, sourceObject, targetObject, sourceReference, mappingRoot);
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
      case MappingPackage.REFERENCE_CHANGE_HANDLER__TRANSFORMER:
        if (eContainer != null)
          msgs = eBasicRemoveFromContainer(msgs);
        return eBasicSetContainer(otherEnd, MappingPackage.REFERENCE_CHANGE_HANDLER__TRANSFORMER, msgs);
      default:
        return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass,
      NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
      case MappingPackage.REFERENCE_CHANGE_HANDLER__TRANSFORMER:
        return eBasicSetContainer(null, MappingPackage.REFERENCE_CHANGE_HANDLER__TRANSFORMER, msgs);
      default:
        return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
    if (eContainerFeatureID >= 0) {
      switch (eContainerFeatureID) {
      case MappingPackage.REFERENCE_CHANGE_HANDLER__TRANSFORMER:
        return eContainer.eInverseRemove(this, MappingPackage.TRANSFORMER__REFERENCE_CHANGE_HANDLER, Transformer.class,
            msgs);
      default:
        return eDynamicBasicRemoveFromContainer(msgs);
      }
    }
    return eContainer.eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.REFERENCE_CHANGE_HANDLER__TRANSFORMER:
      return getTransformer();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.REFERENCE_CHANGE_HANDLER__TRANSFORMER:
      setTransformer((Transformer) newValue);
      return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.REFERENCE_CHANGE_HANDLER__TRANSFORMER:
      setTransformer((Transformer) null);
      return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.REFERENCE_CHANGE_HANDLER__TRANSFORMER:
      return getTransformer() != null;
    }
    return eDynamicIsSet(eFeature);
  }

  private void applyMapping(Mapping mapping, EObject sourceObject, EObject targetObject, EReference sourceReference, MappingRoot mappingRoot) {
    // Do not process source reference that are not set
    if (!sourceObject.eIsSet(sourceReference))
      return;
    Object value = sourceObject.eGet(sourceReference);
    EClass targetClass = targetObject.eClass();
    // Collect the value(s)
    List valueList = new ArrayList();
    if (sourceReference.isMany()) {
      valueList.addAll((Collection) value);
    } else if (value != null){
      valueList.add(value);
    }
    // Proceed on feature mappings
    for (Iterator iter = mapping.getOutputs().iterator(); iter.hasNext();) {
      Object featureOutput = (Object) iter.next();
      if (featureOutput instanceof EReference) {
        EReference targetReference = (EReference) featureOutput;
        EClass targetReferenceType = targetReference.getEReferenceType();
        if (!targetReference.isChangeable() ||
            !targetReference.getEContainingClass().isSuperTypeOf(targetClass))
          continue;        
        // If the mapped object is a reference from the input class, then we should try to fill a mapped value
        Object initialTargetValue = targetObject.eGet(targetReference);
        // Ensure the value is not null or empty
        if (valueList.isEmpty()) {
          if (targetReference.isMany()) {
            Collection targetValues = (Collection) initialTargetValue;
            if (!targetValues.isEmpty())
              targetValues.clear();
          } else {
            if (initialTargetValue != null)
              targetObject.eSet(targetReference, null);
          }
          continue;
        }        
        List initialTargetValueList = new ArrayList();
        if (targetReference.isMany()) {
          initialTargetValueList.addAll((Collection) initialTargetValue);
        } else if (initialTargetValue != null) {
          initialTargetValueList.add(initialTargetValue);
        }
        // Get or Create the mapped EObject value(s)
        List targetValueList = new ArrayList();
        for (Iterator valueIt = valueList.iterator(); valueIt.hasNext();) {
          EObject eObjectVal = (EObject) valueIt.next();
          // Try to get mapped instances from the eObject value
          Collection mappedEObjectValues = getTransformer().getMappedInstances(eObjectVal, true);
          Iterator mappedEObjectValuesIt = mappedEObjectValues.iterator();
          while (mappedEObjectValuesIt.hasNext()) {
            EObject mappedEObjectValue = (EObject) mappedEObjectValuesIt.next();
            if (targetReferenceType.isInstance(mappedEObjectValue))
              targetValueList.add(mappedEObjectValue);
          }
        }
        // If targetValueList && initialTargetValueList are equals, continue
        if (targetValueList.equals(initialTargetValueList))
          continue;
        // If no targetValue has been computed, return
        if (targetValueList.isEmpty())
          continue;
        // Assign the value to the targetObject
        if (targetReference.isMany()) {
          Collection targetValues = (Collection) initialTargetValue;
          targetValues.clear();
          targetValues.addAll(targetValueList);
        } else {
          Object mappedValue = targetValueList.get(0);
          targetObject.eSet(targetReference, mappedValue);
        }
      }
    }
    // Fire custom actions for feature mappings if relevant
    MappingRule mappingRule = MappingModelUtil.getMappingRule(mapping);
    if (mappingRule != null && targetObject != null) {
      // Perform the custom actions
      for (Iterator it = mappingRule.getMappingRuleActions().iterator(); it.hasNext();) {
        MappingRuleAction ruleAction = (MappingRuleAction) it.next();
        ruleAction.apply(sourceObject, targetObject, getTransformer(), mappingRoot);
      }
    }
  }

} //ReferenceChangeHandlerImpl
