/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.mappingmodel.mapping.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;
import org.eclipse.emf.mapping.Mapping;
import org.eclipse.emf.mapping.MappingHelper;
import org.eclipse.emf.mapping.impl.MappingImpl;

import com.metys.merlin.generation.mappingmodel.mapping.MappingPackage;
import com.metys.merlin.generation.mappingmodel.mapping.TypeMapping;
import com.metys.merlin.generation.mappingmodel.rules.EvaluationMode;
import com.metys.merlin.generation.mappingmodel.rules.MappingRule;
import com.metys.merlin.generation.mappingmodel.rules.MappingRuleAction;
import com.metys.merlin.generation.mappingmodel.rules.MappingRuleCondition;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Type Mapping</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.TypeMappingImpl#getName <em>Name</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.TypeMappingImpl#getMappingRules <em>Mapping Rules</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.TypeMappingImpl#getMappingRuleConditions <em>Mapping Rule Conditions</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.TypeMappingImpl#getMappingRuleActions <em>Mapping Rule Actions</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.TypeMappingImpl#getConstraints <em>Constraints</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class TypeMappingImpl extends MappingImpl implements TypeMapping {
  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * The cached value of the '{@link #getMappingRules() <em>Mapping Rules</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMappingRules()
   * @generated
   * @ordered
   */
  protected EList mappingRules = null;

  /**
   * The cached value of the '{@link #getMappingRuleConditions() <em>Mapping Rule Conditions</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMappingRuleConditions()
   * @generated
   * @ordered
   */
  protected EList mappingRuleConditions = null;

  /**
   * The cached value of the '{@link #getMappingRuleActions() <em>Mapping Rule Actions</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMappingRuleActions()
   * @generated
   * @ordered
   */
  protected EList mappingRuleActions = null;

  /**
   * The default value of the '{@link #getConstraints() <em>Constraints</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getConstraints()
   * @generated
   * @ordered
   */
  protected static final EvaluationMode CONSTRAINTS_EDEFAULT = EvaluationMode.ALL_CONDITIONS_TRUE_LITERAL;

  /**
   * The cached value of the '{@link #getConstraints() <em>Constraints</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getConstraints()
   * @generated
   * @ordered
   */
  protected EvaluationMode constraints = CONSTRAINTS_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected TypeMappingImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return MappingPackage.eINSTANCE.getTypeMapping();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName() {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(String newName) {
    String oldName = name;
    name = newName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, MappingPackage.TYPE_MAPPING__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getMappingRuleConditions() {
    if (mappingRuleConditions == null) {
      mappingRuleConditions = new EObjectContainmentEList(MappingRuleCondition.class, this,
          MappingPackage.TYPE_MAPPING__MAPPING_RULE_CONDITIONS);
    }
    return mappingRuleConditions;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getMappingRuleActions() {
    if (mappingRuleActions == null) {
      mappingRuleActions = new EObjectContainmentEList(MappingRuleAction.class, this,
          MappingPackage.TYPE_MAPPING__MAPPING_RULE_ACTIONS);
    }
    return mappingRuleActions;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EvaluationMode getConstraints() {
    return constraints;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setConstraints(EvaluationMode newConstraints) {
    EvaluationMode oldConstraints = constraints;
    constraints = newConstraints == null ? CONSTRAINTS_EDEFAULT : newConstraints;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, MappingPackage.TYPE_MAPPING__CONSTRAINTS, oldConstraints,
          constraints));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getMappingRules() {
    if (mappingRules == null) {
      mappingRules = new EObjectContainmentEList(MappingRule.class, this, MappingPackage.TYPE_MAPPING__MAPPING_RULES);
    }
    return mappingRules;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
      case MappingPackage.TYPE_MAPPING__HELPER:
        if (helper != null)
          msgs = ((InternalEObject) helper).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
              - MappingPackage.TYPE_MAPPING__HELPER, null, msgs);
        return basicSetHelper((MappingHelper) otherEnd, msgs);
      case MappingPackage.TYPE_MAPPING__NESTED:
        return ((InternalEList) getNested()).basicAdd(otherEnd, msgs);
      case MappingPackage.TYPE_MAPPING__NESTED_IN:
        if (eContainer != null)
          msgs = eBasicRemoveFromContainer(msgs);
        return eBasicSetContainer(otherEnd, MappingPackage.TYPE_MAPPING__NESTED_IN, msgs);
      default:
        return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass,
      NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
      case MappingPackage.TYPE_MAPPING__HELPER:
        return basicSetHelper(null, msgs);
      case MappingPackage.TYPE_MAPPING__NESTED:
        return ((InternalEList) getNested()).basicRemove(otherEnd, msgs);
      case MappingPackage.TYPE_MAPPING__NESTED_IN:
        return eBasicSetContainer(null, MappingPackage.TYPE_MAPPING__NESTED_IN, msgs);
      case MappingPackage.TYPE_MAPPING__MAPPING_RULES:
        return ((InternalEList) getMappingRules()).basicRemove(otherEnd, msgs);
      case MappingPackage.TYPE_MAPPING__MAPPING_RULE_CONDITIONS:
        return ((InternalEList) getMappingRuleConditions()).basicRemove(otherEnd, msgs);
      case MappingPackage.TYPE_MAPPING__MAPPING_RULE_ACTIONS:
        return ((InternalEList) getMappingRuleActions()).basicRemove(otherEnd, msgs);
      default:
        return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
    if (eContainerFeatureID >= 0) {
      switch (eContainerFeatureID) {
      case MappingPackage.TYPE_MAPPING__NESTED_IN:
        return eContainer.eInverseRemove(this, org.eclipse.emf.mapping.MappingPackage.MAPPING__NESTED, Mapping.class,
            msgs);
      default:
        return eDynamicBasicRemoveFromContainer(msgs);
      }
    }
    return eContainer.eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.TYPE_MAPPING__HELPER:
      return getHelper();
    case MappingPackage.TYPE_MAPPING__NESTED:
      return getNested();
    case MappingPackage.TYPE_MAPPING__NESTED_IN:
      return getNestedIn();
    case MappingPackage.TYPE_MAPPING__INPUTS:
      return getInputs();
    case MappingPackage.TYPE_MAPPING__OUTPUTS:
      return getOutputs();
    case MappingPackage.TYPE_MAPPING__TYPE_MAPPING:
      if (resolve)
        return getTypeMapping();
      return basicGetTypeMapping();
    case MappingPackage.TYPE_MAPPING__NAME:
      return getName();
    case MappingPackage.TYPE_MAPPING__MAPPING_RULES:
      return getMappingRules();
    case MappingPackage.TYPE_MAPPING__MAPPING_RULE_CONDITIONS:
      return getMappingRuleConditions();
    case MappingPackage.TYPE_MAPPING__MAPPING_RULE_ACTIONS:
      return getMappingRuleActions();
    case MappingPackage.TYPE_MAPPING__CONSTRAINTS:
      return getConstraints();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.TYPE_MAPPING__HELPER:
      setHelper((MappingHelper) newValue);
      return;
    case MappingPackage.TYPE_MAPPING__NESTED:
      getNested().clear();
      getNested().addAll((Collection) newValue);
      return;
    case MappingPackage.TYPE_MAPPING__NESTED_IN:
      setNestedIn((Mapping) newValue);
      return;
    case MappingPackage.TYPE_MAPPING__INPUTS:
      getInputs().clear();
      getInputs().addAll((Collection) newValue);
      return;
    case MappingPackage.TYPE_MAPPING__OUTPUTS:
      getOutputs().clear();
      getOutputs().addAll((Collection) newValue);
      return;
    case MappingPackage.TYPE_MAPPING__TYPE_MAPPING:
      setTypeMapping((Mapping) newValue);
      return;
    case MappingPackage.TYPE_MAPPING__NAME:
      setName((String) newValue);
      return;
    case MappingPackage.TYPE_MAPPING__MAPPING_RULES:
      getMappingRules().clear();
      getMappingRules().addAll((Collection) newValue);
      return;
    case MappingPackage.TYPE_MAPPING__MAPPING_RULE_CONDITIONS:
      getMappingRuleConditions().clear();
      getMappingRuleConditions().addAll((Collection) newValue);
      return;
    case MappingPackage.TYPE_MAPPING__MAPPING_RULE_ACTIONS:
      getMappingRuleActions().clear();
      getMappingRuleActions().addAll((Collection) newValue);
      return;
    case MappingPackage.TYPE_MAPPING__CONSTRAINTS:
      setConstraints((EvaluationMode) newValue);
      return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.TYPE_MAPPING__HELPER:
      setHelper((MappingHelper) null);
      return;
    case MappingPackage.TYPE_MAPPING__NESTED:
      getNested().clear();
      return;
    case MappingPackage.TYPE_MAPPING__NESTED_IN:
      setNestedIn((Mapping) null);
      return;
    case MappingPackage.TYPE_MAPPING__INPUTS:
      getInputs().clear();
      return;
    case MappingPackage.TYPE_MAPPING__OUTPUTS:
      getOutputs().clear();
      return;
    case MappingPackage.TYPE_MAPPING__TYPE_MAPPING:
      setTypeMapping((Mapping) null);
      return;
    case MappingPackage.TYPE_MAPPING__NAME:
      setName(NAME_EDEFAULT);
      return;
    case MappingPackage.TYPE_MAPPING__MAPPING_RULES:
      getMappingRules().clear();
      return;
    case MappingPackage.TYPE_MAPPING__MAPPING_RULE_CONDITIONS:
      getMappingRuleConditions().clear();
      return;
    case MappingPackage.TYPE_MAPPING__MAPPING_RULE_ACTIONS:
      getMappingRuleActions().clear();
      return;
    case MappingPackage.TYPE_MAPPING__CONSTRAINTS:
      setConstraints(CONSTRAINTS_EDEFAULT);
      return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.TYPE_MAPPING__HELPER:
      return helper != null;
    case MappingPackage.TYPE_MAPPING__NESTED:
      return nested != null && !nested.isEmpty();
    case MappingPackage.TYPE_MAPPING__NESTED_IN:
      return getNestedIn() != null;
    case MappingPackage.TYPE_MAPPING__INPUTS:
      return inputs != null && !inputs.isEmpty();
    case MappingPackage.TYPE_MAPPING__OUTPUTS:
      return outputs != null && !outputs.isEmpty();
    case MappingPackage.TYPE_MAPPING__TYPE_MAPPING:
      return typeMapping != null;
    case MappingPackage.TYPE_MAPPING__NAME:
      return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
    case MappingPackage.TYPE_MAPPING__MAPPING_RULES:
      return mappingRules != null && !mappingRules.isEmpty();
    case MappingPackage.TYPE_MAPPING__MAPPING_RULE_CONDITIONS:
      return mappingRuleConditions != null && !mappingRuleConditions.isEmpty();
    case MappingPackage.TYPE_MAPPING__MAPPING_RULE_ACTIONS:
      return mappingRuleActions != null && !mappingRuleActions.isEmpty();
    case MappingPackage.TYPE_MAPPING__CONSTRAINTS:
      return constraints != CONSTRAINTS_EDEFAULT;
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString() {
    if (eIsProxy())
      return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (name: ");
    result.append(name);
    result.append(", constraints: ");
    result.append(constraints);
    result.append(')');
    return result.toString();
  }

} //TypeMappingImpl
