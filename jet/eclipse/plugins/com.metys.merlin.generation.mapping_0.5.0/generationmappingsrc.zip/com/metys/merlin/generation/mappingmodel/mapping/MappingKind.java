/**
 * <copyright>
 * </copyright>
 *
 * $Id: MappingKind.java,v 1.1 2005/07/07 21:33:31 jcheuoua Exp $
 */
package com.metys.merlin.generation.mappingmodel.mapping;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Kind</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getMappingKind()
 * @model
 * @generated
 */
public final class MappingKind extends AbstractEnumerator {
  /**
   * The '<em><b>OPERATIONAL</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>OPERATIONAL</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #OPERATIONAL_LITERAL
   * @model
   * @generated
   * @ordered
   */
  public static final int OPERATIONAL = 0;

  /**
   * The '<em><b>RELATION</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>RELATION</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #RELATION_LITERAL
   * @model
   * @generated
   * @ordered
   */
  public static final int RELATION = 1;

  /**
   * The '<em><b>OPERATIONAL</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #OPERATIONAL
   * @generated
   * @ordered
   */
  public static final MappingKind OPERATIONAL_LITERAL = new MappingKind(OPERATIONAL, "OPERATIONAL");

  /**
   * The '<em><b>RELATION</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #RELATION
   * @generated
   * @ordered
   */
  public static final MappingKind RELATION_LITERAL = new MappingKind(RELATION, "RELATION");

  /**
   * An array of all the '<em><b>Kind</b></em>' enumerators.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static final MappingKind[] VALUES_ARRAY = new MappingKind[] { OPERATIONAL_LITERAL, RELATION_LITERAL, };

  /**
   * A public read-only list of all the '<em><b>Kind</b></em>' enumerators.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

  /**
   * Returns the '<em><b>Kind</b></em>' literal with the specified name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static MappingKind get(String name) {
    for (int i = 0; i < VALUES_ARRAY.length; ++i) {
      MappingKind result = VALUES_ARRAY[i];
      if (result.toString().equals(name)) {
        return result;
      }
    }
    return null;
  }

  /**
   * Returns the '<em><b>Kind</b></em>' literal with the specified value.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static MappingKind get(int value) {
    switch (value) {
    case OPERATIONAL:
      return OPERATIONAL_LITERAL;
    case RELATION:
      return RELATION_LITERAL;
    }
    return null;
  }

  /**
   * Only this class can construct instances.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private MappingKind(int value, String name) {
    super(value, name);
  }

} //MappingKind
