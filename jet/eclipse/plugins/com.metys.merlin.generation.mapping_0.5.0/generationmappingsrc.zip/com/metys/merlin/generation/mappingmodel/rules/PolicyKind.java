/**
 * <copyright>
 * </copyright>
 *
 * $Id: PolicyKind.java,v 1.1 2005/07/07 21:33:31 jcheuoua Exp $
 */
package com.metys.merlin.generation.mappingmodel.rules;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Policy Kind</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see com.metys.merlin.generation.mappingmodel.rules.RulesPackage#getPolicyKind()
 * @model
 * @generated
 */
public final class PolicyKind extends AbstractEnumerator {
  /**
   * The '<em><b>ENFORCE</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>ENFORCE</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #ENFORCE_LITERAL
   * @model
   * @generated
   * @ordered
   */
  public static final int ENFORCE = 0;

  /**
   * The '<em><b>CHECK ONLY</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>CHECK ONLY</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #CHECK_ONLY_LITERAL
   * @model
   * @generated
   * @ordered
   */
  public static final int CHECK_ONLY = 1;

  /**
   * The '<em><b>ENFORCE</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #ENFORCE
   * @generated
   * @ordered
   */
  public static final PolicyKind ENFORCE_LITERAL = new PolicyKind(ENFORCE, "ENFORCE");

  /**
   * The '<em><b>CHECK ONLY</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #CHECK_ONLY
   * @generated
   * @ordered
   */
  public static final PolicyKind CHECK_ONLY_LITERAL = new PolicyKind(CHECK_ONLY, "CHECK_ONLY");

  /**
   * An array of all the '<em><b>Policy Kind</b></em>' enumerators.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static final PolicyKind[] VALUES_ARRAY = new PolicyKind[] { ENFORCE_LITERAL, CHECK_ONLY_LITERAL, };

  /**
   * A public read-only list of all the '<em><b>Policy Kind</b></em>' enumerators.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

  /**
   * Returns the '<em><b>Policy Kind</b></em>' literal with the specified name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static PolicyKind get(String name) {
    for (int i = 0; i < VALUES_ARRAY.length; ++i) {
      PolicyKind result = VALUES_ARRAY[i];
      if (result.toString().equals(name)) {
        return result;
      }
    }
    return null;
  }

  /**
   * Returns the '<em><b>Policy Kind</b></em>' literal with the specified value.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static PolicyKind get(int value) {
    switch (value) {
    case ENFORCE:
      return ENFORCE_LITERAL;
    case CHECK_ONLY:
      return CHECK_ONLY_LITERAL;
    }
    return null;
  }

  /**
   * Only this class can construct instances.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private PolicyKind(int value, String name) {
    super(value, name);
  }

} //PolicyKind
