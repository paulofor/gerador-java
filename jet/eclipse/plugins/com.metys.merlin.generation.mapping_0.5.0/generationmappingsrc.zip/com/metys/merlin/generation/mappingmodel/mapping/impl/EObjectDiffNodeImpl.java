/**
 * <copyright>
 * </copyright>
 *
 * $Id: EObjectDiffNodeImpl.java,v 1.1 2005/07/07 21:33:31 jcheuoua Exp $
 */
package com.metys.merlin.generation.mappingmodel.mapping.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.change.ChangeDescription;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import com.metys.merlin.generation.mappingmodel.mapping.EObjectDiffNode;
import com.metys.merlin.generation.mappingmodel.mapping.MappingPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>EObject Diff Node</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.EObjectDiffNodeImpl#getSubDiffNodes <em>Sub Diff Nodes</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.EObjectDiffNodeImpl#getChangeDescription <em>Change Description</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class EObjectDiffNodeImpl extends EObjectImpl implements EObjectDiffNode {
  /**
   * The cached value of the '{@link #getSubDiffNodes() <em>Sub Diff Nodes</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getSubDiffNodes()
   * @generated
   * @ordered
   */
  protected EList subDiffNodes = null;

  /**
   * The cached value of the '{@link #getChangeDescription() <em>Change Description</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getChangeDescription()
   * @generated
   * @ordered
   */
  protected ChangeDescription changeDescription = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EObjectDiffNodeImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return MappingPackage.eINSTANCE.getEObjectDiffNode();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getSubDiffNodes() {
    if (subDiffNodes == null) {
      subDiffNodes = new EObjectContainmentEList(EObjectDiffNode.class, this,
          MappingPackage.EOBJECT_DIFF_NODE__SUB_DIFF_NODES);
    }
    return subDiffNodes;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ChangeDescription getChangeDescription() {
    if (changeDescription != null && changeDescription.eIsProxy()) {
      ChangeDescription oldChangeDescription = changeDescription;
      changeDescription = (ChangeDescription) eResolveProxy((InternalEObject) changeDescription);
      if (changeDescription != oldChangeDescription) {
        if (eNotificationRequired())
          eNotify(new ENotificationImpl(this, Notification.RESOLVE,
              MappingPackage.EOBJECT_DIFF_NODE__CHANGE_DESCRIPTION, oldChangeDescription, changeDescription));
      }
    }
    return changeDescription;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ChangeDescription basicGetChangeDescription() {
    return changeDescription;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setChangeDescription(ChangeDescription newChangeDescription) {
    ChangeDescription oldChangeDescription = changeDescription;
    changeDescription = newChangeDescription;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, MappingPackage.EOBJECT_DIFF_NODE__CHANGE_DESCRIPTION,
          oldChangeDescription, changeDescription));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass,
      NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
      case MappingPackage.EOBJECT_DIFF_NODE__SUB_DIFF_NODES:
        return ((InternalEList) getSubDiffNodes()).basicRemove(otherEnd, msgs);
      default:
        return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.EOBJECT_DIFF_NODE__SUB_DIFF_NODES:
      return getSubDiffNodes();
    case MappingPackage.EOBJECT_DIFF_NODE__CHANGE_DESCRIPTION:
      if (resolve)
        return getChangeDescription();
      return basicGetChangeDescription();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.EOBJECT_DIFF_NODE__SUB_DIFF_NODES:
      getSubDiffNodes().clear();
      getSubDiffNodes().addAll((Collection) newValue);
      return;
    case MappingPackage.EOBJECT_DIFF_NODE__CHANGE_DESCRIPTION:
      setChangeDescription((ChangeDescription) newValue);
      return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.EOBJECT_DIFF_NODE__SUB_DIFF_NODES:
      getSubDiffNodes().clear();
      return;
    case MappingPackage.EOBJECT_DIFF_NODE__CHANGE_DESCRIPTION:
      setChangeDescription((ChangeDescription) null);
      return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.EOBJECT_DIFF_NODE__SUB_DIFF_NODES:
      return subDiffNodes != null && !subDiffNodes.isEmpty();
    case MappingPackage.EOBJECT_DIFF_NODE__CHANGE_DESCRIPTION:
      return changeDescription != null;
    }
    return eDynamicIsSet(eFeature);
  }

} //EObjectDiffNodeImpl
