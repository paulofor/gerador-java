/**
 * <copyright>
 * </copyright>
 *
 * $Id: EvaluationMode.java,v 1.1 2005/07/07 21:33:31 jcheuoua Exp $
 */
package com.metys.merlin.generation.mappingmodel.rules;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Evaluation Mode</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see com.metys.merlin.generation.mappingmodel.rules.RulesPackage#getEvaluationMode()
 * @model
 * @generated
 */
public final class EvaluationMode extends AbstractEnumerator {
  /**
   * The '<em><b>ALL CONDITIONS TRUE</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>ALL CONDITIONS TRUE</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #ALL_CONDITIONS_TRUE_LITERAL
   * @model
   * @generated
   * @ordered
   */
  public static final int ALL_CONDITIONS_TRUE = 0;

  /**
   * The '<em><b>ONE CONDITION TRUE</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>ONE CONDITION TRUE</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #ONE_CONDITION_TRUE_LITERAL
   * @model
   * @generated
   * @ordered
   */
  public static final int ONE_CONDITION_TRUE = 1;

  /**
   * The '<em><b>ALL CONDITIONS FALSE</b></em>' literal value.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of '<em><b>ALL CONDITIONS FALSE</b></em>' literal object isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @see #ALL_CONDITIONS_FALSE_LITERAL
   * @model
   * @generated
   * @ordered
   */
  public static final int ALL_CONDITIONS_FALSE = 2;

  /**
   * The '<em><b>ALL CONDITIONS TRUE</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #ALL_CONDITIONS_TRUE
   * @generated
   * @ordered
   */
  public static final EvaluationMode ALL_CONDITIONS_TRUE_LITERAL = new EvaluationMode(ALL_CONDITIONS_TRUE,
      "ALL_CONDITIONS_TRUE");

  /**
   * The '<em><b>ONE CONDITION TRUE</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #ONE_CONDITION_TRUE
   * @generated
   * @ordered
   */
  public static final EvaluationMode ONE_CONDITION_TRUE_LITERAL = new EvaluationMode(ONE_CONDITION_TRUE,
      "ONE_CONDITION_TRUE");

  /**
   * The '<em><b>ALL CONDITIONS FALSE</b></em>' literal object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #ALL_CONDITIONS_FALSE
   * @generated
   * @ordered
   */
  public static final EvaluationMode ALL_CONDITIONS_FALSE_LITERAL = new EvaluationMode(ALL_CONDITIONS_FALSE,
      "ALL_CONDITIONS_FALSE");

  /**
   * An array of all the '<em><b>Evaluation Mode</b></em>' enumerators.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static final EvaluationMode[] VALUES_ARRAY = new EvaluationMode[] { ALL_CONDITIONS_TRUE_LITERAL,
      ONE_CONDITION_TRUE_LITERAL, ALL_CONDITIONS_FALSE_LITERAL, };

  /**
   * A public read-only list of all the '<em><b>Evaluation Mode</b></em>' enumerators.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

  /**
   * Returns the '<em><b>Evaluation Mode</b></em>' literal with the specified name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static EvaluationMode get(String name) {
    for (int i = 0; i < VALUES_ARRAY.length; ++i) {
      EvaluationMode result = VALUES_ARRAY[i];
      if (result.toString().equals(name)) {
        return result;
      }
    }
    return null;
  }

  /**
   * Returns the '<em><b>Evaluation Mode</b></em>' literal with the specified value.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static EvaluationMode get(int value) {
    switch (value) {
    case ALL_CONDITIONS_TRUE:
      return ALL_CONDITIONS_TRUE_LITERAL;
    case ONE_CONDITION_TRUE:
      return ONE_CONDITION_TRUE_LITERAL;
    case ALL_CONDITIONS_FALSE:
      return ALL_CONDITIONS_FALSE_LITERAL;
    }
    return null;
  }

  /**
   * Only this class can construct instances.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EvaluationMode(int value, String name) {
    super(value, name);
  }

} //EvaluationMode
