/**
 * <copyright>
 * </copyright>
 *
 * $Id: EObjectDiffNode.java,v 1.1 2005/07/07 21:33:31 jcheuoua Exp $
 */
package com.metys.merlin.generation.mappingmodel.mapping;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.change.ChangeDescription;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>EObject Diff Node</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.EObjectDiffNode#getSubDiffNodes <em>Sub Diff Nodes</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.EObjectDiffNode#getChangeDescription <em>Change Description</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getEObjectDiffNode()
 * @model
 * @generated
 */
public interface EObjectDiffNode extends EObject {
  /**
   * Returns the value of the '<em><b>Sub Diff Nodes</b></em>' containment reference list.
   * The list contents are of type {@link com.metys.merlin.generation.mappingmodel.mapping.EObjectDiffNode}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Sub Diff Nodes</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Sub Diff Nodes</em>' containment reference list.
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getEObjectDiffNode_SubDiffNodes()
   * @model type="com.metys.merlin.generation.mappingmodel.mapping.EObjectDiffNode" containment="true"
   * @generated
   */
  EList getSubDiffNodes();

  /**
   * Returns the value of the '<em><b>Change Description</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Change Description</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Change Description</em>' reference.
   * @see #setChangeDescription(ChangeDescription)
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getEObjectDiffNode_ChangeDescription()
   * @model
   * @generated
   */
  ChangeDescription getChangeDescription();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.mappingmodel.mapping.EObjectDiffNode#getChangeDescription <em>Change Description</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Change Description</em>' reference.
   * @see #getChangeDescription()
   * @generated
   */
  void setChangeDescription(ChangeDescription value);

} // EObjectDiffNode
