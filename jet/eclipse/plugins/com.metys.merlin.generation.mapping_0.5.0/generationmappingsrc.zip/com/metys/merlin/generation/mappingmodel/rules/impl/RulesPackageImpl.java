/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.mappingmodel.rules.impl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.change.impl.ChangePackageImpl;
import org.eclipse.emf.ecore.impl.EPackageImpl;
import org.eclipse.emf.ecore.impl.EcorePackageImpl;
import org.eclipse.emf.mapping.ecore2ecore.impl.Ecore2EcorePackageImpl;
import org.eclipse.emf.mapping.impl.MappingPackageImpl;

import com.metys.merlin.generation.mappingmodel.MappingModelPackage;
import com.metys.merlin.generation.mappingmodel.impl.MappingModelPackageImpl;
import com.metys.merlin.generation.mappingmodel.mapping.MappingPackage;
import com.metys.merlin.generation.mappingmodel.rules.EvaluationMode;
import com.metys.merlin.generation.mappingmodel.rules.MappingRule;
import com.metys.merlin.generation.mappingmodel.rules.MappingRuleAction;
import com.metys.merlin.generation.mappingmodel.rules.MappingRuleCondition;
import com.metys.merlin.generation.mappingmodel.rules.PolicyKind;
import com.metys.merlin.generation.mappingmodel.rules.RulesFactory;
import com.metys.merlin.generation.mappingmodel.rules.RulesPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class RulesPackageImpl extends EPackageImpl implements RulesPackage {
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass mappingRuleEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass mappingRuleConditionEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass mappingRuleActionEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum evaluationModeEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum policyKindEEnum = null;

  /**
   * Creates an instance of the model <b>Package</b>, registered with
   * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
   * package URI value.
   * <p>Note: the correct way to create the package is via the static
   * factory method {@link #init init()}, which also performs
   * initialization of the package, or returns the registered package,
   * if one already exists.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.eclipse.emf.ecore.EPackage.Registry
   * @see com.metys.merlin.generation.mappingmodel.rules.RulesPackage#eNS_URI
   * @see #init()
   * @generated
   */
  private RulesPackageImpl() {
    super(eNS_URI, RulesFactory.eINSTANCE);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static boolean isInited = false;

  /**
   * Creates, registers, and initializes the <b>Package</b> for this
   * model, and for any others upon which it depends.  Simple
   * dependencies are satisfied by calling this method on all
   * dependent packages before doing anything else.  This method drives
   * initialization for interdependent packages directly, in parallel
   * with this package, itself.
   * <p>Of this package and its interdependencies, all packages which
   * have not yet been registered by their URI values are first created
   * and registered.  The packages are then initialized in two steps:
   * meta-model objects for all of the packages are created before any
   * are initialized, since one package's meta-model objects may refer to
   * those of another.
   * <p>Invocation of this method will not affect any packages that have
   * already been initialized.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #eNS_URI
   * @see #createPackageContents()
   * @see #initializePackageContents()
   * @generated
   */
  public static RulesPackage init() {
    if (isInited)
      return (RulesPackage) EPackage.Registry.INSTANCE.getEPackage(RulesPackage.eNS_URI);

    // Obtain or create and register package
    RulesPackageImpl theRulesPackage = (RulesPackageImpl) (EPackage.Registry.INSTANCE.getEPackage(eNS_URI) instanceof RulesPackageImpl ? EPackage.Registry.INSTANCE
        .getEPackage(eNS_URI)
        : new RulesPackageImpl());

    isInited = true;

    // Initialize simple dependencies
    EcorePackageImpl.init();
    Ecore2EcorePackageImpl.init();
    MappingPackageImpl.init();
    ChangePackageImpl.init();

    // Obtain or create and register interdependencies
    MappingModelPackageImpl theMappingModelPackage = (MappingModelPackageImpl) (EPackage.Registry.INSTANCE
        .getEPackage(MappingModelPackage.eNS_URI) instanceof MappingModelPackageImpl ? EPackage.Registry.INSTANCE
        .getEPackage(MappingModelPackage.eNS_URI) : MappingModelPackage.eINSTANCE);
    com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl theMappingPackage_1 = (com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl) (EPackage.Registry.INSTANCE
        .getEPackage(MappingPackage.eNS_URI) instanceof com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl ? EPackage.Registry.INSTANCE
        .getEPackage(MappingPackage.eNS_URI)
        : MappingPackage.eINSTANCE);

    // Create package meta-data objects
    theRulesPackage.createPackageContents();
    theMappingModelPackage.createPackageContents();
    theMappingPackage_1.createPackageContents();

    // Initialize created meta-data
    theRulesPackage.initializePackageContents();
    theMappingModelPackage.initializePackageContents();
    theMappingPackage_1.initializePackageContents();

    // Mark meta-data to indicate it can't be changed
    theRulesPackage.freeze();

    return theRulesPackage;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getMappingRule() {
    return mappingRuleEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMappingRule_Name() {
    return (EAttribute) mappingRuleEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getMappingRule_MappingRuleConditions() {
    return (EReference) mappingRuleEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getMappingRule_MappingRuleActions() {
    return (EReference) mappingRuleEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMappingRule_Constraints() {
    return (EAttribute) mappingRuleEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMappingRule_Policy() {
    return (EAttribute) mappingRuleEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getMappingRule_TargetMatchingConditions() {
    return (EReference) mappingRuleEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getMappingRuleCondition() {
    return mappingRuleConditionEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMappingRuleCondition_Condition() {
    return (EAttribute) mappingRuleConditionEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getMappingRuleAction() {
    return mappingRuleActionEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMappingRuleAction_Action() {
    return (EAttribute) mappingRuleActionEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getEvaluationMode() {
    return evaluationModeEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getPolicyKind() {
    return policyKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public RulesFactory getRulesFactory() {
    return (RulesFactory) getEFactoryInstance();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private boolean isCreated = false;

  /**
   * Creates the meta-model objects for the package.  This method is
   * guarded to have no affect on any invocation but its first.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void createPackageContents() {
    if (isCreated)
      return;
    isCreated = true;

    // Create classes and their features
    mappingRuleEClass = createEClass(MAPPING_RULE);
    createEAttribute(mappingRuleEClass, MAPPING_RULE__NAME);
    createEReference(mappingRuleEClass, MAPPING_RULE__TARGET_MATCHING_CONDITIONS);
    createEReference(mappingRuleEClass, MAPPING_RULE__MAPPING_RULE_CONDITIONS);
    createEReference(mappingRuleEClass, MAPPING_RULE__MAPPING_RULE_ACTIONS);
    createEAttribute(mappingRuleEClass, MAPPING_RULE__CONSTRAINTS);
    createEAttribute(mappingRuleEClass, MAPPING_RULE__POLICY);

    mappingRuleConditionEClass = createEClass(MAPPING_RULE_CONDITION);
    createEAttribute(mappingRuleConditionEClass, MAPPING_RULE_CONDITION__CONDITION);

    mappingRuleActionEClass = createEClass(MAPPING_RULE_ACTION);
    createEAttribute(mappingRuleActionEClass, MAPPING_RULE_ACTION__ACTION);

    // Create enums
    evaluationModeEEnum = createEEnum(EVALUATION_MODE);
    policyKindEEnum = createEEnum(POLICY_KIND);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private boolean isInitialized = false;

  /**
   * Complete the initialization of the package and its meta-model.  This
   * method is guarded to have no affect on any invocation but its first.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void initializePackageContents() {
    if (isInitialized)
      return;
    isInitialized = true;

    // Initialize package
    setName(eNAME);
    setNsPrefix(eNS_PREFIX);
    setNsURI(eNS_URI);

    // Obtain other dependent packages
    MappingPackageImpl theMappingPackage = (MappingPackageImpl) EPackage.Registry.INSTANCE
        .getEPackage(org.eclipse.emf.mapping.MappingPackage.eNS_URI);
    EcorePackageImpl theEcorePackage = (EcorePackageImpl) EPackage.Registry.INSTANCE.getEPackage(EcorePackage.eNS_URI);
    com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl theMappingPackage_1 = (com.metys.merlin.generation.mappingmodel.mapping.impl.MappingPackageImpl) EPackage.Registry.INSTANCE
        .getEPackage(MappingPackage.eNS_URI);

    // Add supertypes to classes
    mappingRuleEClass.getESuperTypes().add(theMappingPackage.getMappingHelper());

    // Initialize classes and features; add operations and parameters
    initEClass(mappingRuleEClass, MappingRule.class, "MappingRule", !IS_ABSTRACT, !IS_INTERFACE,
        IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getMappingRule_Name(), theEcorePackage.getEString(), "name", null, 0, 1, MappingRule.class,
        !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getMappingRule_TargetMatchingConditions(), this.getMappingRuleCondition(), null,
        "targetMatchingConditions", null, 0, -1, MappingRule.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
        IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getMappingRule_MappingRuleConditions(), this.getMappingRuleCondition(), null,
        "mappingRuleConditions", null, 0, -1, MappingRule.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
        IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getMappingRule_MappingRuleActions(), this.getMappingRuleAction(), null, "mappingRuleActions", null,
        0, -1, MappingRule.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
        !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMappingRule_Constraints(), this.getEvaluationMode(), "constraints", null, 0, 1,
        MappingRule.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED,
        IS_ORDERED);
    initEAttribute(getMappingRule_Policy(), this.getPolicyKind(), "policy", null, 0, 1, MappingRule.class,
        !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    EOperation op = addEOperation(mappingRuleEClass, null, "fireRule");
    addEParameter(op, theEcorePackage.getEObject(), "source");
    addEParameter(op, theEcorePackage.getEObject(), "target");
    addEParameter(op, theMappingPackage_1.getTransformer(), "mapper");
    addEParameter(op, theMappingPackage.getMappingRoot(), "instancesMappingRoot");

    op = addEOperation(mappingRuleEClass, theEcorePackage.getEBoolean(), "canFireRule");
    addEParameter(op, theEcorePackage.getEObject(), "source");
    addEParameter(op, theEcorePackage.getEObject(), "target");
    addEParameter(op, theMappingPackage_1.getTransformer(), "mapper");
    addEParameter(op, theMappingPackage.getMappingRoot(), "instancesMappingRoot");

    initEClass(mappingRuleConditionEClass, MappingRuleCondition.class, "MappingRuleCondition", !IS_ABSTRACT,
        !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getMappingRuleCondition_Condition(), theEcorePackage.getEString(), "condition", null, 0, 1,
        MappingRuleCondition.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
        !IS_DERIVED, IS_ORDERED);

    op = addEOperation(mappingRuleConditionEClass, theEcorePackage.getEBoolean(), "evaluate");
    addEParameter(op, theEcorePackage.getEObject(), "source");
    addEParameter(op, theEcorePackage.getEObject(), "target");
    addEParameter(op, theMappingPackage_1.getTransformer(), "mapper");
    addEParameter(op, theMappingPackage.getMappingRoot(), "instancesMappingRoot");

    initEClass(mappingRuleActionEClass, MappingRuleAction.class, "MappingRuleAction", !IS_ABSTRACT, !IS_INTERFACE,
        IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getMappingRuleAction_Action(), theEcorePackage.getEString(), "action", null, 0, 1,
        MappingRuleAction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
        !IS_DERIVED, IS_ORDERED);

    op = addEOperation(mappingRuleActionEClass, null, "apply");
    addEParameter(op, theEcorePackage.getEObject(), "source");
    addEParameter(op, theEcorePackage.getEObject(), "target");
    addEParameter(op, theMappingPackage_1.getTransformer(), "mapper");
    addEParameter(op, theMappingPackage.getMappingRoot(), "instancesMappingRoot");

    // Initialize enums and add enum literals
    initEEnum(evaluationModeEEnum, EvaluationMode.class, "EvaluationMode");
    addEEnumLiteral(evaluationModeEEnum, EvaluationMode.ALL_CONDITIONS_TRUE_LITERAL);
    addEEnumLiteral(evaluationModeEEnum, EvaluationMode.ONE_CONDITION_TRUE_LITERAL);
    addEEnumLiteral(evaluationModeEEnum, EvaluationMode.ALL_CONDITIONS_FALSE_LITERAL);

    initEEnum(policyKindEEnum, PolicyKind.class, "PolicyKind");
    addEEnumLiteral(policyKindEEnum, PolicyKind.ENFORCE_LITERAL);
    addEEnumLiteral(policyKindEEnum, PolicyKind.CHECK_ONLY_LITERAL);
  }

} //RulesPackageImpl
