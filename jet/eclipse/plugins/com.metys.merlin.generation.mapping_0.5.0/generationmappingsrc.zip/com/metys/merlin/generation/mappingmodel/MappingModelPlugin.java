/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.mappingmodel;

import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.emf.common.EMFPlugin;
import org.eclipse.emf.common.util.ResourceLocator;
import org.eclipse.emf.ecore.resource.Resource;

import bsh.BshClassManager;
import bsh.EvalError;
import bsh.Interpreter;
import bsh.NameSpace;

/**
 * This is the central singleton for the Mapping model plugin.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public final class MappingModelPlugin extends EMFPlugin {
  /**
   * Keep track of the singleton.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static final MappingModelPlugin INSTANCE = new MappingModelPlugin();

  /**
   * Keep track of the singleton.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static Implementation plugin;

  /**
   * Create the instance.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MappingModelPlugin() {
    super(new ResourceLocator[] {});
  }

  /**
   * Returns the singleton instance of the Eclipse plugin.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the singleton instance.
   * @generated
   */
  public ResourceLocator getPluginResourceLocator() {
    return plugin;
  }

  /**
   * Returns the singleton instance of the Eclipse plugin.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the singleton instance.
   * @generated
   */
  public static Implementation getPlugin() {
    return plugin;
  }

  public static Interpreter getInterpreter() {
    return plugin.getInterpreterInstance();
  }

  public static class BSHScriptClassLoader extends URLClassLoader {
    private List delegateLoaders;

    /**
     * @param urls
     * @param parent
     */
    public BSHScriptClassLoader(ClassLoader parent) {
      super(new URL[] {}, parent);
    }

    public void addClassLoaderDelegate(ClassLoader delegate) {
      if (delegateLoaders == null)
        delegateLoaders = new ArrayList();
      delegateLoaders.add(delegate);
    }

    public Collection getDelegateLoaders() {
      return delegateLoaders;
    }

    /* (non-Javadoc)
     * @see java.lang.ClassLoader#loadClass(java.lang.String)
     */
    public Class loadClass(String name) throws ClassNotFoundException {
      Class c = null;
      //First, Look in the delegates
      if (delegateLoaders != null && !delegateLoaders.isEmpty()) {
        for (Iterator it = delegateLoaders.iterator(); it.hasNext();) {
          ClassLoader delegate = (ClassLoader) it.next();
          try {
            c = delegate.loadClass(name);
            return c;
          } catch (ClassNotFoundException subex) {
            // Continue to the next delegate
          }
        }
      }
      return super.loadClass(name);
    }
  };

  /**
   * The actual implementation of the Eclipse <b>Plugin</b>.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static class Implementation extends EclipsePlugin {
    private Interpreter interpreter;
    private BSHScriptClassLoader interpreterClassLoader;

    /**
     * Creates an instance.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    public Implementation() {
      super();

      // Remember the static instance.
      //
      plugin = this;
    }

    public void logInError(Throwable throwable, String message) {
      String throwableMessage = throwable.getLocalizedMessage();
      if (throwableMessage != null) {
        if (message != null)
          message += " : " + throwableMessage;
        else
          message = throwableMessage;
      }
      if (message == null)
        message = throwable.getClass().getName();
      Status status = new Status(IStatus.ERROR, getBundle().getSymbolicName(), 0, message, throwable);
      log(status);
    }

    public void logInWarning(Throwable throwable, String message) {
      String throwableMessage = throwable.getLocalizedMessage();
      if (throwableMessage != null) {
        if (message != null)
          message += " : " + throwableMessage;
        else
          message = throwableMessage;
      }
      if (message == null)
        message = throwable.getClass().getName();
      Status status = new Status(IStatus.WARNING, getBundle().getSymbolicName(), 0, message, throwable);
      log(status);
    }

    /**
     * @return
     */
    public Interpreter getInterpreterInstance() {
      if (interpreter == null) {
        BshClassManager classManager = new BshClassManager();
        NameSpace namespace = new NameSpace(classManager, "Namespace");
        //  Create the bean shell interpreter
        interpreter = new Interpreter();
        interpreter.setNameSpace(namespace);
      }
      return interpreter;
    }
    
    public BSHScriptClassLoader getInterpreterClassLoader() {
      return interpreterClassLoader;
    }
    
    public void initializeInterpreter(ClassLoader parentClassLoader, List instancesContext) {
      // Create the bean shell class loader
      interpreterClassLoader = new BSHScriptClassLoader(parentClassLoader);
      HashSet classLoaders = new HashSet();
      for (Iterator iter = instancesContext.iterator(); iter.hasNext();) {
        Object context = (Object) iter.next();
        ClassLoader contextLoader = context.getClass().getClassLoader();
        if (!parentClassLoader.equals(contextLoader))
          classLoaders.add(contextLoader);
      }
      for (Iterator iter = classLoaders.iterator(); iter.hasNext();) {
        ClassLoader loader = (ClassLoader) iter.next();
        interpreterClassLoader.addClassLoaderDelegate(loader);  
      }
      getInterpreterInstance().setClassLoader(interpreterClassLoader);
      getInterpreterInstance().getNameSpace().classLoaderChanged();
    }
  }

  public static void addInterpreterClassLoader(ClassLoader additionalLoader) {
    Interpreter interp = getPlugin().getInterpreterInstance();
    // Keep the previous context
    String[] names = interp.getNameSpace().getVariableNames();
    Object[] values = new Object[names.length];
    for (int i = 0; i < names.length; i++) {
      try {
        values[i] = interp.get(names[i]);
      } catch (EvalError e) {
        MappingModelPlugin.getPlugin().logInError(e, null);
      }
    }
    // Add the additional class loader
    if (!getInterpreterClassLoader().getDelegateLoaders().contains(additionalLoader))
      getInterpreterClassLoader().addClassLoaderDelegate(additionalLoader);
    interp.setClassLoader(getInterpreterClassLoader());
    interp.getNameSpace().classLoaderChanged();  
    // Reset the previous context
    for (int i = 0; i < names.length; i++) {
      try {
        interp.set(names[i], values[i]);
      } catch (EvalError e) {
        MappingModelPlugin.getPlugin().logInError(e, null);
      }
    }
  }
  public static BSHScriptClassLoader getInterpreterClassLoader() {
    return getPlugin().getInterpreterClassLoader(); 
  }
  public static void initBSHInterpreter(ClassLoader parentClassLoader, Collection sourceContext, Collection targetContext) {
    List instancesContext = new ArrayList();
    // Collect top source instances
    for (Iterator iter = sourceContext.iterator(); iter.hasNext();) {
      Resource res = (Resource) iter.next();
      if (!res.getContents().isEmpty())
        instancesContext.add(res.getContents().get(0));
    }
    // Collect top target instances
    for (Iterator iter = targetContext.iterator(); iter.hasNext();) {
      Resource res = (Resource) iter.next();
      if (!res.getContents().isEmpty())
        instancesContext.add(res.getContents().get(0));
    }
    getPlugin().initializeInterpreter(parentClassLoader, instancesContext);
  }
}