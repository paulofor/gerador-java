/**
 * <copyright>
 * </copyright>
 *
 * $Id: MappingReport.java,v 1.1 2005/07/07 21:33:31 jcheuoua Exp $
 */
package com.metys.merlin.generation.mappingmodel.mapping;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Report</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.MappingReport#getSeverity <em>Severity</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.MappingReport#getMessage <em>Message</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getMappingReport()
 * @model
 * @generated
 */
public interface MappingReport extends EObject {
  /**
   * Returns the value of the '<em><b>Severity</b></em>' attribute.
   * The literals are from the enumeration {@link com.metys.merlin.generation.mappingmodel.mapping.SeverityKind}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Severity</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Severity</em>' attribute.
   * @see com.metys.merlin.generation.mappingmodel.mapping.SeverityKind
   * @see #setSeverity(SeverityKind)
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getMappingReport_Severity()
   * @model
   * @generated
   */
  SeverityKind getSeverity();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.mappingmodel.mapping.MappingReport#getSeverity <em>Severity</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Severity</em>' attribute.
   * @see com.metys.merlin.generation.mappingmodel.mapping.SeverityKind
   * @see #getSeverity()
   * @generated
   */
  void setSeverity(SeverityKind value);

  /**
   * Returns the value of the '<em><b>Message</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Message</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Message</em>' attribute.
   * @see #setMessage(String)
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getMappingReport_Message()
   * @model
   * @generated
   */
  String getMessage();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.mappingmodel.mapping.MappingReport#getMessage <em>Message</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Message</em>' attribute.
   * @see #getMessage()
   * @generated
   */
  void setMessage(String value);

} // MappingReport
