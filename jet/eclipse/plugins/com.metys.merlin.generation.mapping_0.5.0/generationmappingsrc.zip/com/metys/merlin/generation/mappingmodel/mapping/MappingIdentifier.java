/**
 * <copyright>
 * </copyright>
 *
 * $Id: MappingIdentifier.java,v 1.1 2005/07/07 21:33:31 jcheuoua Exp $
 */
package com.metys.merlin.generation.mappingmodel.mapping;

import org.eclipse.emf.mapping.MappingHelper;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Identifier</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.MappingIdentifier#getId <em>Id</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.MappingIdentifier#getMappingKind <em>Mapping Kind</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getMappingIdentifier()
 * @model
 * @generated
 */
public interface MappingIdentifier extends MappingHelper {
  /**
   * Returns the value of the '<em><b>Id</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Id</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Id</em>' attribute.
   * @see #setId(String)
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getMappingIdentifier_Id()
   * @model id="true" required="true"
   * @generated
   */
  String getId();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.mappingmodel.mapping.MappingIdentifier#getId <em>Id</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Id</em>' attribute.
   * @see #getId()
   * @generated
   */
  void setId(String value);

  /**
   * Returns the value of the '<em><b>Mapping Kind</b></em>' attribute.
   * The literals are from the enumeration {@link com.metys.merlin.generation.mappingmodel.mapping.MappingKind}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Mapping Kind</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Mapping Kind</em>' attribute.
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingKind
   * @see #setMappingKind(MappingKind)
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#getMappingIdentifier_MappingKind()
   * @model
   * @generated
   */
  MappingKind getMappingKind();

  /**
   * Sets the value of the '{@link com.metys.merlin.generation.mappingmodel.mapping.MappingIdentifier#getMappingKind <em>Mapping Kind</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Mapping Kind</em>' attribute.
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingKind
   * @see #getMappingKind()
   * @generated
   */
  void setMappingKind(MappingKind value);

} // MappingIdentifier
