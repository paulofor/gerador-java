/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.mappingmodel.mapping.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.util.InternalEList;
import org.eclipse.emf.mapping.Mapping;
import org.eclipse.emf.mapping.MappingHelper;
import org.eclipse.emf.mapping.ecore2ecore.impl.Ecore2EcoreMappingRootImpl;

import com.metys.merlin.generation.mappingmodel.mapping.MappingFactory;
import com.metys.merlin.generation.mappingmodel.mapping.MappingPackage;
import com.metys.merlin.generation.mappingmodel.mapping.TypeMappingRoot;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Type Mapping Root</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class TypeMappingRootImpl extends Ecore2EcoreMappingRootImpl implements TypeMappingRoot {
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  protected TypeMappingRootImpl() {
    super();
    setTopToBottom(true);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return MappingPackage.eINSTANCE.getTypeMappingRoot();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
      case MappingPackage.TYPE_MAPPING_ROOT__HELPER:
        if (helper != null)
          msgs = ((InternalEObject) helper).eInverseRemove(this, EOPPOSITE_FEATURE_BASE
              - MappingPackage.TYPE_MAPPING_ROOT__HELPER, null, msgs);
        return basicSetHelper((MappingHelper) otherEnd, msgs);
      case MappingPackage.TYPE_MAPPING_ROOT__NESTED:
        return ((InternalEList) getNested()).basicAdd(otherEnd, msgs);
      case MappingPackage.TYPE_MAPPING_ROOT__NESTED_IN:
        if (eContainer != null)
          msgs = eBasicRemoveFromContainer(msgs);
        return eBasicSetContainer(otherEnd, MappingPackage.TYPE_MAPPING_ROOT__NESTED_IN, msgs);
      default:
        return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass,
      NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
      case MappingPackage.TYPE_MAPPING_ROOT__HELPER:
        return basicSetHelper(null, msgs);
      case MappingPackage.TYPE_MAPPING_ROOT__NESTED:
        return ((InternalEList) getNested()).basicRemove(otherEnd, msgs);
      case MappingPackage.TYPE_MAPPING_ROOT__NESTED_IN:
        return eBasicSetContainer(null, MappingPackage.TYPE_MAPPING_ROOT__NESTED_IN, msgs);
      default:
        return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
    if (eContainerFeatureID >= 0) {
      switch (eContainerFeatureID) {
      case MappingPackage.TYPE_MAPPING_ROOT__NESTED_IN:
        return eContainer.eInverseRemove(this, org.eclipse.emf.mapping.MappingPackage.MAPPING__NESTED, Mapping.class,
            msgs);
      default:
        return eDynamicBasicRemoveFromContainer(msgs);
      }
    }
    return eContainer.eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.TYPE_MAPPING_ROOT__HELPER:
      return getHelper();
    case MappingPackage.TYPE_MAPPING_ROOT__NESTED:
      return getNested();
    case MappingPackage.TYPE_MAPPING_ROOT__NESTED_IN:
      return getNestedIn();
    case MappingPackage.TYPE_MAPPING_ROOT__INPUTS:
      return getInputs();
    case MappingPackage.TYPE_MAPPING_ROOT__OUTPUTS:
      return getOutputs();
    case MappingPackage.TYPE_MAPPING_ROOT__TYPE_MAPPING:
      if (resolve)
        return getTypeMapping();
      return basicGetTypeMapping();
    case MappingPackage.TYPE_MAPPING_ROOT__OUTPUT_READ_ONLY:
      return isOutputReadOnly() ? Boolean.TRUE : Boolean.FALSE;
    case MappingPackage.TYPE_MAPPING_ROOT__TOP_TO_BOTTOM:
      return isTopToBottom() ? Boolean.TRUE : Boolean.FALSE;
    case MappingPackage.TYPE_MAPPING_ROOT__COMMAND_STACK:
      return getCommandStack();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.TYPE_MAPPING_ROOT__HELPER:
      setHelper((MappingHelper) newValue);
      return;
    case MappingPackage.TYPE_MAPPING_ROOT__NESTED:
      getNested().clear();
      getNested().addAll((Collection) newValue);
      return;
    case MappingPackage.TYPE_MAPPING_ROOT__NESTED_IN:
      setNestedIn((Mapping) newValue);
      return;
    case MappingPackage.TYPE_MAPPING_ROOT__INPUTS:
      getInputs().clear();
      getInputs().addAll((Collection) newValue);
      return;
    case MappingPackage.TYPE_MAPPING_ROOT__OUTPUTS:
      getOutputs().clear();
      getOutputs().addAll((Collection) newValue);
      return;
    case MappingPackage.TYPE_MAPPING_ROOT__TYPE_MAPPING:
      setTypeMapping((Mapping) newValue);
      return;
    case MappingPackage.TYPE_MAPPING_ROOT__OUTPUT_READ_ONLY:
      setOutputReadOnly(((Boolean) newValue).booleanValue());
      return;
    case MappingPackage.TYPE_MAPPING_ROOT__TOP_TO_BOTTOM:
      setTopToBottom(((Boolean) newValue).booleanValue());
      return;
    case MappingPackage.TYPE_MAPPING_ROOT__COMMAND_STACK:
      setCommandStack((String) newValue);
      return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.TYPE_MAPPING_ROOT__HELPER:
      setHelper((MappingHelper) null);
      return;
    case MappingPackage.TYPE_MAPPING_ROOT__NESTED:
      getNested().clear();
      return;
    case MappingPackage.TYPE_MAPPING_ROOT__NESTED_IN:
      setNestedIn((Mapping) null);
      return;
    case MappingPackage.TYPE_MAPPING_ROOT__INPUTS:
      getInputs().clear();
      return;
    case MappingPackage.TYPE_MAPPING_ROOT__OUTPUTS:
      getOutputs().clear();
      return;
    case MappingPackage.TYPE_MAPPING_ROOT__TYPE_MAPPING:
      setTypeMapping((Mapping) null);
      return;
    case MappingPackage.TYPE_MAPPING_ROOT__OUTPUT_READ_ONLY:
      setOutputReadOnly(OUTPUT_READ_ONLY_EDEFAULT);
      return;
    case MappingPackage.TYPE_MAPPING_ROOT__TOP_TO_BOTTOM:
      setTopToBottom(TOP_TO_BOTTOM_EDEFAULT);
      return;
    case MappingPackage.TYPE_MAPPING_ROOT__COMMAND_STACK:
      setCommandStack(COMMAND_STACK_EDEFAULT);
      return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.TYPE_MAPPING_ROOT__HELPER:
      return helper != null;
    case MappingPackage.TYPE_MAPPING_ROOT__NESTED:
      return nested != null && !nested.isEmpty();
    case MappingPackage.TYPE_MAPPING_ROOT__NESTED_IN:
      return getNestedIn() != null;
    case MappingPackage.TYPE_MAPPING_ROOT__INPUTS:
      return inputs != null && !inputs.isEmpty();
    case MappingPackage.TYPE_MAPPING_ROOT__OUTPUTS:
      return outputs != null && !outputs.isEmpty();
    case MappingPackage.TYPE_MAPPING_ROOT__TYPE_MAPPING:
      return typeMapping != null;
    case MappingPackage.TYPE_MAPPING_ROOT__OUTPUT_READ_ONLY:
      return outputReadOnly != OUTPUT_READ_ONLY_EDEFAULT;
    case MappingPackage.TYPE_MAPPING_ROOT__TOP_TO_BOTTOM:
      return topToBottom != TOP_TO_BOTTOM_EDEFAULT;
    case MappingPackage.TYPE_MAPPING_ROOT__COMMAND_STACK:
      return COMMAND_STACK_EDEFAULT == null ? commandStack != null : !COMMAND_STACK_EDEFAULT.equals(commandStack);
    }
    return eDynamicIsSet(eFeature);
  }

  /* (non-Javadoc)
   * @see org.eclipse.emf.mapping.impl.MappingRootImpl#createMapping()
   */
  protected Mapping createMapping() {
    return MappingFactory.eINSTANCE.createTypeMapping();
  }

  /*
   * (non-Javadoc)
   * 
   * @see org.eclipse.emf.mapping.MappingRoot#canCreateMapping(java.util.Collection,
   *      java.util.Collection, org.eclipse.emf.mapping.Mapping)
   */
  public boolean canCreateMapping(Collection inputObjects, Collection outputObjects, Mapping mapping) {
    if (mapping == this) {
      for (Iterator i = inputObjects.iterator(); i.hasNext();) {
        if (!(i.next() instanceof EPackage)) {
          return false;
        }
      }
      for (Iterator i = outputObjects.iterator(); i.hasNext();) {
        if (!(i.next() instanceof EPackage)) {
          return false;
        }
      }
      return true;
    } else {
      Object inputFirstObject = inputObjects.isEmpty() ? null : inputObjects.iterator().next();
      if (!(inputFirstObject instanceof EClassifier) && !(inputFirstObject instanceof EStructuralFeature))
        return false;
      if (inputObjects.size() != 1 || outputObjects.size() != 1) // Allow only one-one mappings
        return false;
      boolean eclassifierType = inputFirstObject instanceof EClassifier;
      boolean eattrType = inputFirstObject instanceof EAttribute;
      boolean erefType = inputFirstObject instanceof EReference;
      ArrayList allObjects = new ArrayList();
      allObjects.addAll(inputObjects);
      allObjects.addAll(outputObjects);
      for (Iterator it = allObjects.iterator(); it.hasNext();) {
        Object obj = it.next();
        if (eclassifierType && !(obj instanceof EClassifier))
          return false;
        if (erefType && !(obj instanceof EReference))
          return false;
        if (eattrType && !(obj instanceof EAttribute))
          return false;
      }
      return super.canCreateMapping(inputObjects, outputObjects, mapping);
    }
  }
} //TypeMappingRootImpl
