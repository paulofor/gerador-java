/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.mappingmodel.rules;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.mapping.MappingPackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see com.metys.merlin.generation.mappingmodel.rules.RulesFactory
 * @model kind="package"
 * @generated
 */
public interface RulesPackage extends EPackage {
  /**
   * The package name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNAME = "rules";

  /**
   * The package namespace URI.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_URI = "http://www.metys.com/merlin/generation/mappingmodel/rules.ecore";

  /**
   * The package namespace name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_PREFIX = "mappingmodel.rules";

  /**
   * The singleton instance of the package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  RulesPackage eINSTANCE = com.metys.merlin.generation.mappingmodel.rules.impl.RulesPackageImpl.init();

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.mappingmodel.rules.impl.MappingRuleImpl <em>Mapping Rule</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.mappingmodel.rules.impl.MappingRuleImpl
   * @see com.metys.merlin.generation.mappingmodel.rules.impl.RulesPackageImpl#getMappingRule()
   * @generated
   */
  int MAPPING_RULE = 0;

  /**
   * The feature id for the '<em><b>Mapper</b></em>' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_RULE__MAPPER = MappingPackage.MAPPING_HELPER__MAPPER;

  /**
   * The feature id for the '<em><b>Helped Object</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_RULE__HELPED_OBJECT = MappingPackage.MAPPING_HELPER__HELPED_OBJECT;

  /**
   * The feature id for the '<em><b>Nested In</b></em>' container reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_RULE__NESTED_IN = MappingPackage.MAPPING_HELPER__NESTED_IN;

  /**
   * The feature id for the '<em><b>Nested</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_RULE__NESTED = MappingPackage.MAPPING_HELPER__NESTED;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_RULE__NAME = MappingPackage.MAPPING_HELPER_FEATURE_COUNT + 0;

  /**
   * The feature id for the '<em><b>Target Matching Conditions</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_RULE__TARGET_MATCHING_CONDITIONS = MappingPackage.MAPPING_HELPER_FEATURE_COUNT + 1;

  /**
   * The feature id for the '<em><b>Mapping Rule Conditions</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_RULE__MAPPING_RULE_CONDITIONS = MappingPackage.MAPPING_HELPER_FEATURE_COUNT + 2;

  /**
   * The feature id for the '<em><b>Mapping Rule Actions</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_RULE__MAPPING_RULE_ACTIONS = MappingPackage.MAPPING_HELPER_FEATURE_COUNT + 3;

  /**
   * The feature id for the '<em><b>Constraints</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_RULE__CONSTRAINTS = MappingPackage.MAPPING_HELPER_FEATURE_COUNT + 4;

  /**
   * The feature id for the '<em><b>Policy</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_RULE__POLICY = MappingPackage.MAPPING_HELPER_FEATURE_COUNT + 5;

  /**
   * The number of structural features of the the '<em>Mapping Rule</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_RULE_FEATURE_COUNT = MappingPackage.MAPPING_HELPER_FEATURE_COUNT + 6;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.mappingmodel.rules.impl.MappingRuleConditionImpl <em>Mapping Rule Condition</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.mappingmodel.rules.impl.MappingRuleConditionImpl
   * @see com.metys.merlin.generation.mappingmodel.rules.impl.RulesPackageImpl#getMappingRuleCondition()
   * @generated
   */
  int MAPPING_RULE_CONDITION = 1;

  /**
   * The feature id for the '<em><b>Condition</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_RULE_CONDITION__CONDITION = 0;

  /**
   * The number of structural features of the the '<em>Mapping Rule Condition</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_RULE_CONDITION_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.mappingmodel.rules.impl.MappingRuleActionImpl <em>Mapping Rule Action</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.mappingmodel.rules.impl.MappingRuleActionImpl
   * @see com.metys.merlin.generation.mappingmodel.rules.impl.RulesPackageImpl#getMappingRuleAction()
   * @generated
   */
  int MAPPING_RULE_ACTION = 2;

  /**
   * The feature id for the '<em><b>Action</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_RULE_ACTION__ACTION = 0;

  /**
   * The number of structural features of the the '<em>Mapping Rule Action</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MAPPING_RULE_ACTION_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.mappingmodel.rules.EvaluationMode <em>Evaluation Mode</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.mappingmodel.rules.EvaluationMode
   * @see com.metys.merlin.generation.mappingmodel.rules.impl.RulesPackageImpl#getEvaluationMode()
   * @generated
   */
  int EVALUATION_MODE = 3;

  /**
   * The meta object id for the '{@link com.metys.merlin.generation.mappingmodel.rules.PolicyKind <em>Policy Kind</em>}' enum.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.metys.merlin.generation.mappingmodel.rules.PolicyKind
   * @see com.metys.merlin.generation.mappingmodel.rules.impl.RulesPackageImpl#getPolicyKind()
   * @generated
   */
  int POLICY_KIND = 4;

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.mappingmodel.rules.MappingRule <em>Mapping Rule</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Mapping Rule</em>'.
   * @see com.metys.merlin.generation.mappingmodel.rules.MappingRule
   * @generated
   */
  EClass getMappingRule();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.mappingmodel.rules.MappingRule#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see com.metys.merlin.generation.mappingmodel.rules.MappingRule#getName()
   * @see #getMappingRule()
   * @generated
   */
  EAttribute getMappingRule_Name();

  /**
   * Returns the meta object for the containment reference list '{@link com.metys.merlin.generation.mappingmodel.rules.MappingRule#getMappingRuleConditions <em>Mapping Rule Conditions</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Mapping Rule Conditions</em>'.
   * @see com.metys.merlin.generation.mappingmodel.rules.MappingRule#getMappingRuleConditions()
   * @see #getMappingRule()
   * @generated
   */
  EReference getMappingRule_MappingRuleConditions();

  /**
   * Returns the meta object for the containment reference list '{@link com.metys.merlin.generation.mappingmodel.rules.MappingRule#getMappingRuleActions <em>Mapping Rule Actions</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Mapping Rule Actions</em>'.
   * @see com.metys.merlin.generation.mappingmodel.rules.MappingRule#getMappingRuleActions()
   * @see #getMappingRule()
   * @generated
   */
  EReference getMappingRule_MappingRuleActions();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.mappingmodel.rules.MappingRule#getConstraints <em>Constraints</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Constraints</em>'.
   * @see com.metys.merlin.generation.mappingmodel.rules.MappingRule#getConstraints()
   * @see #getMappingRule()
   * @generated
   */
  EAttribute getMappingRule_Constraints();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.mappingmodel.rules.MappingRule#getPolicy <em>Policy</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Policy</em>'.
   * @see com.metys.merlin.generation.mappingmodel.rules.MappingRule#getPolicy()
   * @see #getMappingRule()
   * @generated
   */
  EAttribute getMappingRule_Policy();

  /**
   * Returns the meta object for the containment reference list '{@link com.metys.merlin.generation.mappingmodel.rules.MappingRule#getTargetMatchingConditions <em>Target Matching Conditions</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Target Matching Conditions</em>'.
   * @see com.metys.merlin.generation.mappingmodel.rules.MappingRule#getTargetMatchingConditions()
   * @see #getMappingRule()
   * @generated
   */
  EReference getMappingRule_TargetMatchingConditions();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.mappingmodel.rules.MappingRuleCondition <em>Mapping Rule Condition</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Mapping Rule Condition</em>'.
   * @see com.metys.merlin.generation.mappingmodel.rules.MappingRuleCondition
   * @generated
   */
  EClass getMappingRuleCondition();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.mappingmodel.rules.MappingRuleCondition#getCondition <em>Condition</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Condition</em>'.
   * @see com.metys.merlin.generation.mappingmodel.rules.MappingRuleCondition#getCondition()
   * @see #getMappingRuleCondition()
   * @generated
   */
  EAttribute getMappingRuleCondition_Condition();

  /**
   * Returns the meta object for class '{@link com.metys.merlin.generation.mappingmodel.rules.MappingRuleAction <em>Mapping Rule Action</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Mapping Rule Action</em>'.
   * @see com.metys.merlin.generation.mappingmodel.rules.MappingRuleAction
   * @generated
   */
  EClass getMappingRuleAction();

  /**
   * Returns the meta object for the attribute '{@link com.metys.merlin.generation.mappingmodel.rules.MappingRuleAction#getAction <em>Action</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Action</em>'.
   * @see com.metys.merlin.generation.mappingmodel.rules.MappingRuleAction#getAction()
   * @see #getMappingRuleAction()
   * @generated
   */
  EAttribute getMappingRuleAction_Action();

  /**
   * Returns the meta object for enum '{@link com.metys.merlin.generation.mappingmodel.rules.EvaluationMode <em>Evaluation Mode</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>Evaluation Mode</em>'.
   * @see com.metys.merlin.generation.mappingmodel.rules.EvaluationMode
   * @generated
   */
  EEnum getEvaluationMode();

  /**
   * Returns the meta object for enum '{@link com.metys.merlin.generation.mappingmodel.rules.PolicyKind <em>Policy Kind</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for enum '<em>Policy Kind</em>'.
   * @see com.metys.merlin.generation.mappingmodel.rules.PolicyKind
   * @generated
   */
  EEnum getPolicyKind();

  /**
   * Returns the factory that creates the instances of the model.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the factory that creates the instances of the model.
   * @generated
   */
  RulesFactory getRulesFactory();

} //RulesPackage
