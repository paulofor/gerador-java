/**
 * <copyright>
 * </copyright>
 *
 * $Id: MappingPackageImpl.java,v 1.4 2005/07/07 21:33:31 jcheuoua Exp $
 */
package com.metys.merlin.generation.mappingmodel.mapping.impl;

import com.metys.merlin.generation.mappingmodel.MappingModelPackage;

import com.metys.merlin.generation.mappingmodel.impl.MappingModelPackageImpl;

import com.metys.merlin.generation.mappingmodel.mapping.AttributeChangeHandler;
import com.metys.merlin.generation.mappingmodel.mapping.EObjectDiffNode;
import com.metys.merlin.generation.mappingmodel.mapping.MappedInstanceHandler;
import com.metys.merlin.generation.mappingmodel.mapping.MappedInstancesFactory;
import com.metys.merlin.generation.mappingmodel.mapping.Transformer;
import com.metys.merlin.generation.mappingmodel.mapping.MappingFactory;
import com.metys.merlin.generation.mappingmodel.mapping.MappingIdentifier;
import com.metys.merlin.generation.mappingmodel.mapping.MappingKind;
import com.metys.merlin.generation.mappingmodel.mapping.MappingPackage;
import com.metys.merlin.generation.mappingmodel.mapping.MappingReport;
import com.metys.merlin.generation.mappingmodel.mapping.ReconcilingDiffTree;
import com.metys.merlin.generation.mappingmodel.mapping.ReferenceChangeHandler;
import com.metys.merlin.generation.mappingmodel.mapping.SeverityKind;
import com.metys.merlin.generation.mappingmodel.mapping.TypeMapping;
import com.metys.merlin.generation.mappingmodel.mapping.TypeMappingRoot;

import com.metys.merlin.generation.mappingmodel.rules.RulesPackage;

import com.metys.merlin.generation.mappingmodel.rules.impl.RulesPackageImpl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EcorePackage;

import org.eclipse.emf.ecore.change.ChangePackage;

import org.eclipse.emf.ecore.change.impl.ChangePackageImpl;

import org.eclipse.emf.ecore.impl.EPackageImpl;
import org.eclipse.emf.ecore.impl.EcorePackageImpl;

import org.eclipse.emf.mapping.ecore2ecore.Ecore2EcorePackage;

import org.eclipse.emf.mapping.ecore2ecore.impl.Ecore2EcorePackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class MappingPackageImpl extends EPackageImpl implements MappingPackage {
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass typeMappingRootEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass typeMappingEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass transformerEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass mappingIdentifierEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass mappedInstancesFactoryEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass mappedInstanceHandlerEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass attributeChangeHandlerEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass referenceChangeHandlerEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass mappingReportEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass eObjectDiffNodeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EClass reconcilingDiffTreeEClass = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum severityKindEEnum = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private EEnum mappingKindEEnum = null;

  /**
   * Creates an instance of the model <b>Package</b>, registered with
   * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
   * package URI value.
   * <p>Note: the correct way to create the package is via the static
   * factory method {@link #init init()}, which also performs
   * initialization of the package, or returns the registered package,
   * if one already exists.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.eclipse.emf.ecore.EPackage.Registry
   * @see com.metys.merlin.generation.mappingmodel.mapping.MappingPackage#eNS_URI
   * @see #init()
   * @generated
   */
  private MappingPackageImpl() {
    super(eNS_URI, MappingFactory.eINSTANCE);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static boolean isInited = false;

  /**
   * Creates, registers, and initializes the <b>Package</b> for this
   * model, and for any others upon which it depends.  Simple
   * dependencies are satisfied by calling this method on all
   * dependent packages before doing anything else.  This method drives
   * initialization for interdependent packages directly, in parallel
   * with this package, itself.
   * <p>Of this package and its interdependencies, all packages which
   * have not yet been registered by their URI values are first created
   * and registered.  The packages are then initialized in two steps:
   * meta-model objects for all of the packages are created before any
   * are initialized, since one package's meta-model objects may refer to
   * those of another.
   * <p>Invocation of this method will not affect any packages that have
   * already been initialized.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #eNS_URI
   * @see #createPackageContents()
   * @see #initializePackageContents()
   * @generated
   */
  public static MappingPackage init() {
    if (isInited)
      return (MappingPackage) EPackage.Registry.INSTANCE.getEPackage(MappingPackage.eNS_URI);

    // Obtain or create and register package
    MappingPackageImpl theMappingPackage = (MappingPackageImpl) (EPackage.Registry.INSTANCE.getEPackage(eNS_URI) instanceof MappingPackageImpl ? EPackage.Registry.INSTANCE
        .getEPackage(eNS_URI)
        : new MappingPackageImpl());

    isInited = true;

    // Initialize simple dependencies
    EcorePackageImpl.init();
    Ecore2EcorePackageImpl.init();
    org.eclipse.emf.mapping.impl.MappingPackageImpl.init();
    ChangePackageImpl.init();

    // Obtain or create and register interdependencies
    MappingModelPackageImpl theMappingModelPackage = (MappingModelPackageImpl) (EPackage.Registry.INSTANCE
        .getEPackage(MappingModelPackage.eNS_URI) instanceof MappingModelPackageImpl ? EPackage.Registry.INSTANCE
        .getEPackage(MappingModelPackage.eNS_URI) : MappingModelPackage.eINSTANCE);
    RulesPackageImpl theRulesPackage = (RulesPackageImpl) (EPackage.Registry.INSTANCE.getEPackage(RulesPackage.eNS_URI) instanceof RulesPackageImpl ? EPackage.Registry.INSTANCE
        .getEPackage(RulesPackage.eNS_URI)
        : RulesPackage.eINSTANCE);

    // Create package meta-data objects
    theMappingPackage.createPackageContents();
    theMappingModelPackage.createPackageContents();
    theRulesPackage.createPackageContents();

    // Initialize created meta-data
    theMappingPackage.initializePackageContents();
    theMappingModelPackage.initializePackageContents();
    theRulesPackage.initializePackageContents();

    // Mark meta-data to indicate it can't be changed
    theMappingPackage.freeze();

    return theMappingPackage;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getTypeMappingRoot() {
    return typeMappingRootEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getTypeMapping() {
    return typeMappingEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getTypeMapping_Name() {
    return (EAttribute) typeMappingEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTypeMapping_MappingRules() {
    return (EReference) typeMappingEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTypeMapping_MappingRuleConditions() {
    return (EReference) typeMappingEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTypeMapping_MappingRuleActions() {
    return (EReference) typeMappingEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getTypeMapping_Constraints() {
    return (EAttribute) typeMappingEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getTransformer() {
    return transformerEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTransformer_TypeMappingRoot() {
    return (EReference) transformerEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTransformer_MappingReports() {
    return (EReference) transformerEClass.getEStructuralFeatures().get(4);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTransformer_MappedInstancesFactory() {
    return (EReference) transformerEClass.getEStructuralFeatures().get(6);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTransformer_ReferenceChangeHandler() {
    return (EReference) transformerEClass.getEStructuralFeatures().get(7);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTransformer_AttributeChangeHandler() {
    return (EReference) transformerEClass.getEStructuralFeatures().get(8);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTransformer_MappedInstanceHandler() {
    return (EReference) transformerEClass.getEStructuralFeatures().get(9);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTransformer_MappingRoot() {
    return (EReference) transformerEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getTransformer_ChangeDescription() {
    return (EReference) transformerEClass.getEStructuralFeatures().get(5);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getTransformer_TargetContext() {
    return (EAttribute) transformerEClass.getEStructuralFeatures().get(2);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getTransformer_SourceContext() {
    return (EAttribute) transformerEClass.getEStructuralFeatures().get(3);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getMappingIdentifier() {
    return mappingIdentifierEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMappingIdentifier_Id() {
    return (EAttribute) mappingIdentifierEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMappingIdentifier_MappingKind() {
    return (EAttribute) mappingIdentifierEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getMappedInstancesFactory() {
    return mappedInstancesFactoryEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getMappedInstancesFactory_Transformer() {
    return (EReference) mappedInstancesFactoryEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getMappedInstanceHandler() {
    return mappedInstanceHandlerEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getMappedInstanceHandler_Transformer() {
    return (EReference) mappedInstanceHandlerEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getAttributeChangeHandler() {
    return attributeChangeHandlerEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getAttributeChangeHandler_Transformer() {
    return (EReference) attributeChangeHandlerEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getReferenceChangeHandler() {
    return referenceChangeHandlerEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getReferenceChangeHandler_Transformer() {
    return (EReference) referenceChangeHandlerEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getMappingReport() {
    return mappingReportEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMappingReport_Severity() {
    return (EAttribute) mappingReportEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EAttribute getMappingReport_Message() {
    return (EAttribute) mappingReportEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getEObjectDiffNode() {
    return eObjectDiffNodeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEObjectDiffNode_SubDiffNodes() {
    return (EReference) eObjectDiffNodeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getEObjectDiffNode_ChangeDescription() {
    return (EReference) eObjectDiffNodeEClass.getEStructuralFeatures().get(1);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EClass getReconcilingDiffTree() {
    return reconcilingDiffTreeEClass;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EReference getReconcilingDiffTree_Roots() {
    return (EReference) reconcilingDiffTreeEClass.getEStructuralFeatures().get(0);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getSeverityKind() {
    return severityKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EEnum getMappingKind() {
    return mappingKindEEnum;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MappingFactory getMappingFactory() {
    return (MappingFactory) getEFactoryInstance();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private boolean isCreated = false;

  /**
   * Creates the meta-model objects for the package.  This method is
   * guarded to have no affect on any invocation but its first.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void createPackageContents() {
    if (isCreated)
      return;
    isCreated = true;

    // Create classes and their features
    typeMappingRootEClass = createEClass(TYPE_MAPPING_ROOT);

    typeMappingEClass = createEClass(TYPE_MAPPING);
    createEAttribute(typeMappingEClass, TYPE_MAPPING__NAME);
    createEReference(typeMappingEClass, TYPE_MAPPING__MAPPING_RULES);
    createEReference(typeMappingEClass, TYPE_MAPPING__MAPPING_RULE_CONDITIONS);
    createEReference(typeMappingEClass, TYPE_MAPPING__MAPPING_RULE_ACTIONS);
    createEAttribute(typeMappingEClass, TYPE_MAPPING__CONSTRAINTS);

    transformerEClass = createEClass(TRANSFORMER);
    createEReference(transformerEClass, TRANSFORMER__TYPE_MAPPING_ROOT);
    createEReference(transformerEClass, TRANSFORMER__MAPPING_ROOT);
    createEAttribute(transformerEClass, TRANSFORMER__TARGET_CONTEXT);
    createEAttribute(transformerEClass, TRANSFORMER__SOURCE_CONTEXT);
    createEReference(transformerEClass, TRANSFORMER__MAPPING_REPORTS);
    createEReference(transformerEClass, TRANSFORMER__CHANGE_DESCRIPTION);
    createEReference(transformerEClass, TRANSFORMER__MAPPED_INSTANCES_FACTORY);
    createEReference(transformerEClass, TRANSFORMER__REFERENCE_CHANGE_HANDLER);
    createEReference(transformerEClass, TRANSFORMER__ATTRIBUTE_CHANGE_HANDLER);
    createEReference(transformerEClass, TRANSFORMER__MAPPED_INSTANCE_HANDLER);

    mappingIdentifierEClass = createEClass(MAPPING_IDENTIFIER);
    createEAttribute(mappingIdentifierEClass, MAPPING_IDENTIFIER__ID);
    createEAttribute(mappingIdentifierEClass, MAPPING_IDENTIFIER__MAPPING_KIND);

    mappedInstancesFactoryEClass = createEClass(MAPPED_INSTANCES_FACTORY);
    createEReference(mappedInstancesFactoryEClass, MAPPED_INSTANCES_FACTORY__TRANSFORMER);

    mappedInstanceHandlerEClass = createEClass(MAPPED_INSTANCE_HANDLER);
    createEReference(mappedInstanceHandlerEClass, MAPPED_INSTANCE_HANDLER__TRANSFORMER);

    attributeChangeHandlerEClass = createEClass(ATTRIBUTE_CHANGE_HANDLER);
    createEReference(attributeChangeHandlerEClass, ATTRIBUTE_CHANGE_HANDLER__TRANSFORMER);

    referenceChangeHandlerEClass = createEClass(REFERENCE_CHANGE_HANDLER);
    createEReference(referenceChangeHandlerEClass, REFERENCE_CHANGE_HANDLER__TRANSFORMER);

    mappingReportEClass = createEClass(MAPPING_REPORT);
    createEAttribute(mappingReportEClass, MAPPING_REPORT__SEVERITY);
    createEAttribute(mappingReportEClass, MAPPING_REPORT__MESSAGE);

    eObjectDiffNodeEClass = createEClass(EOBJECT_DIFF_NODE);
    createEReference(eObjectDiffNodeEClass, EOBJECT_DIFF_NODE__SUB_DIFF_NODES);
    createEReference(eObjectDiffNodeEClass, EOBJECT_DIFF_NODE__CHANGE_DESCRIPTION);

    reconcilingDiffTreeEClass = createEClass(RECONCILING_DIFF_TREE);
    createEReference(reconcilingDiffTreeEClass, RECONCILING_DIFF_TREE__ROOTS);

    // Create enums
    severityKindEEnum = createEEnum(SEVERITY_KIND);
    mappingKindEEnum = createEEnum(MAPPING_KIND);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private boolean isInitialized = false;

  /**
   * Complete the initialization of the package and its meta-model.  This
   * method is guarded to have no affect on any invocation but its first.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void initializePackageContents() {
    if (isInitialized)
      return;
    isInitialized = true;

    // Initialize package
    setName(eNAME);
    setNsPrefix(eNS_PREFIX);
    setNsURI(eNS_URI);

    // Obtain other dependent packages
    Ecore2EcorePackageImpl theEcore2EcorePackage = (Ecore2EcorePackageImpl) EPackage.Registry.INSTANCE
        .getEPackage(Ecore2EcorePackage.eNS_URI);
    org.eclipse.emf.mapping.impl.MappingPackageImpl theMappingPackage_1 = (org.eclipse.emf.mapping.impl.MappingPackageImpl) EPackage.Registry.INSTANCE
        .getEPackage(org.eclipse.emf.mapping.MappingPackage.eNS_URI);
    EcorePackageImpl theEcorePackage = (EcorePackageImpl) EPackage.Registry.INSTANCE.getEPackage(EcorePackage.eNS_URI);
    RulesPackageImpl theRulesPackage = (RulesPackageImpl) EPackage.Registry.INSTANCE.getEPackage(RulesPackage.eNS_URI);
    MappingModelPackageImpl theMappingModelPackage = (MappingModelPackageImpl) EPackage.Registry.INSTANCE
        .getEPackage(MappingModelPackage.eNS_URI);
    ChangePackageImpl theChangePackage = (ChangePackageImpl) EPackage.Registry.INSTANCE
        .getEPackage(ChangePackage.eNS_URI);

    // Add supertypes to classes
    typeMappingRootEClass.getESuperTypes().add(theEcore2EcorePackage.getEcore2EcoreMappingRoot());
    typeMappingEClass.getESuperTypes().add(theMappingPackage_1.getMapping());
    mappingIdentifierEClass.getESuperTypes().add(theMappingPackage_1.getMappingHelper());

    // Initialize classes and features; add operations and parameters
    initEClass(typeMappingRootEClass, TypeMappingRoot.class, "TypeMappingRoot", !IS_ABSTRACT, !IS_INTERFACE,
        IS_GENERATED_INSTANCE_CLASS);

    initEClass(typeMappingEClass, TypeMapping.class, "TypeMapping", !IS_ABSTRACT, !IS_INTERFACE,
        IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getTypeMapping_Name(), theEcorePackage.getEString(), "name", null, 0, 1, TypeMapping.class,
        !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getTypeMapping_MappingRules(), theRulesPackage.getMappingRule(), null, "mappingRules", null, 0, -1,
        TypeMapping.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
        !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getTypeMapping_MappingRuleConditions(), theRulesPackage.getMappingRuleCondition(), null,
        "mappingRuleConditions", null, 0, -1, TypeMapping.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
        IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getTypeMapping_MappingRuleActions(), theRulesPackage.getMappingRuleAction(), null,
        "mappingRuleActions", null, 0, -1, TypeMapping.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
        !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getTypeMapping_Constraints(), theRulesPackage.getEvaluationMode(), "constraints", null, 0, 1,
        TypeMapping.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED,
        IS_ORDERED);

    initEClass(transformerEClass, Transformer.class, "Transformer", !IS_ABSTRACT, !IS_INTERFACE,
        IS_GENERATED_INSTANCE_CLASS);
    initEReference(getTransformer_TypeMappingRoot(), theEcore2EcorePackage.getEcore2EcoreMappingRoot(), null,
        "typeMappingRoot", null, 1, 1, Transformer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
        IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getTransformer_MappingRoot(), theMappingPackage_1.getMappingRoot(), null, "mappingRoot", null, 1, 1,
        Transformer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
        !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getTransformer_TargetContext(), theMappingModelPackage.getResource(), "targetContext", null, 0, -1,
        Transformer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED,
        IS_ORDERED);
    initEAttribute(getTransformer_SourceContext(), theMappingModelPackage.getResource(), "sourceContext", null, 0, -1,
        Transformer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED,
        IS_ORDERED);
    initEReference(getTransformer_MappingReports(), this.getMappingReport(), null, "mappingReports", null, 0, -1,
        Transformer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
        !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getTransformer_ChangeDescription(), theChangePackage.getChangeDescription(), null,
        "changeDescription", null, 0, 1, Transformer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
        IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getTransformer_MappedInstancesFactory(), this.getMappedInstancesFactory(), this
        .getMappedInstancesFactory_Transformer(), "mappedInstancesFactory", null, 0, 1, Transformer.class,
        !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE,
        !IS_DERIVED, IS_ORDERED);
    initEReference(getTransformer_ReferenceChangeHandler(), this.getReferenceChangeHandler(), this
        .getReferenceChangeHandler_Transformer(), "referenceChangeHandler", null, 0, 1, Transformer.class,
        !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE,
        !IS_DERIVED, IS_ORDERED);
    initEReference(getTransformer_AttributeChangeHandler(), this.getAttributeChangeHandler(), this
        .getAttributeChangeHandler_Transformer(), "attributeChangeHandler", null, 0, 1, Transformer.class,
        !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE,
        !IS_DERIVED, IS_ORDERED);
    initEReference(getTransformer_MappedInstanceHandler(), this.getMappedInstanceHandler(), this
        .getMappedInstanceHandler_Transformer(), "mappedInstanceHandler", null, 0, 1, Transformer.class, !IS_TRANSIENT,
        !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
        IS_ORDERED);

    EOperation op = addEOperation(transformerEClass, theMappingModelPackage.getCollection(), "transform");
    addEParameter(op, theMappingModelPackage.getCollection(), "sources");
    addEParameter(op, theMappingModelPackage.getCollection(), "targets");
    addEParameter(op, theMappingModelPackage.getProgressMonitor(), "progress");

    op = addEOperation(transformerEClass, theMappingModelPackage.getCollection(), "transform");
    addEParameter(op, theMappingModelPackage.getResource(), "source");
    addEParameter(op, theMappingModelPackage.getResource(), "target");
    addEParameter(op, theMappingModelPackage.getProgressMonitor(), "progress");

    op = addEOperation(transformerEClass, theMappingModelPackage.getCollection(), "transform");
    addEParameter(op, theMappingPackage_1.getMappingRoot(), "inputMappingRoot");
    addEParameter(op, theMappingModelPackage.getProgressMonitor(), "progress");

    op = addEOperation(transformerEClass, null, "process");
    addEParameter(op, theEcorePackage.getEObject(), "source");

    op = addEOperation(transformerEClass, ecorePackage.getEBoolean(), "isProcessed");
    addEParameter(op, theEcorePackage.getEObject(), "eObject");

    op = addEOperation(transformerEClass, theEcorePackage.getEObject(), "getFirstMappedInstance");
    addEParameter(op, theEcorePackage.getEObject(), "sourceObject");
    addEParameter(op, theEcorePackage.getEBoolean(), "create");

    op = addEOperation(transformerEClass, theEcorePackage.getEObject(), "getFirstMappedInstance");
    addEParameter(op, theEcorePackage.getEObject(), "sourceObject");
    addEParameter(op, theEcorePackage.getEJavaClass(), "mappedJavaClass");
    addEParameter(op, theEcorePackage.getEBoolean(), "create");

    op = addEOperation(transformerEClass, theMappingModelPackage.getCollection(), "getMappedInstances");
    addEParameter(op, theEcorePackage.getEObject(), "sourceObject");
    addEParameter(op, theEcorePackage.getEBoolean(), "create");

    op = addEOperation(transformerEClass, theMappingModelPackage.getCollection(), "getMappedInstances");
    addEParameter(op, theEcorePackage.getEObject(), "sourceObject");
    addEParameter(op, theEcorePackage.getEJavaClass(), "mappedJavaClass");
    addEParameter(op, theEcorePackage.getEBoolean(), "create");

    initEClass(mappingIdentifierEClass, MappingIdentifier.class, "MappingIdentifier", !IS_ABSTRACT, !IS_INTERFACE,
        IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getMappingIdentifier_Id(), ecorePackage.getEString(), "id", null, 1, 1, MappingIdentifier.class,
        !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMappingIdentifier_MappingKind(), this.getMappingKind(), "mappingKind", null, 0, 1,
        MappingIdentifier.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
        !IS_DERIVED, IS_ORDERED);

    initEClass(mappedInstancesFactoryEClass, MappedInstancesFactory.class, "MappedInstancesFactory", !IS_ABSTRACT,
        !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getMappedInstancesFactory_Transformer(), this.getTransformer(), this
        .getTransformer_MappedInstancesFactory(), "transformer", null, 0, 1, MappedInstancesFactory.class,
        !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE,
        !IS_DERIVED, IS_ORDERED);

    op = addEOperation(mappedInstancesFactoryEClass, theMappingModelPackage.getCollection(), "createMappedInstances");
    addEParameter(op, theMappingPackage_1.getMapping(), "typeMapping");
    addEParameter(op, theEcorePackage.getEObject(), "sourceObject");
    addEParameter(op, theMappingPackage_1.getMappingRoot(), "mappingRoot");

    initEClass(mappedInstanceHandlerEClass, MappedInstanceHandler.class, "MappedInstanceHandler", !IS_ABSTRACT,
        !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getMappedInstanceHandler_Transformer(), this.getTransformer(), this
        .getTransformer_MappedInstanceHandler(), "transformer", null, 0, 1, MappedInstanceHandler.class, !IS_TRANSIENT,
        !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
        IS_ORDERED);

    op = addEOperation(mappedInstanceHandlerEClass, null, "handleMappedInstance");
    addEParameter(op, theEcorePackage.getEObject(), "sourceObject");
    addEParameter(op, theEcorePackage.getEObject(), "targetObject");
    addEParameter(op, theMappingPackage_1.getMappingRoot(), "mappingRoot");

    initEClass(attributeChangeHandlerEClass, AttributeChangeHandler.class, "AttributeChangeHandler", !IS_ABSTRACT,
        !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getAttributeChangeHandler_Transformer(), this.getTransformer(), this
        .getTransformer_AttributeChangeHandler(), "transformer", null, 0, 1, AttributeChangeHandler.class,
        !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE,
        !IS_DERIVED, IS_ORDERED);

    op = addEOperation(attributeChangeHandlerEClass, null, "handleAttributes");
    addEParameter(op, theEcorePackage.getEObject(), "sourceObject");
    addEParameter(op, theEcorePackage.getEObject(), "targetObject");
    addEParameter(op, theMappingPackage_1.getMappingRoot(), "mappingRoot");
    addEParameter(op, ecorePackage.getEStructuralFeature(), "sourceFeature");

    initEClass(referenceChangeHandlerEClass, ReferenceChangeHandler.class, "ReferenceChangeHandler", !IS_ABSTRACT,
        !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getReferenceChangeHandler_Transformer(), this.getTransformer(), this
        .getTransformer_ReferenceChangeHandler(), "transformer", null, 0, 1, ReferenceChangeHandler.class,
        !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE,
        !IS_DERIVED, IS_ORDERED);

    op = addEOperation(referenceChangeHandlerEClass, null, "handleReferences");
    addEParameter(op, theEcorePackage.getEObject(), "sourceObject");
    addEParameter(op, theEcorePackage.getEObject(), "targetObject");
    addEParameter(op, theMappingPackage_1.getMappingRoot(), "mappingRoot");
    addEParameter(op, ecorePackage.getEStructuralFeature(), "sourceFeature");

    initEClass(mappingReportEClass, MappingReport.class, "MappingReport", !IS_ABSTRACT, !IS_INTERFACE,
        IS_GENERATED_INSTANCE_CLASS);
    initEAttribute(getMappingReport_Severity(), this.getSeverityKind(), "severity", null, 0, 1, MappingReport.class,
        !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEAttribute(getMappingReport_Message(), ecorePackage.getEString(), "message", null, 0, 1, MappingReport.class,
        !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(eObjectDiffNodeEClass, EObjectDiffNode.class, "EObjectDiffNode", !IS_ABSTRACT, !IS_INTERFACE,
        IS_GENERATED_INSTANCE_CLASS);
    initEReference(getEObjectDiffNode_SubDiffNodes(), this.getEObjectDiffNode(), null, "subDiffNodes", null, 0, -1,
        EObjectDiffNode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
        !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
    initEReference(getEObjectDiffNode_ChangeDescription(), theChangePackage.getChangeDescription(), null,
        "changeDescription", null, 0, 1, EObjectDiffNode.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
        !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    initEClass(reconcilingDiffTreeEClass, ReconcilingDiffTree.class, "ReconcilingDiffTree", !IS_ABSTRACT,
        !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
    initEReference(getReconcilingDiffTree_Roots(), this.getEObjectDiffNode(), null, "roots", null, 0, -1,
        ReconcilingDiffTree.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
        !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

    // Initialize enums and add enum literals
    initEEnum(severityKindEEnum, SeverityKind.class, "SeverityKind");
    addEEnumLiteral(severityKindEEnum, SeverityKind.INFO_LITERAL);
    addEEnumLiteral(severityKindEEnum, SeverityKind.WARNING_LITERAL);
    addEEnumLiteral(severityKindEEnum, SeverityKind.ERROR_LITERAL);

    initEEnum(mappingKindEEnum, MappingKind.class, "MappingKind");
    addEEnumLiteral(mappingKindEEnum, MappingKind.OPERATIONAL_LITERAL);
    addEEnumLiteral(mappingKindEEnum, MappingKind.RELATION_LITERAL);
  }

} //MappingPackageImpl
