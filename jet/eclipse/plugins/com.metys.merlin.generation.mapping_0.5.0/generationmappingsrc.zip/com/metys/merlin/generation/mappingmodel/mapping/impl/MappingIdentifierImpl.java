/**
 * <copyright>
 * </copyright>
 *
 * $Id: MappingIdentifierImpl.java,v 1.1 2005/07/07 21:33:31 jcheuoua Exp $
 */
package com.metys.merlin.generation.mappingmodel.mapping.impl;

import com.metys.merlin.generation.mappingmodel.mapping.MappingIdentifier;
import com.metys.merlin.generation.mappingmodel.mapping.MappingKind;
import com.metys.merlin.generation.mappingmodel.mapping.MappingPackage;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.InternalEList;

import org.eclipse.emf.mapping.Mapping;
import org.eclipse.emf.mapping.MappingHelper;

import org.eclipse.emf.mapping.impl.MappingHelperImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Identifier</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.MappingIdentifierImpl#getId <em>Id</em>}</li>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.MappingIdentifierImpl#getMappingKind <em>Mapping Kind</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class MappingIdentifierImpl extends MappingHelperImpl implements MappingIdentifier {
  /**
   * The default value of the '{@link #getId() <em>Id</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getId()
   * @generated
   * @ordered
   */
  protected static final String ID_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getId() <em>Id</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getId()
   * @generated
   * @ordered
   */
  protected String id = ID_EDEFAULT;

  /**
   * The default value of the '{@link #getMappingKind() <em>Mapping Kind</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMappingKind()
   * @generated
   * @ordered
   */
  protected static final MappingKind MAPPING_KIND_EDEFAULT = MappingKind.OPERATIONAL_LITERAL;

  /**
   * The cached value of the '{@link #getMappingKind() <em>Mapping Kind</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMappingKind()
   * @generated
   * @ordered
   */
  protected MappingKind mappingKind = MAPPING_KIND_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected MappingIdentifierImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return MappingPackage.eINSTANCE.getMappingIdentifier();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getId() {
    return id;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setId(String newId) {
    String oldId = id;
    id = newId;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, MappingPackage.MAPPING_IDENTIFIER__ID, oldId, id));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MappingKind getMappingKind() {
    return mappingKind;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setMappingKind(MappingKind newMappingKind) {
    MappingKind oldMappingKind = mappingKind;
    mappingKind = newMappingKind == null ? MAPPING_KIND_EDEFAULT : newMappingKind;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, MappingPackage.MAPPING_IDENTIFIER__MAPPING_KIND,
          oldMappingKind, mappingKind));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
      case MappingPackage.MAPPING_IDENTIFIER__MAPPER:
        if (eContainer != null)
          msgs = eBasicRemoveFromContainer(msgs);
        return eBasicSetContainer(otherEnd, MappingPackage.MAPPING_IDENTIFIER__MAPPER, msgs);
      case MappingPackage.MAPPING_IDENTIFIER__NESTED_IN:
        if (eContainer != null)
          msgs = eBasicRemoveFromContainer(msgs);
        return eBasicSetContainer(otherEnd, MappingPackage.MAPPING_IDENTIFIER__NESTED_IN, msgs);
      case MappingPackage.MAPPING_IDENTIFIER__NESTED:
        return ((InternalEList) getNested()).basicAdd(otherEnd, msgs);
      default:
        return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass,
      NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
      case MappingPackage.MAPPING_IDENTIFIER__MAPPER:
        return eBasicSetContainer(null, MappingPackage.MAPPING_IDENTIFIER__MAPPER, msgs);
      case MappingPackage.MAPPING_IDENTIFIER__NESTED_IN:
        return eBasicSetContainer(null, MappingPackage.MAPPING_IDENTIFIER__NESTED_IN, msgs);
      case MappingPackage.MAPPING_IDENTIFIER__NESTED:
        return ((InternalEList) getNested()).basicRemove(otherEnd, msgs);
      default:
        return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
    if (eContainerFeatureID >= 0) {
      switch (eContainerFeatureID) {
      case MappingPackage.MAPPING_IDENTIFIER__MAPPER:
        return eContainer.eInverseRemove(this, org.eclipse.emf.mapping.MappingPackage.MAPPING__HELPER, Mapping.class,
            msgs);
      case MappingPackage.MAPPING_IDENTIFIER__NESTED_IN:
        return eContainer.eInverseRemove(this, org.eclipse.emf.mapping.MappingPackage.MAPPING_HELPER__NESTED,
            MappingHelper.class, msgs);
      default:
        return eDynamicBasicRemoveFromContainer(msgs);
      }
    }
    return eContainer.eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.MAPPING_IDENTIFIER__MAPPER:
      return getMapper();
    case MappingPackage.MAPPING_IDENTIFIER__HELPED_OBJECT:
      if (resolve)
        return getHelpedObject();
      return basicGetHelpedObject();
    case MappingPackage.MAPPING_IDENTIFIER__NESTED_IN:
      return getNestedIn();
    case MappingPackage.MAPPING_IDENTIFIER__NESTED:
      return getNested();
    case MappingPackage.MAPPING_IDENTIFIER__ID:
      return getId();
    case MappingPackage.MAPPING_IDENTIFIER__MAPPING_KIND:
      return getMappingKind();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.MAPPING_IDENTIFIER__MAPPER:
      setMapper((Mapping) newValue);
      return;
    case MappingPackage.MAPPING_IDENTIFIER__HELPED_OBJECT:
      setHelpedObject((EObject) newValue);
      return;
    case MappingPackage.MAPPING_IDENTIFIER__NESTED_IN:
      setNestedIn((MappingHelper) newValue);
      return;
    case MappingPackage.MAPPING_IDENTIFIER__NESTED:
      getNested().clear();
      getNested().addAll((Collection) newValue);
      return;
    case MappingPackage.MAPPING_IDENTIFIER__ID:
      setId((String) newValue);
      return;
    case MappingPackage.MAPPING_IDENTIFIER__MAPPING_KIND:
      setMappingKind((MappingKind) newValue);
      return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.MAPPING_IDENTIFIER__MAPPER:
      setMapper((Mapping) null);
      return;
    case MappingPackage.MAPPING_IDENTIFIER__HELPED_OBJECT:
      setHelpedObject((EObject) null);
      return;
    case MappingPackage.MAPPING_IDENTIFIER__NESTED_IN:
      setNestedIn((MappingHelper) null);
      return;
    case MappingPackage.MAPPING_IDENTIFIER__NESTED:
      getNested().clear();
      return;
    case MappingPackage.MAPPING_IDENTIFIER__ID:
      setId(ID_EDEFAULT);
      return;
    case MappingPackage.MAPPING_IDENTIFIER__MAPPING_KIND:
      setMappingKind(MAPPING_KIND_EDEFAULT);
      return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.MAPPING_IDENTIFIER__MAPPER:
      return getMapper() != null;
    case MappingPackage.MAPPING_IDENTIFIER__HELPED_OBJECT:
      return helpedObject != null;
    case MappingPackage.MAPPING_IDENTIFIER__NESTED_IN:
      return getNestedIn() != null;
    case MappingPackage.MAPPING_IDENTIFIER__NESTED:
      return nested != null && !nested.isEmpty();
    case MappingPackage.MAPPING_IDENTIFIER__ID:
      return ID_EDEFAULT == null ? id != null : !ID_EDEFAULT.equals(id);
    case MappingPackage.MAPPING_IDENTIFIER__MAPPING_KIND:
      return mappingKind != MAPPING_KIND_EDEFAULT;
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString() {
    if (eIsProxy())
      return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (id: ");
    result.append(id);
    result.append(", mappingKind: ");
    result.append(mappingKind);
    result.append(')');
    return result.toString();
  }

} //MappingIdentifierImpl
