/**
 * <copyright>
 * </copyright>
 *
 * $Id: MappedInstanceHandlerImpl.java,v 1.1 2005/07/07 21:33:31 jcheuoua Exp $
 */
package com.metys.merlin.generation.mappingmodel.mapping.impl;

import java.util.Iterator;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.mapping.MappingRoot;

import com.metys.merlin.generation.mappingmodel.mapping.MappedInstanceHandler;
import com.metys.merlin.generation.mappingmodel.mapping.Transformer;
import com.metys.merlin.generation.mappingmodel.mapping.MappingPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Mapped Instance Handler</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link com.metys.merlin.generation.mappingmodel.mapping.impl.MappedInstanceHandlerImpl#getTransformer <em>Transformer</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class MappedInstanceHandlerImpl extends EObjectImpl implements MappedInstanceHandler {
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected MappedInstanceHandlerImpl() {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass() {
    return MappingPackage.eINSTANCE.getMappedInstanceHandler();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Transformer getTransformer() {
    if (eContainerFeatureID != MappingPackage.MAPPED_INSTANCE_HANDLER__TRANSFORMER)
      return null;
    return (Transformer) eContainer;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTransformer(Transformer newTransformer) {
    if (newTransformer != eContainer
        || (eContainerFeatureID != MappingPackage.MAPPED_INSTANCE_HANDLER__TRANSFORMER && newTransformer != null)) {
      if (EcoreUtil.isAncestor(this, newTransformer))
        throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
      NotificationChain msgs = null;
      if (eContainer != null)
        msgs = eBasicRemoveFromContainer(msgs);
      if (newTransformer != null)
        msgs = ((InternalEObject) newTransformer).eInverseAdd(this,
            MappingPackage.TRANSFORMER__MAPPED_INSTANCE_HANDLER, Transformer.class, msgs);
      msgs = eBasicSetContainer((InternalEObject) newTransformer, MappingPackage.MAPPED_INSTANCE_HANDLER__TRANSFORMER,
          msgs);
      if (msgs != null)
        msgs.dispatch();
    } else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, MappingPackage.MAPPED_INSTANCE_HANDLER__TRANSFORMER,
          newTransformer, newTransformer));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public void handleMappedInstance(EObject sourceObject, EObject targetObject, MappingRoot mappingRoot) {
    EClass sourceClass = sourceObject.eClass();
    // Iterate through all the source object's class features to find which of them have model mappings
    // Then trigger the mapping rules
    for (Iterator features = sourceClass.getEAllStructuralFeatures().iterator(); features.hasNext();) {
      EStructuralFeature sourceFeature = (EStructuralFeature) features.next();
      // Proceed on feature mappings
      if (sourceFeature instanceof EAttribute) {
        getTransformer().getAttributeChangeHandler()
            .handleAttributes(sourceObject, targetObject, mappingRoot, sourceFeature);
      } else if (sourceFeature instanceof EReference) {
        getTransformer().getReferenceChangeHandler()
            .handleReferences(sourceObject, targetObject, mappingRoot, sourceFeature);
      }
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
      case MappingPackage.MAPPED_INSTANCE_HANDLER__TRANSFORMER:
        if (eContainer != null)
          msgs = eBasicRemoveFromContainer(msgs);
        return eBasicSetContainer(otherEnd, MappingPackage.MAPPED_INSTANCE_HANDLER__TRANSFORMER, msgs);
      default:
        return eDynamicInverseAdd(otherEnd, featureID, baseClass, msgs);
      }
    }
    if (eContainer != null)
      msgs = eBasicRemoveFromContainer(msgs);
    return eBasicSetContainer(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass,
      NotificationChain msgs) {
    if (featureID >= 0) {
      switch (eDerivedStructuralFeatureID(featureID, baseClass)) {
      case MappingPackage.MAPPED_INSTANCE_HANDLER__TRANSFORMER:
        return eBasicSetContainer(null, MappingPackage.MAPPED_INSTANCE_HANDLER__TRANSFORMER, msgs);
      default:
        return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eBasicRemoveFromContainer(NotificationChain msgs) {
    if (eContainerFeatureID >= 0) {
      switch (eContainerFeatureID) {
      case MappingPackage.MAPPED_INSTANCE_HANDLER__TRANSFORMER:
        return eContainer.eInverseRemove(this, MappingPackage.TRANSFORMER__MAPPED_INSTANCE_HANDLER, Transformer.class,
            msgs);
      default:
        return eDynamicBasicRemoveFromContainer(msgs);
      }
    }
    return eContainer.eInverseRemove(this, EOPPOSITE_FEATURE_BASE - eContainerFeatureID, null, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.MAPPED_INSTANCE_HANDLER__TRANSFORMER:
      return getTransformer();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.MAPPED_INSTANCE_HANDLER__TRANSFORMER:
      setTransformer((Transformer) newValue);
      return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.MAPPED_INSTANCE_HANDLER__TRANSFORMER:
      setTransformer((Transformer) null);
      return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature) {
    switch (eDerivedStructuralFeatureID(eFeature)) {
    case MappingPackage.MAPPED_INSTANCE_HANDLER__TRANSFORMER:
      return getTransformer() != null;
    }
    return eDynamicIsSet(eFeature);
  }

} //MappedInstanceHandlerImpl
