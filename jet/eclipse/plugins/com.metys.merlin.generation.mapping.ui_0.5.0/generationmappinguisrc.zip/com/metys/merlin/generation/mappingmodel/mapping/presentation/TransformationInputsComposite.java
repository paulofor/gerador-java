package com.metys.merlin.generation.mappingmodel.mapping.presentation;

import java.util.Collection;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.provider.EcoreItemProviderAdapterFactory;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.edit.provider.ComposedAdapterFactory;
import org.eclipse.emf.edit.provider.ReflectiveItemProviderAdapterFactory;
import org.eclipse.emf.edit.provider.resource.ResourceItemProviderAdapterFactory;
import org.eclipse.emf.edit.ui.provider.AdapterFactoryContentProvider;
import org.eclipse.emf.edit.ui.provider.AdapterFactoryLabelProvider;
import org.eclipse.emf.mapping.Mapping;
import org.eclipse.emf.mapping.MappingRoot;
import org.eclipse.emf.mapping.provider.MappingItemProviderAdapterFactory;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;

import com.metys.merlin.generation.mappingmodel.MappingModelUIPlugin;
import com.metys.merlin.generation.mappingmodel.rules.MappingRule;
import com.metys.merlin.generation.mappingmodel.util.MappingModelUtil;
import org.eclipse.swt.layout.FillLayout;

public class TransformationInputsComposite extends Composite {
   
  private Composite sourceTreeComposite = null;
  private Composite typeMappingsTreeComposite = null;
  private Composite targetTreeComposite = null;
  
  private Tree sourceTree = null;
  private Tree typeMappingsTree = null;
  private Tree targetTree = null;
  
  private CLabel sourceObectsLabel = null;
  private CLabel typeMappingsLabel = null;
  private CLabel targetObjectsLabel = null;
  
  private TreeViewer sourceTreeViewer;
  private TreeViewer targetTreeViewer;
  private TreeViewer typeMappingsTreeViewer;
  
  private Resource sourceResource;
  private Resource targetResource;
  private Resource typeMappingsResource;
  
  private MappingRuleReadOnlyComposite mappingRuleComposite = null;
  private MappingRoot typeMappingRoot;
  
  private SashForm modelsSashForm = null;
  private SashForm modelsRightPartSashForm = null;
  private SashForm mappingsSashForm = null;
  
  public TransformationInputsComposite(Composite parent, int style) {
    super(parent, style);
    initialize();
  }

  private void initialize() {
    this.setLayout(new FillLayout());
    createModelsSashForm();
    setSize(new org.eclipse.swt.graphics.Point(522,428));
  }

  public void setSourceResource(Resource sourceResource) {
    this.sourceResource = sourceResource;
    sourceTreeViewer.setInput(sourceResource.getContents());
  }
  
  public void setTargetResource(Resource targetResource) {
    this.targetResource = targetResource;
    targetTreeViewer.setInput(targetResource.getContents());
  }
  
  public void setTypeMappingsResource(Resource typeMappingsResource) {
    this.typeMappingsResource = typeMappingsResource;
    if (!typeMappingsResource.getContents().isEmpty() &&
        typeMappingsResource.getContents().get(0) instanceof MappingRoot) {
      typeMappingRoot = (MappingRoot) typeMappingsResource.getContents().get(0);
      MappingModelUtil.initialize(typeMappingRoot);
      typeMappingsTreeViewer.setInput(typeMappingsResource.getContents());
    }
  }
  
  public Resource getSourceResource() {
    return sourceResource;     
  }
  
  public Resource getTargetResource() {
    return targetResource;     
  }
  
  public Resource getTypeMappingsResource() {
    return typeMappingsResource;
  }
  
  /**
   * This method initializes inputTreeComposite	
   *
   */    
  private void createInputTreeComposite() {
  	GridLayout gridLayout = new GridLayout();
  	gridLayout.horizontalSpacing = 2;
  	gridLayout.marginWidth = 2;
  	gridLayout.verticalSpacing = 2;
  	gridLayout.marginHeight = 2;
  	GridData gridData2 = new GridData();
  	gridData2.grabExcessHorizontalSpace = true;
  	gridData2.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	sourceTreeComposite = new Composite(modelsSashForm, SWT.BORDER);		   
  	sourceObectsLabel = new CLabel(sourceTreeComposite, SWT.CENTER);
  	sourceObectsLabel.setText("Sources");
  	createInputTree();
  	sourceTreeComposite.setLayout(gridLayout);
  	sourceObectsLabel.setLayoutData(gridData2);
  }

  /**
   * This method initializes mappingsTreeComposite	
   *
   */    
  private void createMappingsTreeComposite() {
  	GridLayout gridLayout1 = new GridLayout();
  	gridLayout1.horizontalSpacing = 2;
  	gridLayout1.marginWidth = 2;
  	gridLayout1.verticalSpacing = 2;
  	gridLayout1.marginHeight = 2;
  	GridData gridData9 = new GridData();
  	gridData9.grabExcessHorizontalSpace = true;
  	gridData9.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData9.grabExcessVerticalSpace = false;
  	typeMappingsTreeComposite = new Composite(mappingsSashForm, SWT.NONE);		   
  	typeMappingsLabel = new CLabel(typeMappingsTreeComposite, SWT.CENTER);
  	typeMappingsLabel.setText("Type Mappings");
  	createTypeMappingsTree();
  	typeMappingsTreeComposite.setLayout(gridLayout1);
  	typeMappingsLabel.setLayoutData(gridData9);
  }

  /**
   * This method initializes inputTree	
   *
   */    
  private void createInputTree() {
  	GridData gridData4 = new GridData();
  	gridData4.grabExcessHorizontalSpace = true;
  	gridData4.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData4.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData4.grabExcessVerticalSpace = true;
  	sourceTree = new Tree(sourceTreeComposite, SWT.NONE);		   
  	sourceTree.setLayoutData(gridData4);
    sourceTreeViewer = new TreeViewer(sourceTree);    
    AdapterFactory registeredFactories = new ComposedAdapterFactory(ComposedAdapterFactory.Descriptor.Registry.INSTANCE);
    AdapterFactory reflectiveFactory = new ReflectiveItemProviderAdapterFactory();
    AdapterFactory adapterFactory = new ComposedAdapterFactory(new AdapterFactory[]{
        registeredFactories,
        new ResourceItemProviderAdapterFactory(),
        new EcoreItemProviderAdapterFactory(),
        reflectiveFactory});
    sourceTreeViewer.setContentProvider(new AdapterFactoryContentProvider(adapterFactory){
      public Object [] getElements(Object object) {
        if (object instanceof Collection)
          return ((Collection)object).toArray();        
        return super.getElements(object);
      }
    });
    sourceTreeViewer.setLabelProvider(new AdapterFactoryLabelProvider(adapterFactory));
  }

  /**
   * This method initializes originalMappingsTree	
   *
   */    
  private void createTypeMappingsTree() {
    GridData gridData10 = new GridData();
    gridData10.grabExcessHorizontalSpace = true;
    gridData10.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
    gridData10.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
    gridData10.grabExcessVerticalSpace = true;
    typeMappingsTree = new Tree(typeMappingsTreeComposite, SWT.NONE);
    typeMappingsTree.setLayoutData(gridData10);
    typeMappingsTree.addSelectionListener(new SelectionAdapter() {
      public void widgetSelected(SelectionEvent e) {
        TreeItem[] treeItems = typeMappingsTree.getSelection();
        if (treeItems != null && treeItems.length == 1) {
          TreeItem item = treeItems[0];
          Object data = item.getData();
          if (data instanceof Mapping && ((Mapping)data).getHelper() instanceof MappingRule)
            mappingRuleComposite.setMappingRule((MappingRule)((Mapping)data).getHelper());          
        }
      }      
    });
    typeMappingsTreeViewer = new TreeViewer(typeMappingsTree);
    AdapterFactory registeredFactories = new ComposedAdapterFactory(ComposedAdapterFactory.Descriptor.Registry.INSTANCE);
    AdapterFactory reflectiveFactory = new ReflectiveItemProviderAdapterFactory();
    AdapterFactory adapterFactory = new ComposedAdapterFactory(new AdapterFactory[]{
        new com.metys.merlin.generation.mappingmodel.mapping.provider.MappingItemProviderAdapterFactory(),
        new ResourceItemProviderAdapterFactory(),
        new EcoreItemProviderAdapterFactory(),
        new MappingItemProviderAdapterFactory(),
        registeredFactories,
        reflectiveFactory});
    typeMappingsTreeViewer.setContentProvider(new AdapterFactoryContentProvider(adapterFactory){
      public Object [] getElements(Object object) {
        if (object instanceof Collection) {
          return ((Collection)object).toArray();
        }
        return super.getElements(object);
      }
    });
    typeMappingsTreeViewer.setLabelProvider(new AdapterFactoryLabelProvider(adapterFactory));
  }

  protected void setErrorMessage(Object object) {
    // TODO Auto-generated method stub
    
  }

  public boolean validateFields() {
    boolean ok = true;
    if (sourceResource != null)
      setSourceResource(sourceResource);
    if (typeMappingsResource != null)
      setTypeMappingsResource(typeMappingsResource);
    if (typeMappingsResource != null) {
      try {
        if (sourceResource != null && 
            !sourceResource.getContents().isEmpty() && 
            !typeMappingsResource.getContents().isEmpty()) {
          EObject mappingTopContent = (EObject) typeMappingsResource.getContents().get(0);
          EObject inputTopContent = (EObject) sourceResource.getContents().get(0);
          if (mappingTopContent instanceof MappingRoot) {
            MappingRoot root = (MappingRoot) mappingTopContent;
            if (!root.getInputs().contains(inputTopContent.eClass().getEPackage())) {
              ok = false;
            }
          } else {
            ok = false;
          }
        }        
      } catch (Exception ex) {
        MappingModelUIPlugin.INSTANCE.log(ex);
        return false;
      }
    }    
    return ok;  
  }
  
  /**
   * This method initializes mappingRuleComposite	
   *
   */    
  private void createMappingRuleComposite() {
  	mappingRuleComposite = new MappingRuleReadOnlyComposite(mappingsSashForm, SWT.NONE);  	
  }

  /**
   * This method initializes composite	
   *
   */    
  private void createComposite() {
  	GridData gridData = new GridData();
  	gridData.horizontalAlignment = GridData.FILL;
  	gridData.grabExcessHorizontalSpace = true;
  	GridLayout gridLayout2 = new GridLayout();
  	gridLayout2.horizontalSpacing = 2;
  	gridLayout2.marginWidth = 2;
  	gridLayout2.verticalSpacing = 2;
  	gridLayout2.marginHeight = 2;
  	targetTreeComposite = new Composite(modelsRightPartSashForm, SWT.BORDER);		   
  	targetTreeComposite.setLayout(gridLayout2);
  	targetObjectsLabel = new CLabel(targetTreeComposite, SWT.CENTER);
  	targetObjectsLabel.setText("Initial Targets");
  	targetObjectsLabel.setLayoutData(gridData);
  	createTargetTree();
  }

  /**
   * This method initializes tree	
   *
   */    
  private void createTargetTree() {
  	GridData gridData3 = new GridData();
  	gridData3.horizontalAlignment = GridData.FILL;
  	gridData3.grabExcessHorizontalSpace = true;
  	gridData3.grabExcessVerticalSpace = true;
  	gridData3.verticalAlignment = GridData.FILL;
  	targetTree = new Tree(targetTreeComposite, SWT.NONE);		   
  	targetTree.setLayoutData(gridData3);
    targetTreeViewer = new TreeViewer(targetTree);    
    AdapterFactory registeredFactories = new ComposedAdapterFactory(ComposedAdapterFactory.Descriptor.Registry.INSTANCE);
    AdapterFactory reflectiveFactory = new ReflectiveItemProviderAdapterFactory();
    AdapterFactory adapterFactory = new ComposedAdapterFactory(new AdapterFactory[]{
        registeredFactories,
        new ResourceItemProviderAdapterFactory(),
        new EcoreItemProviderAdapterFactory(),
        reflectiveFactory});
    targetTreeViewer.setContentProvider(new AdapterFactoryContentProvider(adapterFactory){
      public Object [] getElements(Object object) {
        if (object instanceof Collection)
          return ((Collection)object).toArray();        
        return super.getElements(object);
      }
    });
    targetTreeViewer.setLabelProvider(new AdapterFactoryLabelProvider(adapterFactory));
  }

  /**
   * This method initializes modelsSashForm	
   *
   */    
  private void createModelsSashForm() {
  	modelsSashForm = new SashForm(this, SWT.NONE);		   
  	createInputTreeComposite();
  	createModelsRightPartSashForm();
    modelsSashForm.setWeights(new int[] {1,3});
  }

  /**
   * This method initializes modelsRightPartSashForm	
   *
   */    
  private void createModelsRightPartSashForm() {
  	modelsRightPartSashForm = new SashForm(modelsSashForm, SWT.NONE);		   
  	createMappingsSashForm();
  	createComposite();
    modelsRightPartSashForm.setWeights(new int[] {2,1});
  }

  /**
   * This method initializes mappingsSashForm	
   *
   */    
  private void createMappingsSashForm() {
  	mappingsSashForm = new SashForm(modelsRightPartSashForm, SWT.NONE);		   
  	mappingsSashForm.setOrientation(org.eclipse.swt.SWT.VERTICAL);
  	createMappingsTreeComposite();
  	createMappingRuleComposite();
    mappingsSashForm.setWeights(new int[] {1,2});
  }

}  //  @jve:decl-index=0:visual-constraint="10,10"
