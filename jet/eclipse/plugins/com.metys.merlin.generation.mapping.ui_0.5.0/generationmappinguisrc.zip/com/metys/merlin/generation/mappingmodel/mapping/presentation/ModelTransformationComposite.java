package com.metys.merlin.generation.mappingmodel.mapping.presentation;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.mapping.MappingRoot;
import org.eclipse.emf.mapping.ecore2ecore.Ecore2EcoreMappingRoot;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.dialogs.ResourceSelectionDialog;

import com.metys.merlin.generation.mappingmodel.MappingModelUIPlugin;
import com.metys.merlin.generation.mappingmodel.mapping.MappingFactory;
import com.metys.merlin.generation.mappingmodel.mapping.Transformer;
import com.metys.merlin.generation.mappingmodel.util.MappingModelUtil;

public class ModelTransformationComposite extends Composite {
   
  private Composite resourcesComposite = null;
  private Label sourceResourceLabel = null;
  private Text sourceResourceText = null;
  private Button sourceResourceBrowseWSButton = null;
  private Label typeMappingFileLabel = null;
  private Text typeMappingResourceText = null;
  private Button typeMappingResourceBrowseWSButton = null;
  private Label initialMappingsResourceLabel = null;

  private Text initialMappingsResourceText = null;

  private Button initialMappingsResourceBrowseWSButton = null;

  private Button clearInitialMappingsResourceButton = null;

  private Button generateMappingFilecheckBox = null;
  
  private MappingRoot mappingRootResult;
  private Resource sourceResource;
  private Resource targetResource;
  private Resource typeMappingsResource;
  private Resource initialMappingsResource;
  private Button inputAndTypeMappingRadioButton = null;
  private Button initialMappingsRadioButton = null;
  private Button clearSourcesResourceButton = null;
  private Button clearTypeMappingsResourceButton = null;
  private Label glue0 = null;
  private Label glue2 = null;
  private Label glue3 = null;
  private Label glue4 = null;
  private Button previewButton = null;
  private TransformationPreviewComposite transformationPreviewCompostite;
  private Label glue1 = null;
  private Label targetResourceLabel = null;
  private Text targetResourceText = null;
  private Button targetResourceBrowseWSButton = null;
  private Button clearTargetResourceButton = null;
  private TransformationInputsComposite transformationInputsComposite = null;
  private Composite separatorComposite = null;
  
  private ResourceSet resourceSet = new ResourceSetImpl();
  
  public ModelTransformationComposite(Composite parent, int style) {
    super(parent, style);
    initialize();
  }

  private void initialize() {
    GridData gridData9 = new org.eclipse.swt.layout.GridData();
    gridData9.horizontalAlignment = org.eclipse.swt.layout.GridData.BEGINNING;
    gridData9.grabExcessHorizontalSpace = true;
    gridData9.verticalAlignment = org.eclipse.swt.layout.GridData.END;
    this.setLayout(new GridLayout());
    createResourcesComposite();
    setSize(new org.eclipse.swt.graphics.Point(555,522));
    createTransformationInputsComposite();
    previewButton = new Button(this, SWT.NONE);
    previewButton.setText("Preview ...");
    previewButton.setLayoutData(gridData9);
    previewButton.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
      public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
        class MyDialog extends Dialog {
          public MyDialog(Shell shell) {
            super(shell);
            setShellStyle(getShellStyle() | SWT.RESIZE);
          }
          
          /*
           * @see org.eclipse.jface.window.Window#configureShell(org.eclipse.swt.widgets.Shell)
           */
          protected void configureShell(Shell newShell) {
            super.configureShell(newShell);
            newShell.setText("Model Transformation Preview");
          }
          
          protected void createButtonsForButtonBar(Composite parent) {
              // create OK button only by default
              createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL,true);            
          }

          /*
           * @see org.eclipse.jface.dialogs.Dialog#createDialogArea(org.eclipse.swt.widgets.Composite)
           */
          protected Control createDialogArea(Composite parent) {
            transformationPreviewCompostite = new TransformationPreviewComposite(parent, SWT.NULL);
            GridData gd = new GridData(GridData.FILL_BOTH);
            gd.grabExcessHorizontalSpace = true;
            gd.grabExcessVerticalSpace = true;
            transformationPreviewCompostite.setLayoutData(gd);
            computePreview();
            return transformationPreviewCompostite;
          }
        }
        Dialog dialog = new MyDialog(getShell());
        dialog.open();
      }
    });
  }
  
  public Button getInitialMappingsRadioButton() {
    return initialMappingsRadioButton;
  }
  
  public Button getInputAndTypeMappingRadioButton() {
    return inputAndTypeMappingRadioButton;
  }
    
  public Text getSourceResourceText() {
    return sourceResourceText;
  }

  public Text getInitialMappingsResourceText() {
    return initialMappingsResourceText;
  }

  public Text getTypeMappingFileText() {
    return typeMappingResourceText;
  }

  public void setSourceResource(Resource sourceResource) {
    this.sourceResource = sourceResource;
    transformationInputsComposite.setSourceResource(sourceResource);
  }
  
  public void setTargetResource(Resource targetResource) {
    this.targetResource = targetResource;
    transformationInputsComposite.setTargetResource(targetResource);
  }
  
  public void setTypeMappingsResource(Resource typeMappingsResource) {
    this.typeMappingsResource = typeMappingsResource;
    transformationInputsComposite.setTypeMappingsResource(typeMappingsResource);
  }
  
  public void setInitialMappingsResource(Resource initialMappingsResource) {
    this.initialMappingsResource = initialMappingsResource;
  }
  
  public Resource getTargetResource() {
    return targetResource;
  }
  
  public Resource getSourceResource() {
    return sourceResource;     
  }
  
  public Resource getInitialMappingsResource() {
    return initialMappingsResource;
  }

  public Resource getTypeMappingsResource() {
    return typeMappingsResource;
  }

  public MappingRoot getMappingRootResult() {
    if (mappingRootResult == null) {
      boolean ok = validateFields();
      if (ok && 
          typeMappingsResource != null && 
          sourceResource != null) {
        Ecore2EcoreMappingRoot typeMappingRoot = (Ecore2EcoreMappingRoot) typeMappingsResource.getContents().get(0);    
        Transformer transformer = MappingFactory.eINSTANCE.createTransformer();
        
        MappingRoot instancesMappingRoot = null;
        if (initialMappingsResource != null && !initialMappingsResource.getContents().isEmpty()) {
          EObject initialMappingsTopContent = (EObject) initialMappingsResource.getContents().get(0);
          if (initialMappingsTopContent instanceof MappingRoot) {
            instancesMappingRoot = (MappingRoot) initialMappingsTopContent;          
          }
        }
        if (instancesMappingRoot == null) {
          transformer.setTypeMappingRoot(typeMappingRoot);
          transformer.transform(sourceResource, targetResource, null);
        } else {
          transformer.transform(instancesMappingRoot, null);
        }        
        mappingRootResult = transformer.getMappingRoot();
      }
    }
    return mappingRootResult;
  }

  public boolean saveMappingResource() {
    return initialMappingsRadioButton.getSelection() ||
      (inputAndTypeMappingRadioButton.getSelection() && generateMappingFilecheckBox.getSelection());
  }
  
  /**
   * This method initializes resourcesComposite	
   *
   */    
  private void createResourcesComposite() {
  	GridData gridData11 = new org.eclipse.swt.layout.GridData();
  	gridData11.horizontalAlignment = org.eclipse.swt.layout.GridData.CENTER;
  	gridData11.verticalAlignment = org.eclipse.swt.layout.GridData.CENTER;
  	GridData gridData32 = new org.eclipse.swt.layout.GridData();
  	gridData32.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData32.grabExcessHorizontalSpace = true;
  	gridData32.verticalAlignment = org.eclipse.swt.layout.GridData.CENTER;
  	GridData gridData21 = new GridData();
  	gridData21.widthHint = 30;
  	GridData gridData61 = new GridData();
  	gridData61.widthHint = 30;
  	GridData gridData51 = new GridData();
  	gridData51.widthHint = 30;
  	GridData gridData4 = new GridData();
  	gridData4.widthHint = 30;
  	gridData4.verticalAlignment = org.eclipse.swt.layout.GridData.CENTER;
  	GridData gridData3 = new GridData();
  	gridData3.widthHint = 30;
  	GridData gridData2 = new GridData();
  	gridData2.horizontalSpan = 5;
  	GridData gridData18 = new GridData();
  	gridData18.horizontalSpan = 5;
  	GridData gridData112 = new GridData();
  	gridData112.horizontalSpan = 4;
  	gridData112.horizontalAlignment = org.eclipse.swt.layout.GridData.BEGINNING;
  	gridData112.verticalAlignment = org.eclipse.swt.layout.GridData.BEGINNING;
  	GridData gridData111 = new GridData();
  	gridData111.horizontalAlignment = org.eclipse.swt.layout.GridData.BEGINNING;
  	gridData111.horizontalSpan = 1;
  	gridData111.grabExcessHorizontalSpace = false;
  	GridData gridData110 = new GridData();
  	gridData110.horizontalAlignment = org.eclipse.swt.layout.GridData.END;
  	GridData gridData41 = new GridData();
  	gridData41.grabExcessHorizontalSpace = true;
  	gridData41.grabExcessVerticalSpace = false;
  	gridData41.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	GridData gridData31 = new GridData();
  	gridData31.horizontalAlignment = org.eclipse.swt.layout.GridData.END;
  	gridData31.horizontalSpan = 1;
  	gridData31.grabExcessHorizontalSpace = false;
  	GridData gridData17 = new GridData();
  	gridData17.horizontalAlignment = org.eclipse.swt.layout.GridData.BEGINNING;
  	gridData17.horizontalSpan = 1;
  	GridData gridData = new GridData();
  	gridData.horizontalAlignment = org.eclipse.swt.layout.GridData.CENTER;
  	GridData gridData8 = new GridData();
  	gridData8.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData8.grabExcessHorizontalSpace = true;
  	GridData gridData7 = new GridData();
  	gridData7.grabExcessHorizontalSpace = true;
  	gridData7.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	GridData gridData6 = new GridData();
  	gridData6.horizontalAlignment = org.eclipse.swt.layout.GridData.CENTER;
  	GridLayout gridLayout1 = new GridLayout();
  	gridLayout1.numColumns = 5;
  	gridLayout1.verticalSpacing = 0;
  	gridLayout1.marginHeight = 2;
  	GridData gridData5 = new GridData();
  	gridData5.grabExcessHorizontalSpace = true;
  	gridData5.widthHint = 400;
  	gridData5.verticalAlignment = org.eclipse.swt.layout.GridData.BEGINNING;
  	gridData5.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	resourcesComposite = new Composite(this, SWT.NONE);		   
  	resourcesComposite.setLayoutData(gridData5);
  	resourcesComposite.setLayout(gridLayout1);
  	inputAndTypeMappingRadioButton = new Button(resourcesComposite, SWT.RADIO);
  	inputAndTypeMappingRadioButton.setText("Perform transformation from Input Model and Type Mappings");
  	inputAndTypeMappingRadioButton.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
  	  public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
  		refreshEnabledStates();
  	  }
  	});
  	inputAndTypeMappingRadioButton.setLayoutData(gridData18);
  	glue0 = new Label(resourcesComposite, SWT.NONE);
  	glue0.setLayoutData(gridData61);
  	sourceResourceLabel = new Label(resourcesComposite, SWT.NONE);
  	sourceResourceLabel.setText("Sources Resource :");
  	sourceResourceLabel.setLayoutData(gridData17);
  	sourceResourceText = new Text(resourcesComposite, SWT.BORDER);
  	sourceResourceText.setEditable(false);
  	sourceResourceText.setLayoutData(gridData7);
  	sourceResourceBrowseWSButton = new Button(resourcesComposite, SWT.NONE);
  	clearSourcesResourceButton = new Button(resourcesComposite, SWT.NONE);
  	clearSourcesResourceButton.setImage(new Image(Display.getCurrent(), getClass().getResourceAsStream("/com/metys/merlin/generation/mappingmodel/mapping/presentation/clear.gif")));
  	glue1 = new Label(resourcesComposite, SWT.NONE);
  	glue1.setLayoutData(gridData21);
  	targetResourceLabel = new Label(resourcesComposite, SWT.NONE);
  	targetResourceLabel.setText("Initial Targets Resource :");
  	targetResourceText = new Text(resourcesComposite, SWT.BORDER);
  	targetResourceText.setEditable(false);
  	targetResourceText.setLayoutData(gridData32);
  	targetResourceBrowseWSButton = new Button(resourcesComposite, SWT.NONE);
  	targetResourceBrowseWSButton.setText("...");
  	targetResourceBrowseWSButton.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
      public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
        String dialogLabel = MappingModelUIPlugin.INSTANCE.getString("_UI_SelectModelFile_label");
        ResourceSelectionDialog containerSelectionDialog = 
          new ResourceSelectionDialog(getShell(), 
              ResourcesPlugin.getWorkspace().getRoot(), 
              dialogLabel);
        containerSelectionDialog.open();
        Object[] result = containerSelectionDialog.getResult();
        if (result != null) {
          if (result[0] instanceof IResource) {
            IResource outputFileResource = (IResource) result[0];
            targetResourceText.setText(outputFileResource.getFullPath().toString());
            boolean ok = validateFields();
            if (ok)
              setErrorMessage(null);                
            else
              setErrorMessage(MappingModelUIPlugin.INSTANCE.getString("_UI_InvalidTargetFile_label"));            
          }  
        }
      }
    });
  	clearTargetResourceButton = new Button(resourcesComposite, SWT.NONE);
  	clearTargetResourceButton.setImage(new Image(Display.getCurrent(), getClass().getResourceAsStream("/com/metys/merlin/generation/mappingmodel/mapping/presentation/clear.gif")));
  	glue2 = new Label(resourcesComposite, SWT.NONE);
  	glue2.setLayoutData(gridData51);
  	typeMappingFileLabel = new Label(resourcesComposite, SWT.NONE);
  	typeMappingFileLabel.setText("Type Mappings Resource :");
  	typeMappingFileLabel.setLayoutData(gridData111);
  	typeMappingResourceText = new Text(resourcesComposite, SWT.BORDER);
  	typeMappingResourceText.setEditable(false);
  	typeMappingResourceText.setLayoutData(gridData8);
  	typeMappingResourceBrowseWSButton = new Button(resourcesComposite, SWT.NONE);
  	typeMappingResourceBrowseWSButton.setText("...");
  	typeMappingResourceBrowseWSButton.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
  	  public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
        String dialogLabel = MappingModelUIPlugin.INSTANCE.getString("_UI_SelectModelFile_label");
        ResourceSelectionDialog containerSelectionDialog = 
          new ResourceSelectionDialog(getShell(), 
              ResourcesPlugin.getWorkspace().getRoot(), 
              dialogLabel);
        containerSelectionDialog.open();
        Object[] result = containerSelectionDialog.getResult();
        if (result != null) {
          if (result[0] instanceof IResource) {
            IResource typeMappingFileResource = (IResource) result[0];
            typeMappingResourceText.setText(typeMappingFileResource.getFullPath().toString());
            boolean ok = validateFields();
            if (ok)
              setErrorMessage(null);                
            else
              setErrorMessage(MappingModelUIPlugin.INSTANCE.getString("_UI_InvalidMappingFile_label"));            
          }  
        }
  	  }
  	});
  	typeMappingResourceBrowseWSButton.setLayoutData(gridData);
  	sourceResourceBrowseWSButton.setText("...");
  	sourceResourceBrowseWSButton.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
  	  public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
  	    String dialogLabel = MappingModelUIPlugin.INSTANCE.getString("_UI_SelectModelFile_label");
  	    ResourceSelectionDialog containerSelectionDialog = 
          new ResourceSelectionDialog(getShell(), 
              ResourcesPlugin.getWorkspace().getRoot(), 
              dialogLabel);
        containerSelectionDialog.open();
        Object[] result = containerSelectionDialog.getResult();
        if (result != null) {
          if (result[0] instanceof IResource) {
            IResource inputFileResource = (IResource) result[0];
            sourceResourceText.setText(inputFileResource.getFullPath().toString());
            boolean ok = validateFields();
            if (ok)
              setErrorMessage(null);                
            else
              setErrorMessage(MappingModelUIPlugin.INSTANCE.getString("_UI_InvalidInputFile_label"));            
          }  
        }
  	  }
  	});
  	sourceResourceBrowseWSButton.setLayoutData(gridData6);
  	clearTypeMappingsResourceButton = new Button(resourcesComposite, SWT.NONE);
  	clearTypeMappingsResourceButton.setImage(new Image(Display.getCurrent(), getClass().getResourceAsStream("/com/metys/merlin/generation/mappingmodel/mapping/presentation/clear.gif")));
  	glue3 = new Label(resourcesComposite, SWT.NONE);
  	glue3.setLayoutData(gridData4);
  	generateMappingFilecheckBox = new Button(resourcesComposite, SWT.CHECK);
  	createSeparatorComposite();
  	targetResourceBrowseWSButton.setLayoutData(gridData11);
  	initialMappingsRadioButton = new Button(resourcesComposite, SWT.RADIO);
  	initialMappingsRadioButton.setText("Perform transformation from an existing instances mapping");
  	initialMappingsRadioButton.setLayoutData(gridData2);
  	glue4 = new Label(resourcesComposite, SWT.NONE);
  	glue4.setLayoutData(gridData3);
  	initialMappingsResourceLabel = new Label(resourcesComposite, SWT.NONE);
  	initialMappingsResourceLabel.setText("Instances Mappings Resource :");
  	initialMappingsResourceLabel.setLayoutData(gridData31);
  	initialMappingsResourceText = new Text(resourcesComposite, SWT.BORDER);
  	initialMappingsResourceText.setEditable(false);
  	initialMappingsResourceText.setLayoutData(gridData41);
  	initialMappingsResourceBrowseWSButton = new Button(resourcesComposite, SWT.NONE);
  	initialMappingsResourceBrowseWSButton.setText("...");
  	clearInitialMappingsResourceButton = new Button(resourcesComposite, SWT.NONE);
  	clearInitialMappingsResourceButton.setText("Clear");
  	clearInitialMappingsResourceButton.setLayoutData(gridData110);
  	clearInitialMappingsResourceButton.setImage(new Image(Display.getCurrent(), getClass().getResourceAsStream("/com/metys/merlin/generation/mappingmodel/mapping/presentation/clear.gif")));
  	generateMappingFilecheckBox.setText("Generate New Instances Mappings Resource");    
  	generateMappingFilecheckBox.setLayoutData(gridData112);
  	clearInitialMappingsResourceButton.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
  	  public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
        initialMappingsResourceText.setText("");
        boolean ok = validateFields();
        if (ok)
          setErrorMessage(null);                
        else {
          setErrorMessage(MappingModelUIPlugin.INSTANCE.getString("_UI_InvalidMappingFile_label"));
        }
  	  }
  	});
    initialMappingsRadioButton.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
      public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
        refreshEnabledStates();
      }
    });
    initialMappingsResourceBrowseWSButton.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
      public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
        String dialogLabel = MappingModelUIPlugin.INSTANCE.getString("_UI_SelectModelFile_label");
        ResourceSelectionDialog containerSelectionDialog = 
          new ResourceSelectionDialog(getShell(), 
              ResourcesPlugin.getWorkspace().getRoot(), 
              dialogLabel);
        containerSelectionDialog.open();
        Object[] result = containerSelectionDialog.getResult();
        if (result != null) {
          if (result[0] instanceof IResource) {
            IResource outputFileResource = (IResource) result[0];
            initialMappingsResourceText.setText(outputFileResource.getFullPath().toString());
            boolean ok = validateFields();
            if (ok)
              setErrorMessage(null);                
            else {
              setErrorMessage(MappingModelUIPlugin.INSTANCE.getString("_UI_InvalidOutputFile_label"));
            }
          }  
        }
      }
    });
  }
  
  public void refreshEnabledStates() {
    boolean inputAndTypeMappingSelected = inputAndTypeMappingRadioButton.getSelection();
    sourceResourceText.setEnabled(inputAndTypeMappingSelected);
    sourceResourceBrowseWSButton.setEnabled(inputAndTypeMappingSelected);
    clearSourcesResourceButton.setEnabled(inputAndTypeMappingSelected);
    
    typeMappingResourceText.setEnabled(inputAndTypeMappingSelected);
    typeMappingResourceBrowseWSButton.setEnabled(inputAndTypeMappingSelected);
    clearTypeMappingsResourceButton.setEnabled(inputAndTypeMappingSelected);
    
    targetResourceText.setEnabled(inputAndTypeMappingSelected);
    targetResourceBrowseWSButton.setEnabled(inputAndTypeMappingSelected);
    clearTargetResourceButton.setEnabled(inputAndTypeMappingSelected);
    
    generateMappingFilecheckBox.setEnabled(inputAndTypeMappingSelected);
    
    initialMappingsResourceText.setEnabled(!inputAndTypeMappingSelected);
    initialMappingsResourceBrowseWSButton.setEnabled(!inputAndTypeMappingSelected);
    clearInitialMappingsResourceButton.setEnabled(!inputAndTypeMappingSelected);
  }

  protected void setErrorMessage(String errorMessage) {    
  }
  
  public void computePreview() {
    boolean ok = validateFields();
    if (ok && typeMappingsResource != null && sourceResource != null) {
      Ecore2EcoreMappingRoot typeMappingRoot = (Ecore2EcoreMappingRoot) typeMappingsResource.getContents().get(0);    
      
      ResourceSet previewResourceSet = new ResourceSetImpl();
      Resource previewSourceResource = sourceResource == null ? null : previewResourceSet.getResource(sourceResource.getURI(), true);
      Resource previewTargetResource = targetResource == null ? null : previewResourceSet.getResource(targetResource.getURI(), true);
      Resource previewInstancesMappingsResource = initialMappingsResource == null ? null : previewResourceSet.getResource(initialMappingsResource.getURI(), true);
      
      Transformer transformer = MappingFactory.eINSTANCE.createTransformer();
      MappingRoot instancesMappingRoot = null;
      MappingRoot initialInstancesMappingRoot = null;
      if (previewInstancesMappingsResource != null && !previewInstancesMappingsResource.getContents().isEmpty()) {
        EObject initialMappingsTopContent = (EObject) previewInstancesMappingsResource.getContents().get(0);
        if (initialMappingsTopContent instanceof MappingRoot) {
          instancesMappingRoot = (MappingRoot) initialMappingsTopContent;
          initialInstancesMappingRoot = (MappingRoot) EcoreUtil.copy(instancesMappingRoot);
        }
      }
      if (instancesMappingRoot == null) {
        transformer.setTypeMappingRoot(typeMappingRoot);
        transformer.transform(previewSourceResource, previewTargetResource, null);
      } else {
        transformer.transform(instancesMappingRoot, null);        
      }
      
      if (initialInstancesMappingRoot != null)
        transformationPreviewCompostite.setInitialInstancesMappingRoot(initialInstancesMappingRoot);              
      transformationPreviewCompostite.setChangeDescription(transformer.getChangeDescription());
      transformationPreviewCompostite.setExpectedInstancesMappingRoot(mappingRootResult = transformer.getMappingRoot());
    }
  }
  
  public boolean validateFields() {
    boolean ok = true;
    mappingRootResult = null;
    if (inputAndTypeMappingRadioButton.getSelection()) {
      String inputResourcePath = sourceResourceText.getText();
      String targetResourcePath = targetResourceText.getText();
      String typeMappingsResourcePath = typeMappingResourceText.getText();
      
      URI inputResourceURI = null;
      if (inputResourcePath != null && inputResourcePath.length() > 0) {
        if (ResourcesPlugin.getWorkspace().getRoot().findMember(new Path(inputResourcePath)) != null)
          inputResourceURI = URI.createPlatformResourceURI(inputResourcePath);
        else
          inputResourceURI = URI.createURI(inputResourcePath);
      }
      URI typeMappingsResourceURI = null;
      if (typeMappingsResourcePath != null && typeMappingsResourcePath.length() > 0) {
        if (ResourcesPlugin.getWorkspace().getRoot().findMember(new Path(typeMappingsResourcePath)) != null)
          typeMappingsResourceURI = URI.createPlatformResourceURI(typeMappingsResourcePath);
        else
          typeMappingsResourceURI = URI.createURI(typeMappingsResourcePath);
      }
      URI targetResourceURI = null;
      if (targetResourcePath != null && targetResourcePath.length() > 0) {
        if (ResourcesPlugin.getWorkspace().getRoot().findMember(new Path(targetResourcePath)) != null)
          targetResourceURI = URI.createPlatformResourceURI(targetResourcePath);
        else
          targetResourceURI = URI.createURI(targetResourcePath);
      }
      
      sourceResource = inputResourceURI == null ? null : resourceSet.getResource(inputResourceURI, true);
      typeMappingsResource = typeMappingsResourceURI == null ? null : resourceSet.getResource(typeMappingsResourceURI, true);
      targetResource = targetResourceURI == null ? null : resourceSet.getResource(targetResourceURI, true);            
      initialMappingsResource = null;
      
      if (typeMappingsResource != null) {
        try {
          if (sourceResource != null && 
              !sourceResource.getContents().isEmpty() && 
              !typeMappingsResource.getContents().isEmpty()) {
            EObject mappingTopContent = (EObject) typeMappingsResource.getContents().get(0);
            EObject inputTopContent = (EObject) sourceResource.getContents().get(0);
            if (mappingTopContent instanceof Ecore2EcoreMappingRoot) {
              Ecore2EcoreMappingRoot typeMappingRoot = (Ecore2EcoreMappingRoot) mappingTopContent;
              if (!typeMappingRoot.getInputs().contains(inputTopContent.eClass().getEPackage())) {
                ok = false;
              }
            } else {
              ok = false;
            }
          }
          if (targetResource != null && 
              !targetResource.getContents().isEmpty() && 
              !typeMappingsResource.getContents().isEmpty()) {
            EObject mappingTopContent = (EObject) typeMappingsResource.getContents().get(0);
            EObject targetTopContent = (EObject) targetResource.getContents().get(0);
            if (mappingTopContent instanceof Ecore2EcoreMappingRoot) {
              Ecore2EcoreMappingRoot typeMappingRoot = (Ecore2EcoreMappingRoot) mappingTopContent;
              if (!typeMappingRoot.getOutputs().contains(targetTopContent.eClass().getEPackage())) {
                ok = false;
              }
            } else {
              ok = false;
            }
          }
        } catch (Exception ex) {
          MappingModelUIPlugin.INSTANCE.log(ex);
          return false;
        }
      }      
    } else {
      String initialMappingsResourcePath = initialMappingsResourceText.getText();
      URI initialMappingsResourceURI = null;
      if (initialMappingsResourcePath != null && initialMappingsResourcePath.length() > 0) {
        if (ResourcesPlugin.getWorkspace().getRoot().findMember(new Path(initialMappingsResourcePath)) != null)
          initialMappingsResourceURI = URI.createPlatformResourceURI(initialMappingsResourcePath);
        else
          initialMappingsResourceURI = URI.createURI(initialMappingsResourcePath);      
      }      
      initialMappingsResource = initialMappingsResourceURI == null ? null : resourceSet.getResource(initialMappingsResourceURI, true);      
      if (initialMappingsResource != null && !initialMappingsResource.getContents().isEmpty()) {
        EObject initialMappingsTopContent = (EObject) initialMappingsResource.getContents().get(0);
        if (initialMappingsTopContent instanceof MappingRoot) {
          MappingRoot instancesMappingRoot = (MappingRoot) initialMappingsTopContent;
          MappingRoot typeMappingRoot = instancesMappingRoot.getTypeMappingRoot();
          EObject firstInput = MappingModelUtil.getFirstInput(instancesMappingRoot);
          EObject firstOutput = MappingModelUtil.getFirstOutput(instancesMappingRoot);
          sourceResource = firstInput == null ? null : firstInput.eResource();
          typeMappingsResource = typeMappingRoot == null ? null : typeMappingRoot.eResource();
          targetResource = firstOutput == null ? null : firstOutput.eResource();           
        } else {
          ok = false;
        }
      }            
    }            
        
    if (sourceResource != null) {
      setSourceResource(sourceResource);      
    }
    if (typeMappingsResource != null) {
      setTypeMappingsResource(typeMappingsResource);      
    }
    if (targetResource != null) {
      setTargetResource(targetResource);      
    }
    return ok;  
  }
  
  /**
   * This method initializes transformationInputsComposite	
   *
   */    
  private void createTransformationInputsComposite() {
  	GridData gridData1 = new org.eclipse.swt.layout.GridData();
  	gridData1.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData1.grabExcessHorizontalSpace = true;
  	gridData1.grabExcessVerticalSpace = true;
  	gridData1.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	transformationInputsComposite = new TransformationInputsComposite(this, SWT.NONE);		   
  	transformationInputsComposite.setLayoutData(gridData1);
  }

  /**
   * This method initializes separatorComposite	
   *
   */
  private void createSeparatorComposite() {
    GridData gridData10 = new org.eclipse.swt.layout.GridData();
    gridData10.horizontalSpan = 5;
    gridData10.heightHint = 15;
    separatorComposite = new Composite(resourcesComposite, SWT.NONE);
    separatorComposite.setLayoutData(gridData10);
  }

}  //  @jve:decl-index=0:visual-constraint="10,10"
