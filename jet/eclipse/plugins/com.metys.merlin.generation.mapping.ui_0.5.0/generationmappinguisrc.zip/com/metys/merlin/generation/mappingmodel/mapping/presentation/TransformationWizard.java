/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.mappingmodel.mapping.presentation;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.change.ChangeDescription;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.edit.ui.provider.ExtendedImageRegistry;
import org.eclipse.emf.mapping.MappingRoot;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IEditorDescriptor;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.actions.WorkspaceModifyOperation;
import org.eclipse.ui.dialogs.WizardNewFileCreationPage;
import org.eclipse.ui.part.FileEditorInput;
import org.eclipse.ui.part.ISetSelectionTarget;

import com.metys.merlin.generation.mappingmodel.MappingModelUIPlugin;
import com.metys.merlin.generation.mappingmodel.mapping.Transformer;
import com.metys.merlin.generation.mappingmodel.mapping.MappingFactory;
import com.metys.merlin.generation.mappingmodel.mapping.MappingPackage;
import com.metys.merlin.generation.mappingmodel.util.MappingModelUtil;

/**
 * This is a simple wizard for creating a new model file.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class TransformationWizard extends Wizard implements INewWizard {
  /**
   * This caches an instance of the model package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected MappingPackage mappingPackage = MappingPackage.eINSTANCE;

  /**
   * This caches an instance of the model factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected MappingFactory mappingFactory = mappingPackage.getMappingFactory();

  /**
   * This is the file creation page.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected NewFileCreationPage newFileCreationPage;

  /**
   * This is the file creation page.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected TransformationOverviewPage transformationOverviewPage;

  /**
   * Remember the selection during initialization for populating the default container.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected IStructuredSelection selection;

  /**
   * Remember the workbench during initialization.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected IWorkbench workbench;

  protected Transformer mapper;
  private String sourceResourcePath;
  private String initialMappingsResourcePath;
  private String typeMappingsResourcePath;
  private ResourceSet resourceSet = new ResourceSetImpl();
  
  /**
   * This just records the information.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void init(IWorkbench workbench, IStructuredSelection selection) {
    this.workbench = workbench;
    this.selection = selection;
    setWindowTitle(MappingModelUIPlugin.INSTANCE.getString("_UI_Wizard_label"));
    setDefaultPageImageDescriptor(ExtendedImageRegistry.INSTANCE.getImageDescriptor(MappingModelUIPlugin.INSTANCE
        .getImage("full/wizban/NewModelMapping")));
  }
  
  public String getInstanceMappingFileName() {
    String sourceFileName = transformationOverviewPage.getSourceResource().getURI().lastSegment();
    String targetFileName = transformationOverviewPage.getTargetResource() == null ?
        newFileCreationPage.getFileName() :
        transformationOverviewPage.getTargetResource().getURI().lastSegment();
    
    if (sourceFileName.indexOf('.') != -1)
      sourceFileName = sourceFileName.substring(0, sourceFileName.indexOf('.'));
    if (targetFileName.indexOf('.') != -1)
      targetFileName = targetFileName.substring(0, targetFileName.indexOf('.'));
    
    String instanceMappingFileName = sourceFileName + "2" + targetFileName + ".mapper";
    return instanceMappingFileName;
  }
  
  /**
   * Do the work after everything is specified.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean performFinish() {
    try {
      // Remember the file.
      //
      final IFile modelFile = getTargetModelFile();

      // Do the work within an operation.
      //
      WorkspaceModifyOperation operation = new WorkspaceModifyOperation() {
        protected void execute(IProgressMonitor progressMonitor) {
          try {
            Resource resource = transformationOverviewPage.getTargetResource();
            if (resource == null) {
              URI fileURI = URI.createPlatformResourceURI(modelFile.getFullPath().toString());
              resource = resourceSet.createResource(fileURI);
              // Add the initial model object to the contents.
              //
              Collection initialModel = MappingModelUtil.allOutputs(transformationOverviewPage.getMappingRootResult());
              for (Iterator it = initialModel.iterator(); it.hasNext();) {
                EObject output = (EObject) it.next();
                if (output.eContainer() == null || 
                    output.eContainer() instanceof ChangeDescription)
                  resource.getContents().add(output);
              }
            }            
            // Save the contents of the resource to the file system.
            //
            Map options = new HashMap();
            options.put(XMLResource.OPTION_ENCODING, "UTF-8");
            resource.save(options);
            
            if (transformationOverviewPage.saveMappingResource()) {
              Resource res = transformationOverviewPage.getInitialMappingsResource();
              if (res == null) {
                String instanceMappingFileName = getInstanceMappingFileName();
                IPath mappingFilePath = getTargetModelFile().getFullPath().removeLastSegments(1).append(instanceMappingFileName);
                URI instanceMappingURI = URI.createPlatformResourceURI(mappingFilePath.toString());
                res = resourceSet.createResource(instanceMappingURI);
                res.getContents().add(transformationOverviewPage.getMappingRootResult());
              }
              res.save(options);
            }
          } catch (Exception exception) {
            MappingModelUIPlugin.INSTANCE.log(exception);
          } finally {
            progressMonitor.done();
          }
        }
      };

      getContainer().run(false, false, operation);

      // Select the new file resource in the current view.
      //
      IWorkbenchWindow workbenchWindow = workbench.getActiveWorkbenchWindow();
      IWorkbenchPage page = workbenchWindow.getActivePage();
      final IWorkbenchPart activePart = page.getActivePart();
      if (activePart instanceof ISetSelectionTarget) {
        final ISelection targetSelection = new StructuredSelection(modelFile);
        getShell().getDisplay().asyncExec(new Runnable() {
          public void run() {
            ((ISetSelectionTarget) activePart).selectReveal(targetSelection);
          }
        });
      }

      // Open an editor on the new file.
      //
      try {
        IEditorDescriptor editorDescriptor = workbench.getEditorRegistry().getDefaultEditor(modelFile.getFullPath().toString());
        if (editorDescriptor != null)
          page.openEditor(new FileEditorInput(modelFile), editorDescriptor.getId());
      } catch (PartInitException exception) {
        MessageDialog.openError(workbenchWindow.getShell(), MappingModelUIPlugin.INSTANCE
            .getString("_UI_OpenEditorError_label"), exception.getMessage());
        return false;
      }

      return true;
    } catch (Exception exception) {
      MappingModelUIPlugin.INSTANCE.log(exception);
      return false;
    }
  }

  /**
   * This is the one page of the wizard.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public class NewFileCreationPage extends WizardNewFileCreationPage {
    /**
     * Remember the model file.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    protected IFile modelFile;

    /**
     * Pass in the selection.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    public NewFileCreationPage(String pageId, IStructuredSelection selection) {
      super(pageId, selection);
    }

    /**
     * The framework calls this to see if the file is correct.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    protected boolean validatePage() {
      return super.validatePage();
    }
        
    public boolean isPageComplete() {
      if (transformationOverviewPage.getModelTransformationComposite().getTargetResource() != null)
        return true;
      return super.isPageComplete();
    }

    /**
     * Store the dialog field settings upon completion.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    public boolean performFinish() {
      modelFile = getModelFile();
      return true;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    public IFile getModelFile() {
      return modelFile == null ? ResourcesPlugin.getWorkspace().getRoot().getFile(
          getContainerFullPath().append(getFileName())) : modelFile;
    }
  }

  /**
   * A page that allows choosing an existing model in a resource selection
   */
  public class TransformationOverviewPage extends WizardPage {
    
    protected ModelTransformationComposite modelTransformationComposite;
    
    public TransformationOverviewPage(String pageId) {
      super(pageId);
      setPageComplete(false);
    }
    
    public void createControl(Composite parent) {
      modelTransformationComposite = new ModelTransformationComposite(parent, SWT.NONE) {
        protected void setErrorMessage(String errorMessage) {
          TransformationOverviewPage.this.setErrorMessage(errorMessage);
        }
        public boolean validateFields() {
          boolean selectionsValid = super.validateFields();
          setPageComplete(selectionsValid);
          return selectionsValid;
        }
      };
      setControl(modelTransformationComposite);
      if (sourceResourcePath != null || typeMappingsResourcePath != null) {
        modelTransformationComposite.getInputAndTypeMappingRadioButton().setSelection(true);
        if (sourceResourcePath != null )
          modelTransformationComposite.getSourceResourceText().setText(sourceResourcePath);
        if (typeMappingsResourcePath != null)
          modelTransformationComposite.getTypeMappingFileText().setText(typeMappingsResourcePath);
        modelTransformationComposite.getInitialMappingsRadioButton().setEnabled(false);
      }
      
      if (initialMappingsResourcePath != null) {
        modelTransformationComposite.getInitialMappingsRadioButton().setSelection(true);
        modelTransformationComposite.getInitialMappingsResourceText().setText(initialMappingsResourcePath);
        modelTransformationComposite.getInputAndTypeMappingRadioButton().setEnabled(false);
      }
      
      modelTransformationComposite.refreshEnabledStates();
      modelTransformationComposite.validateFields();      
    }
    
    public ModelTransformationComposite getModelTransformationComposite() {
      return modelTransformationComposite;
    }
    
    public boolean saveMappingResource() {
      return modelTransformationComposite.saveMappingResource();
    }
    public Resource getSourceResource() {
      return modelTransformationComposite.getSourceResource();
    }
    public Resource getTargetResource() {
      return modelTransformationComposite.getTargetResource();
    }    
    public Resource getInitialMappingsResource() {
      return modelTransformationComposite.getInitialMappingsResource();
    }
    public MappingRoot getMappingRootResult() {
      return modelTransformationComposite.getMappingRootResult();
    }
  }
  
  
  
  /**
   * The framework calls this to create the contents of the wizard.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void addPages() {
    transformationOverviewPage = new TransformationOverviewPage("Whatever2");
    transformationOverviewPage.setTitle(MappingModelUIPlugin.INSTANCE.getString("_UI_InputFilesWizard_label"));
    transformationOverviewPage.setDescription(MappingModelUIPlugin.INSTANCE
        .getString("_UI_Wizard_inputs_description"));
    addPage(transformationOverviewPage);
        
    newFileCreationPage = new NewFileCreationPage("Whatever", selection);
    newFileCreationPage.setTitle(MappingModelUIPlugin.INSTANCE.getString("_UI_ModelMappingWizard_label"));
    newFileCreationPage.setDescription(MappingModelUIPlugin.INSTANCE.getString("_UI_ModelMappingWizard_description"));
    addPage(newFileCreationPage);

    // Try and get the resource selection to determine a current directory for the file dialog.
    //
    if (selection != null && !selection.isEmpty()) {
      // Get the resource...
      //
      Object selectedElement = selection.iterator().next();
      if (selectedElement instanceof IResource) {
        // Get the resource parent, if its a file.
        //
        IResource selectedResource = (IResource) selectedElement;
        if (selectedResource.getType() == IResource.FILE) {
          selectedResource = selectedResource.getParent();
        }

        // This gives us a directory...
        //
        if (selectedResource instanceof IFolder || selectedResource instanceof IProject) {
          // Set this for the container.
          //
          newFileCreationPage.setContainerFullPath(selectedResource.getFullPath());
        }
      }
    }
  }

  /**
   * Get the file from the page.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public IFile getTargetModelFile() {
    if (transformationOverviewPage.getModelTransformationComposite().getTargetResource() != null) {
      Resource targetResource = transformationOverviewPage.getModelTransformationComposite().getTargetResource(); 
      URI targetResourceURI = targetResource.getURI();
      IPath location = new Path(targetResourceURI.toString());
      location = location.removeFirstSegments(1);
      IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
      IFile eclipseResource = root.getFile(location);
      if (eclipseResource != null && eclipseResource.exists())
        return eclipseResource;
      return null;      
    }
    return newFileCreationPage.getModelFile();
  }
  
  public void setSourceResourcePath(String inputsResourcePath) {
    this.sourceResourcePath = inputsResourcePath;        
  }
  
  public void setInitialMappingsResourcePath(String initialMappingsResourcePath) {
    this.initialMappingsResourcePath = initialMappingsResourcePath;
  }
  
  public void setTypeMappingsResourcePath(String typeMappingsResourcePath) {
    this.typeMappingsResourcePath = typeMappingsResourcePath;       
  }

  public IWizardPage getNextPage(IWizardPage page) {
    if (transformationOverviewPage.getModelTransformationComposite().getTargetResource() != null)
      return null;
    return super.getNextPage(page);
  }
}