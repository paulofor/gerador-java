package com.metys.merlin.generation.mappingmodel.mapping.presentation;

import java.util.Collection;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.ecore.change.ChangeDescription;
import org.eclipse.emf.ecore.change.provider.ChangeItemProviderAdapterFactory;
import org.eclipse.emf.ecore.provider.EcoreItemProviderAdapterFactory;
import org.eclipse.emf.edit.provider.ComposedAdapterFactory;
import org.eclipse.emf.edit.provider.ReflectiveItemProviderAdapterFactory;
import org.eclipse.emf.edit.provider.resource.ResourceItemProviderAdapterFactory;
import org.eclipse.emf.edit.ui.provider.AdapterFactoryContentProvider;
import org.eclipse.emf.edit.ui.provider.AdapterFactoryLabelProvider;
import org.eclipse.emf.mapping.MappingRoot;
import org.eclipse.emf.mapping.provider.MappingItemProviderAdapterFactory;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Tree;

public class TransformationPreviewComposite extends Composite {

  private Composite expectedInstancesMappingsComposite = null;
  private Composite changedEObjectsComposite = null;
  
  private CLabel changedEObjectsLabel = null;
  private CLabel expectedInstancesMappingsLabel = null;
  
  private Tree changedEObjectsTree = null;
  private Tree expectedInstancesMappingsTree = null;
  
  private TreeViewer changedEObjectsTreeViewer;
  private TreeViewer initialInstancesMappingsTreeViewer;
  private TreeViewer expectedInstancesMappingsTreeViewer;
  
  private SashForm mainSashForm = null;
  private SashForm instancesMappingsSashForm = null;
  private Composite initialInstancesMappingsComposite = null;
  private CLabel initialInstancesMappingsLabel = null;
  private Tree initialInstancesMappingsTree = null;
  
  public TransformationPreviewComposite(Composite parent, int style) {
    super(parent, style);
    initialize();
  }

  private void initialize() {
    this.setLayout(new FillLayout());
    createMainSashForm();
    setSize(new org.eclipse.swt.graphics.Point(358,115));
  }
  
  public void setChangeDescription(ChangeDescription changeDescription) {
    changedEObjectsTreeViewer.setInput(changeDescription);
  }

  public void setInitialInstancesMappingRoot(MappingRoot instancesMappingRoot) {
    initialInstancesMappingsTreeViewer.setInput(instancesMappingRoot);
  }

  public void setExpectedInstancesMappingRoot(MappingRoot mappingRoot) {
    expectedInstancesMappingsTreeViewer.setInput(mappingRoot);
  }
  
  /**
   * This method initializes 	
   *
   */    
  private void createRemovedEObjectsComposite() {
  	GridLayout gridLayout2 = new GridLayout();
  	gridLayout2.marginHeight = 0;
  	gridLayout2.verticalSpacing = 0;
  	gridLayout2.marginWidth = 0;
  	gridLayout2.horizontalSpacing = 0;
  	expectedInstancesMappingsComposite = new Composite(instancesMappingsSashForm, SWT.BORDER);		   
	expectedInstancesMappingsLabel = new CLabel(expectedInstancesMappingsComposite, SWT.CENTER);

    expectedInstancesMappingsLabel.setText("New Mappings");
    createInstancesMappingsTree();  
    expectedInstancesMappingsComposite.setLayout(gridLayout2);
    GridData gridData4 = new GridData();
    gridData4.grabExcessHorizontalSpace = true;
    gridData4.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
    expectedInstancesMappingsLabel.setLayoutData(gridData4);
  }

  /**
   * This method initializes chang
   */    
  private void createChangedEObjectsComposite() {
  	GridLayout gridLayout = new GridLayout();
  	gridLayout.verticalSpacing = 0;
  	gridLayout.horizontalSpacing = 0;
  	gridLayout.marginHeight = 0;
  	gridLayout.marginWidth = 0;
  	changedEObjectsComposite = new Composite(instancesMappingsSashForm, SWT.NONE);		   
	changedEObjectsLabel = new CLabel(changedEObjectsComposite, SWT.CENTER);
	changedEObjectsLabel.setText("Changes");
    createChagedEObjectsTree();
    changedEObjectsComposite.setLayout(gridLayout);
    GridData gridData2 = new GridData();
    gridData2.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
	changedEObjectsLabel.setLayoutData(gridData2);    
  }

  /**
   * This method initializes chagedEObjectsTree	
   *
   */    
  private void createChagedEObjectsTree() {
  	GridData gridData5 = new GridData();
  	gridData5.grabExcessVerticalSpace = true;
  	gridData5.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData5.grabExcessHorizontalSpace = true;
  	gridData5.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	changedEObjectsTree = new Tree(changedEObjectsComposite, SWT.NONE);		   
  	changedEObjectsTree.setLayoutData(gridData5);
    changedEObjectsTreeViewer = new TreeViewer(changedEObjectsTree);
    AdapterFactory registeredFactories = new ComposedAdapterFactory(ComposedAdapterFactory.Descriptor.Registry.INSTANCE);
    AdapterFactory reflectiveFactory = new ReflectiveItemProviderAdapterFactory();
    AdapterFactory adapterFactory = new ComposedAdapterFactory(new AdapterFactory[]{
        new com.metys.merlin.generation.mappingmodel.mapping.provider.MappingItemProviderAdapterFactory(),
        registeredFactories,
        new ChangeItemProviderAdapterFactory(),
        new EcoreItemProviderAdapterFactory(),
        new ResourceItemProviderAdapterFactory(),
        reflectiveFactory});
    changedEObjectsTreeViewer.setContentProvider(new AdapterFactoryContentProvider(adapterFactory){
      public Object [] getElements(Object object) {
        if (object instanceof Collection) {
          return ((Collection)object).toArray();
        }
        return super.getElements(object);
      }
    });
    changedEObjectsTreeViewer.setLabelProvider(new AdapterFactoryLabelProvider(adapterFactory));
  }

  /**
   * This method initializes removedEObjectsTree	
   *
   */    
  private void createInstancesMappingsTree() {
  	GridData gridData7 = new GridData();
  	gridData7.grabExcessHorizontalSpace = true;
  	gridData7.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData7.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData7.grabExcessVerticalSpace = true;
  	expectedInstancesMappingsTree = new Tree(expectedInstancesMappingsComposite, SWT.NONE);		   
  	expectedInstancesMappingsTree.setLayoutData(gridData7);
    expectedInstancesMappingsTreeViewer = new TreeViewer(expectedInstancesMappingsTree);
    AdapterFactory registeredFactories = new ComposedAdapterFactory(ComposedAdapterFactory.Descriptor.Registry.INSTANCE);
    AdapterFactory reflectiveFactory = new ReflectiveItemProviderAdapterFactory();
    AdapterFactory adapterFactory = new ComposedAdapterFactory(new AdapterFactory[]{
        new com.metys.merlin.generation.mappingmodel.mapping.provider.MappingItemProviderAdapterFactory(),
        registeredFactories,
        new ResourceItemProviderAdapterFactory(),
        new MappingItemProviderAdapterFactory(),
        new EcoreItemProviderAdapterFactory(),
        reflectiveFactory});
    expectedInstancesMappingsTreeViewer.setContentProvider(new AdapterFactoryContentProvider(adapterFactory){
      public Object [] getElements(Object object) {
        if (object instanceof Collection) {
          return ((Collection)object).toArray();
        }
        return super.getElements(object);
      }
    });
    expectedInstancesMappingsTreeViewer.setLabelProvider(new AdapterFactoryLabelProvider(adapterFactory));
  }

  /**
   * This method initializes sashForm1	
   *
   */    
  private void createMainSashForm() {
	mainSashForm = new SashForm(this, SWT.NONE);		   
	createInitialInstancesMappingsComposite();
	createInstancesMappingsSashForm();
    mainSashForm.setWeights(new int[]{1,2});
  }

  /**
   * This method initializes instancesMappingsSashForm	
   *
   */    
  private void createInstancesMappingsSashForm() {
  	instancesMappingsSashForm = new SashForm(mainSashForm, SWT.NONE);		   
  	createChangedEObjectsComposite();
  	createRemovedEObjectsComposite();
    instancesMappingsSashForm.SASH_WIDTH = 1;
  }

  /**
   * This method initializes initialInstancesMappingsComposite	
   *
   */    
  private void createInitialInstancesMappingsComposite() {
  	GridLayout gridLayout3 = new GridLayout();
  	gridLayout3.horizontalSpacing = 0;
  	gridLayout3.marginWidth = 0;
  	gridLayout3.verticalSpacing = 0;
  	gridLayout3.marginHeight = 0;
  	GridData gridData1 = new GridData();
  	gridData1.grabExcessHorizontalSpace = true;
  	gridData1.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	initialInstancesMappingsComposite = new Composite(mainSashForm, SWT.BORDER);		   
  	initialInstancesMappingsLabel = new CLabel(initialInstancesMappingsComposite, SWT.CENTER);
  	initialInstancesMappingsLabel.setText("Initial Mappings");
  	createInitialInstancesMappingsTree();
  	initialInstancesMappingsComposite.setLayout(gridLayout3);
  	initialInstancesMappingsLabel.setLayoutData(gridData1);
  }

  /**
   * This method initializes initialInstancesMappingsTree	
   *
   */    
  private void createInitialInstancesMappingsTree() {
  	GridData gridData8 = new GridData();
  	gridData8.grabExcessHorizontalSpace = true;
  	gridData8.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData8.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData8.grabExcessVerticalSpace = true;
  	initialInstancesMappingsTree = new Tree(initialInstancesMappingsComposite, SWT.NONE);		   
  	initialInstancesMappingsTree.setLayoutData(gridData8);
    initialInstancesMappingsTreeViewer = new TreeViewer(initialInstancesMappingsTree);
    AdapterFactory registeredFactories = new ComposedAdapterFactory(ComposedAdapterFactory.Descriptor.Registry.INSTANCE);
    AdapterFactory reflectiveFactory = new ReflectiveItemProviderAdapterFactory();
    AdapterFactory adapterFactory = new ComposedAdapterFactory(new AdapterFactory[]{
        new com.metys.merlin.generation.mappingmodel.mapping.provider.MappingItemProviderAdapterFactory(),
        registeredFactories,
        new ResourceItemProviderAdapterFactory(),
        new MappingItemProviderAdapterFactory(),
        new EcoreItemProviderAdapterFactory(),
        reflectiveFactory});
    initialInstancesMappingsTreeViewer.setContentProvider(new AdapterFactoryContentProvider(adapterFactory){
      public Object [] getElements(Object object) {
        if (object instanceof Collection) {
          return ((Collection)object).toArray();
        }
        return super.getElements(object);
      }
    });
    initialInstancesMappingsTreeViewer.setLabelProvider(new AdapterFactoryLabelProvider(adapterFactory));
  }

}  //  @jve:decl-index=0:visual-constraint="10,10"
