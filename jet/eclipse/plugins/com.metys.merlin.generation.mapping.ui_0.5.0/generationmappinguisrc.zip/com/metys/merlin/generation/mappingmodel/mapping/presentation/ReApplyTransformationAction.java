package com.metys.merlin.generation.mappingmodel.mapping.presentation;

import org.eclipse.core.resources.IFile;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.mapping.MappingRoot;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionDelegate;

import com.metys.merlin.generation.mappingmodel.MappingModelPlugin;
import com.metys.merlin.generation.mappingmodel.util.MappingModelUtil;

public class ReApplyTransformationAction extends ActionDelegate {
  protected IFile file;

  public ReApplyTransformationAction()
  {
    super();
  }

  public ReApplyTransformationAction(IEditorPart editorPart)
  {
    this();
  }

  public void dispose()
  {
    file = null;
    super.dispose();
  }

  public void selectionChanged(IAction action, ISelection selection)
  {
    if (selection instanceof IStructuredSelection)
    {
      Object object = ((IStructuredSelection)selection).getFirstElement();
      if (object instanceof IFile)
      {
        file = (IFile)object;
        action.setEnabled(checkFileType(file));
        return;
      }
    }
    file = null;
    action.setEnabled(false);
  }

  public boolean checkFileType(IFile aFile) {
    if (aFile == null)
      return false;
    ResourceSet resourceSet = new ResourceSetImpl();
    String initialMappingsResourcePath = file.getFullPath().toString();
    URI initialMappingsResourceURI = URI.createPlatformResourceURI(initialMappingsResourcePath);
    try {
      Resource initialMappingsResource = resourceSet.getResource(initialMappingsResourceURI, true);
      if (initialMappingsResource != null && !initialMappingsResource.getContents().isEmpty()) {
        EObject initialMappingsTopContent = (EObject) initialMappingsResource.getContents().get(0);
        if (!(initialMappingsTopContent instanceof MappingRoot))
          return false;
        MappingRoot initialMappingRoot = (MappingRoot)initialMappingsTopContent;
        if (initialMappingRoot.getTypeMappingRoot() == null)
          return false;              
        if (MappingModelUtil.getFirstInput(initialMappingRoot) == null)
          return false;
      }
    } catch (Exception e) {
      MappingModelPlugin.INSTANCE.log(e);
      return false;
    }
    return true;
  }
  /**
   * This is only called when being used as an editor action delegate.
   */
  public void setActiveEditor(IAction action, IEditorPart targetEditor)
  {
    if (targetEditor != null)
    {
      IEditorInput input = targetEditor.getEditorInput();
      if (input instanceof IFileEditorInput)
      {
        file = ((IFileEditorInput)input).getFile();
        action.setEnabled(checkFileType(file));
        return;
      }
    }
    file = null;
    action.setEnabled(false);
  }
  
  public void run(IAction action)
  {
    run(PlatformUI.getWorkbench(), PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell(), file);
  }

  protected void run(IWorkbench workbench, Shell shell, IFile aFile)
  {
    TransformationWizard wizard = new TransformationWizard();
    wizard.init(workbench, new StructuredSelection(aFile));
    wizard.setInitialMappingsResourcePath(aFile.getFullPath().toString());    
    
    WizardDialog wizardDialog = new WizardDialog(shell, wizard);
    wizardDialog.create();
    wizardDialog.getShell().setSize(650, 750);
    wizardDialog.open();
  }
}
