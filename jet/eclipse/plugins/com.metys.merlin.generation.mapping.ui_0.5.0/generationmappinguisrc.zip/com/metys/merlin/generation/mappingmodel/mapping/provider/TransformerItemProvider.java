/**
 * <copyright>
 * </copyright>
 *
 * $Id: TransformerItemProvider.java,v 1.1 2005/07/07 21:32:50 jcheuoua Exp $
 */
package com.metys.merlin.generation.mappingmodel.mapping.provider;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.util.ResourceLocator;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

import com.metys.merlin.generation.mappingmodel.MappingModelUIPlugin;
import com.metys.merlin.generation.mappingmodel.mapping.MappingFactory;
import com.metys.merlin.generation.mappingmodel.mapping.MappingPackage;
import com.metys.merlin.generation.mappingmodel.mapping.Transformer;

/**
 * This is the item provider adapter for a {@link com.metys.merlin.generation.mappingmodel.mapping.Transformer} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class TransformerItemProvider extends ItemProviderAdapter implements IEditingDomainItemProvider,
    IStructuredItemContentProvider, ITreeItemContentProvider, IItemLabelProvider, IItemPropertySource {
  /**
   * This constructs an instance from a factory and a notifier.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TransformerItemProvider(AdapterFactory adapterFactory) {
    super(adapterFactory);
  }

  /**
   * This returns the property descriptors for the adapted class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getPropertyDescriptors(Object object) {
    if (itemPropertyDescriptors == null) {
      super.getPropertyDescriptors(object);

      addTypeMappingRootPropertyDescriptor(object);
      addMappingRootPropertyDescriptor(object);
      addTargetContextPropertyDescriptor(object);
      addSourceContextPropertyDescriptor(object);
      addChangeDescriptionPropertyDescriptor(object);
    }
    return itemPropertyDescriptors;
  }

  /**
   * This adds a property descriptor for the Type Mapping Root feature.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void addTypeMappingRootPropertyDescriptor(Object object) {
    itemPropertyDescriptors
        .add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
            getResourceLocator(), getString("_UI_Transformer_typeMappingRoot_feature"),
            getString("_UI_PropertyDescriptor_description", "_UI_Transformer_typeMappingRoot_feature",
                "_UI_Transformer_type"), MappingPackage.eINSTANCE.getTransformer_TypeMappingRoot(), true, null, null,
            null));
  }

  /**
   * This adds a property descriptor for the Mapping Root feature.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void addMappingRootPropertyDescriptor(Object object) {
    itemPropertyDescriptors.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory)
        .getRootAdapterFactory(), getResourceLocator(), getString("_UI_Transformer_mappingRoot_feature"), getString(
        "_UI_PropertyDescriptor_description", "_UI_Transformer_mappingRoot_feature", "_UI_Transformer_type"),
        MappingPackage.eINSTANCE.getTransformer_MappingRoot(), true, null, null, null));
  }

  /**
   * This adds a property descriptor for the Change Description feature.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void addChangeDescriptionPropertyDescriptor(Object object) {
    itemPropertyDescriptors.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory)
        .getRootAdapterFactory(), getResourceLocator(), getString("_UI_Transformer_changeDescription_feature"),
        getString("_UI_PropertyDescriptor_description", "_UI_Transformer_changeDescription_feature",
            "_UI_Transformer_type"), MappingPackage.eINSTANCE.getTransformer_ChangeDescription(), true, null, null,
        null));
  }

  /**
   * This adds a property descriptor for the Target Context feature.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void addTargetContextPropertyDescriptor(Object object) {
    itemPropertyDescriptors.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory)
        .getRootAdapterFactory(), getResourceLocator(), getString("_UI_Transformer_targetContext_feature"), getString(
        "_UI_PropertyDescriptor_description", "_UI_Transformer_targetContext_feature", "_UI_Transformer_type"),
        MappingPackage.eINSTANCE.getTransformer_TargetContext(), true, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
        null, null));
  }

  /**
   * This adds a property descriptor for the Source Context feature.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void addSourceContextPropertyDescriptor(Object object) {
    itemPropertyDescriptors.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory)
        .getRootAdapterFactory(), getResourceLocator(), getString("_UI_Transformer_sourceContext_feature"), getString(
        "_UI_PropertyDescriptor_description", "_UI_Transformer_sourceContext_feature", "_UI_Transformer_type"),
        MappingPackage.eINSTANCE.getTransformer_SourceContext(), true, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
        null, null));
  }

  /**
   * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
   * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
   * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Collection getChildrenFeatures(Object object) {
    if (childrenFeatures == null) {
      super.getChildrenFeatures(object);
      childrenFeatures.add(MappingPackage.eINSTANCE.getTransformer_MappingReports());
      childrenFeatures.add(MappingPackage.eINSTANCE.getTransformer_MappedInstancesFactory());
      childrenFeatures.add(MappingPackage.eINSTANCE.getTransformer_ReferenceChangeHandler());
      childrenFeatures.add(MappingPackage.eINSTANCE.getTransformer_AttributeChangeHandler());
      childrenFeatures.add(MappingPackage.eINSTANCE.getTransformer_MappedInstanceHandler());
    }
    return childrenFeatures;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EStructuralFeature getChildFeature(Object object, Object child) {
    // Check the type of the specified child object and return the proper feature to use for
    // adding (see {@link AddCommand}) it as a child.

    return super.getChildFeature(object, child);
  }

  /**
   * This returns Transformer.gif.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object getImage(Object object) {
    return getResourceLocator().getImage("full/obj16/Transformer");
  }

  /**
   * This returns the label text for the adapted class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getText(Object object) {
    return getString("_UI_Transformer_type");
  }

  /**
   * This handles model notifications by calling {@link #updateChildren} to update any cached
   * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void notifyChanged(Notification notification) {
    updateChildren(notification);

    switch (notification.getFeatureID(Transformer.class)) {
    case MappingPackage.TRANSFORMER__TARGET_CONTEXT:
    case MappingPackage.TRANSFORMER__SOURCE_CONTEXT:
      fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
      return;
    case MappingPackage.TRANSFORMER__MAPPING_REPORTS:
    case MappingPackage.TRANSFORMER__MAPPED_INSTANCES_FACTORY:
    case MappingPackage.TRANSFORMER__REFERENCE_CHANGE_HANDLER:
    case MappingPackage.TRANSFORMER__ATTRIBUTE_CHANGE_HANDLER:
    case MappingPackage.TRANSFORMER__MAPPED_INSTANCE_HANDLER:
      fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
      return;
    }
    super.notifyChanged(notification);
  }

  /**
   * This adds to the collection of {@link org.eclipse.emf.edit.command.CommandParameter}s
   * describing all of the children that can be created under this object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void collectNewChildDescriptors(Collection newChildDescriptors, Object object) {
    super.collectNewChildDescriptors(newChildDescriptors, object);

    newChildDescriptors.add(createChildParameter(MappingPackage.eINSTANCE.getTransformer_MappingReports(),
        MappingFactory.eINSTANCE.createMappingReport()));

    newChildDescriptors.add(createChildParameter(MappingPackage.eINSTANCE.getTransformer_MappedInstancesFactory(),
        MappingFactory.eINSTANCE.createMappedInstancesFactory()));

    newChildDescriptors.add(createChildParameter(MappingPackage.eINSTANCE.getTransformer_ReferenceChangeHandler(),
        MappingFactory.eINSTANCE.createReferenceChangeHandler()));

    newChildDescriptors.add(createChildParameter(MappingPackage.eINSTANCE.getTransformer_AttributeChangeHandler(),
        MappingFactory.eINSTANCE.createAttributeChangeHandler()));

    newChildDescriptors.add(createChildParameter(MappingPackage.eINSTANCE.getTransformer_MappedInstanceHandler(),
        MappingFactory.eINSTANCE.createMappedInstanceHandler()));
  }

  /**
   * Return the resource locator for this item provider's resources.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ResourceLocator getResourceLocator() {
    return MappingModelUIPlugin.INSTANCE;
  }

}
