package com.metys.merlin.generation.mappingmodel.mapping.presentation;

import java.util.Iterator;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CCombo;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Text;

import com.metys.merlin.generation.mappingmodel.rules.EvaluationMode;
import com.metys.merlin.generation.mappingmodel.rules.MappingRule;
import com.metys.merlin.generation.mappingmodel.rules.MappingRuleAction;
import com.metys.merlin.generation.mappingmodel.rules.MappingRuleCondition;
import com.metys.merlin.generation.mappingmodel.rules.PolicyKind;
import com.metys.merlin.generation.mappingmodel.rules.RulesFactory;

public class MappingRuleComposite extends Composite {

  private EObject bodyInputSelection;
  private SashForm sashForm = null;
  private Composite ruleDefinitionComposite = null;
  
  private Group conditionsGroup = null;
  private Group actionsGroup = null;
  private Composite buttonsComposite = null;
  private Button addConditionButton = null;
  private Button removeConditionButton = null;
  private Composite actionsButtonsComposite = null;
  private Button addActionButton = null;
  private Button removeActionButton = null;

  private MappingRule mappingRule;
  private List conditionsList = null;
  private List actionsList = null;
  private Composite textAreaComposite = null;  
  private Text textArea = null;
  private Group mappingExecutionModeGroup = null;
  private Label constraintsLabel = null;
  private CCombo constraintsCombo = null;
  private Label instanceCreationPolicyLabel = null;
  private CCombo instanceCreationPolicyCombo = null;
  private Group targetMatchingConditionsGroup = null;
  private List targetMatchingConditionsList = null;
  private Composite targetMatchingConditionsButtonsComposite = null;
  private Button addTargetMatchingConditionButton = null;
  private Button removeTargetMatchingConditionButton = null;
  private Group textAreaBodyGroup = null;
  
  public MappingRuleComposite(Composite parent, int style) {
    super(parent, style);
    initialize();
  }
  
  public MappingRule getMappingRule() {
    return mappingRule;
  }
  
  public void setMappingRule(MappingRule mappingRule) {
    this.mappingRule = mappingRule;
    if (mappingRule != null) {
      refreshLists(mappingRule);
      constraintsCombo.select(mappingRule.getConstraints().getValue());
      instanceCreationPolicyCombo.select(mappingRule.getPolicy().getValue());
    }
  }

  /**
   * @param mappingRule
   */
  private void refreshLists(MappingRule mappingRule) {    
    targetMatchingConditionsList.removeAll();
    actionsList.removeAll();
    conditionsList.removeAll();        
    int i = 0;
    for (Iterator iter = mappingRule.getTargetMatchingConditions().iterator(); iter.hasNext();) {
      MappingRuleCondition condition = (MappingRuleCondition) iter.next();
      String conditionStr = condition.getCondition();
      if (conditionStr == null)
        conditionStr = "";
      if (conditionStr.length() > 50) {
        conditionStr = conditionStr.substring(0, 46);
        conditionStr += "...";
      }
      targetMatchingConditionsList.add(String.valueOf(i) + " - " + conditionStr);
      i++;
    }
    i = 0;
    for (Iterator iter = mappingRule.getMappingRuleConditions().iterator(); iter.hasNext();) {
      MappingRuleCondition condition = (MappingRuleCondition) iter.next();
      String conditionStr = condition.getCondition();
      if (conditionStr == null)
        conditionStr = "";
      if (conditionStr.length() > 50) {
        conditionStr = conditionStr.substring(0, 46);
        conditionStr += "...";
      }
      conditionsList.add(String.valueOf(i) + " - " + conditionStr);
      i++;
    }
    i = 0;
    for (Iterator iter = mappingRule.getMappingRuleActions().iterator(); iter.hasNext();) {
      MappingRuleAction action = (MappingRuleAction) iter.next();
      String actionStr = action.getAction();
      if (actionStr == null)
        actionStr = "";
      if (actionStr.length() > 50) {
        actionStr = actionStr.substring(0, 46);
        actionStr += "...";
      }
      actionsList.add(String.valueOf(i) + " - " + actionStr);
      i++;
    }
  }
  
  
  private void initialize() {
    this.setLayout(new FillLayout());
    createSashForm();
    setSize(new org.eclipse.swt.graphics.Point(600,350));
  }

  /**
   * This method initializes sashForm	
   *
   */    
  private void createSashForm() {
  	sashForm = new SashForm(this, SWT.NONE);		   
  	sashForm.setOrientation(org.eclipse.swt.SWT.VERTICAL);
  	createRuleDefinitionComposite();
  	createTextAreaComposite();
    sashForm.setWeights(new int[]{2,1});
  }

  /**
   * This method initializes ruleDefinitionComposite	
   *
   */    
  private void createRuleDefinitionComposite() {
  	GridLayout gridLayout4 = new GridLayout();
  	gridLayout4.makeColumnsEqualWidth = true;
  	gridLayout4.numColumns = 2;
  	ruleDefinitionComposite = new Composite(sashForm, SWT.NONE);		   
  	ruleDefinitionComposite.setLayout(gridLayout4);
  	createGroup();
  	createMappingExecutionParametersGroup();
  	createConditionsGroup();
  	createActionsGroup();
  }

  /**
   * This method initializes conditionsGroup	
   *
   */    
  private void createConditionsGroup() {
  	GridData gridData14 = new GridData();
  	gridData14.grabExcessHorizontalSpace = true;
  	gridData14.grabExcessVerticalSpace = true;
  	gridData14.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData14.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	GridLayout gridLayout7 = new GridLayout();
  	gridLayout7.numColumns = 2;
  	GridData gridData5 = new GridData();
  	gridData5.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData5.grabExcessVerticalSpace = true;
  	gridData5.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData5.grabExcessHorizontalSpace = true;
  	conditionsGroup = new Group(ruleDefinitionComposite, SWT.NONE);		   
  	conditionsGroup.setText("Transformation Conditions");
  	conditionsGroup.setLayoutData(gridData5);
  	conditionsGroup.setLayout(gridLayout7);
  	conditionsList = new List(conditionsGroup, SWT.BORDER);
  	createButtonsComposite();
  	conditionsList.setLayoutData(gridData14);
  	conditionsList.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
  	  public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
  	    actionsList.deselectAll();
        targetMatchingConditionsList.deselectAll();
        int index = conditionsList.getSelectionIndex();
        if (index != -1) {
          MappingRuleCondition condition = (MappingRuleCondition) getMappingRule().getMappingRuleConditions().get(index);
          bodyInputSelection = condition;
          textArea.setEnabled(true);
          textArea.setText(condition.getCondition() == null ? "" : condition.getCondition());
        }
      }
  	});
  }

  /**
   * This method initializes actionsGroup	
   *
   */    
  private void createActionsGroup() {
  	GridData gridData15 = new GridData();
  	gridData15.grabExcessHorizontalSpace = true;
  	gridData15.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData15.grabExcessVerticalSpace = true;
  	gridData15.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	GridData gridData13 = new GridData();
  	gridData13.grabExcessHorizontalSpace = true;
  	gridData13.grabExcessVerticalSpace = true;
  	gridData13.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData13.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	GridLayout gridLayout10 = new GridLayout();
  	gridLayout10.numColumns = 2;
  	GridData gridData6 = new GridData();
  	gridData6.grabExcessHorizontalSpace = true;
  	gridData6.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	actionsGroup = new Group(ruleDefinitionComposite, SWT.NONE);		   
  	actionsGroup.setText("Transformation Actions");
  	actionsGroup.setLayoutData(gridData15);
  	actionsGroup.setLayout(gridLayout10);
  	actionsList = new List(actionsGroup, SWT.BORDER);
  	createActionsButtonsComposite();
  	actionsList.setLayoutData(gridData13);
  	actionsList.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
  	  public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
  		conditionsList.deselectAll();
        targetMatchingConditionsList.deselectAll();
        int index = actionsList.getSelectionIndex();
        if (index != -1) {
          MappingRuleAction action = (MappingRuleAction) getMappingRule().getMappingRuleActions().get(index);
          bodyInputSelection = action;
          textArea.setEnabled(true);
          textArea.setText(action.getAction() == null ? "" : action.getAction());
        }
  	  }
  	});
  }

  /**
   * This method initializes buttonsComposite	
   *
   */    
  private void createButtonsComposite() {
  	GridData gridData9 = new GridData();
  	gridData9.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData9.grabExcessVerticalSpace = true;
  	gridData9.horizontalAlignment = org.eclipse.swt.layout.GridData.END;
  	gridData9.grabExcessHorizontalSpace = false;
  	buttonsComposite = new Composite(conditionsGroup, SWT.NONE);		   
  	buttonsComposite.setLayout(new GridLayout());
  	buttonsComposite.setLayoutData(gridData9);
  	addConditionButton = new Button(buttonsComposite, SWT.NONE);
  	addConditionButton.setImage(new Image(Display.getCurrent(), getClass().getResourceAsStream("/com/metys/merlin/generation/mappingmodel/mapping/presentation/add.gif")));
  	removeConditionButton = new Button(buttonsComposite, SWT.NONE);
  	removeConditionButton.setImage(new Image(Display.getCurrent(), getClass().getResourceAsStream("/com/metys/merlin/generation/mappingmodel/mapping/presentation/remove.gif")));
  	removeConditionButton.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
  	  public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
  	    int index = conditionsList.getSelectionIndex();
        if (index != -1) {
          getMappingRule().getMappingRuleConditions().remove(index);
          refreshLists(getMappingRule());
        }
  	  }
  	});
  	addConditionButton.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
  	  public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
  		MappingRuleCondition condition = RulesFactory.eINSTANCE.createMappingRuleCondition();
        getMappingRule().getMappingRuleConditions().add(condition);
        conditionsList.add(getMappingRule().getMappingRuleConditions().indexOf(condition) + " - ");                  
  	  }
  	});
  }

  /**
   * This method initializes actionsButtonsComposite	
   *
   */    
  private void createActionsButtonsComposite() {
  	GridData gridData12 = new GridData();
  	gridData12.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData12.grabExcessVerticalSpace = true;
  	gridData12.horizontalAlignment = org.eclipse.swt.layout.GridData.END;
  	gridData12.grabExcessHorizontalSpace = false;
  	actionsButtonsComposite = new Composite(actionsGroup, SWT.NONE);		   
  	actionsButtonsComposite.setLayout(new GridLayout());
  	actionsButtonsComposite.setLayoutData(gridData12);
  	addActionButton = new Button(actionsButtonsComposite, SWT.NONE);
  	addActionButton.setImage(new Image(Display.getCurrent(), getClass().getResourceAsStream("/com/metys/merlin/generation/mappingmodel/mapping/presentation/add.gif")));
  	removeActionButton = new Button(actionsButtonsComposite, SWT.NONE);
  	removeActionButton.setImage(new Image(Display.getCurrent(), getClass().getResourceAsStream("/com/metys/merlin/generation/mappingmodel/mapping/presentation/remove.gif")));
  	removeActionButton.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
  	  public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
  		int index = actionsList.getSelectionIndex();
        if (index != -1) {
          getMappingRule().getMappingRuleActions().remove(index);
          refreshLists(getMappingRule());
        }
  	  }
  	});
  	addActionButton.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
  	  public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
  	    MappingRuleAction action = RulesFactory.eINSTANCE.createMappingRuleAction();
  	    getMappingRule().getMappingRuleActions().add(action);
        actionsList.add(getMappingRule().getMappingRuleActions().indexOf(action)+ " - ");
  	  }
  	});
  }

  /**
   * This method initializes textAreaComposite	
   *
   */    
  private void createTextAreaComposite() {
  	textAreaComposite = new Composite(sashForm, SWT.NONE);		   
  	textAreaComposite.setLayout(new GridLayout());
    createTextAreaBodyGroup();
  }

  /**
   * This method initializes mappingExecutionParametersGroup	
   *
   */    
  private void createMappingExecutionParametersGroup() {
  	GridData gridData11 = new org.eclipse.swt.layout.GridData();
  	gridData11.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData11.grabExcessHorizontalSpace = true;
  	gridData11.grabExcessVerticalSpace = true;
  	gridData11.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	GridData gridData2 = new GridData();
  	gridData2.grabExcessHorizontalSpace = true;
  	gridData2.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	GridData gridData1 = new GridData();
  	gridData1.grabExcessHorizontalSpace = true;
  	gridData1.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	GridLayout gridLayout = new GridLayout();
  	gridLayout.numColumns = 2;
  	mappingExecutionModeGroup = new Group(ruleDefinitionComposite, SWT.NONE);		   
  	mappingExecutionModeGroup.setText("Execution Mode");
  	mappingExecutionModeGroup.setLayoutData(gridData11);
  	mappingExecutionModeGroup.setLayout(gridLayout);
  	constraintsLabel = new Label(mappingExecutionModeGroup, SWT.NONE);
  	constraintsLabel.setText("Rule Evaluation Kind :");
  	constraintsCombo = new CCombo(mappingExecutionModeGroup, SWT.READ_ONLY);
  	constraintsCombo.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
  	  public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
		int index = constraintsCombo.getSelectionIndex();
        getMappingRule().setConstraints(EvaluationMode.get(index));
  	  }
  	});
  	constraintsCombo.setLayoutData(gridData1);
    constraintsCombo.add(EvaluationMode.get(0).getName());
    constraintsCombo.add(EvaluationMode.get(1).getName());
    constraintsCombo.add(EvaluationMode.get(2).getName());
  	instanceCreationPolicyLabel = new Label(mappingExecutionModeGroup, SWT.NONE);
  	instanceCreationPolicyLabel.setText("Transformation Policy :");
  	instanceCreationPolicyCombo = new CCombo(mappingExecutionModeGroup, SWT.READ_ONLY);
  	instanceCreationPolicyCombo.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
  	  public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
  		int index = instanceCreationPolicyCombo.getSelectionIndex();
        getMappingRule().setPolicy(PolicyKind.get(index));
  	  }
  	});
  	instanceCreationPolicyCombo.setLayoutData(gridData2);
    instanceCreationPolicyCombo.add(PolicyKind.get(0).getName());
    instanceCreationPolicyCombo.add(PolicyKind.get(1).getName());    
  }

  /**
   * This method initializes group	
   *
   */    
  private void createGroup() {
  	GridData gridData7 = new org.eclipse.swt.layout.GridData();
  	gridData7.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData7.grabExcessHorizontalSpace = true;
  	gridData7.grabExcessVerticalSpace = true;
  	gridData7.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	GridData gridData3 = new GridData();
  	gridData3.horizontalAlignment = GridData.FILL;
  	gridData3.grabExcessHorizontalSpace = true;
  	gridData3.grabExcessVerticalSpace = true;
  	gridData3.verticalAlignment = GridData.FILL;
  	GridLayout gridLayout1 = new GridLayout();
  	gridLayout1.numColumns = 2;
  	targetMatchingConditionsGroup = new Group(ruleDefinitionComposite, SWT.NONE);		   
  	targetMatchingConditionsGroup.setText("Matching Conditions");
  	targetMatchingConditionsGroup.setLayoutData(gridData7);
  	targetMatchingConditionsGroup.setLayout(gridLayout1);
  	targetMatchingConditionsList = new List(targetMatchingConditionsGroup, SWT.BORDER);
  	targetMatchingConditionsList.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
      public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
        actionsList.deselectAll();
        conditionsList.deselectAll();
        int index = targetMatchingConditionsList.getSelectionIndex();
        if (index != -1) {
          MappingRuleCondition condition = (MappingRuleCondition) getMappingRule().getTargetMatchingConditions().get(index);
          bodyInputSelection = condition;
          textArea.setEnabled(true);
          textArea.setText(condition.getCondition() == null ? "" : condition.getCondition());
        }
      }
  	});
  	targetMatchingConditionsList.setLayoutData(gridData3);
  	createTargetMatchingConditionsComposite();
  }

  /**
   * This method initializes composite	
   *
   */    
  private void createTargetMatchingConditionsComposite() {
  	GridData gridData4 = new GridData();
  	gridData4.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData4.grabExcessVerticalSpace = true;
  	gridData4.horizontalAlignment = org.eclipse.swt.layout.GridData.END;
  	gridData4.grabExcessHorizontalSpace = false;
  	targetMatchingConditionsButtonsComposite = new Composite(targetMatchingConditionsGroup, SWT.NONE);		   
  	targetMatchingConditionsButtonsComposite.setLayout(new GridLayout());
  	targetMatchingConditionsButtonsComposite.setLayoutData(gridData4);
  	addTargetMatchingConditionButton = new Button(targetMatchingConditionsButtonsComposite, SWT.NONE);
  	addTargetMatchingConditionButton.setImage(new Image(Display.getCurrent(), getClass().getResourceAsStream("/com/metys/merlin/generation/mappingmodel/mapping/presentation/add.gif")));
  	removeTargetMatchingConditionButton = new Button(targetMatchingConditionsButtonsComposite, SWT.NONE);
  	removeTargetMatchingConditionButton.setImage(new Image(Display.getCurrent(), getClass().getResourceAsStream("/com/metys/merlin/generation/mappingmodel/mapping/presentation/remove.gif")));
    removeTargetMatchingConditionButton.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
      public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
        int index = conditionsList.getSelectionIndex();
        if (index != -1) {
          getMappingRule().getTargetMatchingConditions().remove(index);
          refreshLists(getMappingRule());
        }
      }
    });
    addTargetMatchingConditionButton.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
      public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
        MappingRuleCondition condition = RulesFactory.eINSTANCE.createMappingRuleCondition();
        getMappingRule().getTargetMatchingConditions().add(condition);
        targetMatchingConditionsList.add(getMappingRule().getTargetMatchingConditions().indexOf(condition) + " - ");          
      }
    });
  }

  /**
   * This method initializes textAreaBodyGroup	
   *
   */    
  private void createTextAreaBodyGroup() {
  	GridData gridData = new org.eclipse.swt.layout.GridData();
  	gridData.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData.grabExcessHorizontalSpace = true;
  	gridData.grabExcessVerticalSpace = true;
  	gridData.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	textAreaBodyGroup = new Group(textAreaComposite, SWT.NONE);
  	textAreaBodyGroup.setLayout(new FillLayout());
  	textAreaBodyGroup.setLayoutData(gridData);
  	textAreaBodyGroup.setText("Body");
    textArea = new Text(textAreaBodyGroup, SWT.MULTI | SWT.WRAP | SWT.V_SCROLL | SWT.BORDER);        
    textArea.addModifyListener(new org.eclipse.swt.events.ModifyListener() { 
      public void modifyText(org.eclipse.swt.events.ModifyEvent e) {    
        if (bodyInputSelection instanceof MappingRuleAction) {
          MappingRuleAction action = (MappingRuleAction) bodyInputSelection;
          action.setAction(textArea.getText());
        }
        else if (bodyInputSelection instanceof MappingRuleCondition) {
          MappingRuleCondition condition = (MappingRuleCondition) bodyInputSelection;
          condition.setCondition(textArea.getText());          
        }
      }
     });
    textArea.setEnabled(false);
  }

}  //  @jve:decl-index=0:visual-constraint="10,10"
