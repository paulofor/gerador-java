package com.metys.merlin.generation.mappingmodel.mapping.presentation;

import java.util.Iterator;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Text;

import com.metys.merlin.generation.mappingmodel.rules.MappingRule;
import com.metys.merlin.generation.mappingmodel.rules.MappingRuleAction;
import com.metys.merlin.generation.mappingmodel.rules.MappingRuleCondition;
import org.eclipse.swt.layout.GridLayout;

public class MappingRuleReadOnlyComposite extends Composite {

  private SashForm sashForm = null;
  private Composite ruleDefinitionComposite = null;
  
  private Group conditionsGroup = null;
  private Group actionsGroup = null;
  private MappingRule mappingRule;
  private List conditionsList = null;
  private List actionsList = null;
  private Composite textAreaComposite = null;  
  private Text textArea = null;
  private Group existingTargetMatchingConditionsGroup = null;
  private List existingTargetMatchingConditionsList = null;
  private Group textAreaGroup = null;
  public MappingRuleReadOnlyComposite(Composite parent, int style) {
    super(parent, style);
    initialize();
  }
  
  public MappingRule getMappingRule() {
    return mappingRule;
  }
  
  public void setMappingRule(MappingRule mappingRule) {
    this.mappingRule = mappingRule;
    if (mappingRule != null) {
      conditionsList.removeAll();
      actionsList.removeAll();
      existingTargetMatchingConditionsList.removeAll();
      textArea.setText("");
      for (Iterator iter = mappingRule.getMappingRuleConditions().iterator(); iter.hasNext();) {
        MappingRuleCondition condition = (MappingRuleCondition) iter.next();
        String conditionStr = condition.getCondition();
        if (conditionStr == null)
          conditionStr = "";
        if (conditionStr.length() > 50) {
          conditionStr = conditionStr.substring(0, 46);
          conditionStr += "...";
        }
        conditionsList.add(conditionStr);
      }
      for (Iterator iter = mappingRule.getMappingRuleActions().iterator(); iter.hasNext();) {
        MappingRuleAction action = (MappingRuleAction) iter.next();
        String actionStr = action.getAction();
        if (actionStr == null)
          actionStr = "";
        if (actionStr.length() > 50) {
          actionStr = actionStr.substring(0, 46);
          actionStr += "...";
        }
        actionsList.add(actionStr);
      }
      for (Iterator iter = mappingRule.getTargetMatchingConditions().iterator(); iter.hasNext();) {
        MappingRuleCondition condition = (MappingRuleCondition) iter.next();
        String conditionStr = condition.getCondition();
        if (conditionStr == null)
          conditionStr = "";
        if (conditionStr.length() > 50) {
          conditionStr = conditionStr.substring(0, 46);
          conditionStr += "...";
        }
        existingTargetMatchingConditionsList.add(conditionStr);
      }
    }
  }
  
 
  private void initialize() {
    this.setLayout(new FillLayout());
    createSashForm();
    setSize(new org.eclipse.swt.graphics.Point(600,350));
  }

  /**
   * This method initializes sashForm	
   *
   */    
  private void createSashForm() {
  	sashForm = new SashForm(this, SWT.NONE);		   
  	sashForm.setOrientation(org.eclipse.swt.SWT.VERTICAL);
  	createRuleDefinitionComposite();
  	createTextAreaComposite();
    sashForm.setWeights(new int[] {2,1});
  }

  /**
   * This method initializes ruleDefinitionComposite	
   *
   */    
  private void createRuleDefinitionComposite() {
  	GridLayout gridLayout = new GridLayout();
  	gridLayout.numColumns = 2;
  	gridLayout.horizontalSpacing = 2;
  	gridLayout.verticalSpacing = 2;
  	gridLayout.marginWidth = 2;
  	gridLayout.marginHeight = 0;
  	gridLayout.makeColumnsEqualWidth = true;
  	ruleDefinitionComposite = new Composite(sashForm, SWT.NONE);		   
  	ruleDefinitionComposite.setLayout(gridLayout);
  	createGroup();
  	createConditionsGroup();
  	createActionsGroup();
  }

  /**
   * This method initializes conditionsGroup	
   *
   */    
  private void createConditionsGroup() {
  	GridData gridData = new org.eclipse.swt.layout.GridData();
  	gridData.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData.grabExcessHorizontalSpace = true;
  	gridData.grabExcessVerticalSpace = true;
  	gridData.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	FillLayout fillLayout = new FillLayout();
  	fillLayout.marginWidth = 5;
  	fillLayout.marginHeight = 5;
  	conditionsGroup = new Group(ruleDefinitionComposite, SWT.NONE);		   
  	conditionsGroup.setText("Transformation Conditions");
  	conditionsGroup.setLayoutData(gridData);
  	conditionsGroup.setLayout(fillLayout);
  	conditionsList = new List(conditionsGroup, SWT.BORDER | SWT.V_SCROLL);
  	conditionsList.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
  	  public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
  	    actionsList.deselectAll();
  	    existingTargetMatchingConditionsList.deselectAll();
        int index = conditionsList.getSelectionIndex();
        if (index != -1) {
          MappingRuleCondition condition = (MappingRuleCondition) getMappingRule().getMappingRuleConditions().get(index);
          textArea.setText(condition.getCondition() == null ? "" : condition.getCondition());
        }
      }
  	});
  }

  /**
   * This method initializes actionsGroup	
   *
   */    
  private void createActionsGroup() {
  	GridData gridData1 = new org.eclipse.swt.layout.GridData();
  	gridData1.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData1.grabExcessHorizontalSpace = true;
  	gridData1.grabExcessVerticalSpace = true;
  	gridData1.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	FillLayout fillLayout1 = new FillLayout();
  	fillLayout1.marginWidth = 5;
  	fillLayout1.marginHeight = 5;
  	GridData gridData6 = new GridData();
  	gridData6.grabExcessHorizontalSpace = true;
  	gridData6.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	actionsGroup = new Group(ruleDefinitionComposite, SWT.NONE);		   
  	actionsGroup.setText("Transformation Actions");
  	actionsGroup.setLayoutData(gridData1);
  	actionsGroup.setLayout(fillLayout1);
  	actionsList = new List(actionsGroup, SWT.BORDER | SWT.V_SCROLL);
  	actionsList.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
  	  public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
  		conditionsList.deselectAll();
        existingTargetMatchingConditionsList.deselectAll();
        int index = actionsList.getSelectionIndex();
        if (index != -1) {
          MappingRuleAction action = (MappingRuleAction) getMappingRule().getMappingRuleActions().get(index);
          textArea.setText(action.getAction() == null ? "" : action.getAction());
        }
  	  }
  	});
  }

  /**
   * This method initializes textAreaComposite	
   *
   */    
  private void createTextAreaComposite() {
  	FillLayout fillLayout16 = new FillLayout();
  	fillLayout16.marginHeight = 0;
  	fillLayout16.marginWidth = 0;
  	textAreaComposite = new Composite(sashForm, SWT.NONE);		   
  	textAreaComposite.setLayout(fillLayout16);
    createTextAreaGroup();
  }

  /**
   * This method initializes group	
   *
   */    
  private void createGroup() {
  	GridData gridData2 = new org.eclipse.swt.layout.GridData();
  	gridData2.grabExcessHorizontalSpace = true;
  	gridData2.verticalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	gridData2.grabExcessVerticalSpace = true;
  	gridData2.horizontalSpan = 2;
  	gridData2.horizontalAlignment = org.eclipse.swt.layout.GridData.FILL;
  	FillLayout fillLayout2 = new FillLayout();
  	fillLayout2.marginWidth = 5;
  	fillLayout2.marginHeight = 5;
  	existingTargetMatchingConditionsGroup = new Group(ruleDefinitionComposite, SWT.NONE);		   
  	existingTargetMatchingConditionsGroup.setText("Matching Conditions");
  	existingTargetMatchingConditionsGroup.setLayoutData(gridData2);
  	existingTargetMatchingConditionsGroup.setLayout(fillLayout2);
  	existingTargetMatchingConditionsList = new List(existingTargetMatchingConditionsGroup, SWT.BORDER | SWT.V_SCROLL);
  	existingTargetMatchingConditionsList.addSelectionListener(new org.eclipse.swt.events.SelectionAdapter() { 
  	  public void widgetSelected(org.eclipse.swt.events.SelectionEvent e) {    
        conditionsList.deselectAll();
        actionsList.deselectAll();
        int index = existingTargetMatchingConditionsList.getSelectionIndex();
        if (index != -1) {
          MappingRuleCondition condition = (MappingRuleCondition) getMappingRule().getTargetMatchingConditions().get(index);
          textArea.setText(condition.getCondition() == null ? "" : condition.getCondition());
        }
  	  }
  	});
  }

  /**
   * This method initializes textAreaGroup	
   *
   */    
  private void createTextAreaGroup() {
  	textAreaGroup = new Group(textAreaComposite, SWT.NONE);
  	textAreaGroup.setLayout(new FillLayout());
  	textAreaGroup.setText("Body");
    textArea = new Text(textAreaGroup, SWT.MULTI | SWT.WRAP | SWT.V_SCROLL | SWT.BORDER);    
    textArea.setEditable(false);
  }

}  //  @jve:decl-index=0:visual-constraint="10,10"
