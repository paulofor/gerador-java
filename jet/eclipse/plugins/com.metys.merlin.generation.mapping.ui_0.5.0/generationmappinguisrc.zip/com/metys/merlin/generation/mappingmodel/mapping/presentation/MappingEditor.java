/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.mappingmodel.mapping.presentation;

import java.net.URL;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.emf.common.command.BasicCommandStack;
import org.eclipse.emf.common.command.CommandStack;
import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.ui.ViewerPane;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.provider.EcoreItemProviderAdapterFactory;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.edit.provider.ComposedAdapterFactory;
import org.eclipse.emf.edit.provider.ReflectiveItemProviderAdapterFactory;
import org.eclipse.emf.edit.provider.resource.ResourceItemProviderAdapterFactory;
import org.eclipse.emf.mapping.MappingPlugin;
import org.eclipse.emf.mapping.MappingRoot;
import org.eclipse.emf.mapping.command.PersistentCommandStack;
import org.eclipse.emf.mapping.domain.AdapterFactoryMappingDomain;
import org.eclipse.emf.mapping.domain.MappingDomain;
import org.eclipse.emf.mapping.domain.PluginAdapterFactoryMappingDomain;
import org.eclipse.emf.mapping.provider.MappingItemProviderAdapterFactory;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.actions.WorkspaceModifyOperation;
import org.eclipse.ui.part.FileEditorInput;
import org.eclipse.ui.views.properties.IPropertySheetPage;
import org.eclipse.ui.views.properties.PropertySheetPage;

import com.metys.merlin.generation.mappingmodel.MappingModelAdapterFactoryContentProvider;
import com.metys.merlin.generation.mappingmodel.MappingModelUIPlugin;
import com.metys.merlin.generation.mappingmodel.mapping.MappingFactory;
import com.metys.merlin.generation.mappingmodel.rules.provider.RulesItemProviderAdapterFactory;

/**
 * This is an example of a ModelMapper model editor.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated NOT
 */
public class MappingEditor extends org.eclipse.emf.mapping.presentation.MappingEditor {
  public MappingEditor() {
    topLabel = MappingModelUIPlugin.getPlugin().getString("_UI_EcoreModel_label");
    bottomLabel = MappingModelUIPlugin.getPlugin().getString("_UI_EcoreModel_label");
  }

  protected void doSaveHelper(final IFile file) {
    // Do the work within an operation because this is a long running activity that modifies the workbench.
    //
    WorkspaceModifyOperation operation = new WorkspaceModifyOperation() {
      // This is the method that gets invoked when the operation runs.
      //
      protected void execute(IProgressMonitor monitor) throws CoreException {
        try {
          if (mappingDomain.getCommandStack() instanceof PersistentCommandStack) {
            mappingRoot.setCommandStack(((PersistentCommandStack) mappingDomain.getCommandStack()).getEncoding());
          }
          // Save the resource to the file system.
          //
          Resource r = mappingRoot.eResource();
          r.save(Collections.EMPTY_MAP);
          // Update the workbench's knowledge of the file's contents.
          //
          file.refreshLocal(1, monitor);
          if (!mappingRoot.isOutputReadOnly()) {
            HashSet mappedObjectResources = new HashSet();
            for (Iterator outputs = mappingRoot.getOutputs().iterator(); outputs.hasNext();) {
              EObject output = (EObject) outputs.next();
              if (output instanceof EPackage && EPackage.Registry.INSTANCE.containsKey(((EPackage) output).getNsURI()))
                continue;
              Resource mappedObjectResource = output.eResource();
              if (mappedObjectResource != null) {
                if (mappedObjectResources.add(mappedObjectResource)) {
                  mappedObjectResource.save(Collections.EMPTY_MAP);
                  URL resolvedURL = Platform.resolve(new URL(mappedObjectResource.getURI().toString()));
                  IFile mappedObjectFile = ResourcesPlugin.getWorkspace().getRoot().getFileForLocation(
                      new Path(resolvedURL.getFile()));
                  if (mappedObjectFile != null) {
                    mappedObjectFile.refreshLocal(1, monitor);
                  }
                }
              }
            }
          }
        } catch (Exception exception) {
          exception.printStackTrace();
        }
      }
    };
    try {
      // This runs the operation, and shows progress.
      // (It appears to be a bad thing to fork this onto another thread.)
      //
      new ProgressMonitorDialog(getSite().getShell()).run(false, false, operation);
      // Refresh the necessary state.
      //
      ((BasicCommandStack) mappingDomain.getCommandStack()).saveIsDone();
      firePropertyChange(IEditorPart.PROP_DIRTY);
    } catch (Exception exception) {
      // Something went wrong that shouldn't.
      //
      System.err.println(MappingPlugin.getPlugin().getString("_EXC_SaveFailed"));
      exception.printStackTrace();
    }
  }

  public static class MyMappingDomain extends PluginAdapterFactoryMappingDomain {
    /**
     * Constructor for MyMappingDomain.
     * 
     * @param mappingDomainAdapterFactory
     * @param topDomainAdapterFactory
     * @param bottomDomainAdapterFactory
     * @param commandStack
     * @param mappingDomainKey
     */
    public MyMappingDomain(AdapterFactory mappingDomainAdapterFactory, AdapterFactory topDomainAdapterFactory,
        AdapterFactory bottomDomainAdapterFactory, CommandStack commandStack, String mappingDomainKey) {
      super(mappingDomainAdapterFactory, topDomainAdapterFactory, bottomDomainAdapterFactory, commandStack,
          mappingDomainKey);
      setMappingEnablementFlags(MappingDomain.ENABLE_ALL);
    }
  }

  protected AdapterFactoryMappingDomain createMappingDomain() {
    AdapterFactory mappingAdapterFactory = new ComposedAdapterFactory(new AdapterFactory[] {
        new ResourceItemProviderAdapterFactory(),
        new com.metys.merlin.generation.mappingmodel.mapping.provider.MappingItemProviderAdapterFactory(),
        new RulesItemProviderAdapterFactory(), new MappingItemProviderAdapterFactory() });
    // This is a test case for the persistent command stack implementation.
    //
    CommandStack commandStack = new BasicCommandStack();
    ComposedAdapterFactory outputAdapterFactory = new ComposedAdapterFactory(new AdapterFactory[] {
        new ComposedAdapterFactory(ComposedAdapterFactory.Descriptor.Registry.INSTANCE),
        new ResourceItemProviderAdapterFactory(), new EcoreItemProviderAdapterFactory(),
        new ReflectiveItemProviderAdapterFactory() });
    ComposedAdapterFactory inputAdapterFactory = new ComposedAdapterFactory(new AdapterFactory[] {
        new ComposedAdapterFactory(ComposedAdapterFactory.Descriptor.Registry.INSTANCE),
        new ResourceItemProviderAdapterFactory(), new EcoreItemProviderAdapterFactory(),
        new ReflectiveItemProviderAdapterFactory() });
    // This is a test case for cross domain code.
    // It creates two instances of the factory.
    //
    AdapterFactoryMappingDomain aMappingDomain = new MyMappingDomain(mappingAdapterFactory, inputAdapterFactory,
        outputAdapterFactory, commandStack, null);
    return aMappingDomain;
  }

  public void createPages() {
    // TODO Auto-generated method stub
    super.createPages();
    //  Create a page for the preview.
    ViewerPane viewerPane = new ViewerPane(getSite().getPage(), MappingEditor.this) {
      public Viewer createViewer(Composite composite) {
        Viewer aViewer = new MappingModelPreviewViewer(composite, (MappingRoot) getMappingDomain().getMappingRoot());
        return aViewer;
      }
    };
    viewerPane.createControl(getContainer());
    viewerPane.getViewer().setInput(getEditorInput());
    int pageIndex = addPage(viewerPane.getControl());
    setPageText(pageIndex, MappingModelUIPlugin.INSTANCE.getString("_UI_MappingModelPreview_title"));
    setActivePage(0);
  }

  protected void setMappingRoot(MappingRoot mappingRoot) {
    if (mappingRoot.getTypeMappingRoot() != null) {
      mappingRoot.getTypeMappingRoot().setDomain(mappingDomain);
    }
    super.setMappingRoot(mappingRoot);
  }

  /**
   * This accesses a cached version of the property sheet.
   */
  public IPropertySheetPage getPropertySheetPage() {
    if (propertySheetPage == null) {
      propertySheetPage = new PropertySheetPage() {
        public void setActionBars(IActionBars actionBars) {
          super.setActionBars(actionBars);
          getActionBarContributor().shareGlobalActions(this, actionBars);
        }
      };
      propertySheetPage.setPropertySourceProvider(new MappingModelAdapterFactoryContentProvider(mappingDomain
          .getAdapterFactory()));
    }
    return propertySheetPage;
  }

  /**
   * @see org.eclipse.emf.mapping.presentation.MappingEditor#handleMissingModelFile()
   */
  protected void handleMissingModelFile() {
    try {
      IFile mappingModelFile = modelFile.getFile().getParent().getFile(
          new Path(new Path(modelFile.getName()).removeFileExtension().toOSString() + ".mapping"));
      MappingRoot originalRootObject = (MappingRoot) ((Resource) mappingDomain.getResourceSet().getResources()
          .iterator().next()).getContents().get(0);
      // Switch over.
      //
      modelFile = new FileEditorInput(mappingModelFile);
      Resource mappingModelResource = null;
      if (mappingModelFile.exists()) {
        Resource resource = mappingDomain.loadResource(getURIFromFile(modelFile.getFile()));
        mappingRoot = (MappingRoot) resource.getContents().get(0);
      } else {
        // Get the resource factory for this type of file name.
        //
        mappingModelResource = mappingDomain.getResourceSet().createResource(
            URI.createFileURI(modelFile.getFile().getFullPath().toString()));
        // Add the initial model object to the extent.
        //
        mappingRoot = MappingFactory.eINSTANCE.createTypeMappingRoot();
        mappingModelResource.getContents().add(mappingRoot);
        mappingDomain.getResourceSet().getResources().add(mappingModelResource);
        mappingRoot.getInputs().add(originalRootObject);
        IFile outputModelFile = modelFile.getFile().getParent().getFile(
            new Path(new Path(modelFile.getName()).removeFileExtension().toOSString() + "_mapper_result.classside"));
        Resource outputResource = null;
        if (outputModelFile.exists()) {
          outputResource = mappingDomain.loadResource(getURIFromFile(outputModelFile));
        } else {
          // Get the resource factory for this type of file name.
          //
          outputResource = mappingDomain.getResourceSet()
              .createResource(URI.createURI(getURIFromFile(outputModelFile)));
          MappingRoot templateMappingRoot = MappingFactory.eINSTANCE.createTypeMappingRoot();
          outputResource.getContents().add(templateMappingRoot);
          mappingRoot.getOutputs().addAll(outputResource.getContents());
        }
        doSave(null);
      }
      mappingRoot.setDomain(mappingDomain);
      mappingRoot.setTopToBottom(true);
    } catch (Exception exception) {
      exception.printStackTrace();
    }
  }
}