/**
 * <copyright>
 * </copyright>
 *
 * $Id: MappingIdentifierItemProvider.java,v 1.1 2005/07/07 21:32:50 jcheuoua Exp $
 */
package com.metys.merlin.generation.mappingmodel.mapping.provider;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.util.ResourceLocator;
import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ViewerNotification;
import org.eclipse.emf.mapping.provider.MappingHelperItemProvider;

import com.metys.merlin.generation.mappingmodel.MappingModelUIPlugin;
import com.metys.merlin.generation.mappingmodel.mapping.MappingFactory;
import com.metys.merlin.generation.mappingmodel.mapping.MappingIdentifier;
import com.metys.merlin.generation.mappingmodel.mapping.MappingPackage;
import com.metys.merlin.generation.mappingmodel.rules.RulesFactory;

/**
 * This is the item provider adapter for a {@link com.metys.merlin.generation.mappingmodel.mapping.MappingIdentifier} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class MappingIdentifierItemProvider extends MappingHelperItemProvider implements IEditingDomainItemProvider,
    IStructuredItemContentProvider, ITreeItemContentProvider, IItemLabelProvider, IItemPropertySource {
  /**
   * This constructs an instance from a factory and a notifier.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MappingIdentifierItemProvider(AdapterFactory adapterFactory) {
    super(adapterFactory);
  }

  /**
   * This returns the property descriptors for the adapted class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getPropertyDescriptors(Object object) {
    if (itemPropertyDescriptors == null) {
      super.getPropertyDescriptors(object);

      addIdPropertyDescriptor(object);
      addMappingKindPropertyDescriptor(object);
    }
    return itemPropertyDescriptors;
  }

  /**
   * This adds a property descriptor for the Id feature.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void addIdPropertyDescriptor(Object object) {
    itemPropertyDescriptors.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory)
        .getRootAdapterFactory(), getResourceLocator(), getString("_UI_MappingIdentifier_id_feature"), getString(
        "_UI_PropertyDescriptor_description", "_UI_MappingIdentifier_id_feature", "_UI_MappingIdentifier_type"),
        MappingPackage.eINSTANCE.getMappingIdentifier_Id(), true, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null,
        null));
  }

  /**
   * This adds a property descriptor for the Mapping Kind feature.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void addMappingKindPropertyDescriptor(Object object) {
    itemPropertyDescriptors.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory)
        .getRootAdapterFactory(), getResourceLocator(), getString("_UI_MappingIdentifier_mappingKind_feature"),
        getString("_UI_PropertyDescriptor_description", "_UI_MappingIdentifier_mappingKind_feature",
            "_UI_MappingIdentifier_type"), MappingPackage.eINSTANCE.getMappingIdentifier_MappingKind(), true,
        ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
  }

  /**
   * This returns MappingIdentifier.gif.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object getImage(Object object) {
    return getResourceLocator().getImage("full/obj16/MappingIdentifier");
  }

  /**
   * This returns the label text for the adapted class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getText(Object object) {
    String label = ((MappingIdentifier) object).getId();
    return label == null || label.length() == 0 ? getString("_UI_MappingIdentifier_type")
        : getString("_UI_MappingIdentifier_type") + " " + label;
  }

  /**
   * This handles model notifications by calling {@link #updateChildren} to update any cached
   * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void notifyChanged(Notification notification) {
    updateChildren(notification);

    switch (notification.getFeatureID(MappingIdentifier.class)) {
    case MappingPackage.MAPPING_IDENTIFIER__ID:
    case MappingPackage.MAPPING_IDENTIFIER__MAPPING_KIND:
      fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
      return;
    }
    super.notifyChanged(notification);
  }

  /**
   * This adds to the collection of {@link org.eclipse.emf.edit.command.CommandParameter}s
   * describing all of the children that can be created under this object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void collectNewChildDescriptors(Collection newChildDescriptors, Object object) {
    super.collectNewChildDescriptors(newChildDescriptors, object);

    newChildDescriptors.add(createChildParameter(org.eclipse.emf.mapping.MappingPackage.eINSTANCE
        .getMappingHelper_Nested(), MappingFactory.eINSTANCE.createMappingIdentifier()));

    newChildDescriptors.add(createChildParameter(org.eclipse.emf.mapping.MappingPackage.eINSTANCE
        .getMappingHelper_Nested(), RulesFactory.eINSTANCE.createMappingRule()));
  }

  /**
   * Return the resource locator for this item provider's resources.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ResourceLocator getResourceLocator() {
    return MappingModelUIPlugin.INSTANCE;
  }

}
