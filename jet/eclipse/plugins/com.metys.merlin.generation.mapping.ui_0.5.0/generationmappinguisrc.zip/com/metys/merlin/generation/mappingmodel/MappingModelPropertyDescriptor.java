/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.mappingmodel;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.ui.provider.PropertyDescriptor;
import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.swt.widgets.Composite;

/**
 * @author Jo�l
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MappingModelPropertyDescriptor extends PropertyDescriptor {
  
  private AdapterFactory adapterFactory;
  /**
   * @param object
   * @param itemPropertyDescriptor
   */
  public MappingModelPropertyDescriptor(AdapterFactory adapterFactory, Object object, IItemPropertyDescriptor itemPropertyDescriptor) {
    super(object, itemPropertyDescriptor);
    this.adapterFactory = adapterFactory;
  }
  
  /*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.views.properties.IPropertyDescriptor#createPropertyEditor(org.eclipse.swt.widgets.Composite)
	 */
	public CellEditor createPropertyEditor(Composite composite) {    
	  Object feature = itemPropertyDescriptor.getFeature(object);
//    if (feature == RulesPackage.eINSTANCE.getMappingRuleAction_Action() ||
//        feature == RulesPackage.eINSTANCE.getMappingRuleCondition_Condiition()) {
//      final String dialogLabel = (feature == RulesPackage.eINSTANCE.getMappingRuleAction_Action()) ? 
//          MappingModelUIPlugin.INSTANCE.getString("_UI_ActionScript_label") :
//          MappingModelUIPlugin.INSTANCE.getString("_UI_ConditionScript_label");
//      CellEditor cellEditor = new DialogCellEditor(composite) {
//        protected Object openDialogBox(Control cellEditorWindow) {
//          
//          ResourceSelectionDialog containerSelectionDialog = new ResourceSelectionDialog(cellEditorWindow
//              .getShell(), ResourcesPlugin.getWorkspace().getRoot(), dialogLabel);
//          containerSelectionDialog.open();
//          Object[] result = containerSelectionDialog.getResult();
//          if (result != null) {
//            for (int i = 0; i < result.length; i++) {
//              if (result[i] instanceof IResource) {
//                IResource resource = (IResource) result[i];
//                return resource.getFullPath().toString();
//              }
//            }
//          }
//          return null;
//        }        
//      };
//      return cellEditor;          
//    }
//	  if (feature == ModelMapperPackage.eINSTANCE.getModelMapper_InputFilePath()
//        || feature == ModelMapperPackage.eINSTANCE.getModelMapper_MappingFilePath()) {
//      final String dialogLabel = (feature == ModelMapperPackage.eINSTANCE.getModelMapper_MappingFilePath()) ? ModelMappingUIPlugin.INSTANCE
//          .getString("_UI_SelectMappingFile_label")
//          : ModelMappingUIPlugin.INSTANCE.getString("_UI_SelectModelFile_label");
//      CellEditor cellEditor = new DialogCellEditor(composite) {
//        protected Object openDialogBox(Control cellEditorWindow) {
//          ResourceSelectionDialog containerSelectionDialog = new ResourceSelectionDialog(cellEditorWindow
//              .getShell(), ResourcesPlugin.getWorkspace().getRoot(), dialogLabel);
//          containerSelectionDialog.open();
//          Object[] result = containerSelectionDialog.getResult();
//          if (result != null) {
//            for (int i = 0; i < result.length; i++) {
//              if (result[i] instanceof IResource) {
//                IResource resource = (IResource) result[i];
//                return resource.getFullPath().toString();
//              }
//            }
//          }
//          return null;
//        }        
//      };
//      return cellEditor;
//    }    
//	  if (feature == ModelMapperPackage.eINSTANCE.getModelMapper_OutputFilePath()) {
//	    CellEditor cellEditor = new DialogCellEditor(composite) {
//        protected Object openDialogBox(Control cellEditorWindow) {
//          MappingModelCreationDialog fileCreationDialog = new MappingModelCreationDialog(cellEditorWindow.getShell());
//          fileCreationDialog.open();
//          IPath result = fileCreationDialog.getResult();
//          if (result != null) {
//            return result.toString();            
//          }
//          return null;
//        }        
//      };
//      return cellEditor;
//	  }
		return super.createPropertyEditor(composite);
	}
}
