/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * Initial Implementation : Jo�l, 4 mai 2005
 */

package com.metys.merlin.generation.mappingmodel.mapping.presentation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.edit.provider.ComposedAdapterFactory;
import org.eclipse.emf.edit.provider.ReflectiveItemProviderAdapterFactory;
import org.eclipse.emf.edit.provider.resource.ResourceItemProviderAdapterFactory;
import org.eclipse.emf.edit.ui.provider.AdapterFactoryContentProvider;
import org.eclipse.emf.edit.ui.provider.AdapterFactoryLabelProvider;
import org.eclipse.emf.mapping.MappingRoot;
import org.eclipse.emf.mapping.provider.MappingItemProviderAdapterFactory;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.ui.dialogs.ContainerSelectionDialog;
import org.eclipse.ui.dialogs.ResourceSelectionDialog;
import org.eclipse.ui.forms.ManagedForm;
import org.eclipse.ui.forms.SectionPart;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;
import org.eclipse.ui.forms.widgets.Section;

import com.metys.merlin.generation.mappingmodel.MappingModelUIPlugin;
import com.metys.merlin.generation.mappingmodel.mapping.MappingFactory;
import com.metys.merlin.generation.mappingmodel.mapping.Transformer;


/**
 * @author Jo�l
 */
public class MappingModelPreviewViewer extends Viewer {

  private TreeViewer previewModelViewer;
  private Object fInput;
  private ScrolledForm sForm;
  
  private Text sourceResource = null;
  private Button browseSource = null; 
  private Tree sourceTree = null;
  private TreeViewer sourceTreeViewer = null;
  
  private Text targetResource = null;
  private Button browseTarget = null; 
  private Tree targetTree = null;
  private TreeViewer targetTreeViewer = null;
  
  private ISelection selection;
  
  private MappingRoot typeMappingRoot;
  
  public MappingModelPreviewViewer(Composite parent, MappingRoot typeMappingRoot) {
    Display display = parent.getDisplay();
    this.typeMappingRoot = typeMappingRoot;
    FormToolkit formToolkit = new FormToolkit(display);
    sForm = formToolkit.createScrolledForm(parent);
    ManagedForm overviewForm = new ManagedForm(formToolkit, sForm);
    Composite body = sForm.getBody();

    GridLayout layout = new GridLayout();
    layout.numColumns = 1;
    layout.marginWidth = 10;
    layout.horizontalSpacing = 10;
    layout.verticalSpacing = 10;
    body.setLayout(layout);

    createInputArgumentsSection(overviewForm, body, formToolkit);
    createTextViewerSection(overviewForm, body, formToolkit);
    
    overviewForm.initialize();
    overviewForm.refresh();    
    
  }
  
  /**
   * @param mForm
   * @param body
   * @param formToolkit
   */
  private void createInputArgumentsSection(ManagedForm mForm, Composite body, FormToolkit formToolkit) {
    final Section section = formToolkit.createSection(body, Section.TITLE_BAR);
    section.setText("Transformation Inputs"); //$NON-NLS-1$    
    Composite client = formToolkit.createComposite(section);
    GridLayout layout = new GridLayout();
    layout.marginWidth = formToolkit.getBorderStyle() != SWT.NULL ? 0 : 2;
    client.setLayout(layout);
    
    List factories = new ArrayList();
    factories.add(new ComposedAdapterFactory(ComposedAdapterFactory.Descriptor.Registry.INSTANCE));
    factories.add(new ResourceItemProviderAdapterFactory());
    factories.add(new MappingItemProviderAdapterFactory());
    factories.add(new ReflectiveItemProviderAdapterFactory());

    AdapterFactory adapterFactory = new ComposedAdapterFactory(factories);
    
    SashForm inputsSashForm = new SashForm(client, SWT.NONE);
    GridData gd = new GridData();
    gd.grabExcessHorizontalSpace = true;
    gd.horizontalAlignment = GridData.FILL;
    gd.grabExcessVerticalSpace = false;
    inputsSashForm.setLayoutData(gd);
    
    Composite sourceComposite = formToolkit.createComposite(inputsSashForm);
    layout = new GridLayout();
    layout.marginWidth = formToolkit.getBorderStyle() != SWT.NULL ? 0 : 2;
    layout.numColumns = 2;
    sourceComposite.setLayout(layout);
    
    Label sourceLabel = formToolkit.createLabel(sourceComposite, "Sources");    
    sourceLabel.setBackground(formToolkit.getColors().getInactiveBackground());
    gd = new GridData();
    gd.horizontalSpan = 2;
    gd.grabExcessHorizontalSpace = true;
    gd.horizontalAlignment = GridData.FILL;
    gd.grabExcessVerticalSpace = false;
    sourceLabel.setLayoutData(gd);
    
    sourceResource = formToolkit.createText(sourceComposite, "<Empty>");
    sourceResource.setEditable(false);
    gd = new GridData();
    gd.grabExcessHorizontalSpace = true;
    gd.horizontalAlignment = GridData.FILL;
    gd.grabExcessVerticalSpace = false;
    sourceResource.setLayoutData(gd);
    
    browseSource = formToolkit.createButton(sourceComposite, "Browse ...", SWT.NONE);
    browseSource.addSelectionListener(new SelectionAdapter() {
      public void widgetSelected(SelectionEvent e) {
        ResourceSelectionDialog resSelectionDialog = 
          new ResourceSelectionDialog(section.getShell(), ResourcesPlugin.getWorkspace().getRoot(), "Select a workspace resource");
        if (resSelectionDialog.open() == ContainerSelectionDialog.OK) {
          Object[] result = resSelectionDialog.getResult();
          if (result.length == 1) {
            String inputFile = ((IResource) result[0]).getFullPath().toString();
            sourceResource.setText(inputFile);
            ResourceSet resourceSet = new ResourceSetImpl();
            URI uri = URI.createPlatformResourceURI(inputFile);
            Resource resource = resourceSet.getResource(uri, true);
            if (resource != null)
              sourceTreeViewer.setInput(resourceSet);
          }
        }
      }
    });
    
    sourceTree = formToolkit.createTree(sourceComposite, SWT.BORDER | SWT.SINGLE);
    gd = new GridData();
    gd.horizontalSpan = 2;
    gd.horizontalAlignment = GridData.FILL;
    gd.verticalAlignment = GridData.FILL;
    gd.grabExcessVerticalSpace = true;
    sourceTree.setLayoutData(gd);
    sourceTreeViewer = new TreeViewer(sourceTree);
    
    sourceTreeViewer.setContentProvider(new AdapterFactoryContentProvider(adapterFactory));
    sourceTreeViewer.setLabelProvider(new AdapterFactoryLabelProvider(adapterFactory));
    
    Composite targetComposite = formToolkit.createComposite(inputsSashForm);
    layout = new GridLayout();
    layout.marginWidth = formToolkit.getBorderStyle() != SWT.NULL ? 0 : 2;
    layout.numColumns = 2;
    targetComposite.setLayout(layout);
    
    Label targetLabel = formToolkit.createLabel(targetComposite, "Targets");
    targetLabel.setBackground(formToolkit.getColors().getInactiveBackground());
    gd = new GridData();
    gd.horizontalSpan = 2;
    gd.grabExcessHorizontalSpace = true;
    gd.horizontalAlignment = GridData.FILL;
    gd.grabExcessVerticalSpace = false;
    targetLabel.setLayoutData(gd);
    
    targetResource = formToolkit.createText(targetComposite, "<Empty>");
    targetResource.setEditable(false);
    gd = new GridData();
    gd.horizontalSpan = 1;
    gd.grabExcessHorizontalSpace = true;
    gd.horizontalAlignment = GridData.FILL;
    gd.grabExcessVerticalSpace = false;
    targetResource.setLayoutData(gd);
    
    browseTarget = formToolkit.createButton(targetComposite, "Browse ...", SWT.NONE);
    browseTarget.addSelectionListener(new SelectionAdapter() {
      public void widgetSelected(SelectionEvent e) {
        ResourceSelectionDialog resSelectionDialog = 
          new ResourceSelectionDialog(section.getShell(), ResourcesPlugin.getWorkspace().getRoot(), "Select a workspace resource");
        if (resSelectionDialog.open() == ContainerSelectionDialog.OK) {
          Object[] result = resSelectionDialog.getResult();
          if (result.length == 1) {
            String inputFile = ((IResource) result[0]).getFullPath().toString();
            targetResource.setText(inputFile);
            ResourceSet resourceSet = new ResourceSetImpl();
            URI uri = URI.createPlatformResourceURI(inputFile);
            Resource resource = resourceSet.getResource(uri, true);
            if (resource != null)
              targetTreeViewer.setInput(resourceSet);
          }
        }
      }
    });
    
    targetTree = formToolkit.createTree(targetComposite, SWT.BORDER | SWT.SINGLE);
    gd = new GridData();
    gd.horizontalSpan = 2;
    gd.horizontalAlignment = GridData.FILL;
    gd.verticalAlignment = GridData.FILL;
    gd.grabExcessVerticalSpace = true;
    targetTree.setLayoutData(gd);
    targetTreeViewer = new TreeViewer(targetTree);
    
    targetTreeViewer.setContentProvider(new AdapterFactoryContentProvider(adapterFactory));
    targetTreeViewer.setLabelProvider(new AdapterFactoryLabelProvider(adapterFactory));
        
    Button button = formToolkit.createButton(client,"Apply", SWT.PUSH | SWT.FLAT);    
    button.addSelectionListener(new SelectionAdapter() {
      public void widgetSelected(SelectionEvent e) {
        Transformer transformer = MappingFactory.eINSTANCE.createTransformer();
        MappingRoot instancesMappingRoot = org.eclipse.emf.mapping.MappingFactory.eINSTANCE.createMappingRoot();
        instancesMappingRoot.setTypeMapping(typeMappingRoot);
        
        ResourceSet resourceSet = new ResourceSetImpl();
        
        String targetFilePath = targetResource.getText();
        URI uri = targetFilePath.equals("<Empty>") ? null : URI.createPlatformResourceURI(targetFilePath);
        Resource targetEMFResource = targetFilePath.equals("<Empty>") ? null : resourceSet.getResource(uri, true);
        
        String sourceFilePath = sourceResource.getText();
        uri = sourceFilePath.equals("<Empty>") ? null : URI.createPlatformResourceURI(sourceFilePath);
        Resource sourceEMFResource = sourceFilePath.equals("<Empty>") ? null : resourceSet.getResource(uri, true);
        
        try {
          transformer.setMappingRoot(instancesMappingRoot);
          transformer.transform(sourceEMFResource, targetEMFResource, new NullProgressMonitor());           
          previewModelViewer.setInput(transformer.getChangeDescription());
        } catch (Throwable ex) {
          previewModelViewer.setInput("/** Cannot generate preview ... The transformation failed. Check log file for details.*/");
          MappingModelUIPlugin.getPlugin().logInError(ex, null);
        }        
      }
    });
    
    section.setClient(client);
    
    gd = new GridData();
    gd.grabExcessHorizontalSpace = true;
    gd.horizontalAlignment = GridData.FILL;
    gd.verticalAlignment = GridData.BEGINNING;
    section.setLayoutData(gd);
    SectionPart sectionPart = new SectionPart(section);
    mForm.addPart(sectionPart);
  }
  
  /**
   * @param mForm
   * @param body
   * @param formToolkit
   */
  private void createTextViewerSection(ManagedForm mForm, Composite body, FormToolkit formToolkit) {
    Section section = formToolkit.createSection(body, Section.TITLE_BAR);
    section.setText("Preview"); //$NON-NLS-1$
    
    Tree previewTree = formToolkit.createTree(section, SWT.BORDER | SWT.SINGLE);
    previewModelViewer = new TreeViewer(previewTree);
    
    List factories = new ArrayList();
    factories.add(new ComposedAdapterFactory(ComposedAdapterFactory.Descriptor.Registry.INSTANCE));
    factories.add(new ResourceItemProviderAdapterFactory());
    factories.add(new MappingItemProviderAdapterFactory());
    factories.add(new ReflectiveItemProviderAdapterFactory());

    AdapterFactory adapterFactory = new ComposedAdapterFactory(factories);
    previewModelViewer.setContentProvider(new AdapterFactoryContentProvider(adapterFactory) {
      public Object[] getElements(Object inputElement) {
        if (inputElement instanceof String)
          return new Object[] {inputElement};
        if (inputElement instanceof Collection)
          return ((Collection)inputElement).toArray();
        return super.getElements(inputElement);
      }
    });
    previewModelViewer.setLabelProvider(new AdapterFactoryLabelProvider(adapterFactory));
    
    section.setClient(previewTree);
    
    GridData gd = new GridData();
    gd.horizontalAlignment = GridData.FILL;
    gd.verticalAlignment = GridData.FILL;
    gd.grabExcessHorizontalSpace = true;
    gd.grabExcessVerticalSpace = true;
    
    section.setLayoutData(gd);
    SectionPart sectionPart = new SectionPart(section);
    mForm.addPart(sectionPart);
  }
  
  public Control getControl() {
    return sForm;
  }
  
  public void setInput(Object input) {
    fInput= input;
  }
  
  public Object getInput() {
    return fInput;
  }
  
  public ISelection getSelection() {
    return selection;
  }
  
  public void setSelection(ISelection s, boolean reveal) {
    this.selection = s;
  }
  
  public void refresh() {
  }

}
