/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */

package com.metys.merlin.generation.gef.genmodel.gefeditor;

import org.eclipse.gef.editparts.ZoomManager;
import org.eclipse.gef.ui.actions.ActionBarContributor;
import org.eclipse.gef.ui.actions.DeleteRetargetAction;
import org.eclipse.gef.ui.actions.RedoRetargetAction;
import org.eclipse.gef.ui.actions.UndoRetargetAction;
import org.eclipse.gef.ui.actions.ZoomComboContributionItem;
import org.eclipse.gef.ui.actions.ZoomInRetargetAction;
import org.eclipse.gef.ui.actions.ZoomOutRetargetAction;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.ui.actions.ActionFactory;
import org.eclipse.ui.part.EditorActionBarContributor;

/**
 * The GenModelEditor GEF editor action bar contributor.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class GenModelEditorActionBarContributor extends ActionBarContributor {
  
  /**
   * @see org.eclipse.gef.ui.actions.ActionBarContributor#buildActions()
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void buildActions() {
    addRetargetAction(new UndoRetargetAction());
    addRetargetAction(new RedoRetargetAction());
    addRetargetAction(new DeleteRetargetAction());
    
    addRetargetAction(new ZoomInRetargetAction());
    addRetargetAction(new ZoomOutRetargetAction());
  }

  /**
   * @see EditorActionBarContributor#contributeToToolBar(IToolBarManager)
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated   
   */
  public void contributeToToolBar(IToolBarManager manager) {
    manager.add(getAction(ActionFactory.UNDO.getId()));
    manager.add(getAction(ActionFactory.REDO.getId()));
    
    manager.add(new Separator()); 
    String[] zoomStrings = new String[] { ZoomManager.FIT_ALL, 
                        ZoomManager.FIT_HEIGHT, 
                        ZoomManager.FIT_WIDTH };
    manager.add(new ZoomComboContributionItem(getPage(), zoomStrings));    
  }
  
  /**
   * @see org.eclipse.gef.ui.actions.ActionBarContributor#declareGlobalActionKeys()
   * @generated
   */
  protected void declareGlobalActionKeys() {
    // TODO : Implement this method to declare global action handler
    // do not forget to remove the @generated javadoc or add NOT
  }
}