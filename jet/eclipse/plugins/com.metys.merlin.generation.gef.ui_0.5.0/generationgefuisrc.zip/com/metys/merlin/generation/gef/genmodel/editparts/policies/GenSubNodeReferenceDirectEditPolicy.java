/**
 * <copyright>
 * </copyright>
 *
 * $Id: GenSubNodeReferenceDirectEditPolicy.java,v 1.2 2005/07/10 23:39:38 jcheuoua Exp $
 */

package com.metys.merlin.generation.gef.genmodel.editparts.policies;

import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.geometry.Point;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.gef.commands.Command;
import org.eclipse.gef.requests.DirectEditRequest;
import org.eclipse.jface.viewers.TextCellEditor;

import com.metys.merlin.generation.gef.commands.RenameCommand;
import com.metys.merlin.generation.gef.figures.ENodeFigure;
import com.metys.merlin.generation.gef.figures.EObjectCellEditorLocator;
import com.metys.merlin.generation.gef.figures.EObjectDirectEditManager;
import com.metys.merlin.generation.gef.genmodel.GenModelPackage;
import com.metys.merlin.generation.gef.genmodel.editparts.GenSubNodeReferenceEditPart;
import com.metys.merlin.generation.gef.genmodel.impl.GenSubNodeReferenceImpl;
import com.metys.merlin.generation.gef.model.ENode;
import com.metys.merlin.generation.gef.policies.ENodeDirectEditPolicy;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class GenSubNodeReferenceDirectEditPolicy extends ENodeDirectEditPolicy{
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Command getDirectEditCommand(DirectEditRequest request) {
    String name = (String) request.getCellEditor().getValue();
    RenameCommand cmd = new RenameCommand((GenSubNodeReferenceEditPart)getHost(), name);		
    return cmd;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void showCurrentEditValue(DirectEditRequest request) {
    GenSubNodeReferenceEditPart hostEditPart = (GenSubNodeReferenceEditPart) getHost();
    hostEditPart.refreshVisuals();
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected boolean isDirectEditLocation(Point requestLoc) {
    Point locationCopy = requestLoc.getCopy();
    GenSubNodeReferenceEditPart hostEditPart = (GenSubNodeReferenceEditPart) getHost();
    IFigure header = ((ENodeFigure) hostEditPart.getFigure()).getHeader();
    header.translateToRelative(locationCopy);
    if (header.containsPoint(locationCopy))
      return true;
    return false;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void performDirectEdit() {
  GenSubNodeReferenceEditPart hostEditPart = (GenSubNodeReferenceEditPart) getHost();
    Label header = ((ENodeFigure) hostEditPart.getFigure()).getHeader();
    if (manager == null)
      manager = new EObjectDirectEditManager(hostEditPart, TextCellEditor.class, new EObjectCellEditorLocator(header), header);    
    manager.show();
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void handleNodeNameChanged(ENode node, String newName, String oldName) {
    GenSubNodeReferenceImpl object = (GenSubNodeReferenceImpl) node.getEObject();
    EStructuralFeature labelFeature = 
      GenModelPackage.eINSTANCE.getGenSubNodeReference_ParentLayoutClass(); 
    object.eSet(labelFeature, newName);		
  }
}