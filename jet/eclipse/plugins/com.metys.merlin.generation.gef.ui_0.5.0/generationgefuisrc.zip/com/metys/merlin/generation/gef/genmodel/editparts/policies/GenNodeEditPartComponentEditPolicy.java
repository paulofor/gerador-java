/**
 * <copyright>
 * </copyright>
 *
 * $Id: GenNodeEditPartComponentEditPolicy.java,v 1.2 2005/07/10 23:39:38 jcheuoua Exp $
 */

package com.metys.merlin.generation.gef.genmodel.editparts.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gef.requests.GroupRequest;

import com.metys.merlin.generation.gef.commands.DeleteNodeCommand;
import com.metys.merlin.generation.gef.genmodel.editparts.GenNodeEditPartEditPart;
import com.metys.merlin.generation.gef.parts.GraphicalComponentEditPart;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class GenNodeEditPartComponentEditPolicy extends GenEditPartComponentEditPolicy{
    
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Command createDeleteCommand(GroupRequest deleteRequest) {
    Command deleteCmd = new DeleteNodeCommand((GraphicalComponentEditPart) getHost().getParent(), (GenNodeEditPartEditPart) getHost());
    return deleteCmd;
  }
}