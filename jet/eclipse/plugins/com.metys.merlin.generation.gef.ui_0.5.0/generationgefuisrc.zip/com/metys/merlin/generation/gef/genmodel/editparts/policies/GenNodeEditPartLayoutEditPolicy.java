/**
 * <copyright>
 * </copyright>
 *
 * $Id: GenNodeEditPartLayoutEditPolicy.java,v 1.2 2005/07/10 23:39:38 jcheuoua Exp $
 */

package com.metys.merlin.generation.gef.genmodel.editparts.policies;

import java.util.Collection;
import java.util.List;

import org.eclipse.draw2d.geometry.Point;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.Request;
import org.eclipse.gef.commands.Command;
import org.eclipse.gef.commands.CompoundCommand;
import org.eclipse.gef.commands.UnexecutableCommand;
import org.eclipse.gef.requests.CreateRequest;
import org.eclipse.gef.requests.GroupRequest;

import com.metys.merlin.generation.gef.commands.AddElementCommand;
import com.metys.merlin.generation.gef.commands.ChangeBoundsCommand;
import com.metys.merlin.generation.gef.commands.CreateElementCommand;
import com.metys.merlin.generation.gef.commands.OrphanNodeCommand;
import com.metys.merlin.generation.gef.commands.TransferLinkCommand;
import com.metys.merlin.generation.gef.genmodel.GenModelPackage;
import com.metys.merlin.generation.gef.genmodel.editparts.GenNodeEditPartEditPart;
import com.metys.merlin.generation.gef.genmodel.impl.GenNodeEditPartImpl;
import com.metys.merlin.generation.gef.model.EDiagram;
import com.metys.merlin.generation.gef.model.ELink;
import com.metys.merlin.generation.gef.model.ENode;
import com.metys.merlin.generation.gef.model.EObjectLink;
import com.metys.merlin.generation.gef.model.EReferenceLink;
import com.metys.merlin.generation.gef.model.ModelFactory;
import com.metys.merlin.generation.gef.outline.ClassLinkModel;
import com.metys.merlin.generation.gef.outline.LinkModel;
import com.metys.merlin.generation.gef.outline.ReferenceLinkModel;
import com.metys.merlin.generation.gef.parts.EDiagramEditPart;
import com.metys.merlin.generation.gef.parts.ENodeEditPart;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class GenNodeEditPartLayoutEditPolicy extends GenEditPartLayoutEditPolicy{
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Command createChangeConstraintCommand(EditPart child, Object constraint) {
    Rectangle rec = (Rectangle) constraint;
    Point newLocation = new Point(rec.x, rec.y);
    return new ChangeBoundsCommand((ENodeEditPart)child, newLocation, rec.width, rec.height);
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Command createAddCommand(EditPart childEditPart, Object constraint) {
    ENode child = (ENode) childEditPart.getModel();
    ENode parent = (ENode) (getHost().getModel());
    Point location = new Point();
    if (constraint instanceof Rectangle) {
      location.x = ((Rectangle) constraint).x;
      location.y = ((Rectangle) constraint).y;
    }
    AddElementCommand add = new AddElementCommand((GenNodeEditPartEditPart)getHost(), child, location);
    return add;
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Command getCreateCommand(CreateRequest request) {
    GenNodeEditPartEditPart hostEditPart = (GenNodeEditPartEditPart)getHost();
    Point loc = request.getLocation();
    if (request.getNewObject() instanceof ENode) {      
      hostEditPart.getContentPane().translateToRelative(loc);
      return new CreateElementCommand(hostEditPart,(ENode)request.getNewObject(), loc);
    } else if (request.getNewObject() instanceof EObject) {
      ENode node = ModelFactory.eINSTANCE.createENode();
      node.setEObject((EObject) request.getNewObject());
      return new CreateElementCommand(hostEditPart, node, loc);        
    } else if (request.getNewObject() instanceof List) {
      List views = (List)request.getNewObject();      
      if (views.isEmpty())
        return UnexecutableCommand.INSTANCE;
      CompoundCommand command = new CompoundCommand();
      hostEditPart.getContentPane().translateToRelative(loc);
      for (int i = 0; i < views.size(); i++) {
        Object view = views.get(i);
        if (view instanceof ENode) {
          hostEditPart.getContentPane().translateToRelative(loc);
          command.add(new CreateElementCommand(hostEditPart,(ENode)view, loc.getTranslated(i * 40, i * 40)));
        } else if (view instanceof EObject) {
          ENode node = ModelFactory.eINSTANCE.createENode();
          node.setEObject((EObject) view);
          command.add(new CreateElementCommand(hostEditPart, node, loc.getTranslated(i * 40, i * 40)));        
        } else if (view instanceof LinkModel) {
          LinkModel linkModel = (LinkModel) view;
          EDiagram diagram = getDiagram();
          ENode sourceNode = diagram.getENode(linkModel.getEObject());
          ENode targetNode = diagram.getENode(linkModel.getRefEObject());
          // Look for the edit parts in the contents of this parent
          EDiagramEditPart diagramEditPart = null;
          EditPart parent = hostEditPart;
          while (!(parent instanceof EDiagramEditPart) && parent != null)
            parent = parent.getParent();
          if (parent instanceof EDiagramEditPart)
            diagramEditPart = (EDiagramEditPart) parent;
          ENodeEditPart sourceEditPart = diagramEditPart.findNodeEditPart(sourceNode);
          ENodeEditPart targetEditPart = diagramEditPart.findNodeEditPart(targetNode);          
          ELink link = null;
          if (linkModel instanceof ReferenceLinkModel) {
            link = ModelFactory.eINSTANCE.createEReferenceLink();
            ((EReferenceLink)link).setEReference(((ReferenceLinkModel)linkModel).getEReference());
          } else if (linkModel instanceof ClassLinkModel) {
            link = ModelFactory.eINSTANCE.createEObjectLink();
            ((EObjectLink)link).setTransitionEObject(((ClassLinkModel)linkModel).getTransitionObject());
            ((EObjectLink)link).setSourceReference(((ClassLinkModel)linkModel).getSourceRef());
            ((EObjectLink)link).setTargetReference(((ClassLinkModel)linkModel).getTargetRef());
          }
          command.add(new TransferLinkCommand(link, sourceEditPart, targetEditPart));
        }
      }
      return command;
    }
    return UnexecutableCommand.INSTANCE;
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Command getOrphanChildrenCommand(Request request) {
    GroupRequest gRequest = (GroupRequest) request;
    List parts = gRequest.getEditParts();
    CompoundCommand result = new CompoundCommand();
    for (int i = 0; i < parts.size(); i++) {
      ENode parent = (ENode) getHost().getModel();
      ENode child = (ENode) ((EditPart) parts.get(i)).getModel();           
      OrphanNodeCommand orphan 
      	= new OrphanNodeCommand((GenNodeEditPartEditPart)getHost(), child);
      result.add(orphan);
    }
    return result.unwrap();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean acceptAdd(ENode child) {
    if (GenModelPackage.eINSTANCE.getGenNodeEditPart_GenFigure().getEReferenceType().isInstance(child.getEObject()))
        return true;
    if (GenModelPackage.eINSTANCE.getGenNodeEditPart_SubNodeReferences().getEReferenceType().isInstance(child.getEObject()))
        return true;
    return false;    
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean acceptRemove(ENode child) {
    return true;
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void handleNodeAdded(ENode parent, ENode child) {  	
    {
      GenNodeEditPartImpl object = (GenNodeEditPartImpl) parent.getEObject();
      if (GenModelPackage.eINSTANCE.getGenNodeEditPart_GenFigure().getEReferenceType().isInstance(child.getEObject())) {
     	  object.eSet(GenModelPackage.eINSTANCE.getGenNodeEditPart_GenFigure(), child.getEObject());
      }
    }
    {
      GenNodeEditPartImpl object = (GenNodeEditPartImpl) parent.getEObject();
      if (GenModelPackage.eINSTANCE.getGenNodeEditPart_SubNodeReferences().getEReferenceType().isInstance(child.getEObject())) {
        ((Collection)object.eGet(GenModelPackage.eINSTANCE.getGenNodeEditPart_SubNodeReferences())).add(child.getEObject());				
      }
    }
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void handleNodeRemoved(ENode parent, ENode child) {
    {
      GenNodeEditPartImpl object = (GenNodeEditPartImpl) parent.getEObject();
      if (GenModelPackage.eINSTANCE.getGenNodeEditPart_GenFigure().getEReferenceType().isInstance(child.getEObject())) {
     	  object.eSet(GenModelPackage.eINSTANCE.getGenNodeEditPart_GenFigure(), null);
      }
    }
    {
      GenNodeEditPartImpl object = (GenNodeEditPartImpl) parent.getEObject();
      if (GenModelPackage.eINSTANCE.getGenNodeEditPart_SubNodeReferences().getEReferenceType().isInstance(child.getEObject())) {
        ((Collection)object.eGet(GenModelPackage.eINSTANCE.getGenNodeEditPart_SubNodeReferences())).remove(child.getEObject());     	  
      }
    }
  }
}