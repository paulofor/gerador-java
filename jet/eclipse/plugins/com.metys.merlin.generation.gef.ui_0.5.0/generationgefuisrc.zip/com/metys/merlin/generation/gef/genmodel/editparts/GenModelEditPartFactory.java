/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */

package com.metys.merlin.generation.gef.genmodel.editparts;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPartFactory;

import com.metys.merlin.generation.gef.genmodel.GenEditPartFactory;
import com.metys.merlin.generation.gef.genmodel.GenEditor;
import com.metys.merlin.generation.gef.genmodel.GenFigure;
import com.metys.merlin.generation.gef.genmodel.GenGEFModel;
import com.metys.merlin.generation.gef.genmodel.GenLinkEditPart;
import com.metys.merlin.generation.gef.genmodel.GenModelPackage;
import com.metys.merlin.generation.gef.genmodel.GenNodeEditPart;
import com.metys.merlin.generation.gef.genmodel.GenPaletteComponentsFactory;
import com.metys.merlin.generation.gef.genmodel.GenPaletteConnectionsFactory;
import com.metys.merlin.generation.gef.genmodel.GenViewer;
import com.metys.merlin.generation.gef.model.EDiagram;
import com.metys.merlin.generation.gef.model.ENode;
import com.metys.merlin.generation.gef.model.EObjectLink;
import com.metys.merlin.generation.gef.model.EReferenceLink;
import com.metys.merlin.generation.gef.parts.EDiagramEditPart;
import com.metys.merlin.generation.gef.parts.ELinkEditPart;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class GenModelEditPartFactory implements EditPartFactory {

  /**
 	 * <!-- begin-user-doc -->
 	 * <!-- end-user-doc -->
 	 * @generated
 	 */
  private AdapterFactory adapterFactory;
  
  /**
 	 * <!-- begin-user-doc -->
 	 * <!-- end-user-doc -->
 	 * @generated
 	 */
  private Resource modelResource;
  
  /**
 	 * <!-- begin-user-doc -->
 	 * <!-- end-user-doc -->
 	 * @generated
 	 */
  public GenModelEditPartFactory(AdapterFactory adapterFactory, Resource modelResource) {
    this.adapterFactory = adapterFactory;
    this.modelResource = modelResource;
  }
  
  /**
   * This creates an edit part for a {@link GenGEFModel}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EditPart createGenGEFModelEditPart(ENode model)
  {
    return new GenGEFModelEditPart(model, adapterFactory);
  }
  /**
   * This creates an edit part for a {@link GenEditor}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EditPart createGenEditorEditPart(ENode model)
  {
    return new GenEditorEditPart(model, adapterFactory);
  }
  /**
   * This creates an edit part for a {@link GenViewer}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EditPart createGenViewerEditPart(ENode model)
  {
    return new GenViewerEditPart(model, adapterFactory);
  }
  /**
   * This creates an edit part for a {@link GenEditPartFactory}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EditPart createGenEditPartFactoryEditPart(ENode model)
  {
    return new GenEditPartFactoryEditPart(model, adapterFactory);
  }
  /**
   * This creates an edit part for a {@link GenNodeEditPart}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EditPart createGenNodeEditPartEditPart(ENode model)
  {
    return new GenNodeEditPartEditPart(model, adapterFactory);
  }
  /**
   * This creates an edit part for a {@link GenLinkEditPart}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EditPart createGenLinkEditPartEditPart(ENode model)
  {
    return new GenLinkEditPartEditPart(model, adapterFactory);
  }
  /**
   * This creates an edit part for a {@link GenPaletteComponentsFactory}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EditPart createGenPaletteComponentsFactoryEditPart(ENode model)
  {
    return new GenPaletteComponentsFactoryEditPart(model, adapterFactory);
  }
  /**
   * This creates an edit part for a {@link GenPaletteConnectionsFactory}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EditPart createGenPaletteConnectionsFactoryEditPart(ENode model)
  {
    return new GenPaletteConnectionsFactoryEditPart(model, adapterFactory);
  }
  /**
   * This creates an edit part for a {@link GenFigure}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EditPart createGenFigureEditPart(ENode model)
  {
    return new GenFigureEditPart(model, adapterFactory);
  }  

  
  /**
   * This creates an edit part for any 
   * model object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EditPart createEditPart(EditPart context, Object model) {
    EditPart part = null;
    if (model instanceof EDiagram) {
      part = new EDiagramEditPart((EDiagram) model, adapterFactory, modelResource);
    } else if (model instanceof EReferenceLink) {
      part = new ELinkEditPart((EReferenceLink) model, adapterFactory);
    }	else if (model instanceof EObjectLink) {
      EClass ecoreClass = ((EObjectLink)model).getTransitionEObject().eClass();						
    } else if (model instanceof ENode){
      EClass ecoreClass = ((ENode)model).getEObject().eClass();
      if (ecoreClass == GenModelPackage.eINSTANCE.getGenGEFModel())
        part = createGenGEFModelEditPart((ENode) model);
      if (ecoreClass == GenModelPackage.eINSTANCE.getGenEditor())
        part = createGenEditorEditPart((ENode) model);
      if (ecoreClass == GenModelPackage.eINSTANCE.getGenViewer())
        part = createGenViewerEditPart((ENode) model);
      if (ecoreClass == GenModelPackage.eINSTANCE.getGenEditPartFactory())
        part = createGenEditPartFactoryEditPart((ENode) model);
      if (ecoreClass == GenModelPackage.eINSTANCE.getGenNodeEditPart())
        part = createGenNodeEditPartEditPart((ENode) model);
      if (ecoreClass == GenModelPackage.eINSTANCE.getGenLinkEditPart())
        part = createGenLinkEditPartEditPart((ENode) model);
      if (ecoreClass == GenModelPackage.eINSTANCE.getGenPaletteComponentsFactory())
        part = createGenPaletteComponentsFactoryEditPart((ENode) model);
      if (ecoreClass == GenModelPackage.eINSTANCE.getGenPaletteConnectionsFactory())
        part = createGenPaletteConnectionsFactoryEditPart((ENode) model);
      if (ecoreClass == GenModelPackage.eINSTANCE.getGenFigure())
        part = createGenFigureEditPart((ENode) model);      
    }
    return part;
  }	
}