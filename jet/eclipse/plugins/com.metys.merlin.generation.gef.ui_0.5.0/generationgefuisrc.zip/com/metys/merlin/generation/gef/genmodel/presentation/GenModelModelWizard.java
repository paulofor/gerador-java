/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.genmodel.presentation;


import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.StringTokenizer;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.codegen.ecore.genmodel.GenBase;
import org.eclipse.emf.codegen.ecore.genmodel.GenModel;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.edit.ui.provider.ExtendedImageRegistry;
import org.eclipse.emf.mapping.MappingRoot;
import org.eclipse.emf.mapping.ecore2ecore.Ecore2EcoreMappingRoot;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.actions.WorkspaceModifyOperation;
import org.eclipse.ui.dialogs.ContainerSelectionDialog;
import org.eclipse.ui.dialogs.ResourceSelectionDialog;
import org.eclipse.ui.dialogs.WizardNewFileCreationPage;
import org.eclipse.ui.part.FileEditorInput;
import org.eclipse.ui.part.ISetSelectionTarget;
import org.osgi.framework.Bundle;

import com.metys.merlin.generation.gef.GefPackage;
import com.metys.merlin.generation.gef.GefPlugin;
import com.metys.merlin.generation.gef.genmodel.GenGEFModel;
import com.metys.merlin.generation.gef.genmodel.GenModelFactory;
import com.metys.merlin.generation.gef.genmodel.GenModelPackage;
import com.metys.merlin.generation.gef.ui.GefUIPlugin;
import com.metys.merlin.generation.mappingmodel.MappingModelPackage;
import com.metys.merlin.generation.mappingmodel.MappingModelUIPlugin;
import com.metys.merlin.generation.mappingmodel.mapping.MappingFactory;
import com.metys.merlin.generation.mappingmodel.mapping.MappingPackage;
import com.metys.merlin.generation.mappingmodel.mapping.Transformer;
import com.metys.merlin.generation.mappingmodel.mapping.presentation.TransformationInputsComposite;


/**
 * This is a simple wizard for creating a new model file.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class GenModelModelWizard extends Wizard implements INewWizard {
  /**
   * This caches an instance of the model package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected GenModelPackage genModelPackage = GenModelPackage.eINSTANCE;

  /**
   * This caches an instance of the model factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected GenModelFactory genModelFactory = genModelPackage.getGenModelFactory();

  /**
   * This is the file creation page.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected GenModelModelWizardNewFileCreationPage newFileCreationPage;

  /**
   * This is the initial object creation page.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected GenModelModelWizardInitialObjectCreationPage initialObjectCreationPage;

  /**
   * Remember the selection during initialization for populating the default container.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected IStructuredSelection selection;

  /**
   * Remember the workbench during initialization.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected IWorkbench workbench;

  /**
   * Caches the names of the types that can be created as the root object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected List initialObjectNames;

  private Resource defaultMappingFileResource;

  private IFile modelFile;

  private Resource genModelFileResource;

  private ResourceSet resourceSet = new ResourceSetImpl();

  /**
   * This just records the information.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public void init(IWorkbench aWorkbench, IStructuredSelection aSelection) {
    this.workbench = aWorkbench;
    this.selection = aSelection;
    setWindowTitle(GefUIPlugin.INSTANCE.getString("_UI_Wizard_label"));
    setDefaultPageImageDescriptor(ExtendedImageRegistry.INSTANCE.getImageDescriptor(GefUIPlugin.INSTANCE.getImage("full/wizban/NewGenModel")));
    Bundle bundle = GefPlugin.getPlugin().getBundle();
    
    // Ensure the MappingModel Package is loaded
    MappingModelPackage.eINSTANCE.getNsURI();
    // Create JET mappings
    URL mappingResourceURL = bundle.getEntry("/resources/genmodel2gefgenmodel.mapping");
    URI mappingResourceURI = URI.createURI(mappingResourceURL.toString());
    defaultMappingFileResource = resourceSet.getResource(mappingResourceURI, true);
  }

  /**
   * Returns the names of the types that can be created as the root object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Collection getInitialObjectNames() {
    if (initialObjectNames == null) {
      initialObjectNames = new ArrayList();
      for (Iterator classifiers = genModelPackage.getEClassifiers().iterator(); classifiers.hasNext(); ) {
        EClassifier eClassifier = (EClassifier)classifiers.next();
        if (eClassifier instanceof EClass) {
          EClass eClass = (EClass)eClassifier;
          if (!eClass.isAbstract()) {
            initialObjectNames.add(eClass.getName());
          }
        }
      }
      Collections.sort(initialObjectNames, java.text.Collator.getInstance());
    }
    return initialObjectNames;
  }

  /**
   * Create a new model.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EObject createInitialModel() {
    EClass eClass = (EClass)genModelPackage.getEClassifier(initialObjectCreationPage.getInitialObjectName());
    EObject rootObject = genModelFactory.create(eClass);
    return rootObject;
  }

  /**
   * Do the work after everything is specified.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public boolean performFinish() {
    try {
      // Remember the file.
      //
      this.modelFile = getModelFile();

      // Do the work within an operation.
      //
      WorkspaceModifyOperation operation =
        new WorkspaceModifyOperation() {
          protected void execute(IProgressMonitor progressMonitor) {
            try {              
              MappingPackage.eINSTANCE.getNsURI(); // ensure mapping model is loaded
              Resource emfMappingFileResource = initialObjectCreationPage.getMappingFileResource();
              if (emfMappingFileResource == null)
                emfMappingFileResource = defaultMappingFileResource;    
              Resource genGEFModelFileResource = getGenGEFModelResource();
              Transformer transformer = MappingFactory.eINSTANCE.createTransformer();
              Ecore2EcoreMappingRoot metaModelMappingRoot = (Ecore2EcoreMappingRoot) emfMappingFileResource.getContents().get(0);    
              transformer.setTypeMappingRoot(metaModelMappingRoot);
              transformer.transform(genModelFileResource, genGEFModelFileResource, null);
              
              if (!transformer.getChangeDescription().getObjectsToAttach().isEmpty())
                genGEFModelFileResource.getContents().addAll(transformer.getChangeDescription().getObjectsToAttach());              
              
              // Save the contents of the resource to the file system.
              //
              Map options = new HashMap();
              options.put(XMLResource.OPTION_ENCODING, "UTF-8");
              genGEFModelFileResource.save(options);
            }
            catch (Exception exception) {
              GefUIPlugin.INSTANCE.log(exception);
            }
            finally {
              progressMonitor.done();
            }
          }
        };

      getContainer().run(false, false, operation);

      // Select the new file resource in the current view.
      //
      IWorkbenchWindow workbenchWindow = workbench.getActiveWorkbenchWindow();
      IWorkbenchPage page = workbenchWindow.getActivePage();
      final IWorkbenchPart activePart = page.getActivePart();
      if (activePart instanceof ISetSelectionTarget) {
        final ISelection targetSelection = new StructuredSelection(modelFile);
        getShell().getDisplay().asyncExec
          (new Runnable() {
             public void run() {
               ((ISetSelectionTarget)activePart).selectReveal(targetSelection);
             }
           });
      }

      // Open an editor on the new file.
      //
      try {
        page.openEditor
          (new FileEditorInput(modelFile),
           workbench.getEditorRegistry().getDefaultEditor(modelFile.getFullPath().toString()).getId());
      }
      catch (PartInitException exception) {
        MessageDialog.openError(workbenchWindow.getShell(), GefUIPlugin.INSTANCE.getString("_UI_OpenEditorError_label"), exception.getMessage());
        return false;
      }

      return true;
    }
    catch (Exception exception) {
      GefUIPlugin.INSTANCE.log(exception);
      return false;
    }
  }

  /**
   * This is the one page of the wizard.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public class GenModelModelWizardNewFileCreationPage extends WizardNewFileCreationPage {
    
    /**
     * Pass in the selection.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    public GenModelModelWizardNewFileCreationPage(String pageId, IStructuredSelection selection) {
      super(pageId, selection);
    }

    /**
     * The framework calls this to see if the file is correct.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    protected boolean validatePage() {
      if (super.validatePage()) {
        // Make sure the file ends in ".genmodel".
        //
        String requiredExt = GefUIPlugin.INSTANCE.getString("_UI_GenModelEditorFilenameExtension");
        String enteredExt = new Path(getFileName()).getFileExtension();
        if (enteredExt == null || !enteredExt.equals(requiredExt)) {
          setErrorMessage(GefUIPlugin.INSTANCE.getString("_WARN_FilenameExtension", new Object [] { requiredExt }));
          return false;
        }
        else {
          return true;
        }
      }
      else {
        return false;
      }
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    public IFile getModelFile() {
      return ResourcesPlugin.getWorkspace().getRoot().getFile(getContainerFullPath().append(getFileName()));
    }
  }

  /**
   * This is the page where the type of object to create is selected.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public class GenModelModelWizardInitialObjectCreationPage extends WizardPage {
    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    protected Combo initialObjectField;

    /**
     * @generated
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     */
    protected List encodings;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    protected Combo encodingField;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated NOT
     */
    protected String inputFilePath;

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated NOT
     */
    protected Text sourceFileField;
        
    protected Text mappingFileLocationText;
    protected Resource mappingFileResource;
    protected Button chooseDefaultMappingFileButton;
    protected Button chooseCustomMappingFileButton;
    
    protected TransformationInputsComposite transformationInputsComposite;
    
    /**
     * Pass in the selection.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated NOT
     */
    public GenModelModelWizardInitialObjectCreationPage(String pageId) {
      super(pageId);
    }

    public void setTargetResource(Resource genGEFModelResource) {
      if (transformationInputsComposite != null)
        transformationInputsComposite.setTargetResource(genGEFModelResource);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated NOT
     */
    public void createControl(Composite parent) {
      Composite composite = new Composite(parent, SWT.NONE);
      {
        GridLayout layout = new GridLayout();
        layout.numColumns = 3;
        composite.setLayout(layout);
        GridData data = new GridData();
        data.verticalAlignment = GridData.FILL;
        data.grabExcessVerticalSpace = true;
        data.horizontalAlignment = GridData.FILL;
        composite.setLayoutData(data);
      }

      Label inputFileLabel = new Label(composite, SWT.LEFT);
      {
        inputFileLabel.setText(GefUIPlugin.INSTANCE.getString("_UI_GenModelInputFile.label"));
        GridData data = new GridData();
        data.horizontalAlignment = GridData.BEGINNING;
        inputFileLabel.setLayoutData(data);
      }

      sourceFileField = new Text(composite, SWT.BORDER);
      {
        GridData data = new GridData();
        data.horizontalAlignment = GridData.FILL;
        data.grabExcessHorizontalSpace = true;
        sourceFileField.setLayoutData(data);
      }
      
      Button button = new Button(composite, SWT.PUSH);
      button.setText(GefUIPlugin.INSTANCE.getString("_UI_Browse"));
      button.addSelectionListener(new SelectionAdapter() {
        public void widgetSelected(SelectionEvent e) {
          ResourceSelectionDialog dialog = new ResourceSelectionDialog(
              getShell(), ResourcesPlugin.getWorkspace().getRoot(), 
              GefUIPlugin.INSTANCE.getString("_UI_SelectGenModel.title"));    
          if (dialog.open() == ContainerSelectionDialog.OK) {
            Object[] result = dialog.getResult();
            if (result.length == 1) {
              String inputFile = ((IResource) result[0]).getFullPath().toString();
              try {                
                URI uri = URI.createPlatformResourceURI(inputFile);
                Resource selectionFileResource = resourceSet.getResource(uri, true);
                if (selectionFileResource != null &&
                    !selectionFileResource.getContents().isEmpty()) {
                  EObject topContent = (EObject) selectionFileResource.getContents().get(0);
                  if (topContent instanceof GenBase) {
                    genModelFileResource = selectionFileResource;
                    transformationInputsComposite.setSourceResource(genModelFileResource);                    
                  }
                } 
              } catch (Exception ex) {}              
              sourceFileField.setText(inputFile);
              boolean pageOK = validatePage();
              setPageComplete(pageOK); 
            }
          }
        }
      });
      chooseDefaultMappingFileButton = new Button(composite, SWT.RADIO);
      {
        GridData data = new GridData();
        data.horizontalAlignment = GridData.FILL;
        data.horizontalSpan = 3;
        chooseDefaultMappingFileButton.setLayoutData(data);
        String label = GefUIPlugin.INSTANCE.getString("_UI_DefaultMappingFile_label");
        chooseDefaultMappingFileButton.setText(label);        
      }
      chooseCustomMappingFileButton = new Button(composite, SWT.RADIO);
      {
        GridData data = new GridData();
        data.horizontalAlignment = GridData.FILL;
        data.horizontalSpan = 3;
        chooseCustomMappingFileButton.setLayoutData(data);
        String label = GefUIPlugin.INSTANCE.getString("_UI_CustomMappingFile_label");
        chooseCustomMappingFileButton.setText(label);        
      }
      //Mapping 
      final Label mappingfileLabel = new Label(composite, SWT.LEFT);
      {
        String label = GefUIPlugin.INSTANCE.getString("_UI_MappingFile_label");
        mappingfileLabel.setText(label);
        GridData data = new GridData();
        data.horizontalAlignment = GridData.BEGINNING;
        mappingfileLabel.setLayoutData(data);        
      }
      mappingFileLocationText = new Text(composite, SWT.SINGLE | SWT.BORDER);
      {
        GridData data = new GridData();
        data.grabExcessHorizontalSpace = true;
        data.horizontalAlignment = GridData.FILL;
        mappingFileLocationText.setLayoutData(data);
      }
      final Button browseWorkspaceButton = new Button(composite, SWT.PUSH);
      {
        browseWorkspaceButton.setText(MappingModelUIPlugin.INSTANCE.getString("_UI_Browse_label"));
        GridData data = new GridData();
        data.horizontalAlignment = GridData.END;
        browseWorkspaceButton.setLayoutData(data);
      }
      chooseDefaultMappingFileButton.addSelectionListener(new SelectionAdapter() {
        public void widgetSelected(SelectionEvent e) {
          boolean sel = chooseCustomMappingFileButton.getSelection();
          browseWorkspaceButton.setEnabled(sel);
          mappingfileLabel.setEnabled(sel);   
          mappingFileLocationText.setEnabled(sel);
          if (!sel)
            transformationInputsComposite.setTypeMappingsResource(defaultMappingFileResource);
        }
      });
      chooseCustomMappingFileButton.addSelectionListener(new SelectionAdapter() {
        public void widgetSelected(SelectionEvent e) {
          boolean sel = chooseCustomMappingFileButton.getSelection();
          browseWorkspaceButton.setEnabled(sel);
          mappingfileLabel.setEnabled(sel);   
          mappingFileLocationText.setEnabled(sel);
          if (!sel)
            transformationInputsComposite.setTypeMappingsResource(defaultMappingFileResource);
        }
      });
      chooseDefaultMappingFileButton.setSelection(true);
      mappingFileLocationText.setEditable(false);
      browseWorkspaceButton.setEnabled(false);
      mappingfileLabel.setEnabled(false);   
      mappingFileLocationText.setEnabled(false);
      browseWorkspaceButton.addSelectionListener(new SelectionAdapter() {
        public void widgetSelected(SelectionEvent event) {
          String dialogLabel = MappingModelUIPlugin.INSTANCE.getString("_UI_SelectMappingFile_label");
          ResourceSelectionDialog containerSelectionDialog = new ResourceSelectionDialog(
              GenModelModelWizardInitialObjectCreationPage.this.getShell(), ResourcesPlugin.getWorkspace().getRoot(), dialogLabel);
          containerSelectionDialog.open();
          Object[] result = containerSelectionDialog.getResult();
          if (result != null && result.length > 0) {
            if (result[0] instanceof IResource) {
              IResource mappingFile = (IResource) result[0];
              mappingFileLocationText.setText(mappingFile.getFullPath().toString());
              URI uri = URI.createPlatformResourceURI(mappingFile.getFullPath().toString());
              try {
                Resource selectedFileResource = resourceSet.getResource(uri, true);          
                if (selectedFileResource != null &&
                    !selectedFileResource.getContents().isEmpty() &&
                    selectedFileResource.getContents().get(0) instanceof MappingRoot) {
                  mappingFileResource = selectedFileResource;
                  transformationInputsComposite.setTypeMappingsResource(mappingFileResource);
                }
              } catch (Exception e) {}
              boolean pageOK = validatePage();
              setPageComplete(pageOK);              
            }            
          }
        }
      });
      transformationInputsComposite = new TransformationInputsComposite(composite, SWT.NONE);
      {
        GridData data = new GridData();
        data.horizontalSpan = 3;
        data.heightHint = 300;
        data.widthHint = 200;
        data.grabExcessHorizontalSpace = true;
        data.grabExcessVerticalSpace = true;
        data.horizontalAlignment = GridData.FILL;
        data.verticalAlignment = GridData.FILL;
        transformationInputsComposite.setLayoutData(data);        
      }
      transformationInputsComposite.setTargetResource(getGenGEFModelResource());
      transformationInputsComposite.setTypeMappingsResource(defaultMappingFileResource);
      if (selection.getFirstElement() instanceof IFile) {
        IFile selectionFile = (IFile) selection.getFirstElement();
        URI uri = URI.createPlatformResourceURI(selectionFile.getFullPath().toString());
        try {
          Resource selectionFileResource = resourceSet.getResource(uri, true);
          if (selectionFileResource != null &&
              !selectionFileResource.getContents().isEmpty()) {
            EObject topContent = (EObject) selectionFileResource.getContents().get(0);
            if (topContent instanceof GenBase)
              genModelFileResource = selectionFileResource;
          }          
        } catch (Exception e) {              
        }
      }
      
      if (genModelFileResource != null &&
          !genModelFileResource.getContents().isEmpty()) {
        transformationInputsComposite.setSourceResource(genModelFileResource);
        sourceFileField.setText(genModelFileResource.getURI().toString());
        setPageComplete(true);
        setPageComplete(isPageComplete());
      }
      setControl(composite);
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    protected ModifyListener validator =
      new ModifyListener() {
        public void modifyText(ModifyEvent e) {
          setPageComplete(validatePage());
        }
      };

    public Resource getMappingFileResource() {
      return mappingFileResource;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated NOT
     */
    public void setVisible(boolean visible) {
      super.setVisible(visible);      
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    public String getInitialObjectName() {
      String label = initialObjectField.getText();

      for (Iterator i = getInitialObjectNames().iterator(); i.hasNext(); ) {
        String name = (String)i.next();
        if (getLabel(name).equals(label)) {
          return name;
        }
      }
      return null;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    public String getEncoding() {
      return encodingField.getText();
    }

    /**
     * The framework calls this to see if the file is correct.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated NOT
     */
    public boolean isPageComplete() {
      if (super.isPageComplete()) {
        return validatePage();
      }
      else {
        return false;
      }
    }

    /**
     * @return
     */
    protected boolean validatePage() {
      setErrorMessage(null);
      if (chooseCustomMappingFileButton.getSelection()) {
        boolean mappingFileValid = validateMappingFile();
        if (!mappingFileValid) {
          setErrorMessage(MappingModelUIPlugin.INSTANCE.getString("_UI_InvalidMappingFile_label"));
          return false;
        }
      }
      if (genModelFileResource != null) {
        boolean ok = (!genModelFileResource.getContents().isEmpty() && 
            genModelFileResource.getContents().get(0) instanceof GenModel);
        if (!ok)
          setErrorMessage(MappingModelUIPlugin.INSTANCE.getString("_UI_InvalidInput_label"));          
        return ok;
      }
      return false;      
    }
    
    /**
     * @param ok
     * @return
     */
    protected boolean validateMappingFile() {
      boolean ok = false;
      if (mappingFileResource != null &&
          !mappingFileResource.getContents().isEmpty()) {
        MappingRoot typeMappingRoot = (MappingRoot) mappingFileResource.getContents().get(0);
        if (typeMappingRoot.getInputs().contains(org.eclipse.emf.codegen.ecore.genmodel.GenModelPackage.eINSTANCE) &&
            (typeMappingRoot.getOutputs().contains(GefPackage.eINSTANCE) || typeMappingRoot.getOutputs().contains(genModelPackage))) {            
          ok = true;
        }
      }              
      return ok;
    }

    /**
     * Store the dialog field settings upon completion.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated NOT
     */
    public boolean performFinish() {
      inputFilePath = getInputFilePath();
      return true;
    }

    /**
     * Returns the label for the specified type name.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    protected String getLabel(String typeName) {
      try {
        return GefUIPlugin.INSTANCE.getString("_UI_" + typeName + "_type");
      }
      catch(MissingResourceException mre) {
        GefUIPlugin.INSTANCE.log(mre);
      }
      return typeName;
    }

    /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    protected Collection getEncodings() {
      if (encodings == null) {
        encodings = new ArrayList();
        for (StringTokenizer stringTokenizer = new StringTokenizer(GefUIPlugin.INSTANCE.getString("_UI_XMLEncodingChoices")); stringTokenizer.hasMoreTokens(); ) {
          encodings.add(stringTokenizer.nextToken());
        }
      }
      return encodings;
    }
        /**
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated NOT
     */
    public String getInputFilePath() {
      if (inputFilePath != null) {
        return inputFilePath;
      }
      else {
        URI genModelInputURI = URI.createPlatformResourceURI(sourceFileField.getText());
        Resource emfInputFileResource = resourceSet.getResource(genModelInputURI, true);
        if (!emfInputFileResource.getContents().isEmpty() && 
                 emfInputFileResource.getContents().get(0) instanceof GenBase)
          return sourceFileField.getText();
        return null;
      }
    }
  }

  /**
   * The framework calls this to create the contents of the wizard.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public void addPages() {
    // Create a page, set the title, and the initial model file name.
    //
    newFileCreationPage = new GenModelModelWizardNewFileCreationPage("Whatever", selection);
    newFileCreationPage.setTitle(GefUIPlugin.INSTANCE.getString("_UI_GenModelModelWizard_label"));
    newFileCreationPage.setDescription(GefUIPlugin.INSTANCE.getString("_UI_GenModelModelWizard_description"));
    newFileCreationPage.setFileName(GefUIPlugin.INSTANCE.getString("_UI_GenModelEditorFilenameDefaultBase") + "." + GefUIPlugin.INSTANCE.getString("_UI_GenModelEditorFilenameExtension"));
    if (modelFile == null)
      addPage(newFileCreationPage);

    initialObjectCreationPage = new GenModelModelWizardInitialObjectCreationPage("Whatever2");
    initialObjectCreationPage.setTitle(GefUIPlugin.INSTANCE.getString("_UI_GenModelInput_label"));
    initialObjectCreationPage.setDescription(GefUIPlugin.INSTANCE.getString("_UI_GenModelInput_description"));    
    addPage(initialObjectCreationPage);
    // Try and get the resource selection to determine a current directory for the file dialog.
    //
    if (selection != null && !selection.isEmpty()) {
      // Get the resource...
      //
      Object selectedElement = selection.iterator().next();
      if (selectedElement instanceof IResource) {
        // Get the resource parent, if its a file.
        //
        IResource selectedResource = (IResource)selectedElement;
        if (selectedResource.getType() == IResource.FILE) {
          selectedResource = selectedResource.getParent();
        }

        // This gives us a directory...
        //
        if (selectedResource instanceof IFolder || selectedResource instanceof IProject) {
          // Set this for the container.
          //
          newFileCreationPage.setContainerFullPath(selectedResource.getFullPath());

          // Make up a unique new name here.
          //
          String defaultModelBaseFilename = GefUIPlugin.INSTANCE.getString("_UI_GenModelEditorFilenameDefaultBase");
          String defaultModelFilenameExtension = GefUIPlugin.INSTANCE.getString("_UI_GenModelEditorFilenameExtension");
          String modelFilename = defaultModelBaseFilename + "." + defaultModelFilenameExtension;
          for (int i = 1; ((IContainer)selectedResource).findMember(modelFilename) != null; ++i) {
            modelFilename = defaultModelBaseFilename + i + "." + defaultModelFilenameExtension;
          }
          newFileCreationPage.setFileName(modelFilename);
        }
      }
    }    
  }

  public Resource getGenGEFModelResource() {
    if (getModelFile() != null) {
      URI genGEFmodelURI = URI.createPlatformResourceURI(getModelFile().getFullPath().toString());
      if (getModelFile().exists())
        return resourceSet.getResource(genGEFmodelURI, true);
      else
        return resourceSet.createResource(genGEFmodelURI);
    }
    return null;
  }
  
  public void setModelFile(IFile aModelFile) {
    this.modelFile = aModelFile;
    Resource genGEFModelFileResource = getGenGEFModelResource();
    if (!genGEFModelFileResource.getContents().isEmpty() &&
        genGEFModelFileResource.getContents().get(0) instanceof GenGEFModel) {
      GenGEFModel genGEFModel = (GenGEFModel) genGEFModelFileResource.getContents().get(0);
      GenModel genModel = genGEFModel.getGenModel();
      genModelFileResource = genModel.eResource();
    }    
  }
  /**
   * Get the file from the page.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public IFile getModelFile() {
    if (modelFile == null)
      return newFileCreationPage.getModelFile();
    return modelFile;
  }

}
