/**
 * <copyright>
 * </copyright>
 *
 * $Id: GenNodeEditPartGraphicalNodeEditPolicy.java,v 1.2 2005/07/10 23:39:38 jcheuoua Exp $
 */

package com.metys.merlin.generation.gef.genmodel.editparts.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gef.requests.CreateConnectionRequest;
import org.eclipse.gef.requests.ReconnectRequest;

import com.metys.merlin.generation.gef.commands.CreateConnectionCommand;
import com.metys.merlin.generation.gef.commands.ReconnectSourceCommand;
import com.metys.merlin.generation.gef.commands.ReconnectTargetCommand;
import com.metys.merlin.generation.gef.genmodel.editparts.GenNodeEditPartEditPart;
import com.metys.merlin.generation.gef.model.ELink;
import com.metys.merlin.generation.gef.model.ENode;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class GenNodeEditPartGraphicalNodeEditPolicy extends GenEditPartGraphicalNodeEditPolicy{
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Command getConnectionCompleteCommand(CreateConnectionRequest request) {
    if (request.getStartCommand() instanceof CreateConnectionCommand) {
      CreateConnectionCommand cmd = (CreateConnectionCommand) request.getStartCommand();
      GenNodeEditPartEditPart targetNodeEditPart = (GenNodeEditPartEditPart) getHost();
      ENode target = targetNodeEditPart.getENode();
      ELink link = cmd.getLink();
      if (acceptLinkAsTarget(target, link)) {
        cmd.setTargetNodeEditPart(targetNodeEditPart);
        return cmd;
      }
    }
    return null;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Command getConnectionCreateCommand(CreateConnectionRequest request) {
    GenNodeEditPartEditPart sourceNodeEditPart = (GenNodeEditPartEditPart) getHost();
    ENode source = sourceNodeEditPart.getENode();
    ELink link = (ELink) request.getNewObject();
    if (acceptLinkAsSource(source, link)) {
      CreateConnectionCommand cmd = new CreateConnectionCommand(sourceNodeEditPart, link);
      request.setStartCommand(cmd);
      return cmd;
    }
    return null;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Command getReconnectSourceCommand(ReconnectRequest request) {
    GenNodeEditPartEditPart sourceNodeEditPart = (GenNodeEditPartEditPart) getHost();
    ELink link = (ELink) request.getConnectionEditPart().getModel();
    ENode source = sourceNodeEditPart.getENode();
    if (acceptLinkAsSource(source, link)) {
      ReconnectSourceCommand cmd = new ReconnectSourceCommand(sourceNodeEditPart, link);
      return cmd;
    }
    return null;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Command getReconnectTargetCommand(ReconnectRequest request) {
    GenNodeEditPartEditPart targetNodeEditPart = (GenNodeEditPartEditPart) getHost();
    ELink link = (ELink) request.getConnectionEditPart().getModel();
    ENode target = targetNodeEditPart.getENode();
    if (acceptLinkAsTarget(target, link)) {
      ReconnectTargetCommand cmd = new ReconnectTargetCommand(targetNodeEditPart, link);
      return cmd;
    }
    return null;
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean acceptLinkAsTarget(ENode target, ELink link) {
    return target.acceptLinkAsTarget(link);
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean acceptLinkAsSource(ENode source, ELink link) {
    return source.acceptLinkAsSource(link);
  }
}