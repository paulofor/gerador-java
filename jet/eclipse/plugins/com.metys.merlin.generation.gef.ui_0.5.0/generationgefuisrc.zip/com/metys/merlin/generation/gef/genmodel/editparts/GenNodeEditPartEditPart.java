/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */

package com.metys.merlin.generation.gef.genmodel.editparts;

import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.PositionConstants;
import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.draw2d.geometry.Point;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.GraphicalEditPart;

import com.metys.merlin.generation.gef.figures.ENodeFigure;
import com.metys.merlin.generation.gef.genmodel.editparts.policies.GenNodeEditPartComponentEditPolicy;
import com.metys.merlin.generation.gef.genmodel.editparts.policies.GenNodeEditPartDirectEditPolicy;
import com.metys.merlin.generation.gef.genmodel.editparts.policies.GenNodeEditPartGraphicalNodeEditPolicy;
import com.metys.merlin.generation.gef.genmodel.editparts.policies.GenNodeEditPartLayoutEditPolicy;
import com.metys.merlin.generation.gef.genmodel.impl.GenNodeEditPartImpl;
import com.metys.merlin.generation.gef.model.ENode;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class GenNodeEditPartEditPart extends GenEditPartEditPart{
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenNodeEditPartEditPart(ENode model, AdapterFactory adapterFactory) {
    super(model, adapterFactory);
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenNodeEditPartImpl getGenNodeEditPart() {
    return (GenNodeEditPartImpl)getENode().getEObject();
  }
  
  /**
   * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#createFigure()
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated   
   */
  protected IFigure createFigure() {
    Label l = new Label(getImage());
    l.setLabelAlignment(PositionConstants.CENTER);
    return new ENodeFigure(l);
  }

  /**
   * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#getContentPane()
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated   
   */
  public IFigure getContentPane() {
    return ((ENodeFigure) getFigure()).getContentPane();
  }

  /**
   * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#refreshVisuals()
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void refreshVisuals() {
    String name = getENode().getName();
    if (name == null || name.trim().length() == 0)
      name = getLabelProvider().getText(getENode().getEObject());
    Label l = (Label) ((ENodeFigure) getFigure()).getHeader();
    l.setText(name);

    Point loc = getENode().getLocation();
    Dimension size = new Dimension((int) getENode().getWidth(), (int) getENode().getHeight());
    Rectangle r = new Rectangle(loc, size);

  if (getParent() instanceof GraphicalEditPart)
    	((GraphicalEditPart) getParent()).setLayoutConstraint(this, getFigure(), r);
  }

  /**
   * @see org.eclipse.gef.editparts.AbstractEditPart#createEditPolicies()
   * <!-- begin-user-doc --> 
   * <!-- end-user-doc -->
   * @generated
   */
  protected void createEditPolicies() {
    // Node Container & Layout Edit Policy
    installEditPolicy(EditPolicy.LAYOUT_ROLE, new GenNodeEditPartLayoutEditPolicy());
    // Node Component Edit Policy
    installEditPolicy(EditPolicy.COMPONENT_ROLE, new GenNodeEditPartComponentEditPolicy());
    // Node Direct Edit Policy
    installEditPolicy(EditPolicy.DIRECT_EDIT_ROLE, new GenNodeEditPartDirectEditPolicy());
    // Node Graphical Node Edit Policy
    installEditPolicy(EditPolicy.GRAPHICAL_NODE_ROLE, new GenNodeEditPartGraphicalNodeEditPolicy());
  }

}