/**
 * <copyright>
 * </copyright>
 *
 * $Id: GenModelViewer.java,v 1.2 2005/07/10 23:39:40 jcheuoua Exp $
 */

package com.metys.merlin.generation.gef.genmodel.gefviewer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.ecore.provider.EcoreItemProviderAdapterFactory;
import org.eclipse.emf.edit.provider.ComposedAdapterFactory;
import org.eclipse.emf.edit.provider.ReflectiveItemProviderAdapterFactory;
import org.eclipse.emf.edit.provider.resource.ResourceItemProviderAdapterFactory;
import org.eclipse.emf.mapping.provider.MappingItemProviderAdapterFactory;
import org.eclipse.gef.EditPartFactory;
import org.eclipse.swt.widgets.Composite;

import com.metys.merlin.generation.gef.genmodel.editparts.GenModelEditPartFactory;
import com.metys.merlin.generation.gef.genmodel.provider.GenModelItemProviderAdapterFactory;
import com.metys.merlin.generation.gef.model.provider.ModelItemProviderAdapterFactory;
import com.metys.merlin.generation.gef.provider.GefItemProviderAdapterFactory;
import com.metys.merlin.generation.gef.viewer.GEFGraphicalViewer;
import com.metys.merlin.generation.templates.jetmapping.provider.JETMappingItemProviderAdapterFactory;
import com.metys.merlin.generation.templates.provider.JETTemplateItemProviderAdapterFactory;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class GenModelViewer extends GEFGraphicalViewer {
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private AdapterFactory adapterFactory;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenModelViewer(Composite parent) {
    super(parent);
  }
    
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected AdapterFactory createAdapterFactory() {
    List factories = new ArrayList();
    factories.add(new ResourceItemProviderAdapterFactory());
    factories.add(new GefItemProviderAdapterFactory());
    factories.add(new ModelItemProviderAdapterFactory());
    factories.add(new GenModelItemProviderAdapterFactory());
    factories.add(new JETTemplateItemProviderAdapterFactory());
    factories.add(new JETMappingItemProviderAdapterFactory());
    factories.add(new EcoreItemProviderAdapterFactory());
    factories.add(new org.eclipse.emf.codegen.ecore.genmodel.provider.GenModelItemProviderAdapterFactory());
    factories.add(new MappingItemProviderAdapterFactory());
    factories.add(new ReflectiveItemProviderAdapterFactory());
    adapterFactory = new ComposedAdapterFactory(factories);
    return adapterFactory;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Map getTransitionClasses() {
    return Collections.EMPTY_MAP;
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EditPartFactory createEditPartFactory() {
  	return new GenModelEditPartFactory(createAdapterFactory(), null);
  }
}