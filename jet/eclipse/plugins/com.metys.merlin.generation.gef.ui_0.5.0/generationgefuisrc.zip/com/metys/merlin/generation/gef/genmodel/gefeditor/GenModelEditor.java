/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */

package com.metys.merlin.generation.gef.genmodel.gefeditor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.edit.provider.ComposedAdapterFactory;
import org.eclipse.emf.edit.provider.ReflectiveItemProviderAdapterFactory;
import org.eclipse.emf.edit.provider.resource.ResourceItemProviderAdapterFactory;
import org.eclipse.gef.ContextMenuProvider;
import org.eclipse.gef.EditPartFactory;
import org.eclipse.gef.editparts.ScalableFreeformRootEditPart;
import org.eclipse.gef.palette.CombinedTemplateCreationEntry;
import org.eclipse.gef.palette.ConnectionCreationToolEntry;
import org.eclipse.gef.palette.PaletteContainer;
import org.eclipse.gef.ui.parts.GraphicalViewerKeyHandler;
import org.eclipse.jface.resource.ImageDescriptor;

import com.metys.merlin.generation.gef.GefPlugin;
import com.metys.merlin.generation.gef.dnd.EObjectTemplateCreationFactory;
import com.metys.merlin.generation.gef.dnd.EReferenceLinkTemplateCreationFactory;
import com.metys.merlin.generation.gef.editor.GEFEditor;
import com.metys.merlin.generation.gef.editor.GEFEditorContextMenuProvider;
import com.metys.merlin.generation.gef.genmodel.GenModelPackage;
import com.metys.merlin.generation.gef.genmodel.editparts.GenModelEditPartFactory;
import com.metys.merlin.generation.gef.genmodel.provider.GenModelItemProviderAdapterFactory;
import com.metys.merlin.generation.gef.model.provider.ModelItemProviderAdapterFactory;
import com.metys.merlin.generation.gef.provider.GefItemProviderAdapterFactory;
import com.metys.merlin.generation.gef.ui.GefUIPlugin;

/**
 * The GenModelEditor GEF editor.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class GenModelEditor extends GEFEditor {
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void createComponentsDrawerEntries(PaletteContainer container) {
    List entries = new ArrayList();

    CombinedTemplateCreationEntry combined = null;
    EClass eClass = null;    
    eClass = GenModelPackage.eINSTANCE.getGenGEFModel();
    combined = new CombinedTemplateCreationEntry(
  		"GenGEFModel",
  		"Create a new GenGEFModel",
  		eClass,
  		new EObjectTemplateCreationFactory(eClass),
  			ImageDescriptor.createFromURL(GefUIPlugin.getPlugin().getBundle().getEntry("icons/full/obj16/GenGEFModel.gif")),
  			ImageDescriptor.createFromURL(GefUIPlugin.getPlugin().getBundle().getEntry("icons/full/obj16/GenGEFModel.gif")));
  	entries.add(combined);		
    eClass = GenModelPackage.eINSTANCE.getGenEditor();
    combined = new CombinedTemplateCreationEntry(
  		"GenEditor",
  		"Create a new GenEditor",
  		eClass,
  		new EObjectTemplateCreationFactory(eClass),
  			ImageDescriptor.createFromURL(GefUIPlugin.getPlugin().getBundle().getEntry("icons/full/obj16/GenEditor.gif")),
  			ImageDescriptor.createFromURL(GefUIPlugin.getPlugin().getBundle().getEntry("icons/full/obj16/GenEditor.gif")));
  	entries.add(combined);		
    eClass = GenModelPackage.eINSTANCE.getGenViewer();
    combined = new CombinedTemplateCreationEntry(
  		"GenViewer",
  		"Create a new GenViewer",
  		eClass,
  		new EObjectTemplateCreationFactory(eClass),
  			ImageDescriptor.createFromURL(GefUIPlugin.getPlugin().getBundle().getEntry("icons/full/obj16/GenViewer.gif")),
  			ImageDescriptor.createFromURL(GefUIPlugin.getPlugin().getBundle().getEntry("icons/full/obj16/GenViewer.gif")));
  	entries.add(combined);		
    eClass = GenModelPackage.eINSTANCE.getGenEditPartFactory();
    combined = new CombinedTemplateCreationEntry(
  		"GenEditPartFactory",
  		"Create a new GenEditPartFactory",
  		eClass,
  		new EObjectTemplateCreationFactory(eClass),
  			ImageDescriptor.createFromURL(GefUIPlugin.getPlugin().getBundle().getEntry("icons/full/obj16/GenEditPartFactory.gif")),
  			ImageDescriptor.createFromURL(GefUIPlugin.getPlugin().getBundle().getEntry("icons/full/obj16/GenEditPartFactory.gif")));
  	entries.add(combined);		
    eClass = GenModelPackage.eINSTANCE.getGenNodeEditPart();
    combined = new CombinedTemplateCreationEntry(
  		"GenNodeEditPart",
  		"Create a new GenNodeEditPart",
  		eClass,
  		new EObjectTemplateCreationFactory(eClass),
  			ImageDescriptor.createFromURL(GefUIPlugin.getPlugin().getBundle().getEntry("icons/full/obj16/GenNodeEditPart.gif")),
  			ImageDescriptor.createFromURL(GefUIPlugin.getPlugin().getBundle().getEntry("icons/full/obj16/GenNodeEditPart.gif")));
  	entries.add(combined);		
    eClass = GenModelPackage.eINSTANCE.getGenLinkEditPart();
    combined = new CombinedTemplateCreationEntry(
  		"GenLinkEditPart",
  		"Create a new GenLinkEditPart",
  		eClass,
  		new EObjectTemplateCreationFactory(eClass),
  			ImageDescriptor.createFromURL(GefUIPlugin.getPlugin().getBundle().getEntry("icons/full/obj16/GenLinkEditPart.gif")),
  			ImageDescriptor.createFromURL(GefUIPlugin.getPlugin().getBundle().getEntry("icons/full/obj16/GenLinkEditPart.gif")));
  	entries.add(combined);		
    eClass = GenModelPackage.eINSTANCE.getGenPaletteComponentsFactory();
    combined = new CombinedTemplateCreationEntry(
  		"GenPaletteComponentsFactory",
  		"Create a new GenPaletteComponentsFactory",
  		eClass,
  		new EObjectTemplateCreationFactory(eClass),
  			ImageDescriptor.createFromURL(GefUIPlugin.getPlugin().getBundle().getEntry("icons/full/obj16/GenPaletteComponentsFactory.gif")),
  			ImageDescriptor.createFromURL(GefUIPlugin.getPlugin().getBundle().getEntry("icons/full/obj16/GenPaletteComponentsFactory.gif")));
  	entries.add(combined);		
    eClass = GenModelPackage.eINSTANCE.getGenPaletteConnectionsFactory();
    combined = new CombinedTemplateCreationEntry(
  		"GenPaletteConnectionsFactory",
  		"Create a new GenPaletteConnectionsFactory",
  		eClass,
  		new EObjectTemplateCreationFactory(eClass),
  			ImageDescriptor.createFromURL(GefUIPlugin.getPlugin().getBundle().getEntry("icons/full/obj16/GenPaletteConnectionsFactory.gif")),
  			ImageDescriptor.createFromURL(GefUIPlugin.getPlugin().getBundle().getEntry("icons/full/obj16/GenPaletteConnectionsFactory.gif")));
  	entries.add(combined);		
    eClass = GenModelPackage.eINSTANCE.getGenFigure();
    combined = new CombinedTemplateCreationEntry(
  		"GenFigure",
  		"Create a new GenFigure",
  		eClass,
  		new EObjectTemplateCreationFactory(eClass),
  			ImageDescriptor.createFromURL(GefUIPlugin.getPlugin().getBundle().getEntry("icons/full/obj16/GenFigure.gif")),
  			ImageDescriptor.createFromURL(GefUIPlugin.getPlugin().getBundle().getEntry("icons/full/obj16/GenFigure.gif")));
  	entries.add(combined);		
    container.addAll(entries);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void createClassConnectionEntries(PaletteContainer container) {
    
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Map getTransitionClasses() {
    return Collections.EMPTY_MAP;
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EditPartFactory createEditPartFactory() {
  	return new GenModelEditPartFactory(createAdapterFactory(), modelResource);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void createReferenceConnectionEntries(PaletteContainer container) {
    List entries = new ArrayList();

    ConnectionCreationToolEntry tool = null;
    EClass eClass = null;

    tool = new ConnectionCreationToolEntry(
  		"GenGEFModel 2 GenModel",
  		"Creating GenModel connection",
  		new EReferenceLinkTemplateCreationFactory(GenModelPackage.eINSTANCE.getGenGEFModel_GenModel()),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")));
  	entries.add(tool);		
    tool = new ConnectionCreationToolEntry(
  		"GenEditor 2 GenEditPartFactory",
  		"Creating GenEditPartFactory connection",
  		new EReferenceLinkTemplateCreationFactory(GenModelPackage.eINSTANCE.getGenEditor_GenEditPartFactory()),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")));
  	entries.add(tool);    
    tool = new ConnectionCreationToolEntry(
  		"GenViewer 2 GenEditPartFactory",
  		"Creating GenEditPartFactory connection",
  		new EReferenceLinkTemplateCreationFactory(GenModelPackage.eINSTANCE.getGenViewer_GenEditPartFactory()),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")));
  	entries.add(tool);		
    tool = new ConnectionCreationToolEntry(
  		"GenEditPartFactory 2 GenEditPart",
  		"Creating GenEditParts connection",
  		new EReferenceLinkTemplateCreationFactory(GenModelPackage.eINSTANCE.getGenEditPartFactory_GenEditParts()),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")));
  	entries.add(tool);		
    tool = new ConnectionCreationToolEntry(
  		"GenEditPart 2 EClass",
  		"Creating EcoreClass connection",
  		new EReferenceLinkTemplateCreationFactory(GenModelPackage.eINSTANCE.getGenEditPart_EcoreClass()),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")));
  	entries.add(tool);		
    tool = new ConnectionCreationToolEntry(
  		"GenEditPart 2 EClass",
  		"Creating EcoreClass connection",
  		new EReferenceLinkTemplateCreationFactory(GenModelPackage.eINSTANCE.getGenEditPart_EcoreClass()),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")));
  	entries.add(tool);
    tool = new ConnectionCreationToolEntry(
  		"GenLinkEditPart 2 EReference",
  		"Creating SourceReference connection",
  		new EReferenceLinkTemplateCreationFactory(GenModelPackage.eINSTANCE.getGenLinkEditPart_SourceReference()),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")));
  	entries.add(tool);
    tool = new ConnectionCreationToolEntry(
  		"GenLinkEditPart 2 EReference",
  		"Creating TargetReference connection",
  		new EReferenceLinkTemplateCreationFactory(GenModelPackage.eINSTANCE.getGenLinkEditPart_TargetReference()),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")));
  	entries.add(tool);		
    tool = new ConnectionCreationToolEntry(
  		"GenPaletteComponentsFactory 2 GenNodeEditPart",
  		"Creating GenNodeParts connection",
  		new EReferenceLinkTemplateCreationFactory(GenModelPackage.eINSTANCE.getGenPaletteComponentsFactory_GenNodeParts()),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")));
  	entries.add(tool);
    tool = new ConnectionCreationToolEntry(
  		"GenPaletteConnectionsFactory 2 GenLinkEditPart",
  		"Creating GenLinkParts connection",
  		new EReferenceLinkTemplateCreationFactory(GenModelPackage.eINSTANCE.getGenPaletteConnectionsFactory_GenLinkParts()),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")),
  			ImageDescriptor.createFromURL(GefPlugin.getPlugin().getBundle().getEntry("icons/referenceLink.gif")));
  	entries.add(tool);
    container.addAll(entries);
  }  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void configureGraphicalViewer() {
    getGraphicalViewer().getControl().setBackground(ColorConstants.listBackground);
    getGraphicalViewer().setRootEditPart(new ScalableFreeformRootEditPart());
    getGraphicalViewer().setEditPartFactory(createEditPartFactory());
    getGraphicalViewer().setKeyHandler(new GraphicalViewerKeyHandler(getGraphicalViewer()).setParent(getCommonKeyHandler()));

    ContextMenuProvider provider 
      = new GEFEditorContextMenuProvider(getGraphicalViewer(), getActionRegistry());
    getGraphicalViewer().setContextMenu(provider);
    getSite().registerContextMenu("GenModelEditor.gef.editor.contextmenu", //$NON-NLS-1$
        provider, getGraphicalViewer());
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected AdapterFactory createAdapterFactory() {
    List factories = new ArrayList();
    factories.add(new ResourceItemProviderAdapterFactory());
    factories.add(new GefItemProviderAdapterFactory());
    factories.add(new ModelItemProviderAdapterFactory());
    factories.add(new GenModelItemProviderAdapterFactory());
    factories.add(new org.eclipse.emf.codegen.ecore.genmodel.provider.GenModelItemProviderAdapterFactory());
    factories.add(new ReflectiveItemProviderAdapterFactory());
    adapterFactory = new ComposedAdapterFactory(factories);
    return adapterFactory;
  }
}