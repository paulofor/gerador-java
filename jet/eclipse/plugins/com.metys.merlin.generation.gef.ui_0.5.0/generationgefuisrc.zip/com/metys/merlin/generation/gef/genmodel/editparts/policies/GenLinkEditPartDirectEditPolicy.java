/**
 * <copyright>
 * </copyright>
 *
 * $Id: GenLinkEditPartDirectEditPolicy.java,v 1.2 2005/07/10 23:39:39 jcheuoua Exp $
 */

package com.metys.merlin.generation.gef.genmodel.editparts.policies;

import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.geometry.Point;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.gef.commands.Command;
import org.eclipse.gef.requests.DirectEditRequest;
import org.eclipse.jface.viewers.TextCellEditor;

import com.metys.merlin.generation.gef.commands.RenameCommand;
import com.metys.merlin.generation.gef.figures.ENodeFigure;
import com.metys.merlin.generation.gef.figures.EObjectCellEditorLocator;
import com.metys.merlin.generation.gef.figures.EObjectDirectEditManager;
import com.metys.merlin.generation.gef.genmodel.GenModelPackage;
import com.metys.merlin.generation.gef.genmodel.editparts.GenLinkEditPartEditPart;
import com.metys.merlin.generation.gef.genmodel.impl.GenLinkEditPartImpl;
import com.metys.merlin.generation.gef.model.ENode;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class GenLinkEditPartDirectEditPolicy extends GenEditPartDirectEditPolicy{
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Command getDirectEditCommand(DirectEditRequest request) {
    String name = (String) request.getCellEditor().getValue();
    RenameCommand cmd = new RenameCommand((GenLinkEditPartEditPart)getHost(), name);		
    return cmd;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void showCurrentEditValue(DirectEditRequest request) {
    GenLinkEditPartEditPart hostEditPart = (GenLinkEditPartEditPart) getHost();
    hostEditPart.refreshVisuals();
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected boolean isDirectEditLocation(Point requestLoc) {
    Point locationCopy = requestLoc.getCopy();
    GenLinkEditPartEditPart hostEditPart = (GenLinkEditPartEditPart) getHost();
    IFigure header = ((ENodeFigure) hostEditPart.getFigure()).getHeader();
    header.translateToRelative(locationCopy);
    if (header.containsPoint(locationCopy))
      return true;
    return false;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void performDirectEdit() {
  GenLinkEditPartEditPart hostEditPart = (GenLinkEditPartEditPart) getHost();
    Label header = ((ENodeFigure) hostEditPart.getFigure()).getHeader();
    if (manager == null)
      manager = new EObjectDirectEditManager(hostEditPart, TextCellEditor.class, new EObjectCellEditorLocator(header), header);    
    manager.show();
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void handleNodeNameChanged(ENode node, String newName, String oldName) {
    GenLinkEditPartImpl object = (GenLinkEditPartImpl) node.getEObject();
    EStructuralFeature labelFeature = 
      GenModelPackage.eINSTANCE.getGenGEFBase_Name(); 
    object.eSet(labelFeature, newName);		
  }
}