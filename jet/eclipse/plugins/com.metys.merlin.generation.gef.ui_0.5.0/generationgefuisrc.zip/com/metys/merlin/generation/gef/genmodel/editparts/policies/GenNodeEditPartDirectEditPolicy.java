/**
 * <copyright>
 * </copyright>
 *
 * $Id: GenNodeEditPartDirectEditPolicy.java,v 1.2 2005/07/10 23:39:38 jcheuoua Exp $
 */

package com.metys.merlin.generation.gef.genmodel.editparts.policies;

import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.geometry.Point;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.gef.commands.Command;
import org.eclipse.gef.requests.DirectEditRequest;
import org.eclipse.jface.viewers.TextCellEditor;

import com.metys.merlin.generation.gef.commands.RenameCommand;
import com.metys.merlin.generation.gef.figures.ENodeFigure;
import com.metys.merlin.generation.gef.figures.EObjectCellEditorLocator;
import com.metys.merlin.generation.gef.figures.EObjectDirectEditManager;
import com.metys.merlin.generation.gef.genmodel.GenModelPackage;
import com.metys.merlin.generation.gef.genmodel.editparts.GenNodeEditPartEditPart;
import com.metys.merlin.generation.gef.genmodel.impl.GenNodeEditPartImpl;
import com.metys.merlin.generation.gef.model.ENode;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class GenNodeEditPartDirectEditPolicy extends GenEditPartDirectEditPolicy{
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Command getDirectEditCommand(DirectEditRequest request) {
    String name = (String) request.getCellEditor().getValue();
    RenameCommand cmd = new RenameCommand((GenNodeEditPartEditPart)getHost(), name);		
    return cmd;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void showCurrentEditValue(DirectEditRequest request) {
    GenNodeEditPartEditPart hostEditPart = (GenNodeEditPartEditPart) getHost();
    hostEditPart.refreshVisuals();
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected boolean isDirectEditLocation(Point requestLoc) {
    Point locationCopy = requestLoc.getCopy();
    GenNodeEditPartEditPart hostEditPart = (GenNodeEditPartEditPart) getHost();
    IFigure header = ((ENodeFigure) hostEditPart.getFigure()).getHeader();
    header.translateToRelative(locationCopy);
    if (header.containsPoint(locationCopy))
      return true;
    return false;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void performDirectEdit() {
  GenNodeEditPartEditPart hostEditPart = (GenNodeEditPartEditPart) getHost();
    Label header = ((ENodeFigure) hostEditPart.getFigure()).getHeader();
    if (manager == null)
      manager = new EObjectDirectEditManager(hostEditPart, TextCellEditor.class, new EObjectCellEditorLocator(header), header);    
    manager.show();
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void handleNodeNameChanged(ENode node, String newName, String oldName) {
    GenNodeEditPartImpl object = (GenNodeEditPartImpl) node.getEObject();
    EStructuralFeature labelFeature = 
      GenModelPackage.eINSTANCE.getGenGEFBase_Name(); 
    object.eSet(labelFeature, newName);		
  }
}