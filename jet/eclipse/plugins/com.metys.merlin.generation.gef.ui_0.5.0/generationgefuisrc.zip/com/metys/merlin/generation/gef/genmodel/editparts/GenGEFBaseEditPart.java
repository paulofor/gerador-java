/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */

package com.metys.merlin.generation.gef.genmodel.editparts;

import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.PositionConstants;
import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.draw2d.geometry.Point;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.gef.GraphicalEditPart;

import com.metys.merlin.generation.gef.figures.ENodeFigure;
import com.metys.merlin.generation.gef.genmodel.impl.GenGEFBaseImpl;
import com.metys.merlin.generation.gef.model.ENode;
import com.metys.merlin.generation.gef.parts.ENodeEditPart;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class GenGEFBaseEditPart extends ENodeEditPart{
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenGEFBaseEditPart(ENode model, AdapterFactory adapterFactory) {
    super(model, adapterFactory);
  }
  
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenGEFBaseImpl getGenGEFBase() {
    return (GenGEFBaseImpl)getENode().getEObject();
  }
  
  /**
   * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#createFigure()
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated   
   */
  protected IFigure createFigure() {
    Label l = new Label(getImage());
    l.setLabelAlignment(PositionConstants.CENTER);
    return new ENodeFigure(l);
  }

  /**
   * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#getContentPane()
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated   
   */
  public IFigure getContentPane() {
    return ((ENodeFigure) getFigure()).getContentPane();
  }

  /**
   * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#refreshVisuals()
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void refreshVisuals() {
    String name = getENode().getName();
    if (name == null || name.trim().length() == 0)
      name = getLabelProvider().getText(getENode().getEObject());
    Label l = (Label) ((ENodeFigure) getFigure()).getHeader();
    l.setText(name);

    Point loc = getENode().getLocation();
    Dimension size = new Dimension((int) getENode().getWidth(), (int) getENode().getHeight());
    Rectangle r = new Rectangle(loc, size);

  if (getParent() instanceof GraphicalEditPart)
    	((GraphicalEditPart) getParent()).setLayoutConstraint(this, getFigure(), r);
  }


}