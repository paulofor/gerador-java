/**
 * <copyright>
 * </copyright>
 *
 * $Id: GenSubNodeReferenceComponentEditPolicy.java,v 1.2 2005/07/10 23:39:38 jcheuoua Exp $
 */

package com.metys.merlin.generation.gef.genmodel.editparts.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gef.requests.GroupRequest;

import com.metys.merlin.generation.gef.commands.DeleteNodeCommand;
import com.metys.merlin.generation.gef.genmodel.editparts.GenSubNodeReferenceEditPart;
import com.metys.merlin.generation.gef.parts.GraphicalComponentEditPart;
import com.metys.merlin.generation.gef.policies.ENodeComponentEditPolicy;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class GenSubNodeReferenceComponentEditPolicy extends ENodeComponentEditPolicy{
    
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Command createDeleteCommand(GroupRequest deleteRequest) {
    Command deleteCmd = new DeleteNodeCommand((GraphicalComponentEditPart) getHost().getParent(), (GenSubNodeReferenceEditPart) getHost());
    return deleteCmd;
  }
}