/**
 * <copyright>
 * </copyright>
 *
 * $Id: GenEditPartComponentEditPolicy.java,v 1.2 2005/07/10 23:39:38 jcheuoua Exp $
 */

package com.metys.merlin.generation.gef.genmodel.editparts.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gef.requests.GroupRequest;

import com.metys.merlin.generation.gef.commands.DeleteNodeCommand;
import com.metys.merlin.generation.gef.genmodel.editparts.GenEditPartEditPart;
import com.metys.merlin.generation.gef.parts.GraphicalComponentEditPart;

/**
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class GenEditPartComponentEditPolicy extends GenGEFBaseComponentEditPolicy{
    
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Command createDeleteCommand(GroupRequest deleteRequest) {
    Command deleteCmd = new DeleteNodeCommand((GraphicalComponentEditPart) getHost().getParent(), (GenEditPartEditPart) getHost());
    return deleteCmd;
  }
}