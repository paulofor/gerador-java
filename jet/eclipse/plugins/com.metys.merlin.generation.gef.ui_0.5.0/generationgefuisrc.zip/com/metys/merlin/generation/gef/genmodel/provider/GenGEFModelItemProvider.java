/**
 * Copyright (c) 2005 Jo�l Cheuoua & Contributors
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Merlin project nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
package com.metys.merlin.generation.gef.genmodel.provider;


import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.util.ResourceLocator;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ViewerNotification;

import com.metys.merlin.generation.gef.genmodel.GenGEFModel;
import com.metys.merlin.generation.gef.genmodel.GenModelFactory;
import com.metys.merlin.generation.gef.genmodel.GenModelPackage;
import com.metys.merlin.generation.gef.ui.GefUIPlugin;

/**
 * This is the item provider adapter for a {@link com.metys.merlin.generation.gef.genmodel.GenGEFModel} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class GenGEFModelItemProvider
  extends GenGEFBaseItemProvider
  implements
    IEditingDomainItemProvider,
    IStructuredItemContentProvider,
    ITreeItemContentProvider,
    IItemLabelProvider,
    IItemPropertySource {
  /**
   * This constructs an instance from a factory and a notifier.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public GenGEFModelItemProvider(AdapterFactory adapterFactory) {
    super(adapterFactory);
  }

  /**
   * This returns the property descriptors for the adapted class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public List getPropertyDescriptors(Object object) {
    if (itemPropertyDescriptors == null) {
      super.getPropertyDescriptors(object);

      addOutputDirectoryPathPropertyDescriptor(object);
      addCopyrightTextPropertyDescriptor(object);
      addPluginIDPropertyDescriptor(object);
      addPluginClassPropertyDescriptor(object);
      addGenModelPropertyDescriptor(object);
      addTemplateDirectoryPropertyDescriptor(object);
    }
    return itemPropertyDescriptors;
  }

  /**
   * This adds a property descriptor for the Output Directory Path feature.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void addOutputDirectoryPathPropertyDescriptor(Object object) {
    itemPropertyDescriptors.add
      (createItemPropertyDescriptor
        (((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
         getResourceLocator(),
         getString("_UI_GenGEFModel_outputDirectoryPath_feature"),
         getString("_UI_PropertyDescriptor_description", "_UI_GenGEFModel_outputDirectoryPath_feature", "_UI_GenGEFModel_type"),
         GenModelPackage.eINSTANCE.getGenGEFModel_OutputDirectoryPath(),
         true,
         ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
         null,
         null));
  }

  /**
   * This adds a property descriptor for the Copyright Text feature.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void addCopyrightTextPropertyDescriptor(Object object) {
    itemPropertyDescriptors.add
      (createItemPropertyDescriptor
        (((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
         getResourceLocator(),
         getString("_UI_GenGEFModel_copyrightText_feature"),
         getString("_UI_PropertyDescriptor_description", "_UI_GenGEFModel_copyrightText_feature", "_UI_GenGEFModel_type"),
         GenModelPackage.eINSTANCE.getGenGEFModel_CopyrightText(),
         true,
         ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
         null,
         null));
  }

  /**
   * This adds a property descriptor for the Plugin ID feature.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void addPluginIDPropertyDescriptor(Object object) {
    itemPropertyDescriptors.add
      (createItemPropertyDescriptor
        (((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
         getResourceLocator(),
         getString("_UI_GenGEFModel_pluginID_feature"),
         getString("_UI_PropertyDescriptor_description", "_UI_GenGEFModel_pluginID_feature", "_UI_GenGEFModel_type"),
         GenModelPackage.eINSTANCE.getGenGEFModel_PluginID(),
         true,
         ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
         null,
         null));
  }

  /**
   * This adds a property descriptor for the Plugin Class feature.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void addPluginClassPropertyDescriptor(Object object) {
    itemPropertyDescriptors.add
      (createItemPropertyDescriptor
        (((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
         getResourceLocator(),
         getString("_UI_GenGEFModel_pluginClass_feature"),
         getString("_UI_PropertyDescriptor_description", "_UI_GenGEFModel_pluginClass_feature", "_UI_GenGEFModel_type"),
         GenModelPackage.eINSTANCE.getGenGEFModel_PluginClass(),
         true,
         ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
         null,
         null));
  }

  /**
   * This adds a property descriptor for the Gen Model feature.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void addGenModelPropertyDescriptor(Object object) {
    itemPropertyDescriptors.add
      (createItemPropertyDescriptor
        (((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
         getResourceLocator(),
         getString("_UI_GenGEFModel_genModel_feature"),
         getString("_UI_PropertyDescriptor_description", "_UI_GenGEFModel_genModel_feature", "_UI_GenGEFModel_type"),
         GenModelPackage.eINSTANCE.getGenGEFModel_GenModel(),
         true,
         null,
         null,
         null));
  }

  /**
   * This adds a property descriptor for the Template Directory feature.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void addTemplateDirectoryPropertyDescriptor(Object object) {
    itemPropertyDescriptors.add
      (createItemPropertyDescriptor
        (((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
         getResourceLocator(),
         getString("_UI_GenGEFModel_templateDirectory_feature"),
         getString("_UI_PropertyDescriptor_description", "_UI_GenGEFModel_templateDirectory_feature", "_UI_GenGEFModel_type"),
         GenModelPackage.eINSTANCE.getGenGEFModel_TemplateDirectory(),
         true,
         ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
         null,
         null));
  }

  /**
   * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
   * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
   * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Collection getChildrenFeatures(Object object) {
    if (childrenFeatures == null) {
      super.getChildrenFeatures(object);
      childrenFeatures.add(GenModelPackage.eINSTANCE.getGenGEFModel_GenEditPartFactories());
      childrenFeatures.add(GenModelPackage.eINSTANCE.getGenGEFModel_GenEditors());
      childrenFeatures.add(GenModelPackage.eINSTANCE.getGenGEFModel_GenViewers());
      childrenFeatures.add(GenModelPackage.eINSTANCE.getGenGEFModel_GenEditParts());
    }
    return childrenFeatures;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EStructuralFeature getChildFeature(Object object, Object child) {
    // Check the type of the specified child object and return the proper feature to use for
    // adding (see {@link AddCommand}) it as a child.

    return super.getChildFeature(object, child);
  }

  /**
   * This returns GenGEFModel.gif.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object getImage(Object object) {
    return getResourceLocator().getImage("full/obj16/GenGEFModel");
  }

  /**
   * This returns the label text for the adapted class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated NOT
   */
  public String getText(Object object) {
    String label = ((GenGEFModel)object).getName();
    return label == null || label.length() == 0 ?
      getString("_UI_GenGEFModel_type") :
      label + " : " + getString("_UI_GenGEFModel_type");
  }

  /**
   * This handles model notifications by calling {@link #updateChildren} to update any cached
   * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void notifyChanged(Notification notification) {
    updateChildren(notification);

    switch (notification.getFeatureID(GenGEFModel.class)) {
      case GenModelPackage.GEN_GEF_MODEL__OUTPUT_DIRECTORY_PATH:
      case GenModelPackage.GEN_GEF_MODEL__COPYRIGHT_TEXT:
      case GenModelPackage.GEN_GEF_MODEL__PLUGIN_ID:
      case GenModelPackage.GEN_GEF_MODEL__PLUGIN_CLASS:
      case GenModelPackage.GEN_GEF_MODEL__TEMPLATE_DIRECTORY:
        fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
        return;
      case GenModelPackage.GEN_GEF_MODEL__GEN_EDIT_PART_FACTORIES:
      case GenModelPackage.GEN_GEF_MODEL__GEN_EDITORS:
      case GenModelPackage.GEN_GEF_MODEL__GEN_VIEWERS:
      case GenModelPackage.GEN_GEF_MODEL__GEN_EDIT_PARTS:
        fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
        return;
    }
    super.notifyChanged(notification);
  }

  /**
   * This adds to the collection of {@link org.eclipse.emf.edit.command.CommandParameter}s
   * describing all of the children that can be created under this object.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void collectNewChildDescriptors(Collection newChildDescriptors, Object object) {
    super.collectNewChildDescriptors(newChildDescriptors, object);

    newChildDescriptors.add
      (createChildParameter
        (GenModelPackage.eINSTANCE.getGenGEFModel_GenEditPartFactories(),
         GenModelFactory.eINSTANCE.createGenEditPartFactory()));

    newChildDescriptors.add
      (createChildParameter
        (GenModelPackage.eINSTANCE.getGenGEFModel_GenEditors(),
         GenModelFactory.eINSTANCE.createGenEditor()));

    newChildDescriptors.add
      (createChildParameter
        (GenModelPackage.eINSTANCE.getGenGEFModel_GenViewers(),
         GenModelFactory.eINSTANCE.createGenViewer()));

    newChildDescriptors.add
      (createChildParameter
        (GenModelPackage.eINSTANCE.getGenGEFModel_GenEditParts(),
         GenModelFactory.eINSTANCE.createGenNodeEditPart()));

    newChildDescriptors.add
      (createChildParameter
        (GenModelPackage.eINSTANCE.getGenGEFModel_GenEditParts(),
         GenModelFactory.eINSTANCE.createGenLinkEditPart()));
  }

  /**
   * Return the resource locator for this item provider's resources.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ResourceLocator getResourceLocator() {
    return GefUIPlugin.INSTANCE;
  }

}
